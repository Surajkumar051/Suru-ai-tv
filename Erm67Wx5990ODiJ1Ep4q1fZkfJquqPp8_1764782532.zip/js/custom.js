$(document).ready(function() {

    $('.owl-banner').owlCarousel({
        loop: true,
        margin: 1,
        responsiveClass: true,
        nav: false,
        dots: true,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,

            },
            1000: {
                items: 1,
                loop: false
            }
        }
    })
    setTimeout(() => {
        $('.owl-product').owlCarousel({
            loop: true,
            margin: 10,
            responsiveClass: true,
            nav: true,
            dots: false,
            responsive: {
                0: {
                    items: 2,
                },
                600: {
                    items: 3,

                },
                1000: {
                    items: 4,
                    loop: false
                },
                1200: {
                    items: 6,
                    loop: false
                }
            }
        })
    }, 3000);

    setTimeout(() => {
        $('.owl-cast').owlCarousel({
            loop: true,
            margin: 10,
            responsiveClass: true,
            nav: true,
            dots: false,
            responsive: {
                0: {
                    items: 2,
                },
                600: {
                    items: 4,

                },
                1000: {
                    items: 6,
                    loop: false
                },
                1200: {
                    items: 9,
                    loop: false
                }
            }
        })
    }, 3000);


    // setTimeout(() => {
    //     $('.owl-blog').owlCarousel({
    //         loop: true,
    //         margin: 15,
    //         responsiveClass: true,
    //         nav: true,
    //         dots: false,
    //         responsive: {
    //             0: {
    //                 items: 1,
    //                 nav: false,
    //             },
    //             600: {
    //                 items: 2,
    //                 nav: false,

    //             },
    //             1000: {
    //                 items: 3,
    //                 loop: false
    //             }
    //         }
    //     });
    // }, 3000);




    $('.owl-checkout').owlCarousel({
        loop: false,
        margin: 1,
        responsiveClass: true,
        nav: false,
        dots: true,
        URLhashListener: true,
        autoplayHoverPause: true,
        startPosition: 'URLHash',
        mouseDrag: false,
        responsive: {
            0: {
                items: 1
            },
            580: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            },
            1200: {
                items: 1
            }
        }
    });
    //Navigation Dropdown show and Hide
    $(".add-content").click(function() {
        $(".content-propertices").addClass("cp-open");
    })
    $(".cp-close").click(function() {
        $(".content-propertices").removeClass("cp-open");
    })

    $(".player-list li").click(function() {
        var data = $(this).attr("v-src");
        $("#video-players-streem").attr("src", data);
    });

    $('[data-toggle="tooltip"]').tooltip()
});
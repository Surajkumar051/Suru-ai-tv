JsLoadingOverlay.setOptions({
    'overlayBackgroundColor': '#666666',
    'overlayOpacity': 0.8,
    'spinnerIcon': "ball-pulse-sync",
    'spinnerColor': '#23b9f2',
    'spinnerSize': '1x',
    'overlayIDName': 'overlay',
    'spinnerIDName': 'spinner',
    'offsetY': 0,
    'offsetX': 0,
    'lockScroll': false,
    'containerID': null
});
export const owlCarousal = () => {
    $('.owl-banner').trigger('destroy.owl.carousel');
    $('.owl-product').trigger('destroy.owl.carousel');
    $('.owl-cast').trigger('destroy.owl.carousel');
    // $('.owl-blog').trigger('destroy.owl.carousel');
    // $('.owl-newreleases').trigger('destroy.owl.carousel');
    $('.owl-banner').owlCarousel({
            loop: true,
            margin: 1,
            responsiveClass: true,
            nav: false,
            dots: true,
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 1,

                },
                1000: {
                    items: 1,
                    loop: false
                }
            }
        })
        //    setTimeout(() => {
    $('.owl-product').owlCarousel({
        loop: true,
        margin: 15,
        responsiveClass: true,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 2,
            },
            600: {
                items: 3,

            },
            1000: {
                items: 4,
                loop: false
            }

        }
    });
    $('.owl-cast').owlCarousel({
        loop: true,
        margin: 15,
        responsiveClass: true,
        nav: true,
        dots: false,
        responsive: {
            0: {
                items: 2,
            },
            600: {
                items: 3,

            },
            1000: {
                items: 9,
                loop: false
            }

        }
    });

    //    }, 2000);


    // $('.owl-product').owlCarousel({
    //     loop:true,
    //     margin:15,
    //     responsiveClass:true,
    //     nav:true,
    //     dots:false,
    //     responsive:{
    //         0:{
    //             items:2,                
    //         },
    //         600:{
    //             items:3,

    //         },
    //         1000:{
    //             items:4,               
    //             loop:false
    //         }

    //     }
    // })
    // setTimeout(() => {
    //     $('.owl-blog').owlCarousel({
    //         loop: true,
    //         margin: 15,
    //         responsiveClass: true,
    //         nav: true,
    //         dots: false,
    //         responsive: {
    //             0: {
    //                 items: 1,
    //             },
    //             600: {
    //                 items: 2,

    //             },
    //             1000: {
    //                 items: 3,
    //                 loop: false
    //             }
    //         }
    //     })


    // }, 2000);




}
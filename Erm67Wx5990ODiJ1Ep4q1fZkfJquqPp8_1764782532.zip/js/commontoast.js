export const Toast = Swal.mixin({
    background: '#0c0812',
    color: '#ffffff',
    toast: true,
    position: 'bottom-start',
    timer: 3000,
    allowOutsideClick: false,
    showConfirmButton: false,
})
export const Alert = Swal.mixin({
    background: '#0c0812',
    color: '#ffffff',
    showConfirmButton: false,
    timer: 3000,
    allowOutsideClick: false
})
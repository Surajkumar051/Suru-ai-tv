<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script id="head_script">
        //@ER: 74207 Show window alert when page reload during audio playing
        //var isAudioPlaying = (isAudioPlaying) ? 1 : '';
        window.onbeforeunload = function() {
            if (window.isAudioPlaying) {
                return 'Are you sure you want to leave?';
            }
        }
        var scrollLoad = false; //@ER: 74207
        var rootUrl = "<?php echo $rootUrl; ?>"
        var asseturl = "<?php echo $asseturl; ?>"
        var api_gateway = "<?php echo $api_gateway; ?>"
        var asthu_domain_url = "<?php echo $asthu_domain_url; ?>"
        var chat_url = "<?php echo $chat_url; ?>"; //@ER: 89341 (chat in player)
        var ip = "<?php echo $IP; ?>"
        var vd_url = "<?php echo $vd_url; ?>"
        var asset_cdn_url = "<?php echo $asset_cdn_url; ?>"
        var isAudioExists = "<?php echo $isAudioExists; ?>"; //@ER: 74207 - Audio exist in store or not.
        var slug = "<?php echo get_slug(); ?>";
        var cacheVersion = "<?php echo $cacheVersion; ?>";
        var assetCacheVersion = "<?php echo $assetCacheVersion; ?>";
        window.tanslationJson = <?php echo $translation; ?>;
        var language_list = <?php echo $language; ?>;
        var primary_language = "<?php echo $primary_language; ?>";
        <?php foreach ($pagedata as $page_key => $page_value) { ?>
            var page_<?php echo $page_key; ?> = "<?php echo $page_value; ?>"
        <?php  } ?>
        <?php foreach ($params as $param_key => $param_value) { ?>
            var <?php echo $param_key; ?> = "<?php echo $param_value; ?>"
        <?php  } ?>
        localStorage.setItem('access_token', "<?php echo @$access_token; ?>");
        localStorage.setItem('reload_token', "<?php echo @$refresh_token; ?>");
        localStorage.setItem('locationHref', window.location.href);
        //scroll to top
        window.scrollTo(0, 0);
    </script>

    <script>
        // <!-- scripts added in the vd application -->
        <?php echo @$script; ?>
    </script>
    <?php echo @$includeScript; ?>
    <style id="vdjs-styles">
        <?php echo @$vd_style; ?>
    </style>
    <link rel="preload" href="<?php echo $rootUrl; ?>css/local.css?v=<?php echo $cacheVersion; ?>" as="style"
        onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="'stylesheet'" href="<?php echo $rootUrl; ?>css/local.css?v=<?php echo $cacheVersion; ?>">
    </noscript>
    <script src="<?php echo $rootUrl; ?>js/local.js?v=<?php echo $cacheVersion; ?>"></script>


</head>

<body id='layout_body' class="page-bg-<?php $slug = get_slug();
                                        echo $slug ? $slug : 'home' ?>">

    <?php echo @$header; ?>
    <section class='p-0 body-container vd-<?php $slug = get_slug();
                                            echo $slug ? $slug : 'home' ?>' id="ajaxApp">
        <?php echo @$container; ?>
        <?php echo @$siteCookie; ?>
    </section>
    <?php echo @$footer; ?>
    <div id="audio-player"></div>
    <!-- ER 83830-->
    <div id="player_poll" class="audiopoll"></div>
    <div class="tag-wrapper" id="audiotag-wrapper" style="display:none !important">
        <div class="audiocontent" id="tagContainer">
            <div id="container"></div>
        </div>
        <span id="countdownUi" title="Ad Countdown"></span>
        <button id="audioplaypause" title="Play/Pause"></button>
        <button class="mute-audio" id="muteunmute" title="Mute/Unmute"></button>
    </div>


</body>
<script src="<?php echo $rootUrl; ?>layout.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

</html>
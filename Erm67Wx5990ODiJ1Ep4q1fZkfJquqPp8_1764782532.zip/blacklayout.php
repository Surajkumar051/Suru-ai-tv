<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        var rootUrl = "<?php echo $rootUrl; ?>"
        var asseturl = "<?php echo $asseturl; ?>"
        var api_gateway = "<?php echo $api_gateway; ?>"
        var asthu_domain_url = "<?php echo $asthu_domain_url; ?>"
        var ip = "<?php echo $IP; ?>"
        var vd_url = "<?php echo $vd_url; ?>"
        var asset_cdn_url = "<?php echo $asset_cdn_url; ?>"
        var slug = "<?php echo get_slug(); ?>";
        var cacheVersion = "<?php echo $cacheVersion; ?>";
        var assetCacheVersion = "<?php echo $assetCacheVersion; ?>";
        window.tanslationJson=<?php echo $translation; ?>;
        var language_list =<?php echo $language; ?>;
        var primary_language="<?php echo $primary_language; ?>";
        <?php foreach($pagedata as $page_key=>$page_value){ ?>
            var page_<?php echo $page_key; ?>="<?php echo $page_value; ?>"
        <?php  } ?>
        <?php foreach($params as $param_key=>$param_value){ ?>
        var <?php echo $param_key; ?>="<?php echo $param_value; ?>"
        <?php  } ?>
        localStorage.setItem('access_token', "<?php echo @$access_token; ?>");
        localStorage.setItem('reload_token', "<?php echo @$refresh_token; ?>");
        localStorage.setItem('locationHref', window.location.href);
				    //scroll to top
						window.scrollTo(0,0);
        // <!-- scripts added in the vd application -->
        <?php echo @$script; ?>
    </script>
    <?php echo @$includeScript; ?>
    <style id="vdjs-styles">
        <?php echo @$vd_style; ?>
    </style>
    <link rel="preload" href="<?php echo $rootUrl; ?>css/local.css?v=<?php echo $cacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="'stylesheet'" href="<?php echo $rootUrl; ?>css/local.css?v=<?php echo $cacheVersion; ?>">
    </noscript>
    <script src="<?php echo $rootUrl; ?>js/local.js?v=<?php echo $cacheVersion; ?>"></script>        

</head>

<body class="checkout-body page-bg-<?php $slug = get_slug(); echo $slug ? $slug : 'home' ?>" id='layout_body'>
    <?php echo @$header; ?>

    <section class='container-fluid body-container vd-<?php $slug = get_slug();
                                                        echo $slug ? $slug : 'home' ?>'>
        <?php echo @$container; ?>
    </section>
    <?php echo @$footer; ?>
    <div id="audio-player"></div>

</body>
<script src="<?php echo $rootUrl; ?>layout.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

</html>

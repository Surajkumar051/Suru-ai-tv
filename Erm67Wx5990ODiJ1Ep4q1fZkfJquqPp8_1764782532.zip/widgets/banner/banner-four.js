let { getRootUrl,
	getSlug } = await import(window.importAssetJs('js/web-service-url.js'));
let { getVdConfig } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
export default {
	name: "banner_four",
	data() {
		return {
			allBanner: [],
			bannerReturned: false,
            bannerWidth:null,
            bannerHeight:null
		};
	},
	mounted() {
        getVdConfig(this.$attrs["id"], getSlug()).then((res) => {
			this.bannerReturned = true;
			if (res.data.code == 200 && res.data.data.data !== null) {
				this.allBanner = res.data.data.data;
				// this.carouselSettings = res.data.data.settings;
				window.carouselSettings = res.data.data.settings;
                this.bannerWidth=res.data.data.bannerWidth;
                this.bannerHeight=res.data.data.bannerHeight;
				this.allBanner.forEach(item => {
					try {

                        let lbl2 = decodeURIComponent(escape(window.atob(item.bannerData.label2)));//window.atob(item.bannerData.label2);
						if ($(lbl2).length) {
							if ($(lbl2)[0].nodeName.toLowerCase() == 'a') {
								item.bannerData.label2 = lbl2;
							} else {
								item.bannerData.label2 = `<a vd-readonly="true" vd-node="button" href="javascript:void(0);">${item.bannerData.label2}</a>`;
							}
						} else {
							item.bannerData.label2 = `<a vd-readonly="true" vd-node="button" href="javascript:void(0);">${item.bannerData.label2}</a>`;
						}
					} catch (error) {
						item.bannerData.label2 = `<a vd-readonly="true" vd-node="button" href="javascript:void(0);">${item.bannerData.label2}</a>`;
					}
				});
			}
		});
	},
	updated() {
		owlCarousal();
		setTimeout(() => {
			if (!this.allBanner.length && $('.dynamic-banner-btn a').attr('link-type') == undefined) $('.dynamic-banner-btn a').attr('href', `https://${rootUrl.split('/')[2]}/about-us`);
			const owl = $('.owl-banner.owl-carousel');
			const bannerVideoItems = $('.owl-banner .owl-stage video');
			owl.on('changed.owl.carousel', function (e) {
				const index = e.page.index;
                // const element = e.relatedTarget._items[index];
				if (bannerVideoItems.length && index != -1) {
					bannerVideoItems.each(function () {
						$(this)[0].muted = true;
						$(this)[0].pause();
						$(this)[0].currentTime = 0;
						$('.vol-off').show();
						$('.vol-on').hide();
						$('.vol-on, .vol-off').off('click');
					});
				}
                const element = $($('.owl-banner .owl-stage .owl-item')[e.item.index]);
                if (element != undefined && index != -1) {
					if (element.find('.item').attr('type') == 'video') {
						const volOn = element.find('.vol-on');
						const volOff = element.find('.vol-off');
						const vid = element.find('video');
						element.find('video').css('transition', '');
                        //element.find('video').css('opacity', 0);
                        element.find('video')[0].muted = true;
						element.find('video')[0].pause();
						element.find('video')[0].currentTime = 0;
						setTimeout(function () {
                            console.log('Carousel Change Play');
							element.find('video').css('transition', 'opacity 2s ease 0s');
							element.find('video')[0].play();
							element.find('video').css('opacity', 1.0);
							volOff.on('click', function (event) {
								event.stopPropagation();
								vid[0].muted = false;
								volOff.hide();
								volOn.show();
							});
							volOn.on('click', function (event) {
								event.stopPropagation();
								vid[0].muted = true;
								volOn.hide();
								volOff.show();
							});
						}, 1000);
					}
					return;
				}
			});
			const bannerItems = $('.owl-banner .owl-stage').children();
			if (bannerItems.length > 0) {
				bannerItems.each(function () {
					if (window.location.host.indexOf('vd-editor') != -1 || window.location.host.indexOf('vd-dev') != -1 || window.location.host.indexOf('vd-staging') != -1) return;
					if ($(this).find('.item').attr('type') == 'video' && !$(this).hasClass('cloned')) {
						const vid = $(this).find('video');
						if ($(this).find('.item').parent().hasClass('active')) {
							console.log('Trigger Play');
							// $(this).find('video')[0].pause();
							$(this).find('video')[0].currentTime = 0;
							$(this).find('video')[0].muted = true;
							$(this).find('video')[0].play();
							$(this).find('video').css('opacity', 1.0);
						}
						const volOn = $(this).find('.vol-on');
						const volOff = $(this).find('.vol-off');
						volOff.on('click', function (event) {
							event.stopPropagation();
							vid[0].muted = false;
							volOff.hide();
							volOn.show();
						});
						volOn.on('click', function (event) {
							event.stopPropagation();
							vid[0].muted = true;
							volOn.hide();
							volOff.show();
						});
					}
					if ($(this).find('[vd-node="banner"]').attr('link-type') == undefined || $(this).find('[vd-node="banner"]').attr('link-type') == '') {
						return;
					} else {
						$(this).find('[vd-node="button"]').on('click', function (event) {
							event.stopPropagation();
						});
						$(this).mouseenter(function () {
							$(this).css('cursor', 'pointer');
						}).mouseleave(function () {
							$(this).css('cursor', 'auto');
						});
						if ($(this).find('[vd-node="banner"]').attr('link-type') == 'page') {
							$(this).on('click', function () {
								if ($(this).find('[vd-node="banner"]').attr('link-mode') == '' || $(this).find('[vd-node="banner"]').attr('link-mode') == undefined) {
									location.href = `${window.location.origin}/${$(this).find('[vd-node="banner"]').attr('link-src')}`;
								} else {
									window.open(`${window.location.origin}/${$(this).find('[vd-node="banner"]').attr('link-src')}`, '_blank');
								}
							});
						}
						if ($(this).find('[vd-node="banner"]').attr('link-type') == 'category') {
							$(this).on('click', function () {
								if ($(this).find('[vd-node="banner"]').attr('link-mode') == '' || $(this).find('[vd-node="banner"]').attr('link-mode') == undefined) {
									location.href = `${window.location.origin}/category/${$(this).find('[vd-node="banner"]').attr('link-src')}`;
								} else {
									window.open(`${window.location.origin}/category/${$(this).find('[vd-node="banner"]').attr('link-src')}`, '_blank');
								}
							});
						}
						if ($(this).find('[vd-node="banner"]').attr('link-type') == 'content') {
							$(this).on('click', function () {
								if ($(this).find('[vd-node="banner"]').attr('link-mode') == '' || $(this).find('[vd-node="banner"]').attr('link-mode') == undefined) {
									location.href = `${window.location.origin}/content/${$(this).find('[vd-node="banner"]').attr('link-src')}`;
								} else {
									window.open(`${window.location.origin}/content/${$(this).find('[vd-node="banner"]').attr('link-src')}`, '_blank');
								}
							});
						}
						if ($(this).find('[vd-node="banner"]').attr('link-type') == 'web') {
							$(this).on('click', function () {
								if ($(this).find('[vd-node="banner"]').attr('link-mode') == '' || $(this).find('[vd-node="banner"]').attr('link-mode') == undefined) {
									location.href = $(this).find('[vd-node="banner"]').attr('link-src');
								} else {
									window.open($(this).find('[vd-node="banner"]').attr('link-src'), '_blank');
								}
							});
						}
					}
				});
			}
		}, 1000);
	},
	methods: {
		getRootUrl,
		i18n,
         //Generate SRCSET for Images
        generateSrcset(baseUrl) {
            const widths = [720, 1080, 1290, 1440, 2160,2880,3840];
            return widths
                .map(w => `${baseUrl}?w=${w} ${w}w`)
                .join(', ');
            }
	},
	template: `
    <vd-component class="vd banner-four" type="banner-four">
        <section class="banner-section banner-section-navarrow">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0 m-0">
                        <div class="banner-content subcription-banner">
                            <div v-if="bannerReturned" class="owl-banner owl-carousel owl-theme">
                                <template v-if="allBanner != null && allBanner.length > 0"
                                    v-for="(banner,index) in allBanner">

                                    <!-- Color Banner -->

                                    <div v-if="banner.type == 'color'" class="item bannerType-color" 
                                         :style="{backgroundColor: banner.image_src,width: bannerWidth + 'px',height: bannerHeight + 'px'}"
                                         vd-readonly="true"
                                        :image-src="banner.image_src" :image-alt="banner.image" vd-node="banner"
                                        :id="'banner-'+ banner.id" :type="banner.type" :link-type="banner.linkType"
                                        :link-src="banner.linkSrc" :link-mode="banner.linkMode" :content-uuid="banner.linkContent_uuid">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 banner-text-left">
                                            <div class="banner-data" v-if="banner.bannerData != null">
                                                <h1 :text-display="banner.textDisplay" vd-readonly="true"
                                                    class="main-heading white-color"
                                                    :style="{'display': banner.textDisplay == 'none' ? 'none' : 'inherit', 'white-space': 'pre-wrap', 'width': 'max-content' }">
                                                    <vd-component-param type="label1" vd-node="bannerdata"
                                                        v-html="i18n(banner.bannerData.label1)"></vd-component-param>
                                                </h1>
                                                <span :btn-display="banner.btnDisplay"
                                                    class="button watch-now dynamic-banner-btn"
                                                    :style="{'display': banner.btnDisplay == 'none' ? 'none' : 'inherit', 'width': 'max-content' }">
                                                    <vd-component-param type="label2"
                                                        v-html="i18n(banner.bannerData.label2)"></vd-component-param>
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Image Banner -->

                                    <div v-if="banner.type == 'image'" class="item bannerType-img" vd-readonly="true"
                                        :image-src="banner.image_src" :image-alt="banner.image" vd-node="banner"
                                        :id="'banner-'+ banner.id" :type="banner.type" :link-type="banner.linkType"
                                        :link-src="banner.linkSrc" :link-mode="banner.linkMode" :content-uuid="banner.linkContent_uuid"
                                        :style="{width: bannerWidth + 'px',height: bannerHeight + 'px'}">
                                        <img class="banner-img" :src="banner.image_src" :alt="banner.image"
                                            id="'banner-'+ banner.id" :image-src="banner.image_src"
                                            :image-alt="banner.image" :id="'banner-'+ banner.id" :type="banner.type"
                                            :link-type="banner.linkType" :link-src="banner.linkSrc"
                                            :link-mode="banner.linkMode" :content-uuid="banner.linkContent_uuid"
                                            :srcset="generateSrcset(banner.image_src)"
                                            sizes="(max-width: 28em) 448px, (max-width: 55em) 880px, (max-width: 80em) 1300px, (max-width: 100em) 1650px, (max-width: 150em) 2260px, 2260px"/>
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 banner-text-left">
                                            <div class="banner-data" v-if="banner.bannerData != null">
                                                <h1 :text-display="banner.textDisplay" vd-readonly="true"
                                                    class="main-heading white-color"
                                                    :style="{'display': banner.textDisplay == 'none' ? 'none' : 'inherit', 'white-space': 'pre-wrap', 'width': 'max-content' }">
                                                    <vd-component-param type="label1" vd-node="bannerdata"
                                                        v-html="i18n(banner.bannerData.label1)"></vd-component-param>
                                                </h1>
                                                <span :btn-display="banner.btnDisplay"
                                                    class="button watch-now dynamic-banner-btn"
                                                    :style="{'display': banner.btnDisplay == 'none' ? 'none' : 'inherit', 'width': 'max-content' }">
                                                    <vd-component-param type="label2"
                                                        v-html="i18n(banner.bannerData.label2)"></vd-component-param>
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Video Banner -->

                                    <div v-if="banner.type == 'video'" class="item bannerType-video"
                                        :style="{width: bannerWidth + 'px',height: bannerHeight + 'px'}"
                                        vd-readonly="true"
                                        :image-src="banner.image_src" :image-alt="banner.image" vd-node="banner"
                                        :id="'banner-'+ banner.id" :type="banner.type" :link-type="banner.linkType"
                                        :link-src="banner.linkSrc" :link-mode="banner.linkMode" :content-uuid="banner.linkContent_uuid">
                                        <video muted loop playsinline :poster="banner.image_src"
                                            style="width: 100%; height:100%; object-fit: fill; opacity: 1; transition: opacity 2s;">
                                            <source :src="banner.videoUrl" type="video/mp4">
                                        </video>
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 banner-text-left">
                                            <div class="banner-data" v-if="banner.bannerData != null">
                                                <h1 :text-display="banner.textDisplay" vd-readonly="true"
                                                    class="main-heading white-color"
                                                    :style="{'display': banner.textDisplay == 'none' ? 'none' : 'inherit', 'white-space': 'pre-wrap', 'width': 'max-content' }">
                                                    <vd-component-param type="label1" vd-node="bannerdata"
                                                        v-html="i18n(banner.bannerData.label1)"></vd-component-param>
                                                </h1>
                                                <span :btn-display="banner.btnDisplay"
                                                    class="button watch-now dynamic-banner-btn"
                                                    :style="{'display': banner.btnDisplay == 'none' ? 'none' : 'inherit', 'width': 'max-content' }">
                                                    <vd-component-param type="label2"
                                                        v-html="i18n(banner.bannerData.label2)"></vd-component-param>
                                                </span>
                                            </div>
                                        </div>
                                        <div
                                            style="position: absolute;bottom: 30px;right: 20px;color: rgb(255 255 255 / 80%);background-color: #2d343670;padding: 8px;border-radius: 5px;display: flex;">
                                            <?xml version="1.0" ?>
                                            <svg style="display:none;" class="feather feather-volume-2 vol-on" fill="none"
                                                height="24" stroke="currentColor" stroke-linecap="round"
                                                stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                                                <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
                                            </svg>
                                            <?xml version="1.0" ?>
                                            <svg class="feather feather-volume-x vol-off" fill="none" height="24"
                                                stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                stroke-width="2" viewBox="0 0 24 24" width="24"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
                                                <line x1="23" x2="17" y1="9" y2="15" />
                                                <line x1="17" x2="23" y1="9" y2="15" />
                                            </svg>
                                        </div>
                                    </div>
                                </template>
                                <div v-else class="else item"
                                    :style="{'background': 'url(' + getRootUrl()  + 'img/remove-2.jpg)' }" type="image"
                                    :image-src=" getRootUrl()  + 'img/remove-2.jpg'" image-alt="Banner Default"
                                    vd-node="banner" vd-readonly="true" :id="'banner-'+ 1"
									style="width: 100% ;height:560px">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 banner-text-left">
                                        <div class="banner-data">
                                            <h1 vd-readonly="true" class="main-heading white-color"
                                            vd-readonly="true" style="white-space: pre-wrap;">
                                                <vd-component-param type="label1" vd-node="bannerdata"
                                                    v-html="i18n($attrs['label1'])"></vd-component-param>
                                            </h1>
                                            <span class="button watch-now dynamic-banner-btn" style="width:max-content">
                                                <vd-component-param type="label2"
                                                    v-html="i18n($attrs['label2'])"></vd-component-param>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </vd-component>
    `,
};

let {getRootUrl,
    getSlug}=await import(window.importAssetJs('js/web-service-url.js'));
let {getVdConfig}=await import(window.importAssetJs('js/webservices.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: 'banner_three',
    data() {
        return {
            rootUrl:getRootUrl(),
            allBanner: [],
            isloggedin : localStorage.getItem('isloggedin')
        } 
    },
    beforeMount() {
        if(this.isloggedin !== 'true') {
            // getVdConfig(this.$attrs["id"],getSlug).then((res) => {
            //     if (res.data.code == 200 && res.data.data.data?.bannerData?.length > 0) {
            //         this.allBanner = res.data.data.data;
            //         this.carouselSettings = res.data.data.settings;
            //     }
            // });
        }
    },
    updated() {
        //owlCarousal(this.carouselSettings);
    },
    methods: {
        getRootUrl,
        i18n,
    },

    template: `<vd-component class="vd banner-three" type="banner-three">
    <section class="banner-section" v-if="!isloggedin">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0 m-0">
                <div class="banner-content subcription-banner">
                    <div class="owl-carousel owl-theme " style="display:block">
                      <div  class="item">
                            <div class="banner-area border-bottom overflow-hidden">
                            <div class="container">
                                <div class="row align-items-center justify-content-center">
                                    <div class="col-md-6 order-md-2 col-10">
                                        <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                                    </div> 
                                   <div class="col-md-6 order-md-1">
                                        <h1><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h1>
                                        <h2><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h2>
                                        <p><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></p>
                                        <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</vd-component>`,
}

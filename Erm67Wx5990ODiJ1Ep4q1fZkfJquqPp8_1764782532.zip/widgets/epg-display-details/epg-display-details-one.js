let { getEpgJson,epgDetailsDisplay ,getCategories} = await import(window.importAssetJs('js/webservices.js'));
let { getRootUrl,getAssetUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:watch_now_one}=await import(window.importLocalJs('widgets/watch-now/watch-now-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
const { mapState, mapActions } = Vuex;
let { TOGGLE_CONTENT_PURCHASE_MODAL, SET_CURRENT_CONTENT_SELECTION_DATA, GET_END_USER_REGD_LOGIN_SETTING } = await import(window.importAssetJs('js/configurations/actions.js'));

export default {
    name: "epg_display_details_one",
    
    data() {
        return {
            epg_program: [],
            logos: [],
            channel_id: [],
            c_uuid: [],
            c_programs: "",
            timeSlotWidth: 200,
            selectedDay: "Today",
            days: [
                "Sunday",
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
            ],
            epgData: [],
            selectedEpgUrl: "",
            alltimeSlots: [
                "12:00 AM",
                "12:30 AM",
                "01:00 AM",
                "01:30 AM",
                "02:00 AM",
                "02:30 AM",
                "03:00 AM",
                "03:30 AM",
                "04:00 AM",
                "04:30 AM",
                "05:00 AM",
                "05:30 AM",
                "06:00 AM",
                "06:30 AM",
                "07:00 AM",
                "07:30 AM",
                "08:00 AM",
                "08:30 AM",
                "09:00 AM",
                "09:30 AM",
                "10:00 AM",
                "10:30 AM",
                "11:00 AM",
                "11:30 AM",
                "12:00 PM",
                "12:30 PM",
                "01:00 PM",
                "01:30 PM",
                "02:00 PM",
                "02:30 PM",
                "03:00 PM",
                "03:30 PM",
                "04:00 PM",
                "04:30 PM",
                "05:00 PM",
                "05:30 PM",
                "06:00 PM",
                "06:30 PM",
                "07:00 PM",
                "07:30 PM",
                "08:00 PM",
                "08:30 PM",
                "09:00 PM",
                "09:30 PM",
                "10:00 PM",
                "10:30 PM",
                "11:00 PM",
                "11:30 PM",
            ],
            timeSlots:[],
            currentHour: new Date().getHours(),
            currentMinute: new Date().getMinutes(),
            startHourTime: "",
            startIndex: 0,
            daysToShow: [], // Add daysToShow property to store the days to show
            channelData: [], // New property to store processed channel data
            channelsArr: [],
            newarray: [],
            leftValConstant: 490,
            setIntervalObj: null,
            setIntervalObj_timer: null,
            globalStartTime: null,
            newTimeSlot:'',
            stTime:0,
            channelDetailsArray:[],
            url:'',
            languageCode:"en",
            dayDiff:0,
            processedDays:[],
            tvPrograms: [],
            channelMap:[],
            tv_programs:[],
            tv_program_details:[],
            epg_urll:'',
            epg_url_xml:'',
            xml_url:'',
            json_url:'',
            language_code:'en',
            live_tv:'',
            contentList:'',
            bannerImage:'/img/epg-default-banner.jpg',
            current_program_name:'',
            current_program_time:'',
            channe_logo:'',
            contentPermalink: '',
            isButtonShow: false,
            playerRequiredObj: {},
            isQueueBtnShow: false,
            queueObj: {},
            contentUuidAudio: '',
            isAudioPlay: false,
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            rootUrl: getRootUrl(),
            permalinkDataEmitted: null,
            isFreeContent:false,
            showPlayAllAndWatchTrailerButton: false,
            useWatchNow:0,
            selectedDayName:"Today",
            previousHour:-1,
            xmlHttpobj:null,
            contentobj:{}
        };
    },
   
    components: {
        watch_now_one,
        content_purchase_one,
        audio_player_one
    },
    methods: {
        getRootUrl,
        getAssetUrl,
        epgDetailsDisplay,
        getXmlData(){
            console.log("samxmlHttpobj",this.xmlHttpobj);
            if (this.xmlHttpobj.readyState == 4 &&  this.xmlHttpobj.status == 200) {
                let data =  this.xmlHttpobj.responseXML;
                 console.log("datasambit",data);
                return this.processXMLData(data,this.contentobj);
                 }
          },
        fetchXMLData(xml_url,content) {
            console.log("xmlurl",xml_url);
            var xmlUrl = xml_url;
            $(document).ready(() => {
                this.contentobj = content;
            //   $.ajax({
            //     url: xml_url+"&rand="+Math.random(),
            //     type: "GET",
            //     dataType: "xml",
            //     // headers: {
            //     //   Accept: "application/xml"
            //     // },
            //     success: (data, textStatus, jqXHR) => {
            //         console.log("datasambit",data);
            //       return this.processXMLData(data,content);
            //     },
            //     error: (xhr, status, error) => {
            //       console.error("Failed to fetch data, using dummy data", error);
            //       //this.useDummyData();
            //       return [] ;
            //     }
            //   });
            this.xmlHttpobj = new XMLHttpRequest();
            this.xmlHttpobj.onreadystatechange =  this.getXmlData; 
             
                 this.xmlHttpobj.open("GET", xmlUrl, false);
                 this.xmlHttpobj.send();
            });
          },
          processXMLData(data,content) {
            const channels = {};
            const programs_list = [];
            const channels1 = {};
            $(data)
                .find("channel")
                .each((index, element) => {
                    const icon =
                        content.posters &&
                        content.posters.website &&
                        content.posters.website[0] &&
                        content.posters.website[0].file_url !== ""
                            ? content.posters.website[0].file_url
                            : getAssetUrl() + "img/default-channel-logo.svg";
                   
                        const channel_id = $(element).attr('id');
                        const channel = {
                            channel_uuid: channel_id,
                            display_name: content.content_name,
                            programs: [], // Initialize the programs array for each channel
                            channel_icon: icon,
                            permalink:content.content_permalink,
                            content_uuid:content.content_uuid
                        };
                        channels[content.content_uuid] = channel;  // Store by channel_id
                        channels1[content.content_uuid] = channel;
                        programs_list.push(channel);
                        //console.log("programs_list",programs_list);     // Also store in the array
                    });
                    // Now process all programs and link them to their respective channels
                    $(data).find('programme').each((index, element) => {
                        var startdt = this.parseDate($(element).attr("start"));
                        var stopdt = this.parseDate($(element).attr("stop"));
                        if ( parseInt(startdt.substr(0, 8)) != parseInt(stopdt.substr(0, 8)) ) {
                            let program = {
                                start: startdt,
                                stop: startdt.substr(0, 8) + "235959 +999",
                                channel_uuid: $(element).attr("channel"), // Channel UUID reference
                                title: $(element).find("title").text(),
                                content_uuid: content.content_uuid,
                                content_desc: $(element).find("desc").text(),
                            };
                            
                            // Check if the program's channel exists in the channels object
                            if (channels[program.content_uuid]) {
                                channels[program.content_uuid].programs.push(
                                    program
                                ); // Add program to the correct channel
                            }
                            program = {
                                start: stopdt.substr(0, 8) + "000000 +000",
                                stop: stopdt,
                                channel_uuid: $(element).attr("channel"), // Channel UUID reference
                                title: $(element).find("title").text(),
                                content_uuid: content.content_uuid,
                                content_desc: $(element).find("desc").text(),
                            };
                            // Check if the program's channel exists in the channels object
                            if (channels[program.content_uuid]) {
                                channels[program.content_uuid].programs.push(
                                    program
                                ); // Add program to the correct channel
                            }
                        } else {
                            const program = {
                                start: startdt,
                                stop: stopdt,
                                channel_uuid: $(element).attr("channel"), // Channel UUID reference
                                title: $(element).find("title").text(),
                                content_uuid: content.content_uuid,
                                content_desc: $(element).find("desc").text(),
                            };
                            // Check if the program's channel exists in the channels object
                            if (channels[program.content_uuid]) {
                                channels[program.content_uuid].programs.push(program); // Add program to the correct channel
                            }
                        }
                });
            // After processing, assign epgData and channelData
            this.epgData = programs_list; // This contains all channels and their programs
            if (this.channelData && this.channelData.length > 0) {
                const newChannelItem = this.epgData.map((channel) => {
                    return {
                        ...channel,
                        programsByDay: this.groupProgramsByDay(channel.programs), // Grouping programs by day
                    };
                });
                this.channelData.push(newChannelItem[0]);
            } else {
                this.channelData = this.epgData.map((channel) => {
                    return {
                        ...channel,
                        programsByDay: this.groupProgramsByDay(channel.programs), // Grouping programs by day
                    };
                });
            }
            console.log(this.channelData, "Processed xML Channel Data");
            // Now make sure you're showing all channels, not just one
            if (this.channelData.length > 0) {
                const currentDate = new Date();
                const currentDay = this.formatDate(currentDate);
                this.daysToShow = ["Today", ...this.getNextDays(1, 6)]; // Update daysToShow

                // Set default selected day if it matches the current day
                if (this.daysToShow.includes(currentDay)) {
                    this.selectedDay = currentDay;
                }
            }
            clearInterval(this.setintervalobj);
            this.setInitialData();
        },

        parseDate(datestring) {
            const utcDateString =
                datestring.substr(0, 4) +
                "-" +
                datestring.substr(4, 2) +
                "-" +
                datestring.substr(6, 2) +
                "T" +
                datestring.substr(8, 2) +
                ":" +
                datestring.substr(10, 2) +
                ":" +
                datestring.substr(12, 2) +
                "Z";
            const utcDate = new Date(utcDateString);
            return (
                utcDate.toLocaleString('en-US', { year:'numeric' }) +
                utcDate.toLocaleString('en-US', { month: '2-digit'}).toString().padStart(2,"0")  +
                utcDate.toLocaleString('en-US', { day:'2-digit'}).toString().padStart(2,"0") +
                utcDate.toLocaleString('en-US', { hour: '2-digit', hour12: false }).toString().padStart(2,"0") +
                utcDate.toLocaleString('en-US', { minute: '2-digit' }).toString().padStart(2,"0") +
               utcDate.toLocaleString('en-US', { second: '2-digit' }).toString().padStart(2,"0") +
                " +000"
            );
        },
        filteredPrograms(contentId) {
            let dfs = this.getNextOccurrenceOfDay(this.selectedDay);
            let daysDate = this.getDayOfMonthFromDate(dfs);
            let match=false;
            let currenttimestamp = new Date(this.globalStartTime);
            return this.newarray.filter((program) => {
                const programDate = this.convertToDateComponents(program.start);
                const programEndDate = this.convertToDateComponents(program.stop);
                let progDate = programDate.day;
                if (progDate == daysDate) {
                    match = true;
                } else {
                    match = false;
                }
                let ststring=(programEndDate.year).toString()+"-"+(programEndDate.month).toString().padStart(2,"0")+"-"+(programEndDate.day).toString().padStart(2,"0")+"T"+(programEndDate.hours).toString().padStart(2,"0")+":"+(programEndDate.minutes).toString().padStart(2,"0")+":"+(programEndDate.seconds).toString().padStart(2,"0");
                let stDate=new Date(ststring);
                return program.content_uuid == contentId && match;
            });
        },

        useDummyData() {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(this.xml_url, "application/xml");
            if (xmlDoc.getElementsByTagName("parsererror").length > 0) {
                console.error("Error parsing XML:", xmlDoc.getElementsByTagName("parsererror")[0].textContent);
            } else {
                this.processXMLData(xmlDoc);
            }
          
        },
        generateTimeSlots() {
            const currentUTCHour = new Date().getHours();
            const currentUTCMinute = new Date().getMinutes();
            if (this.selectedDayName === "Today") {
                const currentTimeIndex = Math.floor(
                    currentUTCHour * 2 + currentUTCMinute / 30
                );
                const nowTimeIndex = currentTimeIndex - 1;
                this.globalStartTime = (currentTimeIndex - 1) * 30;
                this.newTimeSlot = this.alltimeSlots.length - nowTimeIndex;
                const lastSlotIndex = this.alltimeSlots.findIndex(
                    (slot) => slot === "11:30 PM"
                );
                if (nowTimeIndex < lastSlotIndex) {
                    this.timeSlots = this.alltimeSlots.slice(
                        nowTimeIndex,
                        lastSlotIndex + 1
                    );
                } else {
                    this.timeSlots = []; // If current time exceeds the last slot, reset time slots
                }
            } else {
                this.timeSlots = [...this.alltimeSlots]; // Copy all time slots
            }
        },
        playAudioContent(content_detail) {//ER-101092
            this.contentUuidAudio = content_detail.contentUuid;
            this.isFreeContent = content_detail.isFreeContent; 
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        initialSetup() {
            this.newarray = [];
            this.channelData.forEach((channel) => {
                this.channelDetailsArray.push({
                    channel_id: channel.channel_uuid,
                    logo: channel.channel_icon,
                });
                
                const programsForDays = this.getProgramsForDay(
                    channel,
                    this.selectedDay
                );
                const TodayDate = new Date();
                const TodayDay = this.formatDate(TodayDate);
                let todayT = this.stTime;
                let selectedDay = this.selectedDay || TodayDay;
                let firstprogram = 1;
                programsForDays.forEach((program) => {
                    const stopTime = this.convertToDateComponents(program.stop); // Convert program.stop to Date object
                    const programmStartTime = this.convertToDateComponents(
                        program.start
                    ); // Convert program.stop to Date object
                    
                    const prStartTIme =
                        programmStartTime.hours * 60 +
                        programmStartTime.minutes;
                    const newtotalMinutes =
                        stopTime.hours * 60 + stopTime.minutes;
                    if (newtotalMinutes >= this.stTime) {
                        const starttotalMinutes = this.stTime;
                        const currentTime = new Date();
                        const currentHour = currentTime.getHours(); // Use getUTCHours instead of getHours to get the UTC hours
                        const currentMinute = currentTime.getMinutes(); // Use getUTCMinutes instead of getMinutes to get the UTC minutes
                        const newDate = currentHour * 60 + currentMinute;
                        const totalMinutes = this.globalStartTime;
                        if (selectedDay === TodayDay) {
                            if (newDate > newtotalMinutes) {
                                program.classname = "expired single-episode";
                            } else if (
                                newDate >= prStartTIme &&
                                newDate <= newtotalMinutes
                            ) {
                                program.classname = "running single-episode";
                                this.current_program_name = program.title;
                                this.current_program_time = this.formatProgramTime(program.start,program.stop);
                             } else {
                                program.classname = "upcoming single-episode";
                            }
                        } else {
                            program.classname = "upcoming single-episode";
                        }
                        let durationInMinutes = newtotalMinutes - todayT;
                        // if (durationInMinutes <= 1) {
                        //     durationInMinutes = 1; // Minimum duration to avoid 0 width
                        // }
                        if(prStartTIme>todayT){
                            durationInMinutes = newtotalMinutes - prStartTIme;
                        }
                        var divWidth = ((durationInMinutes * 10)-1);
                        if(firstprogram==1){
                            divWidth = ((durationInMinutes * 10)-11);
                        }
                        if(divWidth > 0){
                            firstprogram++;
                            if(divWidth <= 50){
                                console.log("divWidth",divWidth);
                                program.style = "width:" + (divWidth) + "px;padding:12px 2px;";
                            }else{
                                program.style = "width:" + (divWidth) + "px";
                            }
                     
                            todayT = newtotalMinutes;
                           this.newarray.push(program);  
                        }
                   

                    } else {
                        program.classname = "expired single-episode";
                        program.style = "width:0px;display:none;padding:0px";

                    }
                });
            });
        },

        getNextOccurrenceOfDay(dayName) {
            // Get today's date
            const today = new Date();
            // Find the next occurrence of the specified day
            const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            const currentDayOfWeek = today.getDay();
            const targetDayOfWeek = daysOfWeek.indexOf(dayName);
            // Calculate the difference between the target day and the current day
            let dayDiff = targetDayOfWeek - currentDayOfWeek;
            if (dayDiff < 0) {
                dayDiff += 7; // If the target day has already passed this week, add 7 days to find the next occurrence
            }

            // Calculate the date of the next occurrence of the target day
            const nextOccurrence = new Date(today);
            nextOccurrence.setDate(today.getDate() + dayDiff);
            return nextOccurrence;
        },
        getDayOfMonthFromDate(date) {
            const dayOfMonth = date.getDate(); // Get the day of the month
            return dayOfMonth.toString(); // Convert it to a string
        },

        setInitialData() {
            const currentUTCHour = new Date().getHours();
            const currentUTCMinute = new Date().getMinutes();
            const currentTimeIndex = Math.floor(currentUTCHour * 2 + currentUTCMinute / 30);
            if(currentTimeIndex == 0){
                this.globalStartTime = 0;
                this.leftValConstant =200;
            }else{
                this.globalStartTime = (currentTimeIndex - 1) * 30;
                this.leftValConstant=490;
            }
            const date = new Date(this.globalStartTime);
            const hours = date.getHours();
            const minutes = date.getMinutes();
            const totalMinutes = hours * 60 + minutes;
            const currentTime = new Date();
            const currentHour = currentTime.getHours(); // Use getUTCHours instead of getHours to get the UTC hours
            const currentMinute = currentTime.getMinutes(); // Use getUTCMinutes instead of getMinutes to get the UTC minutes
            const newDate = currentHour * 60 + currentMinute;
            if (this.leftValConstant == 490) {
                this.leftValConstant =
                    this.leftValConstant +
                    (newDate - this.globalStartTime - 30) * 10;
            }
            // Perform initial setup
            this.initialSetup();
        },
        async epgDisplay(jsonUrl,content) {
           $(document).ready(() => {
           //console.log("this.jsonurl",jsonUrl);
            $.ajax({
              url:jsonUrl+"&rand="+Math.random(),
              type: "GET",
              dataType: "json",
              headers: {
                Accept: "application/json"
              },
              success: (data) => {
                return this.processJSONData(data,content);
              },
              error: (xhr, status, error) => {
                console.error("Failed to fetch data, using dummy data", error);
                //this.useDummyData();
                return [] ;
              }
            });
          });
        },
        processJSONData(data, content) {
            const channels = {};
            const programs_list = [];
            // First, process all channels in the JSON data
            data.data.channel.forEach((channelItem) => {
                const icon = 
                            (content.posters && 
                            content.posters.website && 
                            content.posters.website[0] && 
                            content.posters.website[0].file_url !== '')  ? content.posters.website[0].file_url : getAssetUrl() + 'img/default-channel-logo.svg';

                const channel = {
                    channel_uuid: channelItem.id,
                    display_name: content.content_name,
                    programs: [], 
                    channel_icon: icon,
                    permalink: content.content_permalink,
                    content_uuid: content.content_uuid,
                };

                // Store channels by their unique ID
                channels[channel.content_uuid] = channel;
                programs_list.push(channel);

                //console.log(channelItem.schedule, " channelItem.schedule.");
                channelItem.schedule.forEach((programItem) => {
                    const startdt = this.parseDate(programItem.start_date_time);
                    const stopdt = this.parseDate(programItem.end_date_time);
                    
                    if (parseInt(startdt.substr(0, 8)) !== parseInt(stopdt.substr(0, 8))) {
                        // Case when the program spans multiple days
                        let program = {
                            start: startdt,
                            stop: startdt.substr(0, 8) + "235959 +999",
                            channel_uuid: channelItem.id,
                            title: programItem.title,
                            content_desc: programItem.description,
                            content_uuid: content.content_uuid,
                        };
                
                        // Add the program to the correct channel
                        if (channels[program.content_uuid]) {
                            channels[program.content_uuid].programs.push(program);
                        }
                
                        // Add the next day's program continuation
                        program = {
                            start: stopdt.substr(0, 8) + "000000 +000",
                            stop: stopdt,
                            channel_uuid: channelItem.id,
                            title: programItem.title,
                            content_desc: programItem.description,
                            content_uuid: content.content_uuid,
                        };
                
                        // Add the program to the correct channel
                        if (channels[program.content_uuid]) {
                            channels[program.content_uuid].programs.push(program);
                        }
                    } else {
                        // Case when the program is on the same day
                        const program = {
                            start: startdt,
                            stop: stopdt,
                            channel_uuid: channelItem.id,
                            title: programItem.title,
                            content_desc: programItem.description,
                            content_uuid: content.content_uuid,
                        };
                
                        // Add the program to the correct channel
                        if (channels[program.content_uuid]) {
                            channels[program.content_uuid].programs.push(program);
                        }
                    }
                });
            });
            // Assign the processed data to epgData and channelData
            this.epgData = programs_list; // This contains all channels and their programs

            if (this.channelData && this.channelData.length > 0) {
                const newChannelItem = this.epgData.map((channel) => {
                    return {
                        ...channel,
                        programsByDay: this.groupProgramsByDay(
                            channel.programs
                        ), // Grouping programs by day
                    };
                });
                this.channelData.push(newChannelItem[0]);
            } else {
                this.channelData = this.epgData.map((channel) => {
                    return {
                        ...channel,
                        programsByDay: this.groupProgramsByDay(
                            channel.programs
                        ), // Grouping programs by day
                    };
                });
            }
            // Now, handle displaying the channels and programs
            if (this.channelData.length > 0) {
                const currentDate = new Date();
                const currentDay = this.formatDate(currentDate);
                this.daysToShow = ["Today", ...this.getNextDays(1, 6)]; // Update daysToShow

                // Set default selected day if it matches the current day
                if (this.daysToShow.includes(currentDay)) {
                    this.selectedDay = currentDay;
                }
            }
            clearInterval(this.setintervalobj);
            this.setInitialData();
        },
        groupProgramsByDay(programs) {
            const groupedPrograms = {};
            const groupedDayDates = {};
            let ctdateobject=new Date(this.globalStartTime);
            this.days.forEach((day) => {
                groupedPrograms[day] = programs.filter((program) => {
                    const stdateObject = this.convertToDateComponents(program.start);                   
                    const dateObject = this.convertToDateComponents(program.stop); 
                    const programDay = this.formatDate( new Date(stdateObject.year,stdateObject.month - 1,stdateObject.day ));
                    let ststring=(dateObject.year).toString()+"-"+(dateObject.month).toString().padStart(2,"0")+"-"+(dateObject.day).toString().padStart(2,"0")+"T"+(dateObject.hours).toString().padStart(2,"0")+":"+(dateObject.minutes).toString().padStart(2,"0")+":"+(dateObject.seconds).toString().padStart(2,"0");
                    let stDate=new Date(ststring);
                    if(!groupedDayDates[day] && programDay === day && stDate.getTime()>ctdateobject.getTime()){
                        groupedDayDates[day]=stdateObject.day;
                    }
                    return programDay === day && groupedDayDates[day] == stdateObject.day && stDate.getTime()>ctdateobject.getTime();
                });
            });
            return groupedPrograms;
        },
        getProgramsForDay(channel, day) {
            return channel.programsByDay ? channel.programsByDay[day] || [] : [];
        },
        updateCurrentTime() {
            // This method will be called every minute to update the current time
            const newDate = new Date();
            this.currentHour = newDate.getHours();
            this.currentMinute = newDate.getMinutes();
            // this.calculateStartHourTime(); // Recalculate start time based on the updated time
        },
        async fetchData(day) {
            //console.log("fetchday called ",day);
            this.timeSlots = this.alltimeSlots;
            if (day === "Today") {
                const currentUTCHour = new Date().getHours();
                const currentUTCMinute = new Date().getMinutes();
                const currentTimeIndex = Math.floor(currentUTCHour * 2 + currentUTCMinute / 30);
                let nowTimeIndex =0;
                if(currentTimeIndex == 0){
                    this.leftValConstant =200;
                }else{
                     nowTimeIndex = currentTimeIndex - 1;
                    this.leftValConstant=490;
                }
                
                const lastSlotIndex = this.alltimeSlots.findIndex((slot) => slot === "11:30 PM");
                if (nowTimeIndex < lastSlotIndex) {
                    this.timeSlots = this.alltimeSlots.slice(nowTimeIndex,lastSlotIndex + 1);
                } else {
                    this.timeSlots = []; // If current time exceeds the last slot, reset time slots
                }
                this.globalStartTime=nowTimeIndex*30;
                this.stTime= this.globalStartTime;
                const currentDate = new Date();
                const currentDay = this.formatDate(currentDate);
                this.selectedDay = currentDay;
                this.selectedDayName = day;
                const currentHour = currentDate.getHours(); // Use getUTCHours instead of getHours to get the UTC hours
                const currentMinute = currentDate.getMinutes(); // Use getUTCMinutes instead of getMinutes to get the UTC minutes
                const newDate = currentHour * 60 + currentMinute;
                this.leftValConstant =  this.leftValConstant + (newDate - this.globalStartTime - 30) * 10;
                this.initialSetup();
            } else {
                this.stTime = 0;
                this.selectedDay = day;
                this.selectedDayName = day;
                this.leftValConstant = 200;
                this.initialSetup();
                if (!this.processedDays.includes(day)) {
                    this.processedDays.push(day);
                }
            }
        },
        getNextDays(startIndex, count) {
            const daysOfWeek = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            const currentDate = new Date();
            const nextDays = [];
            for (let i = startIndex; i <= count; i++) {
                currentDate.setDate(currentDate.getDate() + 1);
                const nextDay = daysOfWeek[currentDate.getDay()];
                nextDays.push(nextDay);
            }
            return nextDays;
        },
        extractChannelIdFromUrl(url) {
            const pathTokens = new URL(url).pathname.split("/");
            return pathTokens[pathTokens.length - 1].replace(".xml", "");
        },
        extractChannelIdFrom(url) {
            const pathTokens = new URL(url).pathname.split("/");
            return pathTokens[pathTokens.length - 1].replace(".json", "");
        },
        convertToDateComponents(dateString) {
            const year = parseInt(dateString.substring(0, 4));
            const month = parseInt(dateString.substring(4,6));
            const day = parseInt(dateString.substring(6,8));
            const hours = parseInt(dateString.substring(8, 10));
            const minutes = parseInt(dateString.substring(10, 12));
            const seconds = parseInt(dateString.substring(12, 14));
            // const milliseconds = parseInt(dateString.substring(14, 17));
            return { year, month, day, hours, minutes, seconds };
        },
        formatDate(date) {
            return date.toLocaleDateString("en-US", { weekday: "long" });
        },
        formatProgramTime(startTime, stopTime) {
            const start = this.convertToDateComponents(startTime);
            const stop = this.convertToDateComponents(stopTime);
            return `${this.formatTime(start)} - ${this.formatTime(stop)}`;
        },

        formatTime(time) {
            const {hours = 0,minutes = 0,seconds = 0,milliseconds = 0,} = time;
            let formattedHours = hours % 12 || 12; // Use modulo to convert 24-hour to 12-hour format
            const amPm = hours < 12 ? "AM" : "PM"; // Determine whether it's AM or PM
            const formattedTime = `${String(formattedHours).padStart(
                2,
                "0"
            )}:${String(minutes).padStart(2, "0")} ${amPm}`;
            return formattedTime;
        },
        
        resetDataAndSetTimer(){
            
            this.generateTimeSlots();
            const currentHours = new Date().getHours();
            const currentUTCMinute = new Date().getMinutes();
            const currentTimeIndex = Math.floor(currentHours * 2 + currentUTCMinute / 30);
            if(currentTimeIndex == 0){
                this.globalStartTime = 0;
                this.leftValConstant =200;
            }else{
                this.globalStartTime = (currentTimeIndex - 1) * 30;
                this.leftValConstant=490;
            }
            this.stTime= this.globalStartTime;
            const date = new Date(this.globalStartTime);
            const hours = date.getHours();
            const minutes = date.getMinutes();
            const totalMinutes = hours * 60 + minutes;
            const currentTime = new Date();
            const currentHour = currentTime.getHours(); // Use getUTCHours instead of getHours to get the UTC hours
            const currentMinute = currentTime.getMinutes(); // Use getUTCMinutes instead of getMinutes to get the UTC minutes
            const newDate = currentHour * 60 + currentMinute;
            if (this.leftValConstant == 490) {
                this.leftValConstant =
                    this.leftValConstant +
                    (newDate - this.globalStartTime - 30) * 10;
            }

            const currentDate = new Date();
            if(this.previousHour != -1 && this.previousHour == 23 && currentHours == 0 ){
                window.location.reload();
            }
            this.previousHour = currentHours; 
            this.initialSetup();
        },
        startIntervalfunction(){
            clearInterval(this.setIntervalObj_timer);
            console.log("resetDataAndSetTimer eneterd");
            this.setIntervalObj = setInterval(() => {
                this.resetDataAndSetTimer();
            }, 60000); // Update every minute
        },
        
          categoryId() {
            return getCategories().then((res) => {
                const resp = res.data;
                const categoryList = resp.data.categoryList.category_list;
                const liveTvCategory = categoryList.find(category => category.category_name === "Live TV");
                if (liveTvCategory) {
                    this.live_tv = liveTvCategory.category_uuid;
                    console.log("Live TV category ID:", this.live_tv);
                } else {
                    console.log("Live TV category not found.");
                }
                return this.live_tv;
            });
        },
        truncateTitle(title) {
            let words = title.split(' '); // Split the title into an array of words
            let truncated = words.length > 11 ? words.slice(0, 11).join(' ') + '...' : title;
            return truncated;
        },
        epgDetailsDisplay() {
           
            let contentUuids = {};
            if (!this.live_tv) {
                return;
            }
            epgDetailsDisplay(this.live_tv, this.contentPermalink).then(res => {
                console.log("sambit samalllllllllll");
                if (res.data.code === 200) {
                    this.contentList = res.data.data.contentList.content_list;
                    this.$refs.banner.src=(this.contentList[0].banners && 
                        this.contentList[0].banners.website && 
                        this.contentList[0].banners.website[0] && 
                        this.contentList[0].banners.website[0].file_url !== '') ? this.contentList[0].banners.website[0].file_url : getAssetUrl() + 'img/epg-default-banner.jpg';
                    //this.contentList[0].content_desc = "playout channel decsription goes here here it is added s d a m b i t g s a m a l s a ma l";
                    const programDesc = this.contentList[0].content_desc;
                    let words = programDesc.split(' ');
                    let truncatedDesc = words.slice(0, 20).join(' '); // Get the first 20 words
                    
                    if (words.length > 20) {
                         truncatedDesc += '... <a href="javascript:void(0);" data-toggle="modal" data-target=".readmore-banner">Read More</a>';
                    }
                    
                    this.$refs.bannerDescription.innerHTML = truncatedDesc;
                    this.$refs.bannerDescriptions.innerHTML = programDesc;
                    this.setPlayerObj(this.contentList[0]);
                    if (this.contentList && this.contentList.length > 0) {
                        this.contentList.forEach(content => {
                            const channelId = content.channel_uuid;
                            const contentEpgDetails = content.content_epg_details;
                            // Check if content_epg_details exists for each content item
                            if (contentEpgDetails) {
                               this.xml_url = contentEpgDetails.epg_url_xml;
                                this.json_url = contentEpgDetails.epg_url_json;
                                if (this.xml_url) {
                                    contentUuids[content.content_uuid] = this.fetchXMLData(this.xml_url,content);
                                } else if (this.json_url) {
                                    contentUuids[content.content_uuid] = this.epgDisplay(this.json_url,content);
                                } else {
                                    console.log("No EPG URL available for content:", content);
                                }
                            } else {
                                console.log("EPG details are undefined for content:", content);
                            }
                        });
                        // Start interval for periodic updates
                        const currentUTCMinute = new Date().getMinutes();
                        this.setIntervalObj_timer = setInterval(() => {
                            let currentUTCMinute1 = new Date().getMinutes();
                            if(currentUTCMinute!=currentUTCMinute1){
                                this.startIntervalfunction();
                                this.resetDataAndSetTimer();
                            }
                        }, 1000); // Update every minute
                    } else {
                        console.log("No content list found.");
                    }
                }else{
                    window.location.href = "/404";
                }
            });
        },
        isQueueBtn(value) {
            this.isQueueBtnShow = value;
        },
        isQueueObj(value) {
            this.queueObj = value;
        },
        playerPermalinkEmitted(value) {
            let playerPermalinkIsCalled = value;
            if (playerPermalinkIsCalled) {
                this.showPlayAllAndWatchTrailerButton = true;
            }
        },
        setPlayerObj(contentObj) {
            this.playerRequiredObj = {
                rootParentUuid: contentObj.root_parent_uuid,
                contentUuid: contentObj.content_uuid,
                isPlayList: contentObj.is_playlist,
                contentPermalink: contentObj.content_permalink,
                contentAssetType: contentObj.content_asset_type,
                isParent: contentObj.is_parent,
                isFreeContent: contentObj.is_free_content,//ER-101092
                isChannel:1 //ER-101262
            };
            this.useWatchNow = 1;
            console.log("this.playerRequiredObj",this.playerRequiredObj);
        },

        playerPermalinkDataEmitted(data) {
            this.permalinkDataEmitted = data;
        },
    },
    beforeMount() {
        this.content_uuid=localStorage.getItem('epg_content_uuid');
    },
    computed: {
        ...mapState({
            end_user_regd_login_setting: (state) => state.end_user_regd_login_setting,
        }),
    },
    mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
        this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                    content: '',
                    monetization_methods: []
                });
       
        this.fetchData("Today");
        this.categoryId().then(() => {
        // Call detailsEpg only after live_tv is set
        console.log("live-tv category uuid ",this.live_tv); 
        let patharray=window.location.pathname.toString().split("/")
            console.log("Path query string array  ", patharray);
            if (patharray.length >= 3) {
                this.contentPermalink = patharray[patharray.length-1];
                console.log("Content Permalink ", this.contentPermalink);
                if (this.live_tv) {
                    localStorage.setItem('live_tv_category_uuid', this.live_tv);
                    console.log("sambit sam", localStorage.getItem('live_tv_category_uuid'));
                    this.epgDetailsDisplay();
                }
            }
            else {
                window.location.href = "/404";
            }
       });
    },
    template: `   
<vd-component class="vd epg-display-details-one" type="epg-display-details-one">    
    <div>
    <!--Banner Section Start Here-->
    
    <section class="banner-section">
        <div class="banner-content v2">
           <img ref="banner" alt="banner" />  
        </div>
        <div class="container-fluid">
            <div class="row"> 
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5 col-xl-4 banner-text-left align-middle">
                   <div class="banner-data">
                    <span>
                        <img :src="this.channe_logo" class="img-fluid" alt="">
                    </span>
                      <h1 class="main-heading white-color">{{this.current_program_name}}</h1>
                      <h2 class="sub-heading white-color h2-ratingStarts">
                        <span class="hrs-span">{{this.current_program_time}}</span>
                       
                      </h2>
                      <p ref="bannerDescription" class="content-data text-darklight"></p>

                      <span class="button watch-now">
                       <watch_now_one v-if="useWatchNow"
                                    :id="$attrs['id'] +'_watch_now_one_1'" 
                                    @isQueueButton="isQueueBtn" 
                                    @queueObjEmit="isQueueObj"
                                    @playAudioContent="playAudioContent" 
                                    :playerRequiredObj="playerRequiredObj" @player_permalink_data="playerPermalinkDataEmitted" 
                                    ref="$watchNowRef"
                                />
                        </span>
                </div>
              </div>
            </div>
        </div>        
    </section>
    <!--Banner Section End Here-->

    <!--EPG Start Here-->
    <div class="epg-sec">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <ul>
                  <li v-for="(day, index) in daysToShow" :key="index">
                        <a href="javascript:void(0)"    :class="{ 'hightlitday': selectedDayName === day }"
                            @click="fetchData(day)">{{ day }}</a>
                    </li>
                </ul>
            </div>
            <div class="col-12">
                <div class="table-responsive"> 
                    <div class="table-bg"></div>
                    <div class="time-line" :style="{ left: leftValConstant + 'px' }">
                        <svg width="19" height="100%" viewBox="0 0 19 100%" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect width="19" height="3" fill="#FFB950"></rect>
                            <rect x="8" y="3" width="3" height="98%" fill="#FFB950"></rect>
                            <rect y="98%" width="19" height="3" fill="#FFB950"></rect>
                        </svg>
                    </div>
                    <table  :style="{ minWidth: timeSlots.length * 300 + 'px', width: '100%', maxWidth: timeSlots.length * 300 + 'px !important' }" class="parent-table">
                        <thead>
                            <tr>
                                <th width="200" style="max-width:200px" >Channels</th>
                                <th v-for="(timeSlot, index) in timeSlots" :key="index"  :width="index === timeSlots.length - 1 ? '290px' : '300px'" >
                                    {{ timeSlot }}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(channel, channelIndex) in channelData" :key="channelIndex" >
                                <td>
                                <a>
                                    <div class="wrap-channel" >
                                        <div class="channel">
                                            <img :src="channel.channel_icon" alt="">
                                        </div>
                                    </div>
                                  </a>
                                </td>
                                <td class="row flex-nowrap" >
                                <div class="col-auto" v-for="(program, programindex) in filteredPrograms(channel.content_uuid)"  :key="programindex"  >
                                <div :class="program.classname" :style="program.style" >
                                  <div class="inner-text" style="overflow:hidden" :title="program.title" >
                                         {{this.truncateTitle(program.title)}}
                                  <span>{{ formatProgramTime(program.start, program.stop) }}</span>
                                   </div>
                                <div v-if="program.classname == 'running single-episode'" class="table-popup" style="width: 302px;">
                                         <h4>{{program.title}}</h4>
                                         <p>{{program.content_desc}}</p>
                                         <div class="d-flex justify-content-between">
                                           <span>{{ formatProgramTime(program.start, program.stop) }}</span>
                                         </div>
                                    </div>

                                  <div v-if="program.classname !== 'running single-episode'" class="table-popup dark" style="width: 302px;">
                                          <h4>{{program.title}}</h4>
                                          <p>{{program.content_desc}}</p>
                                          <div class="d-flex justify-content-between">
                                            <span>{{ formatProgramTime(program.start, program.stop) }}</span>
                                          
                                        </div>
                                        </div>
                                 </div>
                              </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
    <!--EPG End Here-->
    <!--popup desihn Start Here-->  
    <div class="modal fade readmore-banner" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header flex-column">
            <h5 class="modal-title" id="exampleModalLabel" ref="mainHeadings">
            </h5>
            <h6 ref="hrsSpans">
            </h6>
            <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true"><img src="img/popup-close.jpg" alt="close" /></span>
            </button> -->
           <span class="close-model" data-dismiss="modal"><img  vd-node="image" :src="getRootUrl() + 'img/modalCloseCross.png'" alt="popup" class="modalCloseCross"/></span>
          </div>
          <div class="modal-body">
            <p ref="bannerDescriptions"> </p>
          </div>
        </div>
      </div>
    </div>
        <!--Content purchase popup 116051-->
        <content_purchase_one
            id="$attrs['id'] +'_content_purchase_one_1'"
        />
        <!--Stick Audio player 116051-->
        <audio_player_one
        v-if="isAudioPlay && contentUuidAudio"
        :id="$attrs['id'] +'_audio_player_one_1'"
        @queueEmit="setQueueEmit" :key="resetAudioPlayer"
        :contentUuid="contentUuidAudio" :isFreeContent ="isFreeContent"
    />
    </vd-component>
  `
};

let { TooltipDirective } = await import(window.importAssetJs('js/directives/tooltip.directive.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let {
    addEnduserPlaylist,
    editEnduserPlaylist,
    mapContentToPlaylist,
    removeContentFromPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));

let { i18n } = await import(window.importAssetJs('js/i18n.js'));

const { mapState, mapGetters } = Vuex;

export default {
    name: 'playlist_enduser_one',
    template: `
    <vd-component class="vd playlist-enduser-one" type="playlist-enduser-one">
        <div class="modal fade addPlaylist p-0" id="addPlaylist" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog"
        aria-labelledby="deletehistoryLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md" role="document">
                <div class="modal-content">
                    <div :class="['modal-body', contentDetails?.isListing === false ? 'pb-0' : '']" >
                        <div class="topHeading-div d-flex justify-content-between">
                            <div class="thd-left">
                                {{ contentDetails?.playlist_uuid ? i18n("Edit Playlist") : i18n("Add Playlist") }}
                            </div>
                            <span class="close-model close thd-right d-flex align-items-center" data-dismiss="modal" @click="closeModal">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15 5L5 15" stroke="#7F8286" stroke-width="1.25" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                    <path d="M5 5L15 15" stroke="#7F8286" stroke-width="1.25" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg>
                            </span>
                        </div>
                        <section class="body-section hAuto w-100">
                            <!--<p style="color:#ffffont-size: small;">{{enduser_playlist}}</p>-->
                            <p class="d-none" style="color:#fff;font-size: small;" v-if="contentDetails?.isListing !== false">{{ checkedValues.length ? checkedValues : 'No Values' }}</p>
                            <p :class="['noPlaylist', hideNoPlaylist ? 'd-none' : '']" v-if="!enduser_playlist">
                                {{i18n("You haven't created any playlist yet, create playlist now and let it groove.")}}
                            </p>
                            <div :class="['dynamicPlaylist', hideDynamicPlaylist ? 'd-none' : '']" v-else>
                                <div class="playlistItems" v-for="(plist, index) in enduser_playlist.content_list" :key="plist.content_uuid">
                                    <div class="pli-child">
                                        <div class="plic-left">
                                            <div class="checkbox-button">
                                                <input type="checkbox" :id="'checkbox_'+plist.content_uuid" name="total" :value="plist.content_uuid" v-model="checkedValues">
                                                <label :for="'checkbox_'+plist.content_uuid" class="checkbox-label blue"></label>
                                            </div>
                                        </div>
                                        <label :for="'checkbox_'+plist.content_uuid" class="w-100 m-0" style="cursor:pointer;">
                                            <div class="plic-right">
                                                <div class="plicr-left">
                                                    <span class="plicrl-plName">{{formatText(plist.content_name)}}</span>
                                                    <span class="plicrl-plCreateDate">{{formatDate(plist.content_created_date)}}</span>
                                                </div>
                                                <div class="plicr-right">
                                                    <span class="plicrr-plCount">{{plist.playlist_size}} {{plist.content_asset_type === 1 ? 'Video(s)' : 'Audio(s)'}}</span>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <div class="playlistItems pt-3" v-if="total_count > enduser_playlist?.content_list?.length">
                                    <div class="plic-left">
                                        <button class="loadMore" @click="loadMore">
                                            <span class="pa-icon d-flex">
                                                <img src=${rootUrl}img/playlist-icon.png style="width: 14px;">                           
                                            </span>
                                                Load More
                                        </button>
                                    </div>
                                </div>
                                <div class="playlistItems pt-3 d-none" v-else-if="enduser_playlist?.content_list?.length > 10">
                                    <span class="pa-icon d-flex white-color samll-content">
                                        {{i18n("No more playlists to show")}}!                         
                                    </span>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div :class="['modal-footer', footerPadding ? 'pb-5' : '']">
                        <div class="cpinput">
                            <button type="button" :class="['btn cnplaylist', hideCnPlaylist ? 'd-none' : '', disableCnPlaylist ? 'disabled' : '']" @click="!disableCnPlaylist ? createPlaylistForm() : null">
                                <span class="d-flex">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 3.33203V12.6654" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M3.33594 8H12.6693" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </span> {{i18n("Create new playlist")}}
                            </button>
                            <div :class="['cpinput-div', hideCpinputDiv ? 'd-none' : '']">
                                <div :class="['selectList', invalidPlaylistType ? 'has-invalid' : '']">
                                    <select class="selectpicker no-check" placeholder="Type" id="drpContentType" v-model="playlist_type" name="playlist_type" ref="drpContentType" :disabled="disableDrpContentType">
                                        <option value="0" selected class="d-none">Type</option>
                                        <option value="2" 
                                            data-content="<div class='type-wrapper d-flex align-items-center gap-8'>
                                                <img src=${rootUrl}img/type-audio.png class='img-fluid'> 
                                                <span>Audio</span></div>" v-if="store_content_type === 'All' || store_content_type === 'Audio'">
                                        </option>
                                        <option value="1" 
                                            data-content="<div class='type-wrapper d-flex align-items-center gap-8'>
                                                <img src=${rootUrl}img/type-video.png class='img-fluid'> 
                                                <span>Video</span></div>" v-if="store_content_type === 'All' || store_content_type === 'Video'">
                                        </option>
                                    </select>
                                    <div class="invalid-feedback position-absolute type-err-msg" style="left: 25px; bottom: 25px;">{{errors.playlist_type}}</div>
                                </div>
                                <div>
                                    <input type="text" v-model.trim="playlist_name" name="playlist_name" :class="['form-control playlistName-input', invalidPlaylistName ? 'is-invalid' : '']" aria-label="playlistName" placeholder="Playlist Name" autocomplete="off">
                                    <div class="invalid-feedback position-absolute" style="left: 25px; bottom: 7px;">{{errors.playlist_name}}</div>
                                </div>
                            </div>
                        </div>
                        <div class="btnCreateSave">
                            <button type="button" class="btn btnCreatePlaylist" v-bind:class="{'d-none': hideBtnCreatePlaylist == true}" id="createPlaylist" @click="createPlayList">
                                {{ contentDetails?.playlist_uuid ? i18n("Update") : i18n("Create") }}
                            </button>
                            
                            <button type="button" :class="['btn btnSavePlaylist', disableBtnSavePlaylist ? 'disabled' : '', hideBtnSavePlaylist ? 'd-none' : '']" @click="mapToPlaylist" id="savePlaylist" :disabled="disableBtnSavePlaylist">{{i18n("Save")}}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Playlist added start Here-->
        <div class="modal fade playlistadded-success p-0" id="playlistAddedSuccess" tabindex="-1" role="dialog"
        aria-labelledby="playlistAdded" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="success-div d-flex">
                            <div class="sd-left">
                                <span class="sdl-message">Successfully added to your playlist</span>
                                <a href="#" class="sdl-undo">Undo</a>
                            </div>
                            <span class="close-model sd-right d-flex align-items-center" data-dismiss="modal" data-bs-dismiss="modal">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M11.4138 9.99985L17.7069 3.70685C17.8944 3.51934 17.9997 3.26503 17.9997 2.99985C17.9997 2.73467 17.8944 2.48036 17.7069 2.29285C17.5193 2.10534 17.265 2 16.9998 2C16.7347 2 16.4804 2.10534 16.2928 2.29285L9.99985 8.58585L3.70685 2.29285C3.614 2.2 3.50378 2.12636 3.38247 2.07611C3.26117 2.02586 3.13115 2 2.99985 2C2.86855 2 2.73853 2.02586 2.61722 2.07611C2.49592 2.12636 2.38569 2.2 2.29285 2.29285C2.10534 2.48036 2 2.73467 2 2.99985C2 3.26503 2.10534 3.51934 2.29285 3.70685L8.58585 9.99985L2.29285 16.2928C2.10534 16.4804 2 16.7347 2 16.9998C2 17.265 2.10534 17.5193 2.29285 17.7069C2.48036 17.8944 2.73467 17.9997 2.99985 17.9997C3.26503 17.9997 3.51934 17.8944 3.70685 17.7069L9.99985 11.4138L16.2928 17.7069C16.3855 17.8 16.4957 17.874 16.617 17.9244C16.7383 17.9749 16.8684 18.0009 16.9998 18.0009C17.1313 18.0009 17.2614 17.9749 17.3827 17.9244C17.504 17.874 17.6142 17.8 17.7069 17.7069C17.7998 17.6141 17.8735 17.5039 17.9238 17.3825C17.9742 17.2612 18 17.1312 18 16.9998C18 16.8685 17.9742 16.7385 17.9238 16.6172C17.8735 16.4958 17.7998 16.3856 17.7069 16.2928L11.4138 9.99985Z"
                                    fill="white" />
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Playlist added End Here-->
    </vd-component>
    `,
    props: {
        contentDetails: Object
    },
    directives: {
        tooltip: TooltipDirective
    },
    data() {
        return {
            tempId: '',
            isCheckedFirst: false,
            pageNo: 1,
            hideLoadMore: true,
            total_count: 0,
            selectedIndex: 0,
            rootUrl: getRootUrl(),
            hideCnPlaylist: false,
            disableCnPlaylist: false,
            hideDynamicPlaylist: true,
            hideBtnCreatePlaylist: true,
            disableBtnSavePlaylist: true,
            hideBtnSavePlaylist: false,
            hideCpinputDiv: true,
            hideNoPlaylist: false,
            playlist_type: this.contentDetails?.content_asset_type,
            disableDrpContentType: this.contentDetails?.content_asset_type ? true : false,
            playlist_name: this.contentDetails?.isListing === false ? this.contentDetails?.playlist_name : '',
            isFormValid: false,
            errors: {},
            isReset:false,
            invalidPlaylistType: false,
            invalidPlaylistName: false,
            footerPadding: false,
            checkedValues: [],
            savedValues: [],
            removeValues: []
        }
    },
    computed: {
        ...mapState({
            current_content_uuid: state => state.current_content_uuid,
            store_content_type: (state) => state.store_content_type,
            enduser_playlist: function (state) {
                const vm = this;
                // console.log('vm', vm);
                // console.log('vm.contentDetails?.isListing', vm.contentDetails?.isListing);
                // return state.enduser_playlist
                if(vm.contentDetails?.isListing !== false || vm.contentDetails?.isListing === undefined) {
                    this.total_count = state.enduser_playlist ? state.enduser_playlist?.page_info?.total_count : 0;
                    return state.enduser_playlist;
                } else {
                    vm.hideNoPlaylist = true;
                    return null;
                }
                // return vm.contentDetails?.isListing !== false ? state.enduser_playlist : null
            }
        }),
        // 87419 Raj
        ...mapGetters({
            will_show_apply_promocode: 'is_promotion_enabled',
            //is_third_party_gateway: 'is_third_party_gateway',
        }),
    },
    watch: {
        playlist_type: function (value) {
            // var value=this.name;
            if(value && !this.isReset){
                this.validatePlaylistType(value);
            }
        },
        playlist_name: function (value) {
            // var value=this.name;
            // console.log('watch value', value);
            if(value && !this.isReset){
                this.validatePlaylistName(value);
            }
        },
        checkedValues: function(value) {
            console.log('checkedValues', value.length);
            console.log('checkedValues', value);
            this.removeValues = this.savedValues.filter(x => !this.checkedValues.includes(x));
            console.log('removeValues', this.removeValues);
            // this.playlist_type = 0;
            this.errors.playlist_type = null;
            this.errors.playlist_name = null;
            this.footerPadding = false;
            // if(this.contentDetails.content_asset_type === 0) {
            //     this.playlist_type = 0;
            //     $("#drpContentType option:first").attr('selected','selected');
            // }
            // jQuery(this.$refs.drpContentType).selectpicker('refresh');
            jQuery(this.$refs.drpContentType).selectpicker();
            if(value.length) {
                this.hideCnPlaylist = false;
                // this.disableCnPlaylist = true;
                this.hideCpinputDiv = true;
                this.hideBtnCreatePlaylist = true;
                this.hideBtnSavePlaylist = false;
                this.disableBtnSavePlaylist = false;
            } else {
                this.hideCnPlaylist = false;
                // this.disableCnPlaylist = false;
                this.hideCpinputDiv = true;
                this.hideBtnCreatePlaylist = true;
                this.hideBtnSavePlaylist = false;
                this.disableBtnSavePlaylist = this.removeValues.length ? false : true;
            }
        }
    },
    async beforeMount() {
        if (localStorage.getItem('isloggedin')) {

        }
    },
    async mounted() {
        if (localStorage.getItem('isloggedin')) {
            $('[data-toggle="tooltip"]').tooltip();
            console.log('playlist_name', this.playlist_name);
            console.log('playlist_type', this.playlist_type);
            console.log('this.contentDetails', this.contentDetails);
            console.log('this.enduser_playlist', this.enduser_playlist);
            console.log('this.content_uuid', this.contentDetails.content_uuid);
            // this.checkedValues.push('6335bb028a5e41ba940baece78c51904');
            // this.disableDrpContentType = this.contentDetails?.content_asset_type ? true : false;
            if(this.contentDetails?.isListing === false) {
                this.createPlaylistForm();
            }
            this.markMappedPlaylist();
            this.hideDynamicPlaylist = this.enduser_playlist ? false : true;
            // this.hideNoPlaylist = this.enduser_playlist ? true : false;
            // if(this.contentDetails?.isListing === false) {
            //     this.hideNoPlaylist = true;
            // }
            console.log('MOUNTEDDDDDDDDDDDDDDDDDDDDDDDDDDDDD', this.enduser_playlist);
            console.log('this.hideNoPlaylist', this.hideNoPlaylist);
        }
    },
    methods: {
        i18n,
        getRootUrl,
        markMappedPlaylist() {
            // console.log('LIST', this.enduser_playlist.content_list);
            // console.log('content_uuid', this.contentDetails.content_uuid);
            if(this.enduser_playlist) {
                const pl_list = this.enduser_playlist.content_list;
                for(let i=0; i<pl_list?.length; i++) {
                    let pl_cont_list = pl_list[i].playlist_content_list;
                    for(let j=0; j<pl_cont_list?.length; j++) {
                        if(!this.checkedValues.includes(pl_list[i].content_uuid) && pl_cont_list[j].content_uuid === this.contentDetails.content_uuid) {
                            this.checkedValues.push(pl_list[i].content_uuid);
                            this.savedValues.push(pl_list[i].content_uuid);
                            break;
                        }
                    }
                }
            }
        },
        async loadMore() {
            // console.log('loadmore called');
            // console.log('this.pageNo', this.pageNo);
            // console.log('this.enduser_playlist', this.enduser_playlist);
            // console.log(this.enduser_playlist?.content_list?.length);
            // console.log('total', this.total_count);
            try {
                JsLoader.show();
                if (this.enduser_playlist && this.enduser_playlist?.content_list?.length < this.total_count) {
                    // console.log('called 123');
                    this.pageNo++;
                    this.contentDetails.page = this.pageNo;
                    await this.$store.dispatch(GET_ENDUSER_PLAYLIST, this.contentDetails);
                    this.markMappedPlaylist();
                }
            } catch(error) {
                // console.error("Something went wrong!", error.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: error.message,
                });
            }
            JsLoader.hide();
        },
        closeModal() {
            // console.log('Close Modal');
            // if (document.getElementById('drpContentType')) {
            //     document.getElementById('drpContentType').selectedIndex = 0;
            // }
            setTimeout(() => {
                // jQuery(this.$refs.drpContentType).selectpicker('refresh');
                jQuery(this.$refs.drpContentType).selectpicker();
            }, 100);
            // this.playlist_type = 0;
            this.hideCnPlaylist = false;
            this.hideCpinputDiv = true;
            this.errors.playlist_type = null;
            this.errors.playlist_name = null;
            this.hideBtnCreatePlaylist = true;
            this.hideBtnSavePlaylist = false;
            this.disableBtnSavePlaylist = true;
            this.footerPadding = false;
            this.checkedValues = [];
            this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, false);
        },
        createPlaylistForm() {
            // console.log('Hiiii');
            this.hideCnPlaylist = true;
            this.hideCpinputDiv = false;
            
            this.hideBtnSavePlaylist = true;
            this.hideBtnCreatePlaylist = false;
            // this.playlist_type = 0;
            // $("#drpContentType option:first").attr('selected','selected');
            if(this.contentDetails.content_asset_type === 0) {
                if(this.store_content_type == 'All' || this.store_content_type == 'Audio') {
                    this.playlist_type = 2;
                } else if(this.store_content_type == 'All' || this.store_content_type == 'Video') {
                    this.playlist_type = 1;
                } else {
                    this.playlist_type = 0;
                } 
                this.playlist_name = '';
                // $("#drpContentType option:first").attr('selected','selected');
                $('#drpContentType option:eq(1)').attr('selected', 'selected');
            }
            // jQuery(this.$refs.drpContentType).selectpicker('refresh');
            jQuery(this.$refs.drpContentType).selectpicker();
        },
        validatePlaylistType(value) {
            // console.log('selected value', value);
            if (value === 0) {
                this.isFormValid = false;
                this.errors.playlist_type = i18n("The Playlist Type field is required.");
                this.invalidPlaylistType = true;
                $(".type-err-msg").css("display", "block");
                return false;
            } else {
                $(".type-err-msg").css("display", "none");
                this.errors.playlist_type = null;
                this.invalidPlaylistType = false;
                if (
                    this.errors.playlist_name !== undefined &&
                    this.errors.playlist_name == null &&
                    this.errors.playlist_type !== undefined &&
                    this.errors.playlist_type == null
                ) {
                    this.isFormValid = true;
                    this.footerPadding = false;
                }
            }
        },
        validatePlaylistName(value) {
            // console.log('validate text value', value);
            if (!value.length) {
                this.isFormValid = false;
                this.errors.playlist_name = i18n("The Playlist Name field is required.");
                this.invalidPlaylistName = true;
            } else if (!value.match(/^[a-z\d\s]+$/i)) {
                this.isFormValid = false;
                this.invalidPlaylistName = true;
                this.errors.playlist_name = i18n("The Playlist Name field must contains only alphanumeric.");
            } else if (value.length < 3 || value.length > 50) {
                this.isFormValid = false;
                this.errors.playlist_name = i18n("The Playlist Name should be between 3 to 50 charaters.");
                this.invalidPlaylistName = true;
            } else {
                this.errors.playlist_name = null;
                this.invalidPlaylistName = false;
                if (
                    this.errors.playlist_name !== undefined &&
                    this.errors.playlist_name == null &&
                    this.errors.playlist_type !== undefined &&
                    this.errors.playlist_type == null
                ) {
                    this.isFormValid = true;
                    this.footerPadding = false;
                }
            }
        },
        async createPlayList() {
            // console.log('Hiiii 123');
            // console.log('this.playlist_type', this.playlist_type);
            console.clear();
            console.log(this.contentDetails.playlist_name);
            console.log(this.playlist_name);
            // console.log(this.$refs.plName.value);
            // return false;
            this.validatePlaylistType(this.playlist_type);
            this.validatePlaylistName(this.playlist_name);
            // console.log('errors', this.errors);
            // console.log('isFormValid', this.isFormValid);
            if (this.errors.playlist_type || this.errors.playlist_name || this.isFormValid == false) {
                // console.log('Validate Failed');
                this.footerPadding = true;
                return false;
            }
            // console.log('Validate Success');
            // console.log(this.playlist_type);
            // console.log(this.playlist_name);
            //CALL CREATE PLAYLIST API
            await this.savePlaylist();
        },
        async savePlaylist() {
            console.log('1233333333333');
            JsLoader.show();
            try {
                let add_edit_resp;
                if(this.contentDetails?.isListing === false && this.contentDetails?.playlist_uuid) {
                    if(this.playlist_name === this.contentDetails?.playlist_name) {
                        Toast.fire({
                            icon: "info",
                            title: "Validation Failed",
                            text: 'No changes made in the playlist name to update'
                        });
                        JsLoader.hide();
                        return false;
                    }
                    const postedData = {
                        "playlist_name": this.playlist_name,
                        "playlist_type": this.playlist_type,
                        "account_type": 2,
                        "playlist_uuid": this.contentDetails.playlist_uuid
                    };
                    console.log('postedData Edit', postedData);
                    add_edit_resp = await editEnduserPlaylist(postedData);
                } else {
                    const postedData = {
                        "playlist_name": this.playlist_name,
                        "playlist_type": this.playlist_type,
                        "account_type": 2
                    };
                    console.log('postedData Add', postedData);
                    add_edit_resp = await addEnduserPlaylist(postedData);
                }
                
                // console.log(add_edit_resp);
                if (add_edit_resp.data.code === 200 && add_edit_resp.data.status === "SUCCESS") {
                    this.$emit('reset-page', 1);
                    this.pageNo = 1;
                    this.playlist_name = '';
                    this.footerPadding = false;
                    this.hideBtnCreatePlaylist = this.contentDetails?.isListing === false ? false : true;
                    this.hideCpinputDiv = this.contentDetails?.isListing === false ? false : true;
                    this.hideDynamicPlaylist = false;
                    this.hideCnPlaylist = this.contentDetails?.isListing === false ? true : false;
                    jQuery(this.$refs.drpContentType).selectpicker();
                    
                    const succ_msg = this.contentDetails?.playlist_uuid ? i18n("Playlist updated successfully") : i18n("Playlist added successfully");

                    Toast.fire({
                        icon: "success",
                        title: "Success",
                        text: succ_msg
                    });

                    if(this.contentDetails?.isListing !== false) {
                        console.log('11111111111111111111111');
                        this.disableBtnSavePlaylist = true;
                        this.hideBtnSavePlaylist = false;
                        this.contentDetails.page = this.pageNo;
                        this.isCheckedFirst = true;
                        await this.$store.dispatch(GET_ENDUSER_PLAYLIST, this.contentDetails);
                        // this.checkedValues = [];
                        // console.clear();
                        // console.log(this.enduser_playlist);
                        // console.log('this.savedValues', this.savedValues);
                        if(this.enduser_playlist) {
                            // console.log('Pushed', this.enduser_playlist?.content_list?.[0]?.content_uuid);
                            const tempIndex = this.checkedValues.indexOf(this.tempId);
                            if (tempIndex > -1) { 
                                this.checkedValues.splice(tempIndex, 1);
                            }
                            this.checkedValues.push(this.enduser_playlist?.content_list?.[0]?.content_uuid);
                            this.tempId = this.enduser_playlist?.content_list?.[0]?.content_uuid;
                            // if(this.enduser_playlist?.content_list?.length > 1 && this.checkedValues?.length > 1 && !this.savedValues.includes(this.enduser_playlist?.content_list?.[1]?.content_uuid)) {
                            //     this.checkedValues.splice(-2, 1);
                            // }
                            this.disableBtnSavePlaylist = false;
                            this.isCheckedFirst = false;
                        }
                        console.log('this.checkedValues', this.checkedValues);
                    } else {
                        const params = {
                            content_asset_type: '',
                            page: this.pageNo
                        };
                        await this.$store.dispatch(GET_ENDUSER_PLAYLIST, params);
                    }
                } else {
                    Toast.fire({
                        icon: "error",
                        title: "Error",
                        text: add_edit_resp.data.message,
                    });
                }
            } catch (error) {
                // console.error("Something went wrong!", error.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: error.message,
                });
            }
            if(this.contentDetails?.isListing === false) {
                this.closeModal();
            }
            JsLoader.hide();
        },
        async mapToPlaylist() {
            console.log('Map To Playlist');
            JsLoader.show();
            // return false;
            try {
                let removeMessage = '';
                let remove_resp;
                if(this.removeValues.length) {
                    const removePayload = {
                        "playlist_items": [this.contentDetails?.content_uuid],
                        "playlist_uuid": this.removeValues.join(','),
                        "account_type": 2
                    }
                    remove_resp = await removeContentFromPlaylist(removePayload);
                    console.log('remove_resp', remove_resp);
                    if (remove_resp.data.code === 200 && remove_resp.data.status === "SUCCESS") {
                        removeMessage = ' and ' + remove_resp.data.message;
                        // Toast.fire({
                        //     icon: "success",
                        //     text: remove_resp.data.message,
                        // });
                        // await this.$store.dispatch(GET_ENDUSER_PLAYLIST, this.contentDetails);
                    } else {
                        removeMessage = ' and some ' + remove_resp.data.message;
                        // Toast.fire({
                        //     icon: "error",
                        //     text: remove_resp.data.message,
                        // });
                    }
                }
                if(this.checkedValues.length) {
                    const mapPayload = {
                        "playlist_content_uuid": this.contentDetails?.content_uuid,
                        "playlist_parent_uuid": this.checkedValues.join(','),
                        "account_type": 2
                    };
                    console.log('Map Payload', mapPayload);
                    const mapRes = await mapContentToPlaylist(mapPayload);
                    if (mapRes?.data?.code === 200 && mapRes?.data?.status === "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: "Success",
                            text: mapRes.data.message + removeMessage
                        });
                        // await this.$store.dispatch(GET_ENDUSER_PLAYLIST, this.contentDetails);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: "Error",
                            text: mapRes?.data?.message + removeMessage,
                        });
                    }
                } else {
                    if(removeMessage) {
                        if (remove_resp?.data?.code === 200 && remove_resp?.data?.status === "SUCCESS") {
                            Toast.fire({
                                icon: "success",
                                title: "Success",
                                text: remove_resp?.data?.message
                            });
                        } else {
                            Toast.fire({
                                icon: "error",
                                title: "Error",
                                text: remove_resp?.data?.message,
                            });
                        }
                    }
                }
            } catch(err) {
                // console.error("Something went wrong!", err.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: err.message,
                });
            }
            this.closeModal();
            JsLoader.hide();
        },
        formatDate(inputDate) {
            const local = moment.utc(inputDate).local();
            const dstr = moment(local).format('Do MMMM, YYYY');
            // console.log('Created on '+dstr);
            return 'Created on '+dstr;
        },
        formatText(inputText) {
            return inputText.length > 16 ? inputText.substring(0, 16) + '..' : inputText;
        },
    },
}
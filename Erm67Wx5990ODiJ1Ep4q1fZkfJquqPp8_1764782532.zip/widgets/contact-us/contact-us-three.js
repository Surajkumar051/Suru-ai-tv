let {
    contactUs,
    validateStoreAdminToken,
} = await import(window.importAssetJs('js/webservices.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));

export default {
    name: "contact_us_three",

    data() {
        return {
            fname: "",
            lname: "",
            end_contact_email: "",
            end_contact_message: "",
            phone_no: "",
            isReset:false,
            isFormValid: false,
            errors: {},
            emailFieldNotValidate: false,
            messageFieldNotValidate: false,
            nameFiledNotValidate: false,
            phoneFieldNotValidate: false,
            store_email: "",
            lnameFiledNotValidate: false,
        };
    },
    watch: {
        fname: function (value) {
            // var value=this.name;
           if(value && !this.isReset){
            this.validateFname(value);
            }
          
           },
        lname: function (value) {
             if(value && !this.isReset){
            this.validateLname(value);
             }
        },
        end_contact_message: function (value) {
             if(value && !this.isReset){
            this.validateMessage(value);
             }
        },
        end_contact_email: function (value) {
             if(value && !this.isReset){
            // var value=this.email;
            this.validateEmail(value);
             }
        },
        phone_no: function (phone_number) {
              
             if(phone_number && !this.isReset){
            this.validatePhone(phone_number);
             }
        },

    },
    methods: {
        i18n,
        validateLname(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.lname = i18n("Last Name field is required");
                
                this.lnameFiledNotValidate = true;
               
            } else if (!value.match(/^[a-zA-Z ]+$/)) {
                this.errors.valid = false;
                this.lnameFiledNotValidate = true;
                this.errors.lname =
                   i18n("The Last Name field contains only alphabets");
            } else if (value.length < 2 || value.length > 15) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.lname =
                    i18n("Last Name should be between 2 to 15 charaters");
                this.lnameFiledNotValidate = true;
            } else {
                this.errors.lname = null;
                this.lnameFiledNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                )
                    this.errors.valid = true;
                this.isFormValid = true;
            }
        },
        validateMessage(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_message = i18n("Message field is required");
                this.messageFieldNotValidate = true;
            } else if (value.length < 2) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_message =
                    i18n("Message should be between (2-250) characters");
                this.messageFieldNotValidate = true;
            } else if (value.length > 250) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_message =
                    i18n("Message should be between (2-250) characters");
                this.messageFieldNotValidate = true;
            } else {
                this.errors.end_contact_message = null;
                this.messageFieldNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                )
                    this.errors.valid = true;
                this.isFormValid = true;
            }
        },
        validateEmail(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_email = i18n("Email field is required");
                this.emailFieldNotValidate = true;
            } else if (!this.checkEmail(value)) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_email = i18n("Please enter a valid email");
                this.emailFieldNotValidate = true;
            } else {
                this.errors.end_contact_email = null;
                this.emailFieldNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        validatePhone(phone_number) {
            if (!phone_number.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.phone_no = i18n("Phone number is required");
                this.phoneFieldNotValidate = true;
                //return;
                // ^(?!0+$)[0-9+\\s-()/]{4,20}$|^$
            } else if (!this.checkMobileNum(phone_number)) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.phone_no =
                    i18n("Please enter a valid phone number with country code");
                this.phoneFieldNotValidate = true;
            } else {
                this.errors.phone_no = null;
                this.phoneFieldNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        validateFname(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.fname = i18n("First Name field is required");
                this.nameFiledNotValidate = true;
            } else if (!value.match(/^[a-zA-Z ]+$/)) {
                this.errors.valid = false;
                this.nameFiledNotValidate = true;
                this.errors.fname =
                    i18n("The First Name field contains only alphabets");
            } else if (value.length < 2 || value.length > 15) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.fname =
                    i18n("First Name should be between 2 to 15 charaters");
                this.nameFiledNotValidate = true;
            } else {
                this.errors.fname = null;
                this.nameFiledNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                )
                    this.errors.valid = true;
                this.isFormValid = true;
            }
        },

        submitForm(e) {
            console.log(this.errors);
            const formData = new FormData(e.target);
            const formProps = Object.fromEntries(formData);
            this.validateFname(this.fname);
            this.validateLname(this.lname);
            this.validatePhone(this.phone_no);
            this.validateMessage(this.end_contact_message);
            this.validateEmail(this.end_contact_email);
            if (!formProps.reason) {
                $(".custom-select").addClass("has-invalid");
                $(".reason-err-msg").css("display", "block");
                return false;
            } else {
                $(".reason-err-msg").css("display", "none");
            }
            if (
                this.errors.fname ||
                this.errors.lname ||
                this.errors.end_contact_email ||
                this.errors.end_contact_message ||
                this.errors.phone_no ||
                this.isFormValid == 0
            ) {
                return false;
            }
            $(".reason-err-msg").css("display", "none");
            let userData = {
                first_name: this.fname,
                last_name: this.lname,
                phone: this.phone_no,
                email: this.end_contact_email,
                message: this.end_contact_message,
                store_email: this.store_email,
                reason: formProps.reason,
            };

            contactUs(userData)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        console.log("contactUs", res.data);
                        Toast.fire({
                            icon: "success",
                            text: res.data.message,
                        });
                        this.clearFormData();
                         this.errors = [];
                        setTimeout(() => {
                            
                           this.isReset = false;
                           
                        }, 2000);
                       
                         
                    } else {
                        Toast.fire({
                            icon: "error",
                            text: "Something went wrong",
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                    // //JsLoadingOverlay.hide();
                });
        },
        checkMobileNum(str) {
            var contactformat = true;
            let filter = /^\+[1-9]{1}[0-9]{10,20}$/;
            if (!filter.test(str)) {
                contactformat = false;
            } else {
                contactformat = true;
            }
            return contactformat;
        },
        checkEmail(str) {
            var emailformat = true;
            let filter =
                /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if (!filter.test(str)) {
                emailformat = false;
            } else {
                emailformat = true;
            }
            return emailformat;
        },

        submitContactusData(e) {},
        clearFormData: function () {
            (this.fname = ""),
                (this.lname = ""),
                (this.end_contact_email = ""),
                (this.end_contact_message = ""),
                (this.phone_no = "");
            $(".select-selected").html(i18n("Select"));
              $("#contact-reason").val('default').selectpicker("refresh");
              $('#contact-reason').selectpicker('destroy');
              $("#contact-reason").prop("selectedIndex", 0).val();
              this.isReset=true;

        },
       
    },
    mounted() {
        //@ER: 92989 Start
        document.querySelectorAll('.select-selected').forEach(function(el) {
            el.remove()
        });
        document.querySelectorAll('.select-items,.select-hide').forEach(function(el) {
            el.remove()
        });
        //@ER: 92989 End
        validateStoreAdminToken().then((res) => {
            // if (res.data.code === 200 && res.data.email !== null) {
            this.store_email = res.data.email;
            console.log(this.store_email, "dataaaaaaa");
            // }
        });

        var x, i, j, l, ll, selElmnt, a, b, c;
        /*look for any elements with the class "custom-select":*/
        x = document.getElementsByClassName("custom-select");
        l = x.length;
        for (i = 0; i < l; i++) {
            selElmnt = x[i].getElementsByTagName("select")[0];
            ll = selElmnt.length;
            /*for each element, create a new DIV that will act as the selected item:*/
            a = document.createElement("DIV");
            a.setAttribute("class", "select-selected");
            a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
            x[i].appendChild(a);
            /*for each element, create a new DIV that will contain the option list:*/
            b = document.createElement("DIV");
            b.setAttribute("class", "select-items select-hide");
            for (j = 1; j < ll; j++) {
                /*for each option in the original select element, create a new DIV that will act as an option item:*/
                c = document.createElement("DIV");
                c.innerHTML = selElmnt.options[j].innerHTML;
                c.setAttribute("aria-label", "error-contact-reason");
                c.addEventListener("click", function (e) {
                    /*when an item is clicked, update the original select box, and the selected item:*/
                    var y, i, k, s, h, sl, yl;
                    s =
                        this.parentNode.parentNode.getElementsByTagName(
                            "select"
                        )[0];
                    sl = s.length;
                    h = this.parentNode.previousSibling;
                    for (i = 0; i < sl; i++) {
                        if (s.options[i].innerHTML == this.innerHTML) {
                            s.selectedIndex = i;
                            h.innerHTML = this.innerHTML;
                            y =
                                this.parentNode.getElementsByClassName(
                                    "same-as-selected"
                                );
                            yl = y.length;
                            for (k = 0; k < yl; k++) {
                                y[k].removeAttribute("class");
                            }
                            this.setAttribute("class", "same-as-selected");
                            break;
                        }
                    }
                    h.click();

                    document.getElementById(
                        e.target.getAttribute("aria-label")
                    ).style.display = "none";
                });
                b.appendChild(c);
            }
            x[i].appendChild(b);
            a.addEventListener("click", function (e) {
                /*when the select box is clicked, close any other select boxes, and open/close the current select box:*/
                e.stopPropagation();
                closeAllSelect(this);
                $(".reason-err-msg").css("display", "none");
                this.nextSibling.classList.toggle("select-hide");
                this.classList.toggle("select-arrow-active");
            });
        }
        function closeAllSelect(elmnt) {
            /*a function that will close all select boxes in the document, except the current select box:*/
            var x,
                y,
                i,
                xl,
                yl,
                arrNo = [];
            x = document.getElementsByClassName("select-items");
            y = document.getElementsByClassName("select-selected");
            xl = x.length;
            yl = y.length;
            for (i = 0; i < yl; i++) {
                if (elmnt == y[i]) {
                    arrNo.push(i);
                } else {
                    y[i].classList.remove("select-arrow-active");
                }
            }
            for (i = 0; i < xl; i++) {
                if (arrNo.indexOf(i)) {
                    x[i].classList.add("select-hide");
                }
            }
        }
        /*if the user clicks anywhere outside the select box, then close all select boxes:*/
        document.addEventListener("click", closeAllSelect);
       
        $(".reason-err-msg").css("display", "none");
    },
    template: `<vd-component class="vd contact-us-three" type="contact-us-three">

    <!--================================================================
                        CONTENT AREA START 
    ==================================================================-->
    <div class="contact-wrapper">
        <div class="container-fluid max">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-heading">
                        <span vd-node="text"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></span>
                        <h2><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h2>
                    </div>
                    <p><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></p>
                    <ul>
                        <li>
                            <div class="icon-group">
                                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.0002 24.4999C12.5266 23.243 11.1607 21.865 9.91683 20.3804C8.05016 18.1509 5.8335 14.8306 5.8335 11.6666C5.83184 8.36207 7.82178 5.38223 10.8747 4.11757C13.9277 2.85291 17.4419 3.55272 19.7775 5.89044C21.3134 7.41948 22.1737 9.49939 22.1669 11.6666C22.1669 14.8306 19.9502 18.1509 18.0835 20.3804C16.8396 21.865 15.4737 23.243 14.0002 24.4999ZM14.0002 5.83327C10.7801 5.83713 8.17069 8.44654 8.16683 11.6666C8.16683 13.0269 8.78166 15.3824 11.7077 18.8836C12.4288 19.7447 13.194 20.5679 14.0002 21.3499C14.8064 20.5688 15.5719 19.7468 16.2938 18.8871C19.2187 15.3813 19.8335 13.0258 19.8335 11.6666C19.8296 8.44654 17.2202 5.83713 14.0002 5.83327ZM14.0002 15.1666C12.0672 15.1666 10.5002 13.5996 10.5002 11.6666C10.5002 9.73361 12.0672 8.1666 14.0002 8.1666C15.9332 8.1666 17.5002 9.73361 17.5002 11.6666C17.5002 12.5949 17.1314 13.4851 16.475 14.1415C15.8187 14.7979 14.9284 15.1666 14.0002 15.1666Z" fill="url(#paint0_linear_366_4686)"/>
                                    <defs>
                                    <linearGradient id="paint0_linear_366_4686" x1="5.8335" y1="3.49561" x2="26.9307" y2="10.8682" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#09C6F9"/>
                                    <stop offset="1" stop-color="#045DE9"/>
                                    </linearGradient>
                                    </defs>
                                </svg>                                                                       
                            </div>
                            <div class="text-group">
                                <span vd-node="text"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></span>
                                <p><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></p>
                            </div>
                        </li>
                        <li>
                            <div class="icon-group">
                                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20.5277 24.5069H20.4951C16.0131 24.3966 11.7361 22.607 8.51107 19.4926C5.39551 16.2705 3.60488 11.9951 3.49427 7.51441C3.48767 6.88674 3.73411 6.28283 4.17807 5.83908L7.3444 2.67508C7.79999 2.21963 8.53849 2.21963 8.99407 2.67508L13.6607 7.34175C14.1162 7.79733 14.1162 8.53583 13.6607 8.99141L11.7987 10.8499C12.1441 12.1402 12.7802 13.3342 13.6584 14.3406C14.663 15.2191 15.8555 15.8556 17.1444 16.2014L19.0111 14.3417C19.4667 13.8863 20.2052 13.8863 20.6607 14.3417L25.3274 19.0084C25.7828 19.464 25.7828 20.2025 25.3274 20.6581L22.1611 23.8232C21.7293 24.2595 21.1415 24.5055 20.5277 24.5069ZM8.1669 5.15075H8.16107L5.82774 7.48875C5.92287 11.3605 7.46845 15.0554 10.1584 17.8417C12.9449 20.5308 16.639 22.0762 20.5102 22.1724L22.8517 19.8332L19.8277 16.8174L18.3192 18.3247C18.1034 18.543 17.8095 18.666 17.5026 18.6666C17.4206 18.6666 17.3389 18.658 17.2587 18.6409C15.3146 18.2109 13.5095 17.2999 12.0087 15.9914C10.7003 14.4906 9.78928 12.6855 9.35924 10.7414C9.27811 10.355 9.39796 9.95372 9.67774 9.67508L11.1851 8.16658L8.1669 5.15075Z" fill="url(#paint0_linear_366_4684)"/>
                                    <defs>
                                    <linearGradient id="paint0_linear_366_4684" x1="3.49414" y1="2.3335" x2="30.2334" y2="14.3508" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#09C6F9"/>
                                    <stop offset="1" stop-color="#045DE9"/>
                                    </linearGradient>
                                    </defs>
                                </svg>                                                                                                          
                            </div>
                            <div class="text-group">
                                <span vd-node="text"><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></span>
                                <a class="callByAjax" :href="'tel:'+ $attrs['label10']"><p><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></p></a>
                            </div>
                        </li>
                        <li>
                            <div class="icon-group">
                                <svg vd-node="icon" width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M23.3335 23.3334H4.66683C3.37817 23.3334 2.3335 22.2887 2.3335 21.0001V6.89858C2.38787 5.64972 3.41678 4.66557 4.66683 4.66675H23.3335C24.6222 4.66675 25.6668 5.71142 25.6668 7.00008V21.0001C25.6668 22.2887 24.6222 23.3334 23.3335 23.3334ZM4.66683 9.17942V21.0001H23.3335V9.17942L14.0002 15.4001L4.66683 9.17942ZM5.60016 7.00008L14.0002 12.6001L22.4002 7.00008H5.60016Z" fill="url(#paint0_linear_366_4688)"/>
                                    <defs>
                                    <linearGradient id="paint0_linear_366_4688" x1="2.3335" y1="4.66675" x2="28.0406" y2="19.1076" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#09C6F9"/>
                                    <stop offset="1" stop-color="#045DE9"/>
                                    </linearGradient>
                                    </defs>
                                </svg>                                                                                                        
                            </div>
                            <div class="text-group">
                                <span vd-node="text" ><vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></span>
                                <p>
                                    <a  v-if="$attrs['label3'] != '' " vd-node="styleOnly" class="callByAjax" :href="'mailto:'+ $attrs['label3']"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></a>
                                    <a v-else vd-node="styleOnly" class="callByAjax" :href="'mailto:'+ store_email"><vd-component-param type="label3" v-html="i18n(store_email)"></vd-component-param></a>
                                </p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <div class="form-wrapper">
                        <form novalidate @submit.prevent="submitForm">
                            <div class="row">
                                <div class="col-12">
                                    <h3><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xl-6 vd-form">
                                    <div class="input-group mb-18  vd-form">
                                        <span class="input-group-text" id="name">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12.0001 22C10.4882 22.0043 8.99532 21.6622 7.6361 21C7.13865 20.758 6.66203 20.4754 6.2111 20.155L6.0741 20.055C4.83392 19.1396 3.81997 17.9522 3.1101 16.584C2.37584 15.1679 1.99501 13.5952 2.00005 12C2.00005 6.47715 6.47725 2 12.0001 2C17.5229 2 22.0001 6.47715 22.0001 12C22.0051 13.5944 21.6247 15.1664 20.8911 16.582C20.1822 17.9494 19.1697 19.1364 17.9311 20.052C17.4639 20.394 16.968 20.6951 16.4491 20.952L16.3691 20.992C15.009 21.6577 13.5144 22.0026 12.0001 22ZM12.0001 17C10.5016 16.9971 9.12776 17.834 8.4431 19.167C10.6845 20.2772 13.3157 20.2772 15.5571 19.167V19.162C14.8716 17.8305 13.4977 16.9954 12.0001 17ZM12.0001 15C14.1662 15.0028 16.1635 16.1701 17.2291 18.056L17.2441 18.043L17.2581 18.031L17.2411 18.046L17.2311 18.054C19.7601 15.8691 20.6644 12.3423 19.4987 9.21011C18.3331 6.07788 15.3432 4.00032 12.0011 4.00032C8.65901 4.00032 5.66909 6.07788 4.50345 9.21011C3.33781 12.3423 4.2421 15.8691 6.7711 18.054C7.83736 16.169 9.83446 15.0026 12.0001 15ZM12.0001 14C9.79096 14 8.0001 12.2091 8.0001 10C8.0001 7.79086 9.79096 6 12.0001 6C14.2092 6 16.0001 7.79086 16.0001 10C16.0001 11.0609 15.5787 12.0783 14.8285 12.8284C14.0784 13.5786 13.061 14 12.0001 14ZM12.0001 8C10.8955 8 10.0001 8.89543 10.0001 10C10.0001 11.1046 10.8955 12 12.0001 12C13.1047 12 14.0001 11.1046 14.0001 10C14.0001 8.89543 13.1047 8 12.0001 8Z" fill="#91919F"/>
                                            </svg>                                                                                                                                         
                                        </span>
                                        <input vd-readonly="true" type="text" class="form-control vd-component-attr" v-model="fname" name="fname" id="First-Name"
                                            :class="nameFiledNotValidate ? 'is-invalid' : ''"
                                            vd-component-attr-placeholder="label13" :placeholder=i18n($attrs['label13']) 
                                            vd-component-attr-title="label18" :title=i18n($attrs['label18'])  autocomplete="off">
                                    </div>
                                    <div class="invalid-feedback d-block" >{{errors.fname}}</div>
                                </div>
                                <div class="col-xl-6  vd-form vd-form">
                                    <div class="input-group mb-18">
                                        <span class="input-group-text" id="name">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M12.0001 22C10.4882 22.0043 8.99532 21.6622 7.6361 21C7.13865 20.758 6.66203 20.4754 6.2111 20.155L6.0741 20.055C4.83392 19.1396 3.81997 17.9522 3.1101 16.584C2.37584 15.1679 1.99501 13.5952 2.00005 12C2.00005 6.47715 6.47725 2 12.0001 2C17.5229 2 22.0001 6.47715 22.0001 12C22.0051 13.5944 21.6247 15.1664 20.8911 16.582C20.1822 17.9494 19.1697 19.1364 17.9311 20.052C17.4639 20.394 16.968 20.6951 16.4491 20.952L16.3691 20.992C15.009 21.6577 13.5144 22.0026 12.0001 22ZM12.0001 17C10.5016 16.9971 9.12776 17.834 8.4431 19.167C10.6845 20.2772 13.3157 20.2772 15.5571 19.167V19.162C14.8716 17.8305 13.4977 16.9954 12.0001 17ZM12.0001 15C14.1662 15.0028 16.1635 16.1701 17.2291 18.056L17.2441 18.043L17.2581 18.031L17.2411 18.046L17.2311 18.054C19.7601 15.8691 20.6644 12.3423 19.4987 9.21011C18.3331 6.07788 15.3432 4.00032 12.0011 4.00032C8.65901 4.00032 5.66909 6.07788 4.50345 9.21011C3.33781 12.3423 4.2421 15.8691 6.7711 18.054C7.83736 16.169 9.83446 15.0026 12.0001 15ZM12.0001 14C9.79096 14 8.0001 12.2091 8.0001 10C8.0001 7.79086 9.79096 6 12.0001 6C14.2092 6 16.0001 7.79086 16.0001 10C16.0001 11.0609 15.5787 12.0783 14.8285 12.8284C14.0784 13.5786 13.061 14 12.0001 14ZM12.0001 8C10.8955 8 10.0001 8.89543 10.0001 10C10.0001 11.1046 10.8955 12 12.0001 12C13.1047 12 14.0001 11.1046 14.0001 10C14.0001 8.89543 13.1047 8 12.0001 8Z" fill="#91919F"/>
                                            </svg>                                                                                                                                         
                                        </span>
                                        <input vd-readonly="true" type="text" class="form-control vd-component-attr" v-model="lname" name="lname"
                                            :class="lnameFiledNotValidate ? 'is-invalid' : ''"
                                            id="Last-Name" vd-component-attr-placeholder="label14" :placeholder=i18n($attrs['label14']) 
                                            vd-component-attr-title="label19" :title=i18n($attrs['label19']) autocomplete="off">
                                    </div>
                                    <div class="invalid-feedback d-block" >{{errors.lname}}</div>
                                </div>
                                <div class="col-xl-6 vd-form">
                                    <div class="input-group mb-18">
                                        <span class="input-group-text" id="email">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M20 20H4C2.89543 20 2 19.1046 2 18V5.913C2.04661 4.84255 2.92853 3.99899 4 4H20C21.1046 4 22 4.89543 22 6V18C22 19.1046 21.1046 20 20 20ZM4 7.868V18H20V7.868L12 13.2L4 7.868ZM4.8 6L12 10.8L19.2 6H4.8Z" fill="#91919F"/>
                                            </svg>                                                                                                                                                                                       
                                        </span>
                                        <input vd-readonly="true"  type="email"
                                            class="form-control vd-component-attr" v-model="end_contact_email" name="end_contact_email"
                                            :class="emailFieldNotValidate ? 'is-invalid' : ''"
                                            id="Email-Address" vd-component-attr-placeholder="label15" :placeholder=i18n($attrs['label15']) 
                                            vd-component-attr-title="label20" :title=i18n($attrs['label20']) autocomplete="off">
                                    </div>
                                    <div class="invalid-feedback d-block" >{{ errors.end_contact_email}}</div>
                                </div>
                                <div class="col-xl-6 vd-form">
                                    <div class="input-group mb-18">
                                        <span class="input-group-text" id="email">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M20 20H4C2.89543 20 2 19.1046 2 18V5.913C2.04661 4.84255 2.92853 3.99899 4 4H20C21.1046 4 22 4.89543 22 6V18C22 19.1046 21.1046 20 20 20ZM4 7.868V18H20V7.868L12 13.2L4 7.868ZM4.8 6L12 10.8L19.2 6H4.8Z" fill="#91919F"/>
                                            </svg>                                                                                                                                                                                       
                                        </span>
                                        <input vd-readonly="true" type="text" class="form-control vd-component-attr" id="Phone-Number" autocomplete="off"
                                            vd-component-attr-placeholder="label16" :placeholder=i18n($attrs['label16']) 
                                            vd-component-attr-title="label21" :title=i18n($attrs['label21']) name="phone_no" v-model="phone_no"
                                            :class="phoneFieldNotValidate ? 'is-invalid' : ''" >
                                    </div>
                                    <div class="invalid-feedback d-block" >{{ errors.phone_no }}</div>
                                </div>
                                <div class="col-12">
                                    <div class="input-group mb-18 vd-no-navigation  vd-form">
                                        <span class="input-group-text" id="subject">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M20 19.9999H4C2.93052 20.0319 2.03642 19.1933 2 18.1239V5.87494C2.03641 4.80575 2.93068 3.96737 4 3.99994H20C21.0693 3.96737 21.9636 4.80575 22 5.87494V18.1249C21.963 19.1939 21.0691 20.032 20 19.9999ZM4 5.99994V17.9889L20 17.9999V6.01094L4 5.99994ZM13.43 15.9999H6C6.07353 15.172 6.46534 14.4049 7.093 13.8599C7.79183 13.1667 8.73081 12.7691 9.715 12.7499C10.6992 12.7691 11.6382 13.1667 12.337 13.8599C12.9645 14.405 13.3563 15.1721 13.43 15.9999ZM18 14.9999H15V12.9999H18V14.9999ZM9.715 11.9999C9.17907 12.0186 8.65947 11.8138 8.28029 11.4347C7.9011 11.0555 7.69638 10.5359 7.715 9.99994C7.69668 9.4641 7.9015 8.94468 8.28062 8.56556C8.65974 8.18644 9.17916 7.98162 9.715 7.99994C10.2508 7.98162 10.7703 8.18644 11.1494 8.56556C11.5285 8.94468 11.7333 9.4641 11.715 9.99994C11.7336 10.5359 11.5289 11.0555 11.1497 11.4347C10.7705 11.8138 10.2509 12.0186 9.715 11.9999ZM18 10.9999H14V8.99994H18V10.9999Z" fill="#91919F"/>
                                            </svg>                                                                                                                                                                                                                                 
                                        </span>
                                            <select id="contact-reason" class="custom-select form-control" name="reason" placeholder="Select">
                                                <option value=""><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></option>
                                                <option value="I want to change my account related information"><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param></option>
                                                <option value="I want to renew my subscription"><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></option>
                                                <option value="I want to cancel my subscription"><vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param></option>
                                                <option value="I want to request a content"><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param></option>
                                                <option value="I want to suggest an idea"><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></option>
                                                <option value="Others"><vd-component-param type="label26" v-html="i18n($attrs['label26'])"></vd-component-param></option>
                                            </select>
                                        <div id="error-contact-reason" class="invalid-feedback reason-err-msg"><vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param></div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="message-box position-relative vd-form">
                                        <textarea type="text" class="form-control vd-component-attr" name="end_contact_message" v-model="end_contact_message"
                                            v-bind:class="messageFieldNotValidate ? 'is-invalid' : ''" id="message" vd-component-attr-placeholder="label27" :placeholder=i18n($attrs['label27']) 
                                            vd-component-attr-title="label22" :title=i18n($attrs['label22']) rows="4" cols="50"></textarea>
                                        <div class="invalid-feedback" >{{ errors.end_contact_message }}</div>
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M3 21V5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V15C21 16.1046 20.1046 17 19 17H9C8.56713 16.9992 8.14582 17.1396 7.8 17.4L3 21ZM5 5V17L7.134 15.4C7.47964 15.1393 7.90107 14.9988 8.334 15H19V5H5Z" fill="#91919F"/>
                                        </svg>                                            
                                    </div>
                                </div>
                                <div class="col-12 text-center mt-4">
                                    <button type="submit" vd-node="styleOnly"  vd-readonly="true" class="primary-button btn-solid" id="contact-button"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--================================================================
                        CONTENT AREA END 
    ==================================================================-->

</vd-component>
    `,
    //    inheritAttrs: false
};

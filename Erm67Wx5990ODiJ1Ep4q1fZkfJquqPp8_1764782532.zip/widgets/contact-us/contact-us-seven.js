let {
    contactUs,
    validateStoreAdminToken,
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));

export default {
    name: "contact_us_seven",

    data() {
        return {
            fname: "",
            lname: "",
            end_contact_email: "",
            end_contact_message: "",
            phone_no: "",
            isReset: false,
            isFormValid: false,
            errors: {},
            emailFieldNotValidate: false,
            messageFieldNotValidate: false,
            nameFiledNotValidate: false,
            phoneFieldNotValidate: false,
            store_email: "",
            lnameFiledNotValidate: false,
        };
    },
    watch: {
        fname: function (value) {
            // var value=this.name;
            if (value && !this.isReset) {
                this.validateFname(value);
            }

        },
        lname: function (value) {
            if (value && !this.isReset) {
                this.validateLname(value);
            }
        },
        end_contact_message: function (value) {
            if (value && !this.isReset) {
                this.validateMessage(value);
            }
        },
        end_contact_email: function (value) {
            if (value && !this.isReset) {
                // var value=this.email;
                this.validateEmail(value);
            }
        },
        phone_no: function (phone_number) {

            if (phone_number && !this.isReset) {
                this.validatePhone(phone_number);
            }
        },

    },
    methods: {
        i18n,
        validateLname(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.lname = i18n("Last Name field is required");

                this.lnameFiledNotValidate = true;

            } else if (!value.match(/^[a-zA-Z ]+$/)) {
                this.errors.valid = false;
                this.lnameFiledNotValidate = true;
                this.errors.lname =
                    i18n("The Last Name field contains only alphabets");
            } else if (value.length < 2 || value.length > 15) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.lname =
                    i18n("Last Name should be between 2 to 15 charaters");
                this.lnameFiledNotValidate = true;
            } else {
                this.errors.lname = null;
                this.lnameFiledNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                )
                    this.errors.valid = true;
                this.isFormValid = true;
            }
        },
        validateMessage(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_message = i18n("Message field is required");
                this.messageFieldNotValidate = true;
            } else if (value.length < 2) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_message =
                    i18n("Message should be between (2-250) characters");
                this.messageFieldNotValidate = true;
            } else if (value.length > 250) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_message =
                    i18n("Message should be between (2-250) characters");
                this.messageFieldNotValidate = true;
            } else {
                this.errors.end_contact_message = null;
                this.messageFieldNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                )
                    this.errors.valid = true;
                this.isFormValid = true;
            }
        },
        validateEmail(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_email = i18n("Email field is required");
                this.emailFieldNotValidate = true;
            } else if (!this.checkEmail(value)) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.end_contact_email = i18n("Please enter a valid email");
                this.emailFieldNotValidate = true;
            } else {
                this.errors.end_contact_email = null;
                this.emailFieldNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        validatePhone(phone_number) {
            if (!phone_number.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.phone_no = i18n("Phone number is required");
                this.phoneFieldNotValidate = true;
                //return;
                // ^(?!0+$)[0-9+\\s-()/]{4,20}$|^$
            } else if (!this.checkMobileNum(phone_number)) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.phone_no =
                    i18n("Please enter a valid phone number with country code");
                this.phoneFieldNotValidate = true;
            } else {
                this.errors.phone_no = null;
                this.phoneFieldNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        validateFname(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.fname = i18n("First Name field is required");
                this.nameFiledNotValidate = true;
            } else if (!value.match(/^[a-zA-Z ]+$/)) {
                this.errors.valid = false;
                this.nameFiledNotValidate = true;
                this.errors.fname =
                    i18n("The First Name field contains only alphabets");
            } else if (value.length < 2 || value.length > 15) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.fname =
                    i18n("First Name should be between 2 to 15 charaters");
                this.nameFiledNotValidate = true;
            } else {
                this.errors.fname = null;
                this.nameFiledNotValidate = false;
                if (
                    this.errors.fname !== undefined &&
                    this.errors.fname == null &&
                    this.errors.lname !== undefined &&
                    this.errors.lname == null &&
                    this.errors.end_contact_email !== undefined &&
                    this.errors.end_contact_email == null &&
                    this.errors.end_contact_message !== undefined &&
                    this.errors.end_contact_message == null &&
                    this.errors.phone_no !== undefined &&
                    this.errors.phone_no == null
                )
                    this.errors.valid = true;
                this.isFormValid = true;
            }
        },

        submitForm(e) {
            console.log(this.errors);
            const formData = new FormData(e.target);
            const formProps = Object.fromEntries(formData);
            this.validateFname(this.fname);
            this.validateLname(this.lname);
            this.validatePhone(this.phone_no);
            this.validateMessage(this.end_contact_message);
            this.validateEmail(this.end_contact_email);
            if (!formProps.reason) {
                $(".custom-select").addClass("has-invalid");
                $(".reason-err-msg").css("display", "block");
                return false;
            } else {
                $(".reason-err-msg").css("display", "none");
            }
            if (
                this.errors.fname ||
                this.errors.lname ||
                this.errors.end_contact_email ||
                this.errors.end_contact_message ||
                this.errors.phone_no ||
                this.isFormValid == 0
            ) {
                return false;
            }
            $(".reason-err-msg").css("display", "none");
            let userData = {
                first_name: this.fname,
                last_name: this.lname,
                phone: this.phone_no,
                email: this.end_contact_email,
                message: this.end_contact_message,
                store_email: this.store_email,
                reason: formProps.reason,
            };

            contactUs(userData)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        console.log("contactUs", res.data);
                        Toast.fire({
                            icon: "success",
                            text: res.data.message,
                        });
                        this.clearFormData();
                        this.errors = [];
                        setTimeout(() => {

                            this.isReset = false;

                        }, 2000);


                    } else {
                        Toast.fire({
                            icon: "error",
                            text: "Something went wrong",
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                    // //JsLoadingOverlay.hide();
                });
        },
        checkMobileNum(str) {
            var contactformat = true;
            let filter = /^\+[1-9]{1}[0-9]{10,20}$/;
            if (!filter.test(str)) {
                contactformat = false;
            } else {
                contactformat = true;
            }
            return contactformat;
        },
        checkEmail(str) {
            var emailformat = true;
            let filter =
                /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if (!filter.test(str)) {
                emailformat = false;
            } else {
                emailformat = true;
            }
            return emailformat;
        },

        submitContactusData(e) { },
        clearFormData: function () {
            (this.fname = ""),
                (this.lname = ""),
                (this.end_contact_email = ""),
                (this.end_contact_message = ""),
                (this.phone_no = "");
            $(".select-selected").html(i18n("Select"));
            $("#contact-reason").val('default').selectpicker("refresh");
            $('#contact-reason').selectpicker('destroy');
            this.isReset = true;

        },

    },
    mounted() {
        //@ER: 92989 Start
        document.querySelectorAll('.select-selected').forEach(function (el) {
            el.remove();
        });
        document.querySelectorAll('.select-items,.select-hide').forEach(function (el) {
            el.remove();
        });
        //@ER: 92989 End
        validateStoreAdminToken().then((res) => {
            // if (res.data.code === 200 && res.data.email !== null) {
            this.store_email = res.data.email;
            console.log(this.store_email, "dataaaaaaa");
            // }
        });

        var x, i, j, l, ll, selElmnt, a, b, c;
        /*look for any elements with the class "custom-select":*/
        x = document.getElementsByClassName("custom-select");
        l = x.length;
        for (i = 0; i < l; i++) {
            selElmnt = x[i].getElementsByTagName("select")[0];
            ll = selElmnt.length;
            /*for each element, create a new DIV that will act as the selected item:*/
            a = document.createElement("DIV");
            a.setAttribute("class", "select-selected");
            a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
            x[i].appendChild(a);
            /*for each element, create a new DIV that will contain the option list:*/
            b = document.createElement("DIV");
            b.setAttribute("class", "select-items select-hide");
            for (j = 1; j < ll; j++) {
                /*for each option in the original select element, create a new DIV that will act as an option item:*/
                c = document.createElement("DIV");
                c.innerHTML = selElmnt.options[j].innerHTML;
                c.setAttribute("aria-label", "error-contact-reason");
                c.addEventListener("click", function (e) {
                    /*when an item is clicked, update the original select box, and the selected item:*/
                    var y, i, k, s, h, sl, yl;
                    s =
                        this.parentNode.parentNode.getElementsByTagName(
                            "select"
                        )[0];
                    sl = s.length;
                    h = this.parentNode.previousSibling;
                    for (i = 0; i < sl; i++) {
                        if (s.options[i].innerHTML == this.innerHTML) {
                            s.selectedIndex = i;
                            h.innerHTML = this.innerHTML;
                            y =
                                this.parentNode.getElementsByClassName(
                                    "same-as-selected"
                                );
                            yl = y.length;
                            for (k = 0; k < yl; k++) {
                                y[k].removeAttribute("class");
                            }
                            this.setAttribute("class", "same-as-selected");
                            break;
                        }
                    }
                    h.click();

                    document.getElementById(
                        e.target.getAttribute("aria-label")
                    ).style.display = "none";
                });
                b.appendChild(c);
            }
            x[i].appendChild(b);
            a.addEventListener("click", function (e) {
                /*when the select box is clicked, close any other select boxes, and open/close the current select box:*/
                e.stopPropagation();
                closeAllSelect(this);
                $(".reason-err-msg").css("display", "none");
                this.nextSibling.classList.toggle("select-hide");
                this.classList.toggle("select-arrow-active");
            });
        }
        function closeAllSelect(elmnt) {
            /*a function that will close all select boxes in the document, except the current select box:*/
            var x,
                y,
                i,
                xl,
                yl,
                arrNo = [];
            x = document.getElementsByClassName("select-items");
            y = document.getElementsByClassName("select-selected");
            xl = x.length;
            yl = y.length;
            for (i = 0; i < yl; i++) {
                if (elmnt == y[i]) {
                    arrNo.push(i);
                } else {
                    y[i].classList.remove("select-arrow-active");
                }
            }
            for (i = 0; i < xl; i++) {
                if (arrNo.indexOf(i)) {
                    x[i].classList.add("select-hide");
                }
            }
        }
        /*if the user clicks anywhere outside the select box, then close all select boxes:*/
        document.addEventListener("click", closeAllSelect);

        $(".reason-err-msg").css("display", "none");
    },
    template: `<vd-component class="vd contact-us-seven" type="contact-us-seven">
    <section class="form-wrapper contact-us">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="contact-us-page">
                        <div class="row justify-content-center mb-4">
                            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
                                <div class="contact-top d-md-flex d-lg-flex justify-content-between">
                                    <div class="heading">
                                    <h1><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h1>

                                    </div>
                                    <div class="contact-info">
                                        <ul>
                                             <li><svg vd-node="icon" width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M28 6H4C3.46957 6 2.96086 6.21071 2.58579 6.58579C2.21071 6.96086 2 7.46957 2 8V24C2 24.5304 2.21071 25.0391 2.58579 25.4142C2.96086 25.7893 3.46957 26 4 26H28C28.5304 26 29.0391 25.7893 29.4142 25.4142C29.7893 25.0391 30 24.5304 30 24V8C30 7.46957 29.7893 6.96086 29.4142 6.58579C29.0391 6.21071 28.5304 6 28 6ZM25.8 8L16 14.78L6.2 8H25.8ZM4 24V8.91L15.43 16.82C15.5974 16.9361 15.7963 16.9984 16 16.9984C16.2037 16.9984 16.4026 16.9361 16.57 16.82L28 8.91V24H4Z" fill="#BFC0C4" />
                                                </svg>
                                                    <span vd-node="text" ><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></span></li>
                                                    <li  v-if="$attrs['label3'] != '' " ><a vd-node="styleOnly" class="callByAjax" :href="'mailto:'+ $attrs['label3']"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></a></li>
                                                    <li v-else ><a vd-node="styleOnly" class="callByAjax" :href="'mailto:'+ store_email"><vd-component-param type="label3" v-html="i18n(store_email)"></vd-component-param></a></li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 form-div override-oh">
                                <form novalidate @submit.prevent="submitForm">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="form-group vd-form right-space">
                                            <input vd-readonly="true" type="text" class="form-control vd-component-attr" v-model="fname" name="fname" id="First-Name"
                                            :class="nameFiledNotValidate ? 'is-invalid' : ''"
                                            vd-component-attr-placeholder="label5" :placeholder=i18n($attrs['label5']) 
                                            vd-component-attr-title="label10" :title=i18n($attrs['label10'])  autocomplete="off">
                                            <div class="invalid-feedback" >{{errors.fname}}</div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="form-group vd-form left-space">
                                            <input vd-readonly="true" type="text" class="form-control vd-component-attr" v-model="lname" name="lname"
                                            :class="lnameFiledNotValidate ? 'is-invalid' : ''"
                                             id="Last-Name" vd-component-attr-placeholder="label6" :placeholder=i18n($attrs['label6']) 
                                             vd-component-attr-title="label11" :title=i18n($attrs['label11']) autocomplete="off">
                                             <div class="invalid-feedback" >{{errors.lname}}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="form-group vd-form right-space">
                                            <input vd-readonly="true"  type="email"
                                            class="form-control vd-component-attr" v-model="end_contact_email" name="end_contact_email"
                                            :class="emailFieldNotValidate ? 'is-invalid' : ''"
                                            id="Email-Address" vd-component-attr-placeholder="label7" :placeholder=i18n($attrs['label7']) 
                                            vd-component-attr-title="label12" :title=i18n($attrs['label12']) autocomplete="off">
                                            <div class="invalid-feedback" >{{ errors.end_contact_email}}</div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="form-group vd-form left-space">
                                            <input vd-readonly="true" type="text" class="form-control vd-component-attr" id="Phone-Number" autocomplete="off"
                                            vd-component-attr-placeholder="label8" :placeholder=i18n($attrs['label8']) 
                                            vd-component-attr-title="label13" :title=i18n($attrs['label13']) name="phone_no" v-model="phone_no"
                                             :class="phoneFieldNotValidate ? 'is-invalid' : ''" >
                                             <div class="invalid-feedback" >{{ errors.phone_no }}</div>
                                            </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                     <div class="season-heading vd-form mb-40px">
                                      <label vd-node="text" for="contact-reason" class="heading"><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></label>
                                       <div class="custom-select vd-no-navigation">
                                       <select id="contact-reason"  name="reason" >
                                          <option value=""><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></option>
                                          <option value="I want to change my account related information"><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></option>
                                          <option value="I want to renew my subscription"><vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param></option>
                                          <option value="I want to cancel my subscription"><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></option>
                                          <option value="I want to request a content"><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param></option>
                                          <option value="I want to suggest an idea"><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></option>
                                          <option value="Others"><vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param></option>
                                       </select>

                                       </div>
                                       <div id="error-contact-reason" class="invalid-feedback reason-err-msg"><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></div>
                                     </div>
                                        <div class="form-group vd-form">
                                            <textarea type="text" class="form-control vd-component-attr" name="end_contact_message" v-model="end_contact_message"
                                            v-bind:class="messageFieldNotValidate ? 'is-invalid' : ''" id="message" vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9']) 
                                            vd-component-attr-title="label14" :title=i18n($attrs['label14']) rows="4" cols="50"></textarea>
                                            <div class="invalid-feedback" >{{ errors.end_contact_message }}</div>
                                        </div>

                                        <button type="submit" vd-node="styleOnly"  vd-readonly="true" class="primary-button" id="contact-button"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></button>
                                        <!--Season DropDown End Here-->
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</vd-component>
    `,
    //    inheritAttrs: false
};

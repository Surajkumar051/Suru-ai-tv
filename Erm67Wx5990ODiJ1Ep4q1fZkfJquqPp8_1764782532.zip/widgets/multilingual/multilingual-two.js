let { setCookie } = await import(window.importAssetJs('js/main.js'));
let { getRootUrl,getAssetUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));

export default {
    name: "multilingual_two",
    data() {
        return {
            language_list:language_list,
            primary_language:primary_language,
            currentLocation:window.location.href
        };
    },
    methods: {
        setCookie,
        i18n,
        getRootUrl,
        getAssetUrl,
        getCurrentLocation(lang_code){
            if(primary_language!=lang_code){
                window.location.href=localStorage.getItem('locationHref');
            }            
        }
    },
    template: `
    <vd-component class="vd multilingual-two" type="multilingual-two">
        <div vd-node="styleLang" vd-readonly="true" v-if="language_list.length>1" class="nav-item dropdown language-item">
            <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img style="width: 100%;height: 100%;" :src="getAssetUrl()+'img/language-dropdown-icon-grey.png'" alt="Choose Your Language">
            </a>
            <div v-if="language_list && language_list.length" class="dropdown-menu dropdown-menu-reverse" aria-labelledby="navbarDropdown">
                <a v-for="language in language_list" @click="setCookie('lang_code',language.code,24);" :class="primary_language==language.code?'dropdown-item nav-link active':'dropdown-item nav-link'" @click="getCurrentLocation(language.code)" v-html=i18n(language.name) href="javascript:void(0);"></a>
            </div>    
        </div>  
    </vd-component>`,
};

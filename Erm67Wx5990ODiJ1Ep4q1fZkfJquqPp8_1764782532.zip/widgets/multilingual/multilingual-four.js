let { setCookie } = await import(window.importAssetJs('js/main.js'));
let { getRootUrl,getAssetUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));

export default {
    name: "multilingual_four",
    data() {
        return {
            language_list:language_list,
            primary_language:primary_language,
            currentLocation:window.location.href
        };
    },
    methods: {
        setCookie,
        i18n,
        getRootUrl,
        getAssetUrl,
        getCurrentLocation(lang_code) {
            if (primary_language != lang_code) {
                window.location.href = localStorage.getItem('locationHref');
            }
        }
    },
    template: `
    <vd-component class="vd multilingual-four" type="multilingual-four" v-if="language_list.length>1">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg" data-toggle="tooltip" data-placement="bottom" title="Change Language">
          <path d="M6.37534 5.50325L6.41267 5.58125L9.95067 14.2513C10.015 14.4088 10.0167 14.585 9.95534 14.7437C9.89398 14.9025 9.77424 15.0317 9.62065 15.105C9.46706 15.1783 9.29126 15.1901 9.12926 15.138C8.96726 15.0858 8.83134 14.9737 8.74934 14.8246L8.716 14.7546L7.79534 12.4999H3.60467L2.61134 14.7713C2.54576 14.9209 2.42751 15.0412 2.27905 15.1094C2.13059 15.1777 1.96226 15.189 1.806 15.1413L1.73267 15.1146C1.58291 15.0491 1.46241 14.9309 1.39408 14.7825C1.32574 14.634 1.31433 14.4656 1.362 14.3093L1.38867 14.2359L5.18534 5.56659C5.40934 5.05325 6.11467 5.03659 6.376 5.50392L6.37534 5.50325ZM12.6667 1.83325C12.83 1.83327 12.9876 1.89322 13.1096 2.00173C13.2316 2.11023 13.3096 2.25975 13.3287 2.42192L13.3333 2.49992V5.16659H14C14.1633 5.16661 14.3209 5.22656 14.4429 5.33506C14.5649 5.44357 14.6429 5.59308 14.662 5.75525L14.6667 5.83325C14.6666 5.99654 14.6067 6.15414 14.4982 6.27617C14.3897 6.39819 14.2402 6.47615 14.078 6.49525L14 6.49992H13.3333V11.1666C13.3333 11.3299 13.2734 11.4875 13.1649 11.6095C13.0564 11.7315 12.9068 11.8095 12.7447 11.8286L12.6667 11.8333C12.5034 11.8332 12.3458 11.7733 12.2238 11.6648C12.1017 11.5563 12.0238 11.4068 12.0047 11.2446L12 11.1666V2.49992C12 2.32311 12.0702 2.15354 12.1953 2.02851C12.3203 1.90349 12.4899 1.83325 12.6667 1.83325ZM5.77334 7.54459L4.188 11.1666H7.25134L5.77334 7.54459ZM7.33334 1.83325H10.6667C10.83 1.83327 10.9876 1.89322 11.1096 2.00173C11.2316 2.11023 11.3096 2.25975 11.3287 2.42192L11.3333 2.49992V4.48325C11.3333 5.1905 11.0524 5.86877 10.5523 6.36887C10.0522 6.86897 9.37391 7.14992 8.66667 7.14992C8.48986 7.14992 8.32029 7.07968 8.19526 6.95466C8.07024 6.82963 8 6.66006 8 6.48325C8 6.30644 8.07024 6.13687 8.19526 6.01185C8.32029 5.88682 8.48986 5.81659 8.66667 5.81659C9.00305 5.81669 9.32705 5.68965 9.5737 5.46092C9.82036 5.23219 9.97144 4.91869 9.99667 4.58325L10 4.48325V3.16659H7.33334C7.16342 3.1664 6.99998 3.10133 6.87642 2.98469C6.75287 2.86804 6.67851 2.70862 6.66855 2.53899C6.6586 2.36936 6.71379 2.20233 6.82285 2.07203C6.93191 1.94173 7.08661 1.85799 7.25534 1.83792L7.33334 1.83325Z" fill="white"/>
          </svg>                                  
      </a>
      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
      <a v-for="language in language_list" @click="setCookie('lang_code',language.code,24);" :class="primary_language==language.code?'dropdown-item  active':'dropdown-item '" @click="getCurrentLocation(language.code)" v-html=i18n(language.name) href="javascript:void(0);"></a>                         
      </div>  
       
    </vd-component>`,
};

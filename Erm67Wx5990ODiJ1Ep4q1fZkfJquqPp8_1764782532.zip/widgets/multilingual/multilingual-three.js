let { setCookie } = await import(window.importAssetJs('js/main.js'));
let { getRootUrl, getAssetUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));

export default {
	name: "multilingual_three",
	data() {
		return {
			language_list: language_list,
			primary_language: primary_language,
			currentLocation: window.location.href
		};
	},
	methods: {
		setCookie,
		i18n,
		getRootUrl,
		getAssetUrl,
		getCurrentLocation(lang_code) {
			if (primary_language != lang_code) {
				window.location.href = localStorage.getItem('locationHref');
			}
		}
	},
	template: `
    <vd-component class="vd multilingual-three" type="multilingual-three">
        <a vd-node="styleLang" vd-readonly="true" v-if="language_list.length>1" class="dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
        <img style="height: 100%;" class="lang-img" :src="getAssetUrl()+'img/language-dropdown-icon.png'"  alt="Choose Your Language">
        </a>
        <div v-if="language_list && language_list.length" class="dropdown-menu mt-21" aria-labelledby="navbarDropdown">
            <a v-for="language in language_list" @click="setCookie('lang_code',language.code,24);" :class="primary_language==language.code?'dropdown-item active':'dropdown-item'" @click="getCurrentLocation(language.code)" v-html=i18n(language.name) href="javascript:void(0);"></a>
        </div>
    </vd-component>`,
};

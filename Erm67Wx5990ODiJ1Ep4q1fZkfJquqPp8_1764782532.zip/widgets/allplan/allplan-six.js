let { getSubscriptionPlans,
    generateSST,
    validatePromocode,
    confirmCheckout,
    getMonetizationDetails,
    getContentByContentUuid,
    getvalidateContentPattern,
} = await import(window.importAssetJs('js/webservices.js'));
let { getCookie,
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies } = await import(window.importAssetJs('js/main.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));

//87419 Raj
let { GET_MONETIZATION_SETTINGS, GET_GATEWAY_STATUS } = await import(window.importAssetJs('js/configurations/actions.js'));

const { mapState, mapGetters } = Vuex;

export default {
    name: "allplan_six",
    template: `
        <vd-component class="vd allplan-six" type="allplan-six">
            <!--Choose Your plan Start Here-->
            <section class="dashboard-section post-signup-plans main-content h-100vh dashboard-banner-parent pt-102 without-sidebar pb-4" v-if="subscription_plans.length > 0">
                <div class="container-fluid plr-88">
                    <div class="row content-center">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-10 col-xl-10">
                            <!--Heading-->
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <h1 class="dashboard-heading white-color mbottom-20" v-if="is_promotion_enabled">
                                        <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                                    </h1>
                                </div>
                            </div>
                            <div class="new-all-plans-page">
                                <div class="row">
                                    <div class="col-lg-8 col-md-12 col-12">
                                        <div class="plan-area">
                                            <div class="row">
                                                <div class="col-md-12" v-for="(itemData,index) in subscription_plans">
                                                    <input class="form-check-input" type="radio"
                                                        :id="itemData.subscription_plan_uuid"
                                                        @click="selectedPlan(index, itemData)" :checked="selectedindex == index"
                                                        @change="(e) => {
                                                                    if(promocode) validatePromocode(promocode);
                                                                }">
                                                    <label class="single-plan" :for="itemData.subscription_plan_uuid"
                                                        :class="{ 'selected-plan': (selectedindex == index) }">
                                                        <div class="row justify-content-between align-items-center">
                                                            <div class="col-md-auto col-sm-auto col-xs-12 plan-d">
                                                                <div class="plan-d-1">
                                                                    <div class="plan-time">{{itemData.plan_name.toUpperCase()}}
                                                                        <span class="svg position-relative" v-if="itemData.plan_description">
                                                                            <svg width="14" height="14" viewBox="0 0 14 14"
                                                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                                    d="M7.0026 0.582031C3.45885 0.582031 0.585938 3.45495 0.585938 6.9987C0.585938 10.5424 3.45885 13.4154 7.0026 13.4154C10.5464 13.4154 13.4193 10.5424 13.4193 6.9987C13.4193 3.45495 10.5464 0.582031 7.0026 0.582031ZM6.71094 3.4987C6.55623 3.4987 6.40785 3.56016 6.29846 3.66955C6.18906 3.77895 6.1276 3.92732 6.1276 4.08203C6.1276 4.23674 6.18906 4.38511 6.29846 4.49451C6.40785 4.60391 6.55623 4.66536 6.71094 4.66536H7.0026C7.15731 4.66536 7.30569 4.60391 7.41508 4.49451C7.52448 4.38511 7.58594 4.23674 7.58594 4.08203C7.58594 3.92732 7.52448 3.77895 7.41508 3.66955C7.30569 3.56016 7.15731 3.4987 7.0026 3.4987H6.71094ZM5.83594 5.83203C5.68123 5.83203 5.53285 5.89349 5.42346 6.00289C5.31406 6.11228 5.2526 6.26065 5.2526 6.41536C5.2526 6.57007 5.31406 6.71845 5.42346 6.82784C5.53285 6.93724 5.68123 6.9987 5.83594 6.9987H6.41927V8.7487H5.83594C5.68123 8.7487 5.53285 8.81016 5.42346 8.91955C5.31406 9.02895 5.2526 9.17732 5.2526 9.33203C5.2526 9.48674 5.31406 9.63511 5.42346 9.74451C5.53285 9.85391 5.68123 9.91536 5.83594 9.91536H8.16927C8.32398 9.91536 8.47235 9.85391 8.58175 9.74451C8.69115 9.63511 8.7526 9.48674 8.7526 9.33203C8.7526 9.17732 8.69115 9.02895 8.58175 8.91955C8.47235 8.81016 8.32398 8.7487 8.16927 8.7487H7.58594V6.41536C7.58594 6.26065 7.52448 6.11228 7.41508 6.00289C7.30569 5.89349 7.15731 5.83203 7.0026 5.83203H5.83594Z"
                                                                                    fill="#BBBBBB" fill-opacity="0.6" />
                                                                            </svg>
                                                                            <div class="hover-tooltip">
                                                                                <div class="inner-tooltip position-relative">
                                                                                    <ul>
                                                                                        <li>
                                                                                            <span class="mr-2">
                                                                                                <svg width="15" height="16"
                                                                                                    viewBox="0 0 15 16"
                                                                                                    fill="none"
                                                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                                                    <path fill-rule="evenodd"
                                                                                                        clip-rule="evenodd"
                                                                                                        d="M13.4862 3.27244C13.6697 3.09081 13.8807 3 14.1193 3C14.3578 3 14.5688 3.09081 14.7523 3.27244C14.9174 3.4359 15 3.64022 15 3.88542C15 4.13061 14.9174 4.33494 14.7523 4.4984L5.97248 13.2436C5.95413 13.2618 5.93578 13.2799 5.91743 13.2981C5.89908 13.3162 5.88073 13.3344 5.86238 13.3526C5.69725 13.5342 5.49083 13.625 5.24312 13.625C4.99541 13.625 4.78899 13.5342 4.62385 13.3526L0.247706 9.04808C0.082568 8.88461 0 8.68029 0 8.4351C0 8.1899 0.082568 7.98558 0.247706 7.82212C0.431194 7.64049 0.642201 7.54968 0.880734 7.54968C1.11927 7.54968 1.33027 7.64049 1.51376 7.82212L5.22936 11.5L13.4862 3.27244Z"
                                                                                                        fill="#4A8858" />
                                                                                                </svg>
                                                                                            </span>
                                                                                            {{displayDescription(itemData.plan_description)}}
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </span>
                                                                    </div>
                                                                    <div v-if="itemData.is_free_plan == 0"
                                                                        class="d-flex align-items-center justify-content-start">
                                                                        <!--<div class="active-text-area mr-2 " :class="(isSelected && selectedindex == index)? 'selected' : ''" v-if="selectedindex == index"> Active </div>-->
                                                                        <div class="free-plan"
                                                                            v-if="itemData.price[0].plan_free_trial_interval === 0">
                                                                            {{i18n("No free trial!")}}
                                                                        </div>
                                                                        <div class="free-plan"
                                                                            v-else-if="itemData.price[0].plan_free_trial_interval === 1">
                                                                            {{i18n("First")}} {{itemData.price[0].plan_free_trial_interval}}
                                                                            {{i18n(itemData.price[0].plan_free_trial_unit)}} {{i18n("is free!")}}
                                                                        </div>
                                                                        <div class="free-plan" v-else>{{i18n("First")}}
                                                                            {{itemData.price[0].plan_free_trial_interval}}
                                                                            {{i18n(itemData.price[0].plan_free_trial_unit)}}{{language_code ==='en' ? 's' : ''}} {{i18n("are free!")}}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!--<div class="plan-d-2">
                                                                    <span class="plan-d-txt position-relative">Plan Details
                                                                        <div class="plan-d-list hover-tooltip">
                                                                            <div class="inner-tooltip position-relative">
                                                                                <ul>
                                                                                    <li v-for="(elements, inDx) in contentList[index]" :class="[types.includes(elements) ? 'fw-bold' : '']">
                                                                                        <span class="mr-2">
                                                                                            <svg width="15" height="16"
                                                                                                viewBox="0 0 15 16" fill="none"
                                                                                                xmlns="http://www.w3.org/2000/svg">
                                                                                                <path fill-rule="evenodd"
                                                                                                    clip-rule="evenodd"
                                                                                                    d="M13.4862 3.27244C13.6697 3.09081 13.8807 3 14.1193 3C14.3578 3 14.5688 3.09081 14.7523 3.27244C14.9174 3.4359 15 3.64022 15 3.88542C15 4.13061 14.9174 4.33494 14.7523 4.4984L5.97248 13.2436C5.95413 13.2618 5.93578 13.2799 5.91743 13.2981C5.89908 13.3162 5.88073 13.3344 5.86238 13.3526C5.69725 13.5342 5.49083 13.625 5.24312 13.625C4.99541 13.625 4.78899 13.5342 4.62385 13.3526L0.247706 9.04808C0.082568 8.88461 0 8.68029 0 8.4351C0 8.1899 0.082568 7.98558 0.247706 7.82212C0.431194 7.64049 0.642201 7.54968 0.880734 7.54968C1.11927 7.54968 1.33027 7.64049 1.51376 7.82212L5.22936 11.5L13.4862 3.27244Z"
                                                                                                    fill="#4A8858" />
                                                                                            </svg>
                                                                                        </span>
                                                                                        {{elements.charAt(0).toUpperCase() + elements.slice(1)}}
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </span>
                                                                </div>-->
                                                            </div>
                                                        <div v-if="itemData.is_free_plan == 0" class="col-md-auto col-sm-auto col-xs-12 mt-3 mt-sm-0"
                                                            v-for="price of itemData.price">
                                                            <div class="plan-price">
                                                                {{price.currency_symbol}}{{price.subscription_plan_price.toFixed(2)}}
                                                            </div>
                                                            <div class="billed-time mt-1">/{{price.plan_interval}}
                                                                {{i18n(price.plan_interval_unit)}}{{language_code ==='en' ? '(s)' : ''}} </div>
                                                        </div>
                                                        <div v-else class="col-md-auto col-sm-auto col-xs-12 mt-3 mt-sm-0">
                                                            <div class="plan-price">
                                                                {{i18n('Free')}}
                                                            </div>
                                                            <div class="billed-time mt-1">/
                                                                {{i18n('No Bill')}}</div>
                                                        </div>
                                                </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-12 col-12">
                                    <div class="final-amount-area mt-md-3 mt-lg-1 pos-sticky">
                                        <div class="newpromo-code-area">
                                            <div v-if="is_promotion_enabled && is_free_plan == 0">
                                                <label class="label-text d-block">{{i18n("Promo Code")}}</label>
                                                <div class="input-btn-grp">
                                                    <input type="search" class="form-control input-promocode"
                                                        v-model="promocode" :placeholder="i18n('Enter code here')"
                                                        aria-label="promo code" aria-describedby="button-addon2">
                                                    <button class="apply-promocode btn" type="button"
                                                        @click="validatePromocode(promocode)"
                                                        :disabled="promocode.length === 0 || this.applied_promocode.length > 0"
                                                        :style="[(promocode.length === 0 || this.applied_promocode.length > 0) ? 'pointer-events: none;' : '']">{{i18n("Apply")}}</button>
                                                </div>
                                                <div class="apply-confirm-text"
                                                    :class="{'text-danger' : applied_promocode_type === 0}">
                                                    {{i18n(promocode_message)}}</div>
                                                <div class="border-line"></div>
                                            </div>

                                            <template v-if = "selected_plan_tax_type === 1">
                                                <div class="d-flex justify-content-between align-items-center"
                                                    :class="{'mt-4' : (is_promotion_enabled && is_free_plan == 0)}">
                                                    <div class="plan-price-text">{{i18n("Plan Price(Exclusive of tax)")}}</div>
                                                    <div class="plan-price-number" v-if="is_free_plan == 0">
                                                        {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                                    <div class="plan-price-number" v-else>{{i18n('Free')}}</div>
                                                </div>
                                                <div class="d-flex justify-content-between align-items-center mt-2"
                                                    :class="{'mt-4' : (is_promotion_enabled && is_free_plan == 0)}">
                                                    <div class="plan-price-text">{{selected_plan_tax_name}}({{selected_plan_tax_rate}}%)</div>
                                                    <div class="plan-price-number">{{selected_plan_currency_symbol}}{{selected_plan_tax_amount}}</div>
                                                </div>
                                                
                                            </template>
                
                                            <template v-else-if ="selected_plan_tax_type === 2">
                                                <div class="d-flex justify-content-between align-items-center"
                                                    :class="{'mt-4' : (is_promotion_enabled && is_free_plan == 0)}">
                                                    <div class="plan-price-text">{{i18n("Plan Price(Inclusive of tax)")}}</div>
                                                    <div class="plan-price-number" v-if="is_free_plan == 0">
                                                        {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                                    <div class="plan-price-number" v-else>{{i18n('Free')}}</div>
                                                </div>
                                            </template>
                
                                            <template v-else>
                                                <div class="d-flex justify-content-between align-items-center"
                                                    :class="{'mt-4' : (is_promotion_enabled && is_free_plan == 0)}">
                                                    <div class="plan-price-text">{{i18n("Plan Price")}}</div>
                                                    <div class="plan-price-number" v-if="is_free_plan == 0">
                                                        {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                                    <div class="plan-price-number" v-else>{{i18n('Free')}}</div>
                                                </div>
                                            </template>
                                           

                                            <div class="d-flex justify-content-between align-items-center mt-2"
                                                v-if="applied_promocode">
                                                <div class="plan-price-text" v-if="applied_promocode_type === 1">{{i18n("Coupon Discount")}}({{coupon_discount}})</div>
                                                <div class="plan-price-text" v-else-if="applied_promocode_type === 2">{{i18n("Voucher Discount")}}(100%)</div>
                                                <div class="plan-price-number" v-if="applied_promocode_type === 1">-{{selected_plan_currency_symbol}}{{coupon_discount_amount}}</div>
                                                <div class="plan-price-number" v-if="applied_promocode_type === 2">-{{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center mt-4">
                                                <div class="plan-total-text">{{i18n("Final Amount")}}</div>
                                                <div class="plan-total-number" v-if="applied_promocode_type === 2">{{selected_plan_currency_symbol}}0</div>
                                                <div class="plan-total-number" v-else-if="is_free_plan == 0">
                                                    {{selected_plan_currency_symbol}}{{selected_plan_tax_type === 1 ? selected_plan_final_amount : (selected_plan_price - coupon_discount_amount).toFixed(2)}}</div>
                                                <div class="plan-total-number" v-else>
                                                    {{i18n('Free')}}</div>
                                            </div>
                                        </div>
                                        <div class="checkout-btn-area mt-3">
                                            <button type="button" class="checkout-btn"
                                                @click="internalCheckout(selectedindex, selected_plan)"
                                                v-if="this.applied_promocode_type === 2 || is_free_plan == 1">
                                                {{i18n("Activate")}}
                                            </button>
                                            <button type="button" class="checkout-btn"
                                                @click="redirectCheckout(selectedindex, selected_plan)" v-else>
                                                {{i18n("Proceed to checkout")}}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--Choose Your plan End Here-->

        </vd-component>
    `,
    props: {

    },
    data() {
        return {
            subscription_plans: [],
            subscriptionEnabled: Boolean,
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2,
                promo_code: "",
                promo_type: ""
            },
            countryCode: 'US',
            selected_plan: {},
            selected_plan_price: 0.00,
            selected_plan_tax_uuid: "",
            selected_plan_tax_amount: 0.00,
            selected_plan_tax_rate: 0.00,
            selected_plan_tax_name: "",
            selected_plan_tax_type: null,
            selected_plan_final_amount: 0.00,
            selected_plan_promo_discount: 0.00,
            selected_plan_currency_symbol: '$',
            promocode: '',
            promocode_message: '',
            applied_promocode: '',
            applied_promocode_type: 0,
            is_promotion_enabled: false,
            contentList: [],
            types: ['cast', 'group', 'content type', 'category'],
            language_code: 'en',
            is_free_plan: 0,
            coupon_discount: '',
            coupon_discount_amount: 0.00,
        };
    },
    computed: {
        // ...mapState({
        //     current_content_uuid: state => state.current_content_uuid,
        //     current_monetization_methods: state => state.current_monetization_methods,
        //     show_content_purchase_modal: state => state.show_content_purchase_modal
        // }),
        ...mapGetters({
            // is_subscription_enabled: 'is_subscription_enabled',
            // //87419 Raj
            // is_promotion_enabled : 'is_promotion_enabled'
            //is_third_party_gateway: 'is_third_party_gateway',
            is_multiple_gateway: 'is_multiple_gateway'
        }),
    },
    async beforeMount() {
        if (!localStorage.getItem('isloggedin')) {
            window.location.href = '/sign-up';
        }
        await this.$store.dispatch(GET_GATEWAY_STATUS);
        // if(this.is_third_party_gateway){
        //     window.location.href = '/' +this.languageCode + '/';
        // }
        var hasVoucher = false;
        if (!this.is_multiple_gateway) {
            let response = await getMonetizationDetails();
            // is_promotion_enabled = res.data.data.monetization_methods[2].is_monetization_enabled;
            if (response.data && response.data.data && response.data.data.monetization_methods) {
                // Iterate over monetization_methods array
                response.data.data.monetization_methods.forEach(method => {
                    // Check if 'monetization_code' property contains 'voucher'
                    if (method.monetization_code.includes('voucher') || method.monetization_code.includes('coupon')) {
                        this.is_promotion_enabled = true;
                    }
                });
            }
        }
        console.log(this.is_promotion_enabled);
    },
    methods: {
        i18n,

        async subscriptionPlanContent(newValue) {
            if (newValue) {
                if (newValue.is_specific_plan == 1 && newValue.is_bulk_content == 0) {
                    if (newValue.content_uuIds.length > 0) {
                        return this.getContentByContentUuid(newValue.content_uuIds.join(','));
                    }
                } else if (newValue.is_specific_plan == 1 && newValue.is_bulk_content == 1) {
                    if (newValue.bulk_content_pattern) {
                        newValue.bulk_content_pattern = newValue.bulk_content_pattern.replaceAll('"key"', 'key').replaceAll('"value"', 'value').replaceAll('"operator"', 'operator');
                        return this.getvalidateContentPatterns(newValue.bulk_content_pattern);
                    }
                } else {
                    return ['All Content'];
                }
            }
        },
        async getContentByContentUuid(contentUUids) {
            let contentLists = [];
            if (contentUUids) {
                let res = await getContentByContentUuid(contentUUids).then(res => {
                    if (res.data.status === "SUCCESS") {
                        const content_list = res.data.data.contentList.content_list;
                        content_list.forEach(obj => {
                            contentLists.push(obj.content_name);
                        });
                    } else {
                        contentLists = ['No Detail Found'];
                    }
                });
            }
            return contentLists;
        },
        async getvalidateContentPatterns(pattern) {
            let contentLists = [];
            if (pattern) {
                const response = await getvalidateContentPattern(pattern);
                if (
                    response.data.code == 200 &&
                    response.data.data.validateContentPattern
                ) {
                    response.data.data.validateContentPattern.data.forEach(obj => {
                        if (contentLists.length == 0 || !contentLists.includes(obj.type)) {
                            contentLists.push(obj.type);
                            contentLists.push(obj.value);
                        } else if (contentLists.includes(obj.type)) {
                            contentLists.push(obj.value);
                        }
                    });
                } else {
                    contentLists = ['No Detail Found'];
                }
            }
            return contentLists;
        },

        i18n,
        displayDescription(plan_description) {
            if (plan_description.length > 500) {
                return plan_description.slice(0, 500).concat('...');
            } else {
                return plan_description;
            }
        },
        selectedPlan(data) {
            this.selectedindex = data;
            this.isSelected = true;
        },
        redirectCheckout(i, plan) {
            this.selectedPlanIndex = i + 1;
            if (localStorage.getItem('isloggedin') == "true") {
                const user = JSON.parse(window.localStorage.getItem("user"));
                const parts = user.name.split(' ');
                if (this.selected_plan_tax_uuid != null) {
                    this.planDetail = {
                        plan_uuid: plan.subscription_plan_uuid,
                        pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        billing_type: 2,
                        promo_code: this.applied_promocode,
                        promo_type: this.applied_promocode_type === 2 ? "voucher" : "coupon",
                        tax_uuid: this.selected_plan_tax_uuid,
                        gateway_order: {
                            first_name: parts[0],
                            last_name: parts[1],
                            email: user.email,
                            subscription_plan_uuid: plan.subscription_plan_uuid,
                            plan_free_trial_interval: plan.price[0].plan_free_trial_interval,
                            subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                            cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                            return_url: window.location.origin + '/checkout-success?billing_type=2',
                            promo_code: this.applied_promocode
                        }
                    };
                }
                else {
                    this.planDetail = {
                        plan_uuid: plan.subscription_plan_uuid,
                        pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        billing_type: 2,
                        promo_code: this.applied_promocode,
                        promo_type: this.applied_promocode_type === 2 ? "voucher" : "coupon",
                        gateway_order: {
                            first_name: parts[0],
                            last_name: parts[1],
                            email: user.email,
                            subscription_plan_uuid: plan.subscription_plan_uuid,
                            plan_free_trial_interval: plan.price[0].plan_free_trial_interval,
                            subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                            cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                            return_url: window.location.origin + '/checkout-success?billing_type=2',
                            promo_code: this.applied_promocode
                        }
                    };
                }

                if (this.selectedPlanIndex !== undefined) {
                    generateSST(this.planDetail).then((res) => {
                        let sst_token = res.data.data.sst_token;
                        window.location.href = "/checkout/" + sst_token + '/' + this.planDetail.billing_type;
                    });
                }
            } else {
                window.location.href = "/sign-up";
            }
        },
        selectedPlan: function (data, plan) {
            this.selectedindex = data;
            this.isSelected = true;
            this.selected_plan = plan,
                this.selected_plan_price = plan.price[0].subscription_plan_price.toFixed(2);

            this.selected_plan_promo_discount = 0.00;
            this.selected_plan_currency_symbol = plan.price[0].currency_symbol;
            this.is_free_plan = plan.is_free_plan;
            if(this.is_free_plan === 1){
                this.promocode = '';
            }
         if(this.is_free_plan === 1){
                this.promocode = '';
            }
            if (this.selected_plan.price[0].tax_data != null) {
                this.selected_plan_tax_uuid = this.selected_plan.price[0].tax_data.tax_uuid;
                this.selected_plan_tax_name = this.selected_plan.price[0].tax_data.tax_name;
                this.selected_plan_tax_rate = this.selected_plan.price[0].tax_data.amount;
                this.selected_plan_tax_amount = ((this.selected_plan.price[0].subscription_plan_price - this.coupon_discount_amount) * (this.selected_plan_tax_rate / 100)).toFixed(2);
                this.selected_plan_tax_type = this.selected_plan.price[0].tax_data.tax_type;
                this.selected_plan_final_amount = (this.selected_plan.price[0].subscription_plan_price - this.coupon_discount_amount + parseFloat(this.selected_plan_tax_amount)).toFixed(2);
            }
            else {
                this.selected_plan_tax_uuid = null;
                this.selected_plan_tax_name = "";
                this.selected_plan_tax_rate = 0.00;
                this.selected_plan_tax_amount = 0.00;
                this.selected_plan_tax_type = null;
                this.selected_plan_final_amount = this.selected_plan_price - this.coupon_discount_amount;
            }

        },
        async validatePromocode(promo) {
            // JsLoadingOverlay.show();
            const plans = [];

            plans.push(this.selected_plan.subscription_plan_uuid);

            let params = {
                promo_code: promo,
                subscription_plan_uuid: plans,
                billing_type: 2,
                subscription_pricing_uuid: this.selected_plan.price[0].subscription_pricing_uuid
            };

            const validate_promocode_response = await validatePromocode(params);

            if (validate_promocode_response.data.status === 'SUCCESS') {
                this.applied_promocode = promo;
                if (validate_promocode_response.data.data.promocode_type === 2) {
                    this.promocode_message = "Voucher applied";
                    this.applied_promocode_type = 2;
                    // JsLoadingOverlay.hide();
                } else {
                    const data = validate_promocode_response.data.data;
                    if (data.discount_type === 1) {
                        //percent
                        this.coupon_discount = `${data.discount}%`;
                        this.coupon_discount_amount = (this.selected_plan_price * (parseFloat(data.discount) / 100)).toFixed(2);

                    } else {
                        //flat
                        if (data.discount > this.selected_plan_price) {
                            this.coupon_discount = `${this.selected_plan_currency_symbol} ${this.selected_plan_price}`;
                            this.coupon_discount_amount = this.selected_plan_price;
                        } else {
                            this.coupon_discount = `${this.selected_plan_currency_symbol} ${data.discount}`;
                            this.coupon_discount_amount = data.discount;
                        }
                    }
                    this.promocode_message = "Coupon discount of " + this.coupon_discount + " applied";
                    this.applied_promocode_type = 1;
                    // JsLoadingOverlay.hide();
                }

            } else if (validate_promocode_response.data.status === 'FAILURE') {
                this.promocode_message = validate_promocode_response.data.message;
                this.applied_promocode_type = 0;
                this.applied_promocode = '';
                this.coupon_discount = '';
                this.coupon_discount_amount = 0.00;
                // JsLoadingOverlay.hide();
            }
        },
        resetPromocode() {
            this.promocode = '';
            this.applied_promocode = '';
            this.promocode_message = '';
            this.applied_promocode_type = 0;
            this.coupon_discount = '';
            this.coupon_discount_amount = 0.00;
        },
        async internalCheckout(i, plan) {
            JsLoadingOverlay.show();
            this.selectedPlanIndex = i + 1;
            let sst_token = '';
            if (localStorage.getItem('isloggedin') == "true") {
                const user = JSON.parse(window.localStorage.getItem("user"));
                const parts = user.name.split(' ');
                this.planDetail = {
                    plan_uuid: plan.subscription_plan_uuid,
                    pricing_uuid: plan.price[0].subscription_pricing_uuid,
                    billing_type: 2,
                    promo_code: this.applied_promocode,
                    promo_type: this.applied_promocode_type === 2 ? "voucher" : "coupon",
                    gateway_order: {
                        first_name: parts[0],
                        last_name: parts[1],
                        email: user.email,
                        subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                        return_url: window.location.origin + '/checkout-success?billing_type=2',
                        promo_code: this.applied_promocode
                    }
                };
                if (this.selectedPlanIndex !== undefined) {
                    try {
                        const res = await generateSST(this.planDetail);
                        const sst_token = res.data.data.sst_token;
                        let form = {
                            sst_token: '',
                            billing_type: Number
                        };
                        form.sst_token = sst_token;
                        form.billing_type = 2;

                        JsLoadingOverlay.show();

                        const checkoutResponse = await confirmCheckout(form);
                        JsLoadingOverlay.hide();
                        console.log(checkoutResponse);

                        if (checkoutResponse.data.code === 200) {
                            console.log("inside if");
                            let query_params = {
                                gateway_type: 'na',
                                transaction_uuid: 'na',
                                is_free_plan: plan.is_free_plan,
                            };
                            const params = new URLSearchParams(query_params);
                            console.log(params);
                            window.location.replace(`/checkout-success?${params.toString()}`);
                        } else {
                            console.log("inside else");
                            window.location.replace('/checkout-fail');
                        }
                    } catch (error) {
                        console.error(error);
                    }
                }

                JsLoadingOverlay.hide();

            } else {
                window.location.href = "/sign-up";
            }
        }
    },
    async mounted() {
        
        let languageCode = getCookie('lang_code');
        if (languageCode) {
            this.language_code = languageCode;
        }
        JsLoadingOverlay.show();
        try {
            let userGeoLocation = getUserGeoLocationFromCookies();
            if (!userGeoLocation) {
                await setUserGeoLocationOnCookies();
                userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
            } else {
                userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
            }
            this.countryCode = userGeoLocation.country_code;
        } catch (error) {
            console.error("Something went wrong!", error.message);
        }
        const subscription_plans_response = await getSubscriptionPlans(this.countryCode);
        if (subscription_plans_response.data.code == 200 && subscription_plans_response.data.status === "SUCCESS") {
            const subscription = subscription_plans_response.data.data.subscriptionPlans.subscription_plans_list;
            /* let contentName = [];
             for (const obj of subscription) {
                 let content = await this.subscriptionPlanContent(obj);
                 contentName.push(content);
               }
             this.contentList = contentName;*///It was commented because the Plan Detail is hidden.
            this.subscription_plans = subscription;
            this.subscription_plans.sort((obj1, obj2) => (obj2.hasOwnProperty('is_free_plan') && obj2.is_free_plan === 1 ? 1 : 0) - (obj1.hasOwnProperty('is_free_plan') && obj1.is_free_plan === 1 ? 1 : 0));
            this.selectedindex = this.subscription_plans.findIndex(sp => sp.is_default === 1);
            this.selectedindex = this.selectedindex >= 0 ? this.selectedindex : 0;
            this.isSelected = true;
            this.selected_plan = this.subscription_plans[this.selectedindex];
            this.is_free_plan = this.subscription_plans[this.selectedindex].is_free_plan;
            this.selected_plan_price = this.subscription_plans[this.selectedindex].price[0].subscription_plan_price.toFixed(2);
            this.selected_plan_currency_symbol = this.subscription_plans[this.selectedindex].price[0].currency_symbol;
            if (this.selected_plan.price[0].tax_data != null) {
                this.selected_plan_tax_uuid = this.selected_plan.price[0].tax_data.tax_uuid;
                this.selected_plan_tax_name = this.selected_plan.price[0].tax_data.tax_name;
                this.selected_plan_tax_rate = this.selected_plan.price[0].tax_data.amount;
                this.selected_plan_tax_amount = ((this.selected_plan.price[0].subscription_plan_price - this.coupon_discount_amount) * (this.selected_plan_tax_rate / 100)).toFixed(2);
                this.selected_plan_tax_type = this.selected_plan.price[0].tax_data.tax_type;
                this.selected_plan_final_amount = (this.selected_plan.price[0].subscription_plan_price - this.coupon_discount_amount + parseFloat(this.selected_plan_tax_amount)).toFixed(2);
            }
            else {
                this.selected_plan_tax_uuid = null;
                this.selected_plan_tax_name = "";
                this.selected_plan_tax_rate = 0.00;
                this.selected_plan_tax_amount = 0.00;
                this.selected_plan_tax_type = null;
                this.selected_plan_final_amount = this.selected_plan_price - this.coupon_discount_amount;
            }
        } else {
            if (subscription_plans_response.data.code === 600 && subscription_plans_response.data.status === "FAILED") {
                window.location.replace("/home");
            }
        }
        //$('#ajaxApp').removeClass('body-container');
        JsLoadingOverlay.hide();
    },
    watch: {
        selected_plan() {
            return this.selected_plan;
        },
        applied_promocode_type() {
            return this.applied_promocode_type;
        },
        promocode() {
            if (!this.promocode) {
                this.promocode = '';
                this.applied_promocode = '';
                this.promocode_message = '';
                this.applied_promocode_type = 0;
                this.coupon_discount = '';
                this.coupon_discount_amount = 0.00;
            }
        },
    }
};

let {
    getContent,
    isAuthorizedContent,
} = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_five}=await import(window.importLocalJs('widgets/content-hover/content-hover-five.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { GET_END_USER_REGD_LOGIN_SETTING } = await import(window.importAssetJs('js/configurations/actions.js'));

export default {
    name: "product_list_five",
    emits: ["plpmopen"],
    components: {
        content_hover_five,
        audio_player_one,
    },
    data() {
        return {
            allContentDetails: [],
            contentUuid: "",
            videoDuration: "",
            audioDuration: "",
            nodatafound: false,
            isAuthorized: null,
            audioUuid: "",
            uniqueId: "",
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: "",
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            contentParentUuid: "",
            stickyAudioData: "",
            removeJs: true,
            playBackRatesValue: [],
            // dynamicContentid: localStorage.getItem("contentId"),
            isAuthorizedContent: null,
            isViewTrailer: false,
            noDataFound: true,
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true,
            copiedText: false,
        };
    },
    beforeMount() {},
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    created() {
        this.isViewTrailer = true;
        // JsLoadingOverlay.show();
    },

    mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.enduserURL = window.location.origin + "/";
        this.baseURL = getBaseUrl();

        const params = {
            query: '{ contentList(ip_address:":ip",app_token:":app_token",product_key:":product_key",store_key:":store_key", page: 1, per_page: 50,only_parent:true) { content_list {structure_uuid is_playlist is_encoded is_parent app_token product_key content_uuid content_parent_uuid content_name content_level content_permalink content_category_uuid content_asset_type content_trailer_uuid content_asset_uuid content_poster_uuid no_image_available_url video_details {video_uuid file_name file_url duration third_party_url encoding_end_time encoding_status expected_duration reference_uuid is_feed} audio_details {duration file_url encoding_status} trailer_details {video_uuid file_name file_url} posters {website{file_uuid file_url file_name} } }}}',
        };
        getContent(params).then((res) => {
            // JsLoadingOverlay.hide();
            if (res.data.code == 200 && res.data.data.contentList) {
                this.allContentDetails = res.data.data.contentList.content_list;
                this.allContentDetails.forEach((ele) => {
                    if (ele.video_details !== null) {
                        const vDuration = ele.video_details.duration.replace(
                            /^0(?:0:0?)?/,
                            ""
                        );
                        if (vDuration.length <= 5) {
                            this.videoDuration = vDuration
                                .replace(":", "m ")
                                .concat("s");
                        } else {
                            this.videoDuration = vDuration
                                .replace(":", "h ")
                                .replace(":", "m ")
                                .concat("s");
                        }
                    }
                    if (ele.audio_details !== null) {
                        const aDuration = ele.audio_details.duration.replace(
                            /^0(?:0:0?)?/,
                            ""
                        );
                        if (aDuration.length <= 5) {
                            this.audioDuration = aDuration
                                .replace(":", "m ")
                                .concat("s");
                        } else {
                            this.audioDuration = aDuration
                                .replace(":", "h ")
                                .replace(":", "m ")
                                .concat("s");
                        }
                    }
                });

                this.nodatafound = false;
            } else {
                this.nodatafound = true;
            }
        });
    },
    methods: {
        getRootUrl,
        i18n,
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },
        playTrailer(content_uuid) {
            window.location.href = "/player/" + content_uuid;
        },
        playContent(content_uuid, contentname, assetType, is_parent) {
            isAuthorizedContent(content_uuid).then((res) => {
                if (res.data.code == 200) {
                    this.isAuthorized =
                        res.data.data.isAuthorized.is_content_authorized;
                    if (this.isAuthorized == true) {
                        jQuery("#purchase-modal").modal("hide");
                        if (assetType == 1) {
                            window.location.href = "/player/" + content_uuid;
                        } else {
                            this.audioPlayControl = false;
                            this.audioUuid = content_uuid;
                        }
                    } else {
                        this.$emit("opencpmodal", {
                            content_uuid,
                            monetization_methods:
                                res.data.data.isAuthorized
                                    .monetization_details_list[0]
                                    .monetization_methods,
                        });
                        jQuery("#purchase-modal").modal("hide");
                    }
                }
            });
        },
        openCPModal(e) {
            this.$emit("plpmopen", e);
        },
        playAudioContent(contentUuid) {
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        copyURL() {
            const el = document.createElement("textarea");
            el.value = window.location.href;
            el.setAttribute("readonly", "");
            el.style.position = "absolute";
            el.style.left = "-9999px";
            document.body.appendChild(el);
            const selected =
                document.getSelection().rangeCount > 0
                    ? document.getSelection().getRangeAt(0)
                    : false;
            el.select();
            document.execCommand("copy");
            document.body.removeChild(el);
            if (selected) {
                document.getSelection().removeAllRanges();
                document.getSelection().addRange(selected);
            }
            this.copiedText = true;
        },
    },

    template: /*html*/ `
    <vd-component class="vd product-list-five" type="product-list-five">
      <template v-if="allContentDetails && !nodatafound">
        <section id="iq-favorites">
        <section class="product-listing">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 overflow-hidden">
                        <div class="d-flex align-items-center justify-content-between">
                            <h4 class="main-title"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h4>
                        </div>
                    </div>
                </div>
                            <div class="owl-product-garnet owl-carousel owl-theme">
                                <template v-for="data in allContentDetails">    
                                    <div class="item">
                                        <li style="list-style:none" class="swiper-slide slide-item">
                                            <div class="block-images position-relative ">
                                                <div class="img-box">
                                                    <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" />
                                                    <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="Godzilla vs Kong" />
                                                </div>
                                                <div class="block-description">
                                                    <h6 class="iq-title"><a class="callByAjax" :href="'/content/'+data.content_permalink">
                                                        <span v-if="data.content_name">{{data.content_name}}</span>
                                                      </a>
                                                    </h6>
                                                    <div class="movie-time d-flex align-items-center my-2">
                                                        <span class="text-white">{{data.video_details ? data.video_details.duration.replace(":","hr ").replace(":","mins ") + "secs" : ''}}</span>
                                                     </div>
                                                    <content_hover_five :id="$attrs['id'] +'_content_hover_five_5'"
                                                        :content="data"
                                                        :playNowBtnTxt="$attrs['label2']"
                                                        :viewTrailerBtnTxt="$attrs['label4']"
                                                        :playAllBtnTxt="$attrs['label5']"
                                                        :watchNowBtnTxt="$attrs['label3']"
                                                        :isLogedIn="isLogedIn"
                                                        @playAudioContent="playAudioContent"
                                                    />
                                                </div>
                                                <div class="block-social-info">
                                                    <ul class="list-inline p-0 m-0 music-play-lists-category">
                                                        <li class="share">
                                                            <span><i class="fa-solid fa-share-nodes"></i></span>
                                                            <div class="share-box">
                                                                <div class="d-flex align-items-center">
                                                                    <a vd-name="facebook" href="https://www.facebook.com/muvidotcom" target="_blank" rel="noopener noreferrer" class="share-ico" tabindex="0"><i class="fa-brands fa-facebook-f"></i></a>
                                                                    <a vd-name="twitter" href="https://twitter.com/muvi" target="_blank" rel="noopener noreferrer" class="share-ico" tabindex="0"><i class="fa-brands fa-x-twitter"></i></a>
                                                                    <a v-if="!copiedText" class="share-ico callByAjax" href="Javascript:void(0);">
                                                                        <i class="fa-solid fa-link" @click="copyURL()"></i>
                                                                        </a>
                                                                        <a v-if="copiedText" class="share-ico callByAjax" href="Javascript:void(0);">
                                                                        <i class="fa-solid fa-check"></i>
                                                                        </a>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <span><i class="fa-solid fa-heart"></i></span>
                                                            <span class="count-box">0</span>
                                                        </li>
                                                        <li><span><i class="fa-solid fa-plus"></i></span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    </div>
                                </template>
                            </div>
            </div>
        </section>
        </section>
      </template>
    <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
  </vd-component>`,
};

let {
    getContent,
    isAuthorizedContent,makeContentFavorite,
    getContentFavoriteStatus,getContentSettingsDetails
} = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_two}=await import(window.importLocalJs('widgets/content-hover/content-hover-two.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { GET_END_USER_REGD_LOGIN_SETTING } = await import(window.importAssetJs('js/configurations/actions.js'));
export default {
    name: "product_list_two",
    emits: ["plpmopen"],
    components: {
        content_hover_two,
        audio_player_one,
    },
    data() {
        return {
            allContentDetails: [],
            contentUuid: "",
            videoDuration: "",
            audioDuration: "",
            nodatafound: false,
            isAuthorized: null,
            audioUuid: "",
            uniqueId: "",
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: "",
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            contentParentUuid: "",
            stickyAudioData: "",
            removeJs: true,
            playBackRatesValue: [],
            // dynamicContentid: localStorage.getItem("contentId"),
            isAuthorizedContent: null,
            isViewTrailer: false,
            noDataFound: true,
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true,
						isFavourite: 0,
            isFavouriteEnabled: false,
        };
    },
    beforeMount() {},
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    created() {
        this.isViewTrailer = true;
        // JsLoadingOverlay.show();
    },

    mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
				this.getContentSettingsDetails();
        this.enduserURL = window.location.origin + "/";
        this.baseURL = getBaseUrl();
				
        const params = {
            query: '{ contentList(ip_address:":ip",app_token:":app_token",product_key:":product_key",store_key:":store_key", page: 1, per_page: 50,only_parent:true) { content_list {structure_uuid is_playlist is_encoded is_parent app_token product_key content_uuid content_parent_uuid content_name is_free_content content_level content_permalink content_category_uuid content_asset_type content_trailer_uuid content_asset_uuid content_poster_uuid no_image_available_url video_details {video_uuid file_name file_url duration third_party_url encoding_end_time encoding_status expected_duration reference_uuid is_feed} audio_details {duration file_url encoding_status} trailer_details {video_uuid file_name file_url} posters {website{file_uuid file_url file_name} } }}}',
        };
				
        getContent(params).then((res) => {
            // JsLoadingOverlay.hide();
            if (res.data.code == 200 && res.data.data.contentList) {
                this.allContentDetails = res.data.data.contentList.content_list;
                this.allContentDetails.forEach((ele) => {
                    if (ele.video_details !== null) {
                        const vDuration = ele.video_details.duration.replace(
                            /^0(?:0:0?)?/,
                            ""
                        );
                        if (vDuration.length <= 5) {
                            this.videoDuration = vDuration
                                .replace(":", "m ")
                                .concat("s");
                        } else {
                            this.videoDuration = vDuration
                                .replace(":", "h ")
                                .replace(":", "m ")
                                .concat("s");
                        }
                    }
                    if (ele.audio_details !== null) {
                        const aDuration = ele.audio_details.duration.replace(
                            /^0(?:0:0?)?/,
                            ""
                        );
                        if (aDuration.length <= 5) {
                            this.audioDuration = aDuration
                                .replace(":", "m ")
                                .concat("s");
                        } else {
                            this.audioDuration = aDuration
                                .replace(":", "h ")
                                .replace(":", "m ")
                                .concat("s");
                        }
                    }
                });

                this.nodatafound = false;
            } else {
                this.nodatafound = true;
            }
        });
    },
    methods: {
        getRootUrl,
        i18n,
				getContentSettingsDetails() {
					getContentSettingsDetails().then((res) => {
						if (res.data.code == 200) {
						 this.isFavouriteEnabled = (res.data.data.contentSettings.content_favourite_settings != null) ? res.data.data.contentSettings.content_favourite_settings ?.is_enabled : false;
					}
				});
			},
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },
        playTrailer(content_uuid) {
            window.location.href = "/player/" + content_uuid;
        },
        playContent(content_uuid, contentname, assetType, is_parent) {
            isAuthorizedContent(content_uuid).then((res) => {
                if (res.data.code == 200) {
                    this.isAuthorized =
                        res.data.data.isAuthorized.is_content_authorized;
                    if (this.isAuthorized == true) {
                        jQuery("#purchase-modal").modal("hide");
                        if (assetType == 1) {
                            window.location.href = "/player/" + content_uuid;
                        } else {
                            this.audioPlayControl = false;
                            this.audioUuid = content_uuid;
                        }
                    } else {
                        this.$emit("opencpmodal", {
                            content_uuid,
                            monetization_methods:
                                res.data.data.isAuthorized
                                    .monetization_details_list[0]
                                    .monetization_methods,
                        });
                        jQuery("#purchase-modal").modal("hide");
                    }
                }
            });
        },
        openCPModal(e) {
            this.$emit("plpmopen", e);
        },
        playAudioContent(content_detail) { //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
				getFavoriteContents(page, onScroll) {
					if (this.isNextPageCallReqd) {
							(this.isNextPageCallReqd = false), JsLoadingOverlay.show();
							getFavoriteContents(page).then((res) => {
									JsLoadingOverlay.hide();
									if (
											!onScroll &&
											res.data.code == 200 &&
											res.data.data.favouriteContentList
													.content_favourite_list
									) {
											this.favoriteContents =
													res.data.data.favouriteContentList.content_favourite_list;
											let contents = [];
											this.favoriteContents.forEach(element => {
													contents.push(element.content_details);
											});    
											//contentHelper.getPartnerAndUserUuids(contents,this.userList);
									} else if (
											onScroll &&
											res.data.code == 200 &&
											res.data.data.favouriteContentList
													.content_favourite_list
									) {
											this.favoriteContents.push(
													...res.data.data.favouriteContentList
															.content_favourite_list
											);
											let contents = [];
											res.data.data.favouriteContentList
															.content_favourite_list.forEach(element => {
													contents.push(element.content_details);
											});    
										 // contentHelper.getPartnerAndUserUuids(contents,this.userList);
									}
									if (!onScroll && page == 1 && res.data.status == "FAILED") {
											this.favoriteContents = [];
									}

									if (
											res.data.code == 200 &&
											this.favoriteContents?.length <
													res.data.data.favouriteContentList.page_info
															.total_count
									) {
											this.isNextPageCallReqd = true;
									}
									if (
											this.favoriteContents == null ||
											this.favoriteContents?.length <= 0
									) {
											this.noRecordMsgShow = true;
									}
							});
					}
			},
			getContentFavouriteAction(contentUuid) {
				getContentFavoriteStatus(contentUuid).then((res) => {
						if (res.data.code == 200 && res.data.data !== null) {
								this.isFavourite = res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
						} else {
								this.isFavourite = 0;
						}
				});
		},
		favouriteEvent(contentDetails) {
			if (this.isLogedIn) {
						const param = {
								"app_token": ":app_token",
								"product_key": ":product_key",
								"store_key": ":store_key",
								"end_user_uuid": ":me",
								"content_uuid": contentDetails.content_uuid,
								"is_favourite": this.isFavourite == 0 ? 1 : 0,
						}
						makeContentFavorite(param).then((res) => {
								if (res.data.code == 200 && res.data.status == "SUCCESS") {
										this.getContentFavouriteAction(contentDetails.content_uuid);
								}
						})
				} else {
						window.location.href ="/sign-up";
				}
		},
    },
    template: `
    <vd-component class="vd product-list-two" type="product-list-two"> 
    <div>
      <template v-if="allContentDetails && !nodatafound">
        <section class="section-padding">
          <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12">
                  <h4 class="heading-title"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h4>                   
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                 <div class="raiden-product-slider">
                   <div class="owl-product owl-carousel owl-loaded owl-drag">                 
                    <template v-for="data in allContentDetails">
                      <div class="item">
                        <div class="product-slider-container">
                                    <div class="product-slider-image">
                                        <div class="icons-apply">
                                            <img v-if="data.is_playlist==0 && data.content_asset_type == 1" :src="getRootUrl() + 'img/video-icons.png'"/>
                                            <img v-if="data.is_playlist==0 && data.content_asset_type == 2" :src="getRootUrl() + 'img/audio-icon.png'"/>
                                            <img v-if="data.is_playlist==1" :src="getRootUrl() + 'img/playlist-icon.png'"/>
                                        </div>
                                         <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" />
                                         <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="Godzilla vs Kong" />
                                         <div class="product-like-option" v-if="data.content_level==0">
                                            <div class="like like-heart" v-show="isFavouriteEnabled">
                                                <div class="ulike ulike_is_not_liked">
                                                    <button type="button" class="ulike_btn dislike-image" @click="favouriteEvent(data)"></button>
                                                </div>
                                            </div>
                                        </div>
                                         <content_hover_two :id="$attrs['id'] +'_content_hover_two_2'" 
                                            :content="data" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"/>
                                    </div>
                                    <div class="gen-info-contain">
                                        <div class="gen-movie-info">
                                            <h3 v-if="data.content_name"><a class="callByAjax" :href="'/content/'+data.content_permalink">{{data.content_name}}</a></h3>
                                        </div>
                                    </div>
                            </div> 
                      </div>    
                    </template>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </template>
    </div>
    <audio_player_one :root_url="$attrs['root_url']" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent" />   
    </vd-component>
`,
};

let {
    getContent,
    isAuthorizedContent,
} = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_three}=await import(window.importLocalJs('widgets/content-hover/content-hover-three.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: 'product_list_three',
    emits: ['plpmopen'],
    components : {
        content_hover_three,
    },
    data() {
        return {
            rootUrl:getRootUrl(),
            allContentDetails: [], 
            contentUuid: '',
            videoDuration: '',
            audioDuration: '',
            nodatafound: false,
            isAuthorized: null,
            audioUuid: '',
            uniqueId: '',
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: '',
            user_Info: JSON.parse(localStorage.getItem('user')), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem('isloggedin'),
            contentParentUuid: '',
            stickyAudioData: '',
            removeJs: true,
            playBackRatesValue: [],
            // dynamicContentid: localStorage.getItem("contentId"),
            isAuthorizedContent: null,
            isViewTrailer: false,
            noDataFound: true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
        }
    },
    beforeMount() {

    },
    updated() {
        owlCarousal();
        $('.slider-active').slick({
            dots: true,
            infinite: false,
            arrows:true,
            autoplay:false,
            speed: 300,
            slidesToShow: 5,
            accessibility: true,
            prevArrow: '<button class="slide-arrow prev-arrow"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
            nextArrow: '<button class="slide-arrow next-arrow"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
            responsive: [
                {
                  breakpoint: 1280,
                  settings: {
                    slidesToShow: 3.5,
                    variableWidth: true,
                  }
                },
                {
                  breakpoint: 992,
                  settings: {
                    slidesToShow: 2.5,
                    variableWidth: true,
                    adaptiveHeight: true,
                  }
                },
                {
                  breakpoint: 767,
                  settings: {
                    slidesToShow: 1.4,
                    variableWidth: false,
                    adaptiveHeight: true,
                    accessibility: true,
                  }
                }
              ]
        });
    },
    created() {
        this.isViewTrailer = true;
    },

    mounted() {
        this.enduserURL = window.location.origin + '/';
        this.baseURL = getBaseUrl();

        const params = {
            "query": "{ contentList(ip_address:\":ip\",app_token:\":app_token\",product_key:\":product_key\",store_key:\":store_key\", page: 1, per_page: 50,only_parent:true) { content_list {structure_uuid avg_rating like_status is_playlist level_one_count level_two_count is_encoded is_parent app_token product_key content_uuid content_parent_uuid content_name content_level content_permalink content_category_uuid content_asset_type content_search_tag content_desc content_trailer_uuid content_asset_uuid content_poster_uuid no_image_available_url categories{ category_name } video_details {video_uuid file_name file_url duration third_party_url encoding_end_time encoding_status expected_duration reference_uuid is_feed} audio_details {duration file_url encoding_status} trailer_details {video_uuid file_name file_url} posters {website{file_uuid file_url file_name} tv_apps{file_uuid file_url file_name} mobile_apps{file_uuid file_url file_name} } banners {website{file_uuid file_url file_name} tv_apps{file_uuid file_url file_name} mobile_apps{file_uuid file_url file_name}} categories {category_uuid category_name category_parent_uuid } cast_details {cast_uuid cast_name cast_bio cast_image_uuid created_date cast_image_details {image_uuid file_name file_url } cast_type_details {cast_type_uuid cast_type_name }}}}}"
        };
        getContent(params).then((res) => {
            if (res.data.code == 200 && res.data.data.contentList) {
                this.allContentDetails = res.data.data.contentList.content_list;
                this.allContentDetails.forEach(ele => {
                    if (ele.video_details !== null) {
                        const vDuration = ele.video_details.duration.replace(/^0(?:0:0?)?/, '');
                        if (vDuration.length <= 5) {
                            this.videoDuration = vDuration.replace(':', 'm ').concat('s');
                        } else {
                            this.videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                        }
                    }
                    if (ele.audio_details !== null) {
                        const aDuration = ele.audio_details.duration.replace(/^0(?:0:0?)?/, '');
                        if (aDuration.length <= 5) {
                            this.audioDuration = aDuration.replace(':', 'm ').concat('s');
                        } else {
                            this.audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                        }
                    }
                });

                this.nodatafound = false;
            } else {
                this.nodatafound = true;
            }
        });

        
    },
    methods: {
        i18n,
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration.replace(':', 'm ').concat('s');

                }
                else {
                    videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');

                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration.replace(':', 'm ').concat('s');
                } else {
                    var audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                }
                return audioDuration;
            }
        },
        playTrailer(content_uuid) {
            window.location.href = "/player/" + content_uuid;
        },
        playContent(content_uuid, contentname, assetType, is_parent) {
            isAuthorizedContent(content_uuid).then((res) => {
                if (res.data.code == 200) {
                    this.isAuthorized = res.data.data.isAuthorized.is_content_authorized;
                    if (this.isAuthorized == true) {
                        jQuery('#purchase-modal').modal('hide');
                        if (assetType == 1) {
                            window.location.href = "/player/" + content_uuid;
                        } else {
                            this.audioPlayControl = false;
                            this.audioUuid = content_uuid;
                        }
                    } else {
                        this.$emit('opencpmodal', {
                            content_uuid,
                            monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                        });
                        jQuery('#purchase-modal').modal('hide');
                    }

                }

            });
        },
        openCPModal(e) {
            this.$emit('plpmopen', e);
        },
        playAudioContent(contentUuid){
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `<vd-component class="vd product-list-three" type="product-list-three">
    <template v-if="allContentDetails && !nodatafound">

    <div class="category-slider-area border-bottom overflow-hidden">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                    <h2>
                        <vd-component-param  type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                    </h2>  
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                 
                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="business" role="tabpanel" aria-labelledby="business-tab">
                    <div class="row slider-active vd-no-navigation">
                    <div class="col-md" v-for="(data,i) in allContentDetails" :key="i" >
                   
                   <div class="single-topic-box">
                           <div class="topic-preview">
                               <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" class="img-fluid"  />
                               <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="Godzilla vs Kong" class="img-fluid"  />

                           </div>
                           <div class="topic-overlay">
                               <div class="topic-details">
                                   <span class="d-none">$400.00</span>
                                   <p>{{data.content_name}}</p>
                                   <span class="rating">
                                   <svg v-if="parseInt(data.avg_rating) >0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                    </svg>
                                    {{data.avg_rating}}

                                    <svg v-if="parseInt(data.avg_rating)<=0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                    </svg>
                                   </span>
                               </div>
                               <!-- Hover Text Start -->
                               
                               <div class="hover-details col-12">
                                   <div class="row justify-content-end gx-0 h-100">
                                       <div class="col-12  align-self-start">
                                           <span class="d-block text-end wishlist d-none">
                                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                                               </svg>
                                           </span>
                                           <p v-if="data.content_name">{{data.content_name}}</p>
                                       </div>
                                       <div class="col-12 align-self-end px-0">
                                           <div class="row gx-0 justify-content-between">
                                           <div class="col-auto" v-if="data.categories.category_name">
                                                <div class="badge" v-for="cat in data.categories">
                                                {{cat.category_name}}
                                                </div>
                                            </div>
                                               <div v-if="data.cast_details" class="col-auto" v-for="(cast,j) in data.cast_details" :key="j">
                                                   <span class="author">{{cast.cast_name}}</span>
                                               </div>
                                           </div> 
                                           <div class="row gx-0"> 
                                               <div class="col-12">
                                                   <div class="course-info" v-if="data.content_desc">
                                                       {{data.content_desc.substring(0, 120)}}
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="row gx-0 justify-content-between align-items-center">
                                               <div class="col-auto">
                                                   <span class="price d-none">$350.00</span>
                                               </div>
                                               <div class="col-auto d-none">
                                                   <button class="buy-btn">Buy Now</button>
                                               </div>
                                               <div class="col-auto d-none">
                                                   <content_hover_three :id="$attrs['id'] +'_content_hover_three_1'"
                                                       :content="data"
                                                       :playNowBtnTxt="$attrs['label2']"
                                                       :viewTrailerBtnTxt="$attrs['label4']"
                                                       :playAllBtnTxt="$attrs['label5']"
                                                       :watchNowBtnTxt="$attrs['label3']"
                                                       :isLogedIn="isLogedIn"
                                                       @playAudioContent="playAudioContent"
                                                   />
                                               </div>
                                           </div>
                                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                                               <div class="col-auto">
                                                   <span class="rating">
                                                   <svg v-if="parseInt(data.avg_rating) >0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                    </svg>
                                                    {{data.avg_rating}}
                
                                                    <svg v-if="parseInt(data.avg_rating)<=0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                    </svg>
                                                   </span>
                                               </div>
                                               <div class="col-auto">
                                             
                   
                                                   <a :href="'/content/'+data.content_permalink" class="details-btn callByAjax">
                                                       View Detail
                                                       <div class="svg">
                                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                                           </svg>
                                                       </div>
                                                   </a>
                                               </div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                               <!-- Hover Text End -->
                           </div>
                       </div>
                   </div>
                           
                          
                          
                        </div>
                    </div>
                   
                   
                </div>
                <!-- Tabs Area End -->
                </div>
            </div>
        </div>
    </div>











    <!--================================================================
                             TOPICS AREA START 
    ==================================================================-->
    <div class="topics-area border-bottom d-none">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                    <h2><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <!-- Tabs List Start -->
                <ul class="nav nav-tabs mu-tab" id="myTab" role="tablist">
                    <!-- Tab List -->
                    <li class="nav-item" role="presentation">
                         <button class="nav-link active" id="trending-tab" data-bs-toggle="tab" data-bs-target="#trending" type="button" role="tab" aria-controls="trending" aria-selected="true">Trending</button>
                     </li>
                    <!-- Tab List -->
                    <!-- Tab List -->
                    <li class="nav-item" role="presentation">
                         <button class="nav-link" id="toppic-tab" data-bs-toggle="tab" data-bs-target="#toppic" type="button" role="tab" aria-controls="toppic" aria-selected="false">Top Pick</button>
                     </li>
                    <!-- Tab List -->
                    <!-- Tab List -->
                    <li class="nav-item" role="presentation">
                         <button class="nav-link" id="recent-tab" data-bs-toggle="tab" data-bs-target="#recent" type="button" role="tab" aria-controls="recent" aria-selected="false">Recent Added</button>
                     </li>
                    <!-- Tab List -->
                    <!-- Tab List -->
                    <li class="nav-item" role="presentation">
                         <button class="nav-link" id="popular-tab" data-bs-toggle="tab" data-bs-target="#popular" type="button" role="tab" aria-controls="home" aria-selected="false">Popular Category</button>
                     </li>
                    <!-- Tab List -->
                 </ul>
                 <!-- Tabs List End -->
                 <!-- Tabs Category Start -->
                <div class="scroll-bar">
                    <ul class="categories-list text-uppercase">
                        <li><a href="#">Python</a></li>
                        <li><a href="#">DATA ALGO</a></li>
                        <li><a href="#">JAVASCRIPT</a></li>
                        <li><a href="#">RUBY</a></li>
                        <li><a href="#">C++</a></li>
                        <li><a href="#">JAVA</a></li>
                        <li>
                            <select class="selectpicker">
                                <option selected disabled>MORE</option>
                                <option>One</option>
                                <option>Two</option>
                                <option>Three</option>
                            </select>
                              
                              
                        </li>
                     </ul>
                </div>
                 <!-- Tabs Category End -->
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="trending" role="tabpanel" aria-labelledby="trending-tab">
                        <div class="row row-cols-md-3 row-cols-lg-5 gx-3 gy-4">
                            <div class="col-md" v-for="(data,i) in allContentDetails" :key="i" >
                   
                            <div class="single-topic-box">
                                    <div class="topic-preview">
                                        <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" class="img-fluid"  />
                                        <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="Godzilla vs Kong" class="img-fluid"  />

                                    </div>
                                    <div class="topic-overlay">
                                        <div class="topic-details">
                                            <span>$400.00</span>
                                            <p>{{data.content_name}}</p>
                                            <span class="rating">
                                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                </svg>
                                                4.5
                                            </span>
                                        </div>
                                        <!-- Hover Text Start -->
                                        
                                        <div class="hover-details col-12">
                                            <div class="row justify-content-end gx-0 h-100">
                                                <div class="col-12  align-self-start">
                                                    <span class="d-block text-end wishlist d-none">
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                                                        </svg>
                                                    </span>
                                                    <p v-if="data.content_name">{{data.content_name}}</p>
                                                </div>
                                                <div class="col-12 align-self-end px-0">
                                                    <div class="row gx-0 justify-content-between">
                                                        <div class="col-auto" v-if="data.categories.category_name">
                                                        <div class="badge" v-for="cat in data.categories">
                                                        {{cat.category_name}}
                                                        </div>
                                                    </div>
                                                        <div v-if="data.cast_details" class="col-auto" v-for="(cast,j) in data.cast_details" :key="j">
                                                            <span class="author">{{cast.cast_name}}</span>
                                                        </div>
                                                    </div>
                                                    <div class="row gx-0"> 
                                                        <div class="col-12">
                                                            <div class="course-info" v-if="data.content_desc">
                                                                {{data.content_desc.substring(0, 120)}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row gx-0 justify-content-between align-items-center">
                                                        <div class="col-auto">
                                                            <span class="price">$350.00</span>
                                                        </div>
                                                        <div class="col-auto">
                                                            <button class="buy-btn">Buy Now</button>
                                                        </div>
                                                        <div class="col-auto">
                                                            <content_hover_three :id="$attrs['id'] +'_content_hover_three_1'"
                                                                :content="data"
                                                                :playNowBtnTxt="$attrs['label2']"
                                                                :viewTrailerBtnTxt="$attrs['label4']"
                                                                :playAllBtnTxt="$attrs['label5']"
                                                                :watchNowBtnTxt="$attrs['label3']"
                                                                :isLogedIn="isLogedIn"
                                                                @playAudioContent="playAudioContent"
                                                            />
                                                        </div>
                                                    </div>
                                                    <div class="row gx-0 justify-content-between align-items-center mt-3">
                                                        <div class="col-auto">
                                                            <span class="rating">
                                                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                                </svg>
                                                                4.5
                                                            </span>
                                                        </div>
                                                        <div class="col-auto">
                                                      
                            
                                                            <a :href="'/content/'+data.content_permalink" class="details-btn callByAjax">
                                                                View Detail
                                                                <div class="svg">
                                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                                                    </svg>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Hover Text End -->
                                    </div>
                                </div>
                            </div>
                            
                                        <!-- Hover Text End -->
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
               
                </div>
            </div>
        </div>
    </div>
    <!--================================================================
                             TOPICS AREA END 
    ==================================================================-->

</template>

  </vd-component>`
};

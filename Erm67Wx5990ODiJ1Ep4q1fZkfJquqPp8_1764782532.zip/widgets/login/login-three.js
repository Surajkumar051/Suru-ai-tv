let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {
    loginUser,
    getEndUserRegdLoginSetting,
    // getVdConfig,
} = await import(window.importAssetJs('js/webservices.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let { setUserDataOnLocalStorage } =await import(window.importAssetJs('js/main.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));

const { mapState} = Vuex;
export default {
    name: 'login_three',
    data() {
        return {
            rootUrl: getRootUrl(),
            user_email: "",
            password: "",
            remember_me: "",
            errors: {},
            email_filed: false,
            showPassword: false,
            isChecked: false,
            logo_src: '',
            logo_alt: '',
            logo_style: '',
            isLogoUpdated:Boolean
        }
    },
    computed: {
        email() {
            return this.user_email;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
        })
    },
    created() {
        let isloggedIn = localStorage.getItem("isloggedin");
        if (isloggedIn) {
            window.location.href = "/home";
        }
    },
    mounted() {
        // this.isChecked = true;
        // JsLoadingOverlay.show();
        getEndUserRegdLoginSetting().then((res) => {
            if (res.data.code == 200 && res.data.data !== null) {
                const requireRegistrationAndLogin = parseInt(res.data.data.sections[0].groups[0].nodes[0].node_value);
                if (requireRegistrationAndLogin != 1) {
                    window.location.href = "/";
                }

            }
        });
			// 	getVdConfig('logo').then((res) => {
			// 		if (res.data.code == 200 && res.data.data !== null) {
			// 			this.isLogoUpdated=true;
			// 			this.logo_alt=res.data.data.alt;
			// 			this.logo_src=res.data.data.src;
			// 			this.logo_style=res.data.data.style;
			// 			 }
			// 	 else{
			// 			 this.isLogoUpdated=false;
			// 	 }
			// }).catch(ex => {
			// 		console.log(ex);
			// });

        JsLoadingOverlay.hide();
    },
    watch: {
        email(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.user_email = "Email field is required";

            } else if (!value.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.user_email = "Please enter a valid email";

            } else {
                this.errors.user_email = null;
                this.email_filed = false;
            }
        }
    },
    methods: {
        getRootUrl,
        i18n,
        submitLoginForm() {
            if (!this.user_email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = "Email field is required";
                this.email_filed = true;
                return;
              } else {
                this.errors.user_email = null;
                this.email_filed = false;
              }
            let userDetails = {
                user_email: this.user_email,
                password: this.password
            }
            // this.isChecked = false;
            loginUser(userDetails).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: 'success',
                            title: "Login Successful",
                        });
                        localStorage.setItem('end_user_access_token', res.data.data.access_token);
                        if (this.remember_me) {
                            $cookies.set('token', res.data.data.refresh_token);
                            $("#checkbox1").attr("checked", true);
                        }
                        setUserDataOnLocalStorage();
                    } else {
                        Toast.fire({
                            icon: 'error',
                            title: res.data.status,
                            text: res.data.message,
                        });

                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: 'error',
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });

                });

        }
    },
    template: `
    <vd-component class="vd login-three" type="login-three">
    <section class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a v-if="logo_details['logo']" class="navbar-brand" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
				:alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
				<a v-else-if="logo_details['logo']!=false" class="navbar-brand" href="/"><img vd-node="logo" :src="rootUrl +'img/logo.png'"
				alt="citrine" /></a>
            </nav>
          </div>
        </div>
      </div>
    </section>
    <div class="card-box py-4 full-height">
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 col-lg-7 text-center">
                <div class="form-wrapper">
                    <div class="section-heading mb-4">
                        <h2>Sign in to <span class="text-blue fst-italic"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></span></h2>  
                    </div>
                    <p class="fs-18 d-none"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></p>
                    <div class="row justify-content-center gx-4 d-none">
                        <div class="col-auto">
                            <a href="#/" class="btn-border with-icon">
                                <div class="svg">
                                    <svg width="12" height="20" viewBox="0 0 12 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.19873 19.5H7.19873V11.49H10.8027L11.1987 7.51H7.19873V5.5C7.19873 5.23478 7.30409 4.98043 7.49163 4.79289C7.67916 4.60536 7.93352 4.5 8.19873 4.5H11.1987V0.5H8.19873C6.87265 0.5 5.60088 1.02678 4.6632 1.96447C3.72552 2.90215 3.19873 4.17392 3.19873 5.5V7.51H1.19873L0.802734 11.49H3.19873V19.5Z" fill="url(#paint0_linear_379_1030)"/>
                                        <defs>
                                        <linearGradient id="paint0_linear_379_1030" x1="0.802734" y1="0.5" x2="15.0116" y2="3.99382" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#09C6F9"/>
                                        <stop offset="1" stop-color="#045DE9"/>
                                        </linearGradient>
                                        </defs>
                                    </svg>
                                </div>
                                Facebook
                            </a>
                        </div>
                        <div class="col-auto">
                            <a href="#/" class="btn-border with-icon">
                                <div class="svg">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.4565 8.15401C19.5795 8.81301 19.6465 9.50201 19.6465 10.221C19.6465 15.845 15.8825 19.844 10.1975 19.844C8.90467 19.8444 7.62442 19.59 6.42991 19.0955C5.23541 18.6009 4.15006 17.8758 3.23588 16.9616C2.3217 16.0475 1.59661 14.9621 1.10204 13.7676C0.607475 12.5731 0.353122 11.2929 0.353516 10C0.353122 8.70716 0.607475 7.42691 1.10204 6.2324C1.59661 5.0379 2.3217 3.95255 3.23588 3.03837C4.15006 2.12419 5.23541 1.3991 6.42991 0.904533C7.62442 0.409966 8.90467 0.155612 10.1975 0.156006C12.8555 0.156006 15.0765 1.13401 16.7805 2.72201L14.0055 5.49701V5.49001C12.9725 4.50601 11.6615 4.00101 10.1975 4.00101C6.94952 4.00101 4.30952 6.74501 4.30952 9.99401C4.30952 13.242 6.94952 15.992 10.1975 15.992C13.1445 15.992 15.1505 14.307 15.5625 11.993H10.1975V8.15401H19.4575H19.4565Z" fill="url(#paint0_linear_379_1035)"/>
                                        <defs>
                                        <linearGradient id="paint0_linear_379_1035" x1="0.353516" y1="0.156006" x2="23.7746" y2="10.4702" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#09C6F9"/>
                                        <stop offset="1" stop-color="#045DE9"/>
                                        </linearGradient>
                                        </defs>
                                    </svg>                                        
                                </div>
                                Google
                            </a>
                        </div>
                    </div>
                    <div class="row align-items-center d-none">
                        <div class="col">
                            <div class="border-line"></div>
                        </div>
                        <div class="col-auto">
                            <p>Or</p>
                        </div>
                        <div class="col">
                            <div class="border-line"></div>
                        </div>
                    </div>
                    <div class="row mt-2">
                    <form action="" method="" class="w-100" id="">
                        <div class="col-12">
                            <div class="input-group vd-form mb-30 ">
                                <span class="input-group-text" id="email">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20 20H4C2.89543 20 2 19.1046 2 18V5.913C2.04661 4.84255 2.92853 3.99899 4 4H20C21.1046 4 22 4.89543 22 6V18C22 19.1046 21.1046 20 20 20ZM4 7.868V18H20V7.868L12 13.2L4 7.868ZM4.8 6L12 10.8L19.2 6H4.8Z" fill="#91919F"/>
                                    </svg>                                       
                                </span>
                                <input @keyup.enter="submitLoginForm"  v-model="user_email" type="email" required class="form-control vd-component-attr" autocomplete="false" vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9']) 
                                vd-component-attr-title="label11" :title=i18n($attrs['label11']) aria-label="Email" aria-describedby="email"  :class="email_filed">
                                <template v-if="errors.user_email">
                                    <h3 class="invalid-feedback pb-2 validation-msg" style="position: absolute;bottom: -30px;">{{ errors.user_email }}</h3>
                                </template>



                            </div>
                            <div class="input-group vd-form mb-3 ">
                                <span class="input-group-text">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>                                                                               
                                </span>
                                <input @keyup.enter="submitLoginForm" v-model="password" id="password" autocomplete="off" type="password" class="form-control pe-5 vd-component-attr" @copy.prevent @paste.prevent @cut.prevent autocomplete="off" vd-component-attr-placeholder="label10" :placeholder=i18n($attrs['label10']) 
                                vd-component-attr-title="label12" :title=i18n($attrs['label12'])  aria-label="Password"  aria-describedby="password">

                                <span toggle="#password" class="field-icon toggle-password">
                                    <span class="material-icons">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M19.97 21.385L16.614 18.029C15.1661 18.6882 13.5908 19.0204 12 19.002C10.3599 19.0223 8.73671 18.6684 7.254 17.967C6.10468 17.4062 5.07264 16.6317 4.213 15.685C3.30049 14.7068 2.5833 13.5633 2.1 12.316L2 12.002L2.105 11.686C2.82781 9.84224 4.04426 8.23312 5.621 7.03495L3 4.41395L4.413 3.00195L21.382 19.971L19.972 21.385H19.97ZM7.036 8.45095C5.75792 9.34687 4.74865 10.5747 4.117 12.002C5.47142 15.1269 8.59587 17.1086 12 17.002C13.0498 17.0106 14.0936 16.8415 15.087 16.502L13.287 14.702C12.8863 14.8984 12.4462 15.0009 12 15.002C10.3475 14.9916 9.01037 13.6545 9 12.002C9.00048 11.5547 9.10309 11.1135 9.3 10.712L7.036 8.45095ZM19.852 15.612L18.46 14.221C19.0456 13.5589 19.5256 12.8104 19.883 12.002C18.5304 8.87553 15.4047 6.89303 12 7.00195C11.753 7.00195 11.505 7.01095 11.265 7.02795L9.5 5.26095C10.3216 5.08519 11.1598 4.99835 12 5.00195C13.6401 4.9816 15.2633 5.33557 16.746 6.03695C17.8953 6.59769 18.9274 7.37215 19.787 8.31895C20.6991 9.29592 21.4163 10.438 21.9 11.684L22 12.002L21.895 12.318C21.4268 13.536 20.7342 14.6554 19.853 15.618L19.852 15.612Z" fill="#91919F"/>
                                        </svg>                                                    
                                   </span>
                                </span>
                            </div>
                            <div class="row gx-0 justify-content-between">
                                <div class="col-auto">
                                    <div class="form-check vd-form text-start">
                                        <input class="form-check-input" name="total" value=true checked="" v-model="remember_me" type="checkbox" value="" id="flexCheckDefault">
                                        <label class="form-check-label ms-1" for="flexCheckDefault">
                                        <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-auto vd-form">
																<vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
                                </div>
                            </div>
                            <a vd-readonly="true" vd-node="styleOnly" href="#/" class="btn-solid" :class="(email_filed || password =='')?'disabled_button':''" @click="submitLoginForm()" :disabled="email_filed || password ==''"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></a>

                            <p><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param> <vd-component-param type="label77" v-html="i18n($attrs['label77'])"></vd-component-param></p>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</vd-component>
    `
}
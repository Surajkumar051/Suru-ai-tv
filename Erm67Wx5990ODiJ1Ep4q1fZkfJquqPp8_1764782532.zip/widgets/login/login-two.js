let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {
    loginUser,
    getEndUserRegdLoginSetting,
    // getVdConfig,
    getUserDetails,
    getCountryCodes,
    sendOtp,
    resendOtp,
    validateOtp,
    ssoLogin,
    getSsoConfig,
    checkEndUserExist
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { setUserDataOnLocalStorage } = await import(window.importAssetJs('js/main.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getAuth, GoogleAuthProvider,signInWithPopup, OAuthProvider, FacebookAuthProvider, linkWithCredential } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";

let timer1;
const { mapState} = Vuex;

export default {
    name: "login_two",
    data() {
        return {
            user_email: "",
            password: "",
            remember_me: "",
            errors: {},
            email_filed: false,
            showPassword: false,
            isChecked: false,
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            otpSettingEnabled: false,
            muviAuthEmailOptSettingList: ['3', '34', '35'],
            mobile_field: false,
            mobile: "",
            countryCodes: [],
            selectedCountry: '+91',
            getOtpPartShow: false,
            validateOtpPartShow: false,
            input1: '',
            input2: '',
            input3: '',
            otpDigitOne: "",
            otpDigitTwo: "",
            otpDigitThree: "",
            otpDigitFour: "",
            enableResendButton: true,
            selectCountry: "",
            rootUrl: getRootUrl(),
            google_sso:"G-Auth",
            apple_sso: "A-Auth",
            facebook_sso:"F-Auth",
            is_sso: false,
            sso_enabled: false,
            google_sso_enabled:false,
            apple_sso_enabled:false,
            facebook_sso_enabled:false,
            email:"",
            userName:"",
            registration_mode:"",
            otp_time_interval: 0,
            message: "You have exceeded the limit for resending the OTP",
            errorMsgs:[],
            socialId:"",
            endUserExist:true,
            muviAuthSettingType:"",
            mobile_number_sso:"",
            isEmailVerificationDuringRegdEnable: false,
            ssoEmailverification: false,
            credential:""
        };
    },
    computed: {
        email() {
            return this.user_email;
        },
        mobile() {
            return this.mobile;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
        })
    },
    created() {
        JsLoadingOverlay.show();
        let isloggedIn = localStorage.getItem("isloggedin");
        if (isloggedIn) {
            window.location.href = "/home";
        }
        getSsoConfig().then((res) => {
            if (res.data.code === 200 && res.data.status === "SUCCESS") {
              var ssoConfiguration = res.data.data.getSsoConfigDetails;
              if(ssoConfiguration.length){
                  const firebaseConfigForGoogleSso = {
                    apiKey: ssoConfiguration[0].api_key,
                    authDomain: ssoConfiguration[0].auth_domain,
                    projectId: ssoConfiguration[0].project_id,
                    storageBucket: ssoConfiguration[0].storage_bucket,
                    messagingSenderId: ssoConfiguration[0].messaging_sender_id,
                    appId: ssoConfiguration[0].app_id
                  };
                  // Initialize Firebase
                  const app = initializeApp(firebaseConfigForGoogleSso);
              }else{
                console.log("Error in firebase config");
              }
            } else {
              console.log("Error in get sso config");
            }
          })
          .catch((err) => {
              console.log("Error during initializing firebase//////",err)
          });
        window.addEventListener('updateInput', (event) => {
            this.otpDigitOne = event.detail;
            this.otpDigitTwo = event.detail;
            this.otpDigitThree = event.detail;
            this.otpDigitFour = event.detail;
        });
    },
    mounted() {
        setTimeout(() => {
            $(".selectpicker").selectpicker();
            $(".selectpicker").selectpicker("refresh");
        }, 2000);
      
          $(".signup-google-otp").hide();
      
          $(document).on("click", ".edit-input-btn", function () {
            const button = document.querySelector(".otp-verify-btn");
            button.classList.add("disabled-button");
            $('#validateOtpButton').css('pointer-events','none');
            const inputs = document.querySelectorAll(".otp-digit");
            inputs[0].value = "";
            inputs[1].value = "";
            inputs[2].value = "";
            inputs[3].value = "";
            inputs[0].focus();
            if($(this).attr("id") == "edit-input-btn-sso"){
              $(".verify-otp").hide();
              $(".signup-google-otp").show();
            }else{
              $(".verify-otp").hide();
              $(".get-otp").show();
            }
          
          });
      
          $(".otp-digit").bind("paste", function(e){
            var pastedData = e.originalEvent.clipboardData.getData('text'); 
            if (pastedData) {
               const onlyContainsNumbers = (pastedData) => /^\d+$/.test(pastedData);
               if(onlyContainsNumbers(pastedData) && pastedData.length >= 4){
                   var split = pastedData.split("");
                   const inputs = document.querySelectorAll(".otp-digit");
                   inputs[0].value ="";
                   inputs[1].value ="";
                   inputs[2].value ="";
                   inputs[3].value ="";
                   inputs[0].value = split[0];
                   inputs[1].value = split[1];
                   inputs[2].value = split[2];
                   inputs[3].value = split[3];
                   inputs[3].focus();
                   const button = document.querySelector(".otp-verify-btn");
                   button.classList.remove("disabled-button");
                   $('#validateOtpButton').css('pointer-events','');
               }
           
               return false
            }
           } );


        this.enterOtpEventChanges();
        getUserDetails().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                if (res.data.data.getUserDetails[0].muvi_auth_setting_type != null) {
                    this.otpSettingEnabled = this.muviAuthEmailOptSettingList.includes(res.data.data.getUserDetails[0].muvi_auth_setting_type);
                    this.getOtpPartShow = this.otpSettingEnabled;
                    this.muviAuthSettingType = res.data.data.getUserDetails[0].muvi_auth_setting_type;
                    localStorage.setItem('adminId', res.data.data.getUserDetails[0].user_uuid);
                    var sso_enabled_list = JSON.parse(res.data.data.getUserDetails[0].sso_enabled_list);
                    this.sso_enabled = sso_enabled_list.length != 0 ? true : false;
                    this.google_sso_enabled = sso_enabled_list.includes(this.google_sso);
                    this.apple_sso_enabled = sso_enabled_list.includes(this.apple_sso);
                    this.facebook_sso_enabled = sso_enabled_list.includes(this.facebook_sso);
                    this.otp_time_interval = res.data.data.getUserDetails[0].otp_time_interval * 60 *1000;
                    this.ssoEmailverification = this.sso_enabled && this.muviAuthSettingType === '1' ? true : false;
                }
            }
        });
        getEndUserRegdLoginSetting().then((res) => {
            if (res.data.code == 200 && res.data.data !== null) {
                const requireRegistrationAndLogin = parseInt(
                    res.data.data.sections[0].groups[0].nodes[0].node_value
                );
                const emailVerificationDuringRegd = parseInt(
                    res.data.data.sections[0].groups[2].nodes[5].node_value
                );
                if(requireRegistrationAndLogin == 1){
                  if(emailVerificationDuringRegd == 1){
                      this.isEmailVerificationDuringRegdEnable = true;
                  }
                }
                if (requireRegistrationAndLogin != 1) {
                    window.location.href = "/";
                }
            }
        });
        getCountryCodes().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                console.log(res.data.data.country);
                this.countryCodes = res.data.data.country;
                setTimeout(() => {
                    $("#selectpicker1").selectpicker();
                }, 1700);
            }
        });
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             //this.logo = res.data.data;
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });

        JsLoadingOverlay.hide();
    },
    updated(){
        $(".selectpicker").selectpicker("refresh");
     },
    watch: {
        email(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.user_email = i18n("Email field is required");
            } else if (
                !value.match(
                    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9À-ÿ]+\.)+[a-zA-ZÀ-ÿ]{2,}))$/
                )
            ) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.user_email = i18n("Please enter a valid email");
            } else {
                this.errors.user_email = null;
                this.email_filed = false;
            }
        },
        mobile(value) {
            if (!this.checkMobileNum(value)) {
                this.errors.valid = false;
                this.mobile_field = true;
                this.errors.mobile = i18n("Please enter a valid mobile number");
            }
            else {
                this.errors.mobile = null;
                this.mobile_field = false;
            }
        },
    },
    methods: {
        getRootUrl,
        i18n,
        clearOtpValue() {
            const inputs = document.querySelectorAll(".otp-digit");
            inputs[0].value = "";
            inputs[1].value = "";
            inputs[2].value = "";
            inputs[3].value = "";
            // this.input.otpNumber1 = "";
            // this.input.otpNumber2 = "";
            // this.input.otpNumber3 = "";
            // this.input.otpNumber4 = "";
            inputs[0].focus();
            inputs[1].setAttribute("disabled", true);
            inputs[2].setAttribute("disabled", true);
            inputs[3].setAttribute("disabled", true);

        },
        submitLoginForm() {
            if (!this.user_email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = i18n("Email field is required");
                this.email_filed = true;
                return;
            } else {
                this.errors.user_email = null;
                this.email_filed = false;
            }
            let userDetails = {
                user_email: this.user_email,
                password: this.password,
            };
            // this.isChecked = false;
            loginUser(userDetails)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: res.data.message,
                        });
                        localStorage.setItem(
                            "end_user_access_token",
                            res.data.data.access_token
                        );
                        if (this.remember_me) {
                            $cookies.set("token", res.data.data.refresh_token);
                            $("#checkbox1").attr("checked", true);
                        }
                        setUserDataOnLocalStorage();
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
        },

        checkMobileNum(value) {
            var re = new RegExp(/^(\+\d{1,3}[-]?)?\d{4,20}$|^$/); //biswa
            if (re.test(value)) {
                console.log("Valid");
                return true;
            } else {
                console.log("Invalid");
                return false;
            }
        },
        getOtpForm() {
            if (!this.mobile.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.mobile = i18n("Mobile field is required");
                this.mobile_field = true;
                return;
            } else {
                this.errors.mobile = null;
                this.mobile_field = false;
            }
            console.log(this.selectedCountry);
            this.enableResendButton = false;

            let getOtpPayload = {
                otp_request_event_type: 'login',
                otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                otp_request_mobile: this.selectedCountry.concat(this.mobile),
                otp_application_id: 'end_user'
            };
            console.log(getOtpPayload);
            // this.isChecked = false;
            sendOtp(getOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: "Otp sent Successfully",
                            text: res.data.message
                        });
                        setTimeout(() => {
                            $("#selectpicker2").selectpicker("refresh");
                            $("#selectpicker2").selectpicker();
                        }, 1000);
                        this.selectCountry = this.selectedCountry;
                        console.log(res);
                        this.validateOtpPartShow = true;
                        this.getOtpPartShow = false;
                        console.log('validate otp part' + this.validateOtpPartShow);
                        // localStorage.setItem(
                        //     "end_user_access_token",
                        //     res.data.data.access_token
                        // );
                        // if (this.remember_me) {
                        //     $cookies.set("token", res.data.data.refresh_token);
                        //     $("#checkbox1").attr("checked", true);
                        // }
                        // setUserDataOnLocalStorage();

                        $(".get-otp").hide();
                        $(".verify-otp").show();

                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
                this.countdown(this.otp_time_interval);
        },
        returnToGetOtpPage() {
            this.getOtpPartShow = true;
            this.validateOtpPartShow = false;
        },
        moveToNext(event, nextInputRef) {
            if (event.target.value.length === event.target.maxLength) {
                this.$refs[nextInputRef].focus();
            }
        },
        moveToprev(event, nextInputRef) {
            if (event.target.value.length === 0) {
                this.$refs[nextInputRef].focus();
            }
        },
        validateOtpPart() {
            $('#verifyOtpButton').css('pointer-events','none');
            const inputs = document.querySelectorAll(".otp-digit");
            let validateOtpPayload = {};
            if(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification){
              validateOtpPayload['otp_request_event_type'] ='registration';
              validateOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              validateOtpPayload['otp_request_email']= this.user_email;
              validateOtpPayload['otp_application_id'] = 'end_user';
              validateOtpPayload['username'] =  this.userName ;
              validateOtpPayload['otp_value'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
            }else{
              validateOtpPayload['otp_request_event_type'] ='login';
              validateOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              validateOtpPayload['otp_request_mobile']= this.selectedCountry.concat(this.mobile);
              validateOtpPayload['otp_application_id'] = 'end_user';
              validateOtpPayload['otp_value'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
            }
            
            if(this.is_sso && !(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification)){
              validateOtpPayload['otp_request_sso'] = true;
            }
            validateOtp(validateOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        let userData = {
                            mobile: validateOtpPayload.otp_request_mobile
                        };
                        if(this.is_sso){
                            userData['username']=this.userName;
                            userData['user_email']=this.email;
                            userData['mobile']=validateOtpPayload.otp_request_mobile;
                            userData['authentication_mode']= this.registration_mode;
                            userData['social_sso_user_id']= this.socialId;
                            this.loginWithSsoForMobile(userData);
                          }else{
                            this.loginWithoutSsoForMobile(userData);
                          }
                    } else {
                        $('#verifyOtpButton').css('pointer-events','');
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    $('#verifyOtpButton').css('pointer-events','');
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
        },
        resendOtp() {
            this.clearOtpValue();
            let getOtpPayload = {};
            if(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification){
              getOtpPayload['otp_request_event_type'] ='registration';
              getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              getOtpPayload['otp_request_email']= this.user_email;
              getOtpPayload['otp_application_id'] = 'end_user';
              getOtpPayload['username'] = this.userName;
              getOtpPayload['resend_otp_request'] =true;
            }else{
              getOtpPayload['otp_request_event_type'] ='login';
              getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              getOtpPayload['otp_request_mobile']= this.selectedCountry.concat(this.mobile);
              getOtpPayload['otp_application_id'] = 'end_user';
              getOtpPayload['resend_otp_request'] =true;
            }
          
            if(this.is_sso){
              getOtpPayload['otp_request_sso'] = true;
            }
            console.log(getOtpPayload);
            // this.isChecked = false;
            resendOtp(getOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: "Otp sent Successfully",
                            text: res.data.message
                        });
                        console.log(res);
                        this.validateOtpPartShow = true;
                        this.getOtpPartShow = false;
                        // this.enableResendButton = true;
                        console.log('validate otp part' + this.validateOtpPartShow);
                        this.enableResendButton = false;
                        // Call countdown function with 1 minute (60 seconds)
                        this.countdown(this.otp_time_interval);
                        // localStorage.setItem(
                        //     "end_user_access_token",
                        //     res.data.data.access_token
                        // );
                        // if (this.remember_me) {
                        //     $cookies.set("token", res.data.data.refresh_token);
                        //     $("#checkbox1").attr("checked", true);
                        // }
                        // setUserDataOnLocalStorage();
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                        // this.enableResendButton = true;
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                    // this.enableResendButton = true;
                });
        },
  // Function to start countdown
  countdown(otp_time_interval) {
    clearInterval(timer1);
    var timer = document.getElementById("countdown-timer");
    timer.innerHTML = ""
    var timeUnit = ""
    var countDownDate = otp_time_interval;
    var now = 0
    var self = this; // Save reference to `this` to access within the inner function

      timer1 = setInterval(function() { 
        var counter = document.getElementById("countdown-timer");
        // Find the distance between now an the count down date
        var distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);


        if(hours>0){
          timeUnit = "hours";
          counter.innerHTML = (hours < 10 ? "0" : "")+ String(hours) + ":" + (minutes < 10 ? "0" : "")+ String(minutes) + ":" + (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
        }else if(minutes > 0){
            timeUnit = "minutes";
            counter.innerHTML = (minutes < 10 ? "0" : "")+ String(minutes) + ":" + (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
        }else{
            timeUnit = seconds > 1 ? "seconds" : "second";
            counter.innerHTML = (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
        }
        // Output the result in an element with id="demo"
        //counter.innerHTML = (hours < 10 ? "0" : "")+ String(hours) + " H " + (minutes < 10 ? "0" : "")+ String(minutes) + " M " + (seconds < 10 ? "0" : "") + String(seconds) + " S";
        self.enableResendButton = false;

        // If the count down is over, write some text 
        if (distance < 0) {
            clearInterval(timer1);
            self.enableResendButton = true;
        }
        now = now + 1000
    }, 1000);
  },
  enterOtpEventChanges() {
    const inputs = document.querySelectorAll(".otp-digit");
    const button = document.querySelector(".otp-verify-btn");
    // iterate over all inputs
    inputs.forEach((input, index1) => {
        input.addEventListener("keyup", (e) => {
        // This code gets the current input element and stores it in the currentInput variable
        // This code gets the next sibling element of the current input element and stores it in the nextInput variable
        // This code gets the previous siblinginput element of the current input element and stores it in the prevInput variable
        const currentInput = input,
            nextInput = input.nextElementSibling,
            prevInput = input.previousElementSibling;
    
        // if the value has more than one character then clear it
        if (currentInput.value.length > 1) {
            currentInput.value = "";
            return;
        }
        // if the next input is disabled and the current value is not empty
        //  enable the next input and focus on it
        if (nextInput && currentInput.value !== "") {
            nextInput.removeAttribute("disabled");
            nextInput.focus();
        }
    
        // if the backspace key is pressed
        if (e.key === "Backspace") {
            input.value = "";
            if(prevInput !== null){
                prevInput.focus();
            }else{
                currentInput.focus();
            }
            }
        if (inputs[0].value !== "" && inputs[1].value !== "" && inputs[2].value !== "" && inputs[3].value !== "") {
            button.classList.remove("disabled-button");
            $('#verifyOtpButton').css('pointer-events','');
            return;
        }
        button.classList.add("disabled-button");
        $('#verifyOtpButton').css('pointer-events','none');
        });
    });
    //focus the first input which index is 0 on window load
    window.addEventListener("load", () => inputs[0].focus());
  },

        async googleSignIn() {
            const provider = new GoogleAuthProvider();
            const auth = getAuth();
            provider.setCustomParameters({
                prompt: 'select_account'
            });
        
            try {
                // Use await to wait for the signInWithPopup to complete
                const result = await signInWithPopup(auth, provider);
      
                if(this.credential){
                  let user = await linkWithCredential(result.user, this.credential);
                  this.credential = "";
                }
       
                // Signed in successfully
                const user = result.user;
                console.log("Signed in user:", result);
                this.userName = result.user.displayName ? result.user.displayName :result._tokenResponse.displayName;
                this.email = result.user.email;
                this.socialId = result.user.uid;
                this.registration_mode = "Google SSO";
                
                if (!this.email || this.otpSettingEnabled) {
                    let checkEndUserPayload = {
                        user_email: this.email,
                        social_sso_user_id: this.socialId
                    };
                    console.log(checkEndUserPayload);
        
                    // Await the checkEndUserExist function
                    const res = await checkEndUserExist(checkEndUserPayload);
                    if (res.data.code === 200 && res.data.status === "SUCCESS") {
                        this.endUserExist = res.data.data.is_end_user_exists;
                        if(this.endUserExist){
                           this.email = res.data.data.email;
                           this.mobile_number_sso = res.data.data.mobile;   
                        }  
                    }
                }
                
                if (this.otpSettingEnabled) {
                    if (this.endUserExist) {
                        let userData = {
                            username: this.userName,
                            user_email: this.email,
                            authentication_mode: this.registration_mode,
                            mobile:this.mobile_number_sso,
                            social_sso_user_id: this.socialId
                        };
                        this.loginWithSso(userData);
                    } else{
                        this.user_email = this.email;
                        $(".get-otp").hide();
                        $(".signup-google-otp").show();
                    }
                } else {
                    if (this.endUserExist) {
                        let userData = {
                            username: this.userName,
                            user_email: this.email,
                            authentication_mode: this.registration_mode,
                            social_sso_user_id: this.socialId
                        };
                        this.loginWithSso(userData);
                    } else {
                        $(".regd-form").hide();
                        $(".signup-google-otp").show();
                    }
                }
            } catch (error) {
                // Handle sign-in error
                console.error("Sign-in error:", error);
            }
          },
         async appleSignIn() {
            const provider = new OAuthProvider('apple.com');
            const auth = getAuth();
            
            // Set custom parameters
            provider.setCustomParameters({
                prompt: 'select_account'
            });
            
            // Add scopes
            provider.addScope('email');
            provider.addScope('name');
            
            try {
              // Use await to wait for the signInWithPopup to complete
              const result = await signInWithPopup(auth, provider);
      
              if(this.credential){
               let user = await linkWithCredential(result.user, this.credential);
               this.credential = "";
             }
              // Signed in successfully
              const user = result.user;
              console.log("Signed in user:", result);
              this.userName = result.user.displayName ? result.user.displayName :result._tokenResponse.displayName;
              this.email = result.user.email;
              this.socialId = result.user.uid;
              this.registration_mode = "Apple SSO";
              
              if (!this.email || this.otpSettingEnabled) {
                  let checkEndUserPayload = {
                      user_email: this.email,
                      social_sso_user_id: this.socialId
                  };
                  console.log(checkEndUserPayload);
      
                  // Await the checkEndUserExist function
                  const res = await checkEndUserExist(checkEndUserPayload);
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      this.endUserExist = res.data.data.is_end_user_exists;
                      if(this.endUserExist){
                        this.email = res.data.data.email;
                        this.mobile_number_sso = res.data.data.mobile;   
                      }  
                  }
              }
              
              if (this.otpSettingEnabled) {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          mobile:this.mobile_number_sso,
                          social_sso_user_id: this.socialId
                      };
                      this.loginWithSso(userData);
                  } else{
                      this.user_email = this.email;
                      $(".get-otp").hide();
                      $(".signup-google-otp").show();
                  }
              } else {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          social_sso_user_id: this.socialId
                      };
                      this.loginWithSso(userData);
                  } else {
                      $(".regd-form").hide();
                      $(".signup-google-otp").show();
                  }
              }
          } catch (error) {
              // Handle sign-in error
              console.error("Sign-in error:", error);
          }
          },
      
         async facebookSignIn() {
            const provider = new FacebookAuthProvider();
            const auth = getAuth();
      
            // Set custom parameters
            provider.setCustomParameters({
              prompt: 'select_account'
            });
      
            provider.addScope('email');
      
            provider.setCustomParameters({
                'display': 'popup'
              });
            
            try {
              // Use await to wait for the signInWithPopup to complete
              const result = await signInWithPopup(auth, provider);
              
              // Signed in successfully
              const user = result.user;
              console.log("Signed in user:", result);
              this.userName = result.user.displayName ? result.user.displayName :result._tokenResponse.displayName;
              this.email = result.user.email;
              this.socialId = result.user.uid;
              this.registration_mode = "Facebook SSO";
              
              if (!this.email || this.otpSettingEnabled) {
                  let checkEndUserPayload = {
                      user_email: this.email,
                      social_sso_user_id: this.socialId
                  };
                  console.log(checkEndUserPayload);
      
                  // Await the checkEndUserExist function
                  const res = await checkEndUserExist(checkEndUserPayload);
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      this.endUserExist = res.data.data.is_end_user_exists;
                      if(this.endUserExist){
                        this.email = res.data.data.email;
                        this.mobile_number_sso = res.data.data.mobile;   
                      }  
                  }
              }
              
              if (this.otpSettingEnabled) {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          mobile:this.mobile_number_sso,
                          social_sso_user_id: this.socialId
                      };
                      this.loginWithSso(userData);
                  } else{
                      this.user_email = this.email;
                      $(".get-otp").hide();
                      $(".signup-google-otp").show();
                  }
              } else {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          social_sso_user_id: this.socialId
                      };
                      this.loginWithSso(userData);
                  } else {
                      $(".regd-form").hide();
                      $(".signup-google-otp").show();
                  }
                }
            } catch (error) {
                // Handle sign-in error
                console.error("Sign-in error:", error);
                if (error.code === "auth/account-exists-with-different-credential") {
                  var ssoName='';
                  console.error("Sign-in error:", error.customData);
                   this.credential = FacebookAuthProvider.credentialFromError(error);
                   var verifiedProvider = error.customData._tokenResponse.verifiedProvider;
                  if(verifiedProvider.includes('google.com')){
                      ssoName = "Google";
                  }else{
                      ssoName = "Apple";
                  }
                  var message = "You have already signup with " + ssoName + ".  Please login once using " + ssoName + ". So we can link your Facebook account to it. Afterward, you'll be able to login seamlessly with either " + ssoName + " or Facebook.";
                  $("#signup-error").html(message);
                  $("#signup-error").css("display", "block");
                  setTimeout(() => {
                      $("#signup-error").css("display", "none");
                      $("#signup-error").html("");
                  }, 8000);
               }
            }
          },
      
          loginWithSso(userData){
            ssoLogin(userData).then((res) => {
              if (res.data.code == 200 && res.data.status == "SUCCESS") {
                Toast.fire({
                  icon: "success",
                  title: res.data.message,
                });
                localStorage.setItem(
                  "end_user_access_token",
                  res.data.data.access_token
                );
                if (this.remember_me) {
                  $cookies.set("token", res.data.data.refresh_token);
                  $("#checkbox1").attr("checked", true);
                }
                setUserDataOnLocalStorage();
              } else {
                Toast.fire({
                  icon: "error",
                  title: res.data.status,
                  text: res.data.message,
                });
              }
            }).catch((err) => {
                $('#validateOtpButton').css('pointer-events','');
                console.log("error", err);
            });    
        },
      
        generateOtpForSsoMobile() {
          if(this.validateSsoPopupForm()){
            if(this.user_email){
               this.email = this.user_email;
            }
            let getOtpPayload = {};
            getOtpPayload['otp_request_event_type'] ='login';
            getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
            getOtpPayload['otp_application_id'] = 'end_user';
            getOtpPayload['otp_request_mobile'] = this.selectedCountry.concat(this.mobile);
            getOtpPayload['otp_request_sso'] = true;
            getOtpPayload['sso_email'] = this.email;
            sendOtp(getOtpPayload)
              .then((res) => {
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                  this.is_sso = true;
                  Toast.fire({
                    icon: "success",
                    title: "OTP sent Successfully",
                    text: res.data.message 
                  });
                  this.selectCountry = this.selectedCountry;
                  alert(this.selectedCountry)
                  $(".signup-google-otp").hide();
                  $(".verify-otp").show();
                  const inputs = document.querySelectorAll(".otp-digit");
                  inputs[0].focus();
                  this.countdown(this.otp_time_interval);
                } else {
                  if(res.data.message.includes(this.message)){
                    this.enableResendButton = true;
                    clearInterval(timer1);
                    this.selectCountry = this.selectedCountry;
                    $(".get-otp").hide();
                    $(".verify-otp").show();
                    const inputs = document.querySelectorAll(".otp-digit");
                    inputs[0].focus();
                  }else{
                    Toast.fire({
                      icon: "error",
                      title: res.data.status,
                      text: res.data.message,
                    });
                  }
                    
                }
              })
              .catch((err) => {
                Toast.fire({
                  icon: "error",
                  title: err.response.data.status,
                  text: err.response.data.message,
                });
              });
            }
          },
      
          loginWithoutSsoForMobile(userData){
      
            loginUser(userData).then((res) => {
              if (res.data.code == 200 && res.data.status == "SUCCESS") {
                Toast.fire({
                  icon: "success",
                  title: res.data.message,
                });
                localStorage.setItem(
                  "end_user_access_token",
                  res.data.data.access_token
                );
                setUserDataOnLocalStorage();
              } else {
                Toast.fire({
                  icon: "error",
                  title: res.data.status,
                  text: res.data.message,
                });
              }
            })
            .catch((err) => {
              Toast.fire({
                icon: "error",
                title: err.response.data.status,
                text: err.response.data.message,
              });
            });
      
          },
      
          loginWithSsoForMobile(userData){
            
            ssoLogin(userData).then((res) => {
              if (res.data.code == 200 && res.data.status == "SUCCESS") {
                Toast.fire({
                  icon: "success",
                  title: res.data.message,
                });
                localStorage.setItem(
                  "end_user_access_token",
                  res.data.data.access_token
                );
                setUserDataOnLocalStorage();
              } else {
                Toast.fire({
                  icon: "error",
                  title: res.data.status,
                  text: res.data.message,
                });
              }
            })
            .catch((err) => {
              Toast.fire({
                icon: "error",
                title: err.response.data.status,
                text: err.response.data.message,
              });
            });
          },
          validateSsoPopupForm(){
            let status = true;
            if(this.muviAuthSettingType !== '3' && this.muviAuthSettingType !== '34'){
                if (!this.user_email.length) {
                    this.errorMsgs[0] = i18n("Email field is required");
                    status = false;
                } else if (
                    !this.user_email.match(
                        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9À-ÿ]+\.)+[a-zA-ZÀ-ÿ]{2,}))$/
                    )
                ) {
                    this.errorMsgs[0] = i18n("Please enter a valid email");
                    status = false;
                } else {
                    this.errorMsgs[0] = "";
                }   
            }
            if(this.otpSettingEnabled){
                if (!this.mobile.length) {
                    this.errorMsgs[1] = i18n("Mobile field is required");
                    status = false;
                } else if (!this.mobile.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)) {
                    this.errorMsgs[1] = i18n("Please enter a valid mobile number");;
                    status = false;
                }else {
                    this.errorMsgs[1]="";
                }
            }
            return status;
        },
        getOtpForRegThroughEmailWithSso() {
            if(this.validateSsoPopupForm()){
               if(this.user_email){
                  this.email = this.user_email;
               }
                let getOtpPayload = {
                    otp_request_event_type: 'registration',
                    otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                    otp_request_email: this.user_email,
                    otp_application_id:'end_user',
                    username: this.userName
                };
                console.log(getOtpPayload);
                // this.isChecked = false;
                sendOtp(getOtpPayload).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.is_sso = true ;
                        Toast.fire({
                            icon: "success",
                            title: "OTP sent Successfully",
                            text: res.data.message,
                        });
      
                        $(".signup-google-otp").hide();
                        $(".verify-otp").show();
                        const inputs = document.querySelectorAll(".otp-digit");
                        inputs[0].focus();
                        this.countdown(this.otp_time_interval);//ER-106410
                        console.log(res);
                    } else { 
                        if(res.data.message.includes(this.message)){
                            this.enableResendButton = true;
                            clearInterval(timer1);
                            $(".signup-google-otp").hide();
                            $(".verify-otp").show();
                            const inputs = document.querySelectorAll(".otp-digit");
                            inputs[0].focus();
                        }else{
                            Toast.fire({
                                icon: "error",
                                title: res.data.status,
                                text: res.data.message,
                            });
                        }
                        
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
              }
          }, 

    },
    template: `
    <vd-component class="vd login-two" type="login-two">
        <!--Header Section Start Here-->
        <section class="header login-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                    <a v-if="logo_details['logo']" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']" :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                    <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="rootUrl+'img/logo.png'" alt="Raiden" /></a>
                    </nav>
                </div>
            </div>
        </div>
        </section>
        <!--Header Section End Here-->
        <section class="sign-process">
        <div class="content">
        <!--From Section Start Here-->
        <div class="sign-form-layout regd-form" v-if="!otpSettingEnabled">
            <h2 class="mb-32 pb-8 m-0">
                <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
            </h2>
            <p id="signup-error" style="text-align: left; font-size: 12px; color: red; display: none;"></p>
            <div class="form-group mb-16" v-if="google_sso_enabled">
                <button type="button" class="primary-button d-flex align-items-center justify-content-center google" @click="googleSignIn">
                    <span>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_7_462)">
                            <path d="M19.7618 10.1871C19.7618 9.36767 19.6954 8.76974 19.5515 8.14966H10.1948V11.848H15.687C15.5763 12.7671 14.9783 14.1512 13.6496 15.0813L13.6309 15.2051L16.5893 17.4969L16.7943 17.5174C18.6767 15.7789 19.7618 13.221 19.7618 10.1871Z" fill="#4285F4"/>
                            <path d="M10.1947 19.9313C12.8853 19.9313 15.1442 19.0454 16.7941 17.5174L13.6494 15.0813C12.8079 15.6682 11.6784 16.0779 10.1947 16.0779C7.55932 16.0779 5.3226 14.3395 4.52527 11.9366L4.4084 11.9466L1.33222 14.3273L1.29199 14.4391C2.93077 17.6945 6.29695 19.9313 10.1947 19.9313Z" fill="#34A853"/>
                            <path d="M4.52526 11.9367C4.31488 11.3166 4.19313 10.6522 4.19313 9.96568C4.19313 9.27912 4.31488 8.61476 4.51419 7.99469L4.50862 7.86263L1.39389 5.4437L1.29198 5.49217C0.616561 6.84308 0.229004 8.36011 0.229004 9.96568C0.229004 11.5713 0.616561 13.0882 1.29198 14.4391L4.52526 11.9367Z" fill="#FBBC05"/>
                            <path d="M10.1947 3.85336C12.066 3.85336 13.3282 4.66168 14.048 5.33718L16.8605 2.59107C15.1332 0.985496 12.8853 0 10.1947 0C6.29695 0 2.93077 2.23672 1.29199 5.49214L4.51421 7.99466C5.3226 5.59183 7.55932 3.85336 10.1947 3.85336Z" fill="#EB4335"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_7_462">
                                <rect width="19.542" height="20" fill="white" transform="translate(0.229004)"/>
                            </clipPath>
                        </defs>
                    </svg>
                    </span>
                    <span style="text-transform:none;">
                    <vd-component-param type="label31" v-html="i18n($attrs['label31'])"></vd-component-param>
                    </span>
                </button>
            </div>
            <div class="form-group mb-16"  v-if="apple_sso_enabled">
                <button type="button"  @click="appleSignIn" class="primary-button d-flex align-items-center justify-content-center apple">
                    <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0709 3.19287C13.8 2.34788 14.2914 1.17098 14.1569 0C13.1063 0.04 11.8352 0.671147 11.0819 1.51514C10.4054 2.26413 9.81484 3.4609 9.97359 4.60889C11.1456 4.69588 12.3418 4.03885 13.0709 3.19287ZM15.699 10.625C15.7283 13.652 18.4697 14.6589 18.5 14.6719C18.4778 14.7429 18.0622 16.1066 17.056 17.5166C16.1854 18.7346 15.2824 19.9476 13.8596 19.9736C12.4621 19.9986 12.0122 19.1797 10.4135 19.1797C8.81577 19.1797 8.31624 19.9475 6.9936 19.9985C5.62039 20.0475 4.5738 18.6808 3.6971 17.4668C1.90323 14.9838 0.533065 10.4501 2.37344 7.39014C3.28756 5.87116 4.92064 4.90779 6.69428 4.88379C8.04221 4.85879 9.31531 5.75293 10.1394 5.75293C10.9636 5.75293 12.5107 4.67794 14.1367 4.83594C14.8172 4.86294 16.7284 5.09885 17.955 6.81982C17.8559 6.87882 15.6747 8.09504 15.699 10.625Z" fill="white"></path>
                    </svg>
                    </span>
                    <span style="text-transform:none;">
                    <vd-component-param type="label39" v-html="i18n($attrs['label39'])"></vd-component-param>
                    </span>
                </button>
            </div>
            <div class="form-group mb-16" v-if="facebook_sso_enabled">
                <button type="button" @click="facebookSignIn" class="primary-button d-flex align-items-center justify-content-center facebook">
                    <span>
                    <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_7_469)">
                            <path d="M19.3962 20.0001C20.0057 20.0001 20.5 19.5059 20.5 18.8962V1.10383C20.5 0.494141 20.0057 0 19.3962 0H1.60383C0.994062 0 0.5 0.494141 0.5 1.10383V18.8962C0.5 19.5059 0.994062 20.0001 1.60383 20.0001H19.3962Z" fill="white"></path>
                            <path d="M14.2995 20.0001V12.255H16.8993L17.2885 9.23663H14.2995V7.30944C14.2995 6.43553 14.5423 5.83999 15.7955 5.83999L17.3938 5.83928V3.13968C17.1173 3.10288 16.1685 3.02069 15.0648 3.02069C12.7602 3.02069 11.1826 4.42733 11.1826 7.01061V9.23663H8.57617V12.255H11.1826V20.0001H14.2995Z" fill="#335092"></path>
                        </g>
                        <defs>
                            <clipPath id="clip0_7_469">
                                <rect x="0.5" width="20" height="20" rx="4" fill="white"></rect>
                            </clipPath>
                        </defs>
                    </svg>
                    </span>
                    <span style="text-transform:none;">
                    <vd-component-param type="label41" v-html="i18n($attrs['label41'])"></vd-component-param>
                    </span>
                </button>
            </div>
            <div class="form-group or mb-32 mt-32" v-if="sso_enabled">
                <span>
                    <vd-component-param type="label30" v-html="i18n($attrs['label30'])"></vd-component-param>
                </span>
            </div>
            <form action="" method="" class="" id="">
                <div class="form-group vd-form form-label _required">
                    <input vd-readonly="true" @keyup.enter="submitLoginForm" v-model="user_email" type="email" required class="form-control mb-16 pr-42 vd-component-attr"  vd-component-attr-placeholder="label8" :placeholder=i18n($attrs['label8']) 
                    vd-component-attr-title="label10" :title=i18n($attrs['label10']) :class="email_filed ? 'is-invalid' : ''">
                    <template v-if="errors.user_email">
                    <h3 class="invalid-feedback pb-2 validation-msg">{{ errors.user_email }}</h3>
                    </template>
                </div>
                <div class="form-group ">
                    <div class="show-password vd-form form-label _required">
                    <input @keyup.enter="submitLoginForm" vd-readonly="true" v-bind:type="[showPassword ? 'text' : 'password']" v-model="password" class="form-control mb-16 pr-42  vd-component-attr"  vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9']) 
                        vd-component-attr-title="label11" :title=i18n($attrs['label11'])  autocomplete="off" :class="passwordFieldNotValidate ? 'is-invalid' : ''">
                    <button class="" type="button"  @click="showPassword = !showPassword">
                    <i :class="[showPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i>
                    </button>
                    </div>
                </div>
                <div class="form-group float-left w-100">
                    <!-- <div class="form-box2">
                    <div class="d-flex align-items-center remenber-me">
                        <div class="checkbox-button mr-2">
                            <input class="" type="checkbox" id="checkbox1" name="total" :checked="isChecked" v-model="remember_me">
                            <label for="checkbox1" class="checkbox-label blue"></label>
                        </div>
                        <span><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></span>
                    </div>
                    </div> -->
                    <div class="form-box3 vd-form" style="float:right;">
                    <p vd-node="styleOnly"  vd-readonly="true">
                        <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
                    </p>
                    </div>
                </div>
                <div class="form-group vd-form mb-40">
                    <button vd-node="styleOnly" vd-readonly="true" type="button" style="text-transform: none;" class="primary-button"  @click="submitLoginForm()" >
                    <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                    </button>
                </div>
                <p class="text-center">
                    <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                    <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                </p>
            </form>
        </div>
        <!--Get otp Section Start Here otpSettingEnabled && getOtpPartShow-->
        <div class="sign-form-layout get-otp bg-login-dark p-6448" v-if="otpSettingEnabled">
            <h2 class="mb-32">
                <vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param>
            </h2>
            <p id="signup-error" style="text-align: left; font-size: 12px; color: red; display: none;"></p>
            <div class="form-group mb-16" v-if="google_sso_enabled">
                <button type="button" class="primary-button d-flex align-items-center justify-content-center google" @click="googleSignIn">
                    <span>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_7_462)">
                            <path d="M19.7618 10.1871C19.7618 9.36767 19.6954 8.76974 19.5515 8.14966H10.1948V11.848H15.687C15.5763 12.7671 14.9783 14.1512 13.6496 15.0813L13.6309 15.2051L16.5893 17.4969L16.7943 17.5174C18.6767 15.7789 19.7618 13.221 19.7618 10.1871Z" fill="#4285F4"/>
                            <path d="M10.1947 19.9313C12.8853 19.9313 15.1442 19.0454 16.7941 17.5174L13.6494 15.0813C12.8079 15.6682 11.6784 16.0779 10.1947 16.0779C7.55932 16.0779 5.3226 14.3395 4.52527 11.9366L4.4084 11.9466L1.33222 14.3273L1.29199 14.4391C2.93077 17.6945 6.29695 19.9313 10.1947 19.9313Z" fill="#34A853"/>
                            <path d="M4.52526 11.9367C4.31488 11.3166 4.19313 10.6522 4.19313 9.96568C4.19313 9.27912 4.31488 8.61476 4.51419 7.99469L4.50862 7.86263L1.39389 5.4437L1.29198 5.49217C0.616561 6.84308 0.229004 8.36011 0.229004 9.96568C0.229004 11.5713 0.616561 13.0882 1.29198 14.4391L4.52526 11.9367Z" fill="#FBBC05"/>
                            <path d="M10.1947 3.85336C12.066 3.85336 13.3282 4.66168 14.048 5.33718L16.8605 2.59107C15.1332 0.985496 12.8853 0 10.1947 0C6.29695 0 2.93077 2.23672 1.29199 5.49214L4.51421 7.99466C5.3226 5.59183 7.55932 3.85336 10.1947 3.85336Z" fill="#EB4335"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_7_462">
                                <rect width="19.542" height="20" fill="white" transform="translate(0.229004)"/>
                            </clipPath>
                        </defs>
                    </svg>
                    </span>
                    <span style="text-transform:none;">
                    <vd-component-param type="label33" v-html="i18n($attrs['label33'])"></vd-component-param>
                    </span>
                </button>
            </div>
            <div class="form-group mb-16"  v-if="apple_sso_enabled">
                <button type="button"  @click="appleSignIn" class="primary-button d-flex align-items-center justify-content-center apple">
                    <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0709 3.19287C13.8 2.34788 14.2914 1.17098 14.1569 0C13.1063 0.04 11.8352 0.671147 11.0819 1.51514C10.4054 2.26413 9.81484 3.4609 9.97359 4.60889C11.1456 4.69588 12.3418 4.03885 13.0709 3.19287ZM15.699 10.625C15.7283 13.652 18.4697 14.6589 18.5 14.6719C18.4778 14.7429 18.0622 16.1066 17.056 17.5166C16.1854 18.7346 15.2824 19.9476 13.8596 19.9736C12.4621 19.9986 12.0122 19.1797 10.4135 19.1797C8.81577 19.1797 8.31624 19.9475 6.9936 19.9985C5.62039 20.0475 4.5738 18.6808 3.6971 17.4668C1.90323 14.9838 0.533065 10.4501 2.37344 7.39014C3.28756 5.87116 4.92064 4.90779 6.69428 4.88379C8.04221 4.85879 9.31531 5.75293 10.1394 5.75293C10.9636 5.75293 12.5107 4.67794 14.1367 4.83594C14.8172 4.86294 16.7284 5.09885 17.955 6.81982C17.8559 6.87882 15.6747 8.09504 15.699 10.625Z" fill="white"></path>
                    </svg>
                    </span>
                    <span style="text-transform:none;">
                    <vd-component-param type="label40" v-html="i18n($attrs['label40'])"></vd-component-param>
                    </span>
                </button>
            </div>
            <div class="form-group mb-16" v-if="facebook_sso_enabled">
                <button type="button"  @click="facebookSignIn" class="primary-button d-flex align-items-center justify-content-center facebook">
                    <span>
                    <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_7_469)">
                            <path d="M19.3962 20.0001C20.0057 20.0001 20.5 19.5059 20.5 18.8962V1.10383C20.5 0.494141 20.0057 0 19.3962 0H1.60383C0.994062 0 0.5 0.494141 0.5 1.10383V18.8962C0.5 19.5059 0.994062 20.0001 1.60383 20.0001H19.3962Z" fill="white"></path>
                            <path d="M14.2995 20.0001V12.255H16.8993L17.2885 9.23663H14.2995V7.30944C14.2995 6.43553 14.5423 5.83999 15.7955 5.83999L17.3938 5.83928V3.13968C17.1173 3.10288 16.1685 3.02069 15.0648 3.02069C12.7602 3.02069 11.1826 4.42733 11.1826 7.01061V9.23663H8.57617V12.255H11.1826V20.0001H14.2995Z" fill="#335092"></path>
                        </g>
                        <defs>
                            <clipPath id="clip0_7_469">
                                <rect x="0.5" width="20" height="20" rx="4" fill="white"></rect>
                            </clipPath>
                        </defs>
                    </svg>
                    </span>
                    <span style="text-transform:none;">
                    <vd-component-param type="label42" v-html="i18n($attrs['label42'])"></vd-component-param>
                    </span>
                </button>
            </div>
            <div class="form-group or mb-32 mt-32" v-if="sso_enabled">
                <span>
                    <vd-component-param type="label32" v-html="i18n($attrs['label32'])"></vd-component-param>
                </span>
            </div>
            <form @submit.prevent action="" method="" class="" id="">
                <div class="form-group">
                    <div class="row">
                    <div class="col-md-12 phone-countrycode">
                        <select class="selectpicker" aria-label="Default select example" id = "selectpicker1" v-model="selectedCountry">
                            <option class="no-check" selected="" v-for="country in countryCodes" v-bind:value="country.phone_code" :data-subtext=" country.name">{{country.phone_code}}</option>
                        </select>
                        <input type="text" name="mobile" @keyup.enter="getOtpForm" required id="" class="form-control pl-100 vd-component-attr" vd-component-attr-placeholder="label12" :placeholder=i18n($attrs['label12']) 
                            vd-component-attr-title="label12" :title=i18n($attrs['label12']) v-model="mobile" :class="mobile_field ? 'is-invalid' : ''" >
                        <template v-if="errors.mobile">
                            <h3 class="invalid-feedback pb-2 validation-msg">{{ errors.mobile }}</h3>
                        </template>
                    </div>
                    </div>
                </div>
                <div class="form-group mb-40">
                    <button type="button" class="primary-button get-otp-btn" @click="getOtpForm" :disabled="mobile_field">
                    <vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                    </button>
                </div>
                <p class="text-center">
                    <vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param>
                    <vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param>
                </p>
            </form>
        </div>
        <!--Get otp Section End Here-->
        <!--Verify otp Section Start Here validateOtpPartShow-->
        <div class="sign-form-layout verify-otp bg-login-dark p-6448">
            <h2 class="mb-32">
                <vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param>
            </h2>
            <form action="" method="" class="" id="">
                <div class="form-group position-relative"  v-if="!(isEmailVerificationDuringRegdEnable || ssoEmailverification)">
                    <div class="row" style="pointer-events: none;">
                    <div class="col-md-12 phone-countrycode">
                        <!-- <div class="dropdown bootstrap-select"> -->
                        <select class="selectpicker" aria-label="Default select example" id = "selectpicker2" v-model="selectCountry">
                            <option class="no-check" :value="selectCountry">{{selectCountry}}</option>
                        </select>
                        <!-- </div> -->
                        <!-- </div>
                            <div class="col"> -->
                        <!--<input type="tel" name="" id="" class="form-control pl-75 pr-40" value="willie.jennings@example.com" placeholder="Enter email, or mobile number" > -->
                        <input type="text" name="mobile" required id="" class="form-control pl-100 vd-component-attr" vd-component-attr-placeholder="label23" :placeholder=i18n($attrs['label23']) 
                            vd-component-attr-title="label23" :title=i18n($attrs['label23']) v-model="mobile" :class="mobile_field ? 'is-invalid' : ''" @keyup.enter="getOtpForm">
                    </div>
                    </div>
                    <!--<button type="button" class="edit-input-btn" @click="returnToGetOtpPage">-->
                    <button type="button" class="edit-input-btn" id="edit-input-btn-sso" v-if="is_sso">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                    </button>
                    <button type="button" class="edit-input-btn" v-else>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                    </button>
                </div>
                <div class="form-group position-relative" v-else>
                    <div class="row" style="pointer-events: none;">
                    <div class="col-md-12 phone-countrycode is-email">
                        <input type="tel" name="" id="" class="form-control pl-75 pr-40" v-model="user_email" vd-component-attr-placeholder="label47" :placeholder=i18n($attrs['label47']) >
                    </div>
                    </div>
                    <button type="button"button type="button" class="edit-input-btn" id="edit-input-btn-sso" v-if="is_sso">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                        <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                        </defs>
                    </svg>
                    </button>
                </div>
                <!--OTP input start Here-->
                <div class="recived-code d-flex flex-wrap flex-column">
                    <div class="code d-flex justify-content-center mb-3">
                    <input type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitOne" maxlength="1">
                    <input type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitTwo" disabled="true" maxlength="1">
                    <input type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitThree" disabled="true" maxlength="1">
                    <input @keyup.enter="validateOtpPart" type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitFour" disabled="true" maxlength="1">
                    </div>
                    <div class="resend pl-0" :style="{ 'pointer-events': !enableResendButton ? 'none' : null }">
                    <!--Get Code in time-->
                    <div class="getcode d-flex justify-content-center mb-4" style="gap: 10px;">
                        <p>
                            <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                        </p>
                        <p :style="{ 'pointer-events': enableResendButton ? '' : 'none' }" :style="{ 'cursor': enableResendButton ? '' : 'not-allowed !important' }" :style="{ 'opacity': enableResendButton ? '' : '0.5' }">
                            <a href="javascript:void(0);" @click="resendOtp()">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_3058_11668)">
                                    <path d="M0.664062 2.66602V6.66602H4.66406" stroke="#2C6ECB" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path d="M2.3374 9.99964C2.76966 11.2266 3.58895 12.2798 4.67183 13.0006C5.75471 13.7214 7.04252 14.0707 8.34121 13.996C9.63989 13.9212 10.8791 13.4264 11.8721 12.5861C12.8652 11.7459 13.5582 10.6056 13.8469 9.33722C14.1355 8.06881 14.0041 6.74094 13.4725 5.55371C12.9408 4.36647 12.0377 3.38417 10.8993 2.75482C9.76083 2.12546 8.44867 1.88315 7.16051 2.06438C5.87236 2.24562 4.678 2.84059 3.7574 3.75964L0.664062 6.66631" stroke="#2C6ECB" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                                </g>
                                <defs>
                                    <clipPath id="clip0_3058_11668">
                                        <rect width="16" height="16" fill="white"/>
                                    </clipPath>
                                </defs>
                                </svg>
                                &nbsp;
                                <vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param>
                            </a>
                        </p>
                    </div>
                    <!--Get Code in time-->
                    </div>
                    <div class="form-group mb-24 text-center"  :style="{ 'display': !enableResendButton ? 'block' : 'none' }">
                    <!-- <label class="info">Your OTP will be expired in 3 min</label> -->
                    <label class="info">OTP can be resent in <span class="text-white" id="countdown-timer"></span></label>
                    </div>
                    <div class="form-group mb-32">
                    <button type="button" id="verifyOtpButton" class="primary-button disabled-button otp-verify-btn" @click="validateOtpPart" style="pointer-events: none;">
                        <vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param>
                    </button>
                    </div>
                    <p class="text-center">
                    <vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param>
                    <vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param>
                    </p>
            </form>
            </div>
            <!--verify otp Section End Here-->
            <!--Sso mobile popup Start Here-->
            <div class="sign-form-layout bg-login-dark p-4048 signup-google-otp">
                <h2 class="mb-2">
                    <vd-component-param type="label34" v-html="i18n($attrs['label34'])"></vd-component-param>
                </h2>
                <span class="subtext mb-32">
                    <vd-component-param type="label35" v-html="i18n($attrs['label35'])"></vd-component-param>
                </span>
                <form action="" method="" class="mt-3" id="">
                    <div class="form-group form-label _required"  v-if="otpSettingEnabled==false || muviAuthSettingType == '35'">
                    <label class="form-label">
                        <vd-component-param type="label45" v-html="i18n($attrs['label45'])"></vd-component-param>
                    </label>
                    <input vd-readonly="true" type="text" class="form-control vd-component-attr" v-model="user_email" vd-component-attr-placeholder="label43" :placeholder=i18n($attrs['label43']) 
                        vd-component-attr-title="label44" :title=i18n($attrs['label44']) autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''">
                    <template v-if="errorMsgs[0]!='' && this.errorMsgs[0]!=undefined">
                        <div class="invalid-feedback" :style="errorMsgs[0]!='' && this.errorMsgs[0]!=undefined ? 'display: block;' : 'display: none;'">{{ errorMsgs[0] }}</div>
                    </template>
                    </div>
                    <div class="form-group form-label _required position-relative"  v-if="otpSettingEnabled==true">
                    <label class="form-label">
                        <vd-component-param type="label46" v-html="i18n($attrs['label46'])"></vd-component-param>
                    </label>
                    <div class="row">
                        <div class="col-md-12 phone-countrycode">
                            <select class="selectpicker"  aria-label="Default select example" id = "selectpicker1" v-model="selectedCountry">
                                <option class="no-check" selected="" v-for="country in countryCodes" v-bind:value="country.phone_code" :data-subtext=" country.name">{{country.phone_code}}</option>
                            </select>
                            <input  v-model="mobile" type="text" class="form-control pl-40 vd-component-attr"
                                vd-component-attr-placeholder="label37" :placeholder=i18n($attrs['label37']) 
                                vd-component-attr-title="label37" :title=i18n($attrs['label37']) :class="mobile_field ? 'is-invalid' : ''" required id="" >
                        </div>
                        <template v-if="errorMsgs[1]!='' && this.errorMsgs[1]!=undefined">
                            <div class="col-md-12 invalid-feedback" :style="errorMsgs[1]!='' && this.errorMsgs[1]!=undefined ? 'display: block;' : 'display: none;'">{{ errorMsgs[1]}}</div>
                        </template>
                    </div>
                    </div>
                    <div class="form-group mb-4">
                    <button id="nextButton" v-if="muviAuthSettingType == '1' || muviAuthSettingType == '13'" type="button" vd-node="styleOnly" vd-readonly="true" style="text-transform: none;"
                        class="primary-button"  @click="getOtpForRegThroughEmailWithSso">
                        <vd-component-param type="label48" v-html="i18n($attrs['label48'])"></vd-component-param>
                    </button>
                    <button type="button" v-else class="primary-button getOtp" @click="generateOtpForSsoMobile">
                        <vd-component-param type="label38" v-html="i18n($attrs['label38'])"></vd-component-param>
                    </button>
                    </div>
                </form>
            </div>
            <!--Sso mobile popup End Here-->
        </div>
        </section>
        <!--Sign Up From End Here-->
    </vd-component>`,
};

let {
    getContentSettingsDetails,
    getContentDetails,
    categorizedPermalink,
    getContentFavoriteStatus,
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:watch_now_five}=await import(window.importLocalJs('widgets/watch-now/watch-now-five.js'));
let {default:add_to_queue_one}=await import(window.importLocalJs('widgets/add-to-queue/add-to-queue-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:like_favourite_share_content_eight}=await import(window.importLocalJs('widgets/like-favourite-share-content/like-favourite-share-content-eight.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: "playlist_banner_four",
    components: {
        watch_now_five,
        add_to_queue_one,
        audio_player_one,
        like_favourite_share_content_eight,
    },
    data() {
        return {
            contentDetails: [],
            content_readmore: "",
            contentlevel: 0,
            pointerevents: "none",
            seasonCount: false,
            noOfSession: 0,
            bannerImg: "",
            contentUuid: localStorage.getItem("contentId"),
            seasonLevelData: [],
            count: [],
            child_contentDetails: [],
            optNo: 0,
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            isAuthorized: null,
            childContentUuid: "",
            nestedContentplayBtnShow: false,
            showAddToQueueBtn: false,
            // audio content
            audioUuid: "",
            uniqueId: "",
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: "",
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            contentParentUuid: "",
            stickyAudioData: "",
            removeJs: true,
            playBackRatesValue: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],

            contentName: "",
            videoDuration: "",
            audioDuration: "",
            like_status: "",
            dislike_status: "",
            count: 0,
            userLiked: false,
            userDisliked: false,
            descLength: "",
            no_of_child_content: "",
            contentGroupDetails: Object,
            selectedLabel1Content: Object,
            isFavourite: 0,
            isFavouriteEnabled: false,
            likeReviewRatingsSettings: {
                is_like_enabled: false,
                is_dislike_enabled: false,
                is_like_count_enabled: false,
                is_dislike_count_enabled: false,
                is_rating_enabled:false,
                is_comment_enabled:false,
            },
            contentReadMoreObj: {},
            level1PageNo: -100,
            isNextLevel1PageExist: true,
            level2PageNo: -100,
            isNextLevel2PageExist: true,
            isButtonShow: false,
            playerRequiredObj: {},
            isQueueBtnShow: false,
            queueObj: {},
            contentUuidAudio: '',
            isAudioPlay: false,
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            rootUrl: getRootUrl(),
            permalinkDataEmitted: null
        };
    },
    // created() {
    //     JsLoadingOverlay.show();
    // },

    props: {
        isAuth: String,
    },

    mounted() {
        this.enduserURL = window.location.origin + "/";
        this.baseURL = getBaseUrl();
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    // setTimeout(() => {
                    //     JsLoadingOverlay.hide();
                    // }, 2000);
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    (content.permalink_type == "content" ||
                                        content.is_playlist == 1) &&
                                    content.content_permalink ==
                                    this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        let contentObj =
                            res.data.data.contentList.content_list[
                            findContentParentIndex
                            ];
                        this.contentParentUuid = contentObj.content_uuid;
                        console.log(
                            this.contentParentUuid + "----1----",
                            contentObj.is_playlist
                        );
                        this.getContentDetailsData(
                            this.contentParentUuid,
                            contentObj.is_playlist
                        );
                        this.getContentFavouriteAction(contentObj.content_uuid);
                        this.getContentSettingsDetails(
                            contentObj.structure_uuid
                        );

                        // if(contentObj.is_parent == 1){
                        //     this.getChildDetails(this.contentParentUuid,this.level1PageNo,false);
                        // }
                    }
                }
            });
            //this.loadMore();
        }
    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite =
                        res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },
        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                console.log("2----", res);
                if (res.data.code == 200 && res.data.data !== null) {
                    //BUTTON SHOW
                    this.isButtonShow = true;
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                    this.contentDetails.is_playlist = 1;
                    this.setPlayerObj(this.contentDetails);
                    this.descLength = this.contentDetails.content_desc.length;
                    this.content_readmore =
                        this.contentDetails.content_desc.substring(0, 120);
                    this.noDefaultImage =
                        res.data.data.contentList.content_list[0].no_image_available_url;
                    if (
                        this.contentDetails.posters.website != null &&
                        this.contentDetails.posters.website.file_url !== ""
                    ) {
                        this.bannerImg =
                            this.contentDetails.posters.website[0].file_url;
                    }
                    else {
                        this.bannerImg = res.data.data.contentList.content_list[0].no_image_available_url;
                            // "../resources/views/phoenix/default/img/video-after-login-banner.png"; //res.data.data.contentList.content_list[0].no_image_available_url;
                    }
                    // this.castDetails = res.data.data.contentList.content_list[0];
                    this.no_of_child_content =
                        res.data.data.contentList.content_list[0].no_of_child_content;

                    res.data.data.contentList.content_list.forEach((ele) => {
                        if (
                            ele.video_details !== null &&
                            ele.content_asset_type === 1
                        ) {
                            const vDuration =
                                ele.video_details.duration.replace(
                                    /^0(?:0:0?)?/,
                                    ""
                                );
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration
                                    .replace(":", "m ")
                                    .concat("s");
                            } else {
                                this.videoDuration = vDuration
                                    .replace(":", "h ")
                                    .replace(":", "m ")
                                    .concat("s");
                            }
                        }
                        if (
                            ele.audio_details !== null &&
                            ele.content_asset_type === 2
                        ) {
                            const aDuration =
                                ele.audio_details.duration.replace(
                                    /^0(?:0:0?)?/,
                                    ""
                                );
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration
                                    .replace(":", "m ")
                                    .concat("s");
                            } else {
                                this.audioDuration = aDuration
                                    .replace(":", "h ")
                                    .replace(":", "m ")
                                    .concat("s");
                            }
                        }
                    });
                }
            });
        },
        // getChildDetails(contentParentUuid,pageNo,onScroll) {
        //     this.isNextLevel1PageExist = false;
        //     getChildDetails(contentParentUuid,pageNo).then((res) => {
        //        //console.log("child_contentDetails res", res.data.data.childList.child_list)
        //        // this.child_contentDetails = res.data.data.childList.child_list;
        //         if (onScroll && res.data.data.childList.child_list.child_content != null) {
        //             this.isNextLevel1PageExist = true;
        //             this.child_contentDetails.child_content.push(...res.data.data.childList.child_list.child_content);
        //         }
        //         else if(!onScroll && res.data.data.childList.child_list.child_content != null) {
        //             this.isNextLevel1PageExist = true;
        //             this.child_contentDetails = res.data.data.childList.child_list;
        //         }

        //         if (this.seasonLevelData) {
        //             this.seasonLevelData = res.data.data.childList.child_list.child_content;
        //             this.getChildContentDetails(this.child_contentDetails);
        //             // if (this.child_contentDetails.is_parent) {
        //             //     this.getPlayerPermalink(contentParentUuid);
        //             // }

        //          }
        //     });

        // },

        // getChildContentDetails(content) {
        //     if (content && content.child_content && content.child_content.length > 0) {
        //         let promiseCollection = [];
        //         for (let i = 0; i < content.child_content.length; i++) {
        //             getChildDetails(content.child_content[i].content_uuid,this.level2PageNo,false).then((result) => {
        //                 content.child_content[i].child_content = result.data.data.childList.child_list.child_content;
        //                 if(i==0){
        //                     this.selectedLabel1Content = result.data.data.childList.child_list;
        //                 }
        //                 // if(i == content.child_content.length-1){
        //                 //     this.generateCustomDropdown();
        //                 // }
        //             });

        //         }
        //     }
        // },
        // getEpisodeData(episodeData, index) {
        //     return episodeData[index];
        // },
        // showGridListView(optNum) {
        //     this.optNo = optNum;
        // },

        /**
         * Used for copy the message to the system clip board.
         * @param val : contain the string value which need to be copy.
         */
        copyMessage(val) {
            const selBox = document.createElement("textarea");
            selBox.style.position = "fixed";
            selBox.style.left = "0";
            selBox.style.top = "0";
            selBox.style.opacity = "0";
            selBox.value = val;
            document.body.appendChild(selBox);
            selBox.focus();
            selBox.select();
            document.execCommand("copy");
            document.body.removeChild(selBox);
        },

        getContentSettingsDetails(structureUuid) {
            getContentSettingsDetails(structureUuid).then((res) => {
                if (res.data.code == 200) {
                    if (
                        res.data.data.contentSettings.level_structures !=
                        null &&
                        res.data.data.contentSettings.level_structures.length >
                        0
                    ) {
                        this.contentGroupDetails =
                            res.data.data.contentSettings.level_structures[0];
                        this.contentGroupDetails.level_structure_detail =
                            this.contentGroupDetails.level_structure_detail.sort(
                                (a, b) => {
                                    let fa = a.level,
                                        fb = b.level;
                                    if (fa < fb) {
                                        return -1;
                                    }
                                    if (fa > fb) {
                                        return 1;
                                    }
                                    return 0;
                                }
                            );
                    }
                    this.isFavouriteEnabled =
                        res.data.data.contentSettings
                            .content_favourite_settings != null
                            ? res.data.data.contentSettings
                                .content_favourite_settings?.is_enabled
                            : false;
                    if (
                        res.data.data.contentSettings
                            .content_like_and_review_settings != null
                    ) {
                        this.likeReviewRatingsSettings =
                            res.data.data.contentSettings.content_like_and_review_settings;
                    }
                }
            });
        },

        selectL1Dropdown() {
            let selectedContentUuid = $(
                ".custom-select .select-items .same-as-selected input"
            )
                .val()
                .replaceAll("#_#", "");
            this.selectedLabel1Content =
                this.child_contentDetails?.child_content?.filter(
                    (l1Obj) => l1Obj.content_uuid == selectedContentUuid
                )[0];
        },

        setDataReadMorePop(contentObj) {
            this.contentReadMoreObj = contentObj;
        },

        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration", videoDuration);
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration else", videoDuration);
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },

        setPlayerObj(contentObj) {
            this.playerRequiredObj = {
                contentUuid: contentObj.content_uuid,
                isPlayList: contentObj.is_playlist,
                contentPermalink: contentObj.content_permalink,
                contentAssetType: contentObj.content_asset_type,
                isParent: contentObj.is_parent,
            };
        },
        isQueueBtn(value) {
            this.isQueueBtnShow = value;
        },
        setQueueEmit(value) {
            this.queueObj = value;
        },
        playAudioContent(content_detail) { //ER-101092
            this.contentUuidAudio = content_detail.contentUuid; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        reloadComponentAudio(content_detail){
            this.playAudioContent(content_detail); //ER-101092
        },
        playerPermalinkDataEmitted(data) {
            this.permalinkDataEmitted = data;
        },
        triggerWatchNow() {
            this.$refs.$watchNowRef.getContentDetails('1');
        }
    },
    computed: {
        level0Name() {
            return this.contentGroupDetails.level_structure_detail[0]
                ?.level_name;
        },
        level1Name() {
            return this.contentGroupDetails.level_structure_detail != undefined
                ? this.contentGroupDetails.level_structure_detail[1]?.level_name
                : "Seasons";
        },
        level2Name() {
            return this.contentGroupDetails.allowed_level == 3
                ? this.contentGroupDetails.level_structure_detail[2].level_name
                : "";
        },
    },
    watch: {
        optNo(optNo) {},
    },
    template: `
    <vd-component class="vd playlist-banner-four" type="playlist-banner-four">
    <section class="symphony-banner-content dark-black">
        <div class="container-fluid plr-88">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="album-details-banner d-md-flex d-lg-flex">
                        <div class="left-thamble">
							<img class="mw-100" v-if="contentDetails?.posters?.website == null || contentDetails?.posters?.website?.file_url == ''" :src="bannerImg" alt="banner"/>
                            <img class="mw-100" v-else="contentDetails?.posters?.website != null && contentDetails?.posters?.website?.file_url !== ''" loading="lazy" :src="bannerImg" alt="banner">
                        </div>
                        <div class="data-content">
                            <h1 class="sub-heading white-color separate-page-heading">{{contentDetails.content_name}}
                            </h1>
                            <p
                                v-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==1 && contentDetails?.playlist_content_list?.length>0">
                                {{contentDetails?.playlist_content_list?.length + ' '}} <vd-component-param type="label20"
                                    v-html="i18n($attrs['label20'])"></vd-component-param> </p>
                            <p
                                v-else-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==2 && contentDetails?.playlist_content_list?.length>0) || (contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==6 && contentDetails?.playlist_content_list?.length>0">
                                {{contentDetails?.playlist_content_list?.length + ' '}} <vd-component-param type="label21"
                                    v-html="i18n($attrs['label21'])"></vd-component-param> </p>
                            <span class="hrs-span" v-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==6 && contentDetails?.playlist_content_list?.length>0">
                                {{contentDetails?.playlist_content_list?.length +' '}} 
                                <vd-component-param v-else type="label22" v-html="i18n($attrs['label22'])"></vd-component-param>
                            </span>
                            <span class="ratingstarsCounts" v-if="likeReviewRatingsSettings.is_rating_enabled">
                                <span class="hrs-span">|</span>
                                <a id="openRatingID" class="openRating" href="javascript:void(0);">
                                    <span>
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_3965_17115)">
                                                <path
                                                    d="M6 1L7.545 4.13L11 4.635L8.5 7.07L9.09 10.51L6 8.885L2.91 10.51L3.5 7.07L1 4.635L4.455 4.13L6 1Z"
                                                    fill="#FFB75E" stroke="#FFB75E" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_3965_17115">
                                                    <rect width="12" height="12" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </span>
                                    <span class="ratingCount">{{contentDetails.avg_rating}}</span>
                                </a>
                                <div class="showstarRatingpopup">
                                    <span class="srp-left-arrow">
                                        <svg width="8" height="11" viewBox="0 0 8 11" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M0.455158 4.69656L6.87812 0.414587C7.14394 0.237372 7.5 0.427929 7.5 0.747407L7.5 10.1678C7.5 10.5032 7.11203 10.6896 6.85012 10.4801L0.427161 5.34173C0.215762 5.17261 0.229903 4.84673 0.455158 4.69656Z"
                                                fill="white" />
                                        </svg>
                                    </span>
                                    <div class="starRatingpopup">
                                        <ul class="srp-ul">
                                            <li class="srp-ul-li">
                                                <span class="srp-ul-li-span1">
                                                    <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_2679_23226)">
                                                            <path
                                                                d="M11.8307 14V12.6667C11.8307 11.9594 11.5498 11.2811 11.0497 10.781C10.5496 10.281 9.87131 10 9.16406 10H3.83073C3.12349 10 2.44521 10.281 1.94511 10.781C1.44501 11.2811 1.16406 11.9594 1.16406 12.6667V14"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                            <path
                                                                d="M6.50261 7.33333C7.97537 7.33333 9.16927 6.13943 9.16927 4.66667C9.16927 3.19391 7.97537 2 6.50261 2C5.02985 2 3.83594 3.19391 3.83594 4.66667C3.83594 6.13943 5.02985 7.33333 6.50261 7.33333Z"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                            <path
                                                                d="M15.8359 13.9993V12.6659C15.8355 12.0751 15.6388 11.5011 15.2768 11.0341C14.9149 10.5672 14.408 10.2336 13.8359 10.0859"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                            <path
                                                                d="M11.1641 2.08594C11.7377 2.2328 12.2461 2.5664 12.6092 3.03414C12.9722 3.50188 13.1693 4.07716 13.1693 4.66927C13.1693 5.26138 12.9722 5.83666 12.6092 6.3044C12.2461 6.77214 11.7377 7.10574 11.1641 7.2526"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_2679_23226">
                                                                <rect width="16" height="16" fill="white"
                                                                    transform="translate(0.5)" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    <span class="srpli-span1-txt">Rated By</span>
                                                </span>
                                                <span class="srp-ul-li-span2">{{contentDetails.rated_by}}</span>
                                            </li>
                                            <li class="srp-ul-li">
                                                <span class="srp-ul-li-span1">
                                                    <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M8.5026 1.33398L10.5626 5.50732L15.1693 6.18065L11.8359 9.42732L12.6226 14.014L8.5026 11.8473L4.3826 14.014L5.16927 9.42732L1.83594 6.18065L6.4426 5.50732L8.5026 1.33398Z"
                                                            stroke="#15151A" stroke-width="1.33" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                    <span class="srpli-span1-txt">Average Rating</span>
                                                </span>
                                                <span class="srp-ul-li-span2">{{contentDetails.avg_rating}}</span>
                                            </li>
                                            <li class="srp-ul-li" v-if="likeReviewRatingsSettings.is_comment_enabled">
                                                <span class="srp-ul-li-span1">
                                                    <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_2679_23236)">
                                                            <path
                                                                d="M11.8307 14V12.6667C11.8307 11.9594 11.5498 11.2811 11.0497 10.781C10.5496 10.281 9.87131 10 9.16406 10H3.83073C3.12349 10 2.44521 10.281 1.94511 10.781C1.44501 11.2811 1.16406 11.9594 1.16406 12.6667V14"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                            <path
                                                                d="M6.50261 7.33333C7.97537 7.33333 9.16927 6.13943 9.16927 4.66667C9.16927 3.19391 7.97537 2 6.50261 2C5.02985 2 3.83594 3.19391 3.83594 4.66667C3.83594 6.13943 5.02985 7.33333 6.50261 7.33333Z"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                            <path
                                                                d="M15.8359 13.9993V12.6659C15.8355 12.0751 15.6388 11.5011 15.2768 11.0341C14.9149 10.5672 14.408 10.2336 13.8359 10.0859"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                            <path
                                                                d="M11.1641 2.08594C11.7377 2.2328 12.2461 2.5664 12.6092 3.03414C12.9722 3.50188 13.1693 4.07716 13.1693 4.66927C13.1693 5.26138 12.9722 5.83666 12.6092 6.3044C12.2461 6.77214 11.7377 7.10574 11.1641 7.2526"
                                                                stroke="#15151A" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_2679_23236">
                                                                <rect width="16" height="16" fill="white"
                                                                    transform="translate(0.5)" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                    <span class="srpli-span1-txt">Reviewed By</span>
                                                </span>
                                                <span class="srp-ul-li-span2">{{contentDetails.reviewed_by}}</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </span>
                            <template v-if="descLength > 120">
                                <p class="content-data white-color">{{content_readmore}}
                                    <a class="callByAjax" href="javascript:void(0);" @click="contentReadMoreObj = contentDetails" data-toggle="modal" data-target=".readmore-banner">
                                        <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                                    </a>
                                </p>
                            </template>
                            <div class="button-share d-flex">
                                <div class="button-section">
                                    <template v-if="isButtonShow && contentDetails?.content_asset_type !=6">
                                        <watch_now_five :id="$attrs['id'] +'_watch_now_five_5'"
                                            @isQueueButton="isQueueBtn" @queueObjEmit="isQueueObj"
                                            @playAudioContent="playAudioContent"
                                            :playerRequiredObj="playerRequiredObj" @player_permalink_data="playerPermalinkDataEmitted" ref="$watchNowRef" />
                                    </template>
                                </div>
                                <div class="social-share-icons">
                                    <like_favourite_share_content_eight
                                        :id="$attrs['id'] +'_like_favourite_share_content_eight_8'"
                                        :contentData="contentDetails"
                                        :likeReviewRatingsSettingsData="likeReviewRatingsSettings"
                                        :isFavouriteSettings="isFavouriteEnabled" :shareVideoText="$attrs['label7']"
                                        :linkText="$attrs['label8']" :socialText="$attrs['label9']" :permalinkDataEmitted="permalinkDataEmitted" @call-watch-now="triggerWatchNow" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--popup design readmore Start Here-->
    <div class="modal fade readmore-banner" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header flex-column">
                    <h5 class="modal-title" id="exampleModalLabel">{{contentReadMoreObj?.content_name}}</h5>

                    <h6 class="sub-heading white-color"
                        v-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==1 && contentDetails?.playlist_content_list?.length>0">
                        {{contentDetails?.playlist_content_list?.length+' '}} <vd-component-param v-else type="label20" v-html="i18n($attrs['label20'])"></vd-component-param> </h6>
                    <h6 class="sub-heading white-color"
                        v-else-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==2 && contentDetails?.playlist_content_list?.length>0">
                        {{contentDetails?.playlist_content_list?.length+' '}}&nbsp; <vd-component-param v-else type="label21" v-html="i18n($attrs['label21'])"></vd-component-param> </h6>
                    <h6 class="sub-heading white-color"
                        v-else-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==6 && contentDetails?.playlist_content_list?.length>0">
                        {{contentDetails?.playlist_content_list?.length+' '}} &nbsp; <vd-component-param v-else type="label22" v-html="i18n($attrs['label22'])"></vd-component-param> </h6>
                    <span class="close-model" data-dismiss="modal">
                        <img :src="rootUrl +'img/modalCloseCross.png'" alt="popup" class="modalCloseCross" />
                    </span>
                </div>
                <div class="modal-body">
                    <p>{{contentReadMoreObj?.content_desc}}</p>
                </div>
            </div>
        </div>
    </div>
    <audio_player_one @reloadComponentAudio="reloadComponentAudio" :id="$attrs['id'] +'_audio_player_one_1'" @queueEmit="setQueueEmit" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
</vd-component>`,
    //    inheritAttrs: fa v vlse
};

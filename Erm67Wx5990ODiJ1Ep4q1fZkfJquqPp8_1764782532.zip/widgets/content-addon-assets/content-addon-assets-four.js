let {
    getContentAddonDetails,
    categorizedPermalink,
    isAuthorizedContent
} = await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_five}=await import(window.importLocalJs('widgets/content-hover/content-hover-five.js'));
let {default:audio_player_lite_one}=await import(window.importLocalJs('widgets/audio-player-lite/audio-player-lite-one.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {SET_CURRENT_CONTENT_SELECTION_DATA, TOGGLE_CONTENT_PURCHASE_MODAL, GET_END_USER_REGD_LOGIN_SETTING, PLAY_CONTENT}=await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;

export default {
    name: "content_addon_assets_four",
     data() {
        return {
                addonList:[],
                contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
                contentParentUuid:"",
                isLogedIn: localStorage.getItem('isloggedin'),
            isAudioDisplay: false,
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            audioConfig: '',
            contentDetails:null,
            isRegdLogin: 1,
        }
    },
    computed: {
        ...mapState({
            end_user_regd_login_setting: (state) => state.end_user_regd_login_setting,
        }),
    },
    components: {
        content_hover_five,
        audio_player_lite_one
    },
    beforeCreate() {

    },
    mounted() {

        if (this.contentPermalink) {
            this.isFreeContent = false;//ER-101092
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if (content.permalink_type == "content" && content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.contentDetails = res.data.data.contentList.content_list[findContentParentIndex];
                        this.isFreeContent = res.data.data.contentList.content_list[findContentParentIndex].is_free_content;//ER-101092
                        this.getContentAddonDetails();


                    }
                }
            });
        }
        

    },
    methods: {
        i18n,
        getRootUrl,
        getContentAddonDetails() {
                getContentAddonDetails(this.contentParentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null &&
                    res.data.data.addons.addons?.length>0) {
                    this.addonList = res.data.data.addons.addons;
                    console.log("addonList---",this.addonList);
                }
            });
        },
        audioAddOnObject(value) {
            try {
                //SHOW LOADER
                //JsLoadingOverlay.show();
                this.getAudioObject(value);
                this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                //SHOW PLAYER
                this.isAudioDisplay = true;
            } catch (error) {
                throw "audioAddOnObject=>" + error;
            }
        },
        getAudioObject(value) {
            try {
                console.log( 'value',value);
                let sourcesArr = value.media_details.encoded_url;
                let labelVal= "";
                let newSourceArr = [];
                sourcesArr.forEach((item) => {
                    labelVal= "";
                    var obj = {};
                    if (item.resolution == "320") {
                        labelVal = 'High';
                    } else if (item.resolution == "192") {
                        labelVal = 'Fair';
                    } else if (item.resolution == "128") {
                        labelVal = 'Low';
                    }
                    obj.src = item.url;
                    obj.bitrate = Number(item.resolution);
                    obj.label = labelVal;
                    newSourceArr.push(obj);
                });
                let bestObj = {};
                bestObj.src = value.media_details.file_url;
                bestObj.label="Best";
                newSourceArr.push(bestObj);
                console.log("pithan----",sourcesArr );
                this.audioConfig = {
                    audioSource: [
                        {
                            "name": value.label_name,
                            "full_name": value.label_name,
                            "parent_id": null,
                            "uniq_id": value.addon_uuid,
                            "desc": "",
                            "duration": value.media_details.duration,
                            "poster": getRootUrl()+"/img/thumbnail-audio.png",
                            "sources":newSourceArr,
                            // "sources": [
                            //     {
                            //         "src": "https://dtu142d8k2g2g.cloudfront.net/tkdLO6wuMqG8vXnoQuJb1eHDxBzaJxzB/3D28C83C85544F0D9517DD2E7C7EEDAA/al/b40506fb049b41e3a60480511d6e168f/audios/Tujhe_Bhula_Diya__LoFi_Mix__Kedrock___SD_Style___Mohit_Chauhan__Shekhar_R__Shruti_P___Bhushan_Kumar-1664197712685_128.mp3",
                            //         "label": "Low",
                            //         "bitrate": 128
                            //     },
                            //     {
                            //         "src": value.media_details.file_url,
                            //         "label": "Best",
                            //     }
                            // ],
                            "share_url": this.contentPermalink
                        },
                    ],
                    playbackRates: true,
                    isFreeContent: this.isFreeContent, //ER-101092
                    contentUuid:this.contentParentUuid
                }
            } catch (error) {
                throw "getAudioObject=>" + error;
            }
        },
        async isAuthorized(value) {
            this.isRegdLogin = this.end_user_regd_login_setting.sections[0].groups[0].nodes[0].node_value ? 1 : 0;

            if (this.isRegdLogin === 0) {
                // window.location.href = value;
                window.open(value, '_blank');
            } else {
                if (!this.isLogedIn) {
                    let freeContentLoginRequired = JSON.parse(localStorage.getItem("freeContentLoginRequired"));
                    if (this.isFreeContent && !freeContentLoginRequired) {
                        // window.location.href = value;
                        window.open(value, '_blank');
                    } else {
                        const redirectAfterLogin = window.localStorage.getItem("addOnContentPageUrl");
                        if (redirectAfterLogin) {
                            window.localStorage.removeItem("addOnContentPageUrl");
                            window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                        }
                        window.location.href = "/sign-in";
                        return false;
                    }
                } else {
                    const res = await isAuthorizedContent(this.contentParentUuid );
                    if (res.data.code == 200) {
                        if (res.data.data.isAuthorized.is_content_authorized) {
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                            // window.location.href = value;
                            window.open(value, '_blank');
                        } else {
                            this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                content_uuid: this.contentParentUuid ,
                                monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                            });
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);//true
                        }
                    } else {
                        JsLoadingOverlay.hide();
                        Toast.fire({ icon: "error", title: res.data.message });
                    }
                }
            }

            return false;
        }
    },
    template: /*html*/ `
    <vd-component class="vd content-addon-assets-four" type="content-addon-assets-four">
   	<section class="season-content" v-if="addonList.length>0">
		<div class="container-fluid pl-65">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="addonList.length">
					<div class="episode-heading">
						<h3 vd-readonly="true" class="sub-heading white-color">Add On</h3>
					</div>
				</div>
				
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="row" >
                                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="data in addonList">
                                                        <div class="tiles grid-hover">
                                                                <div class="picture">
                                        <!--<div class="icons-apply">
                                            <img v-if="data.media_type == 1"
                                                :src="getRootUrl() + 'img/video-icons.png'" />
                                            <img v-if="data.media_type == 2"
                                                :src="getRootUrl() + 'img/audio-icon.png'" />
                                                                       
                                        </div>-->
                                        <img class="w-100" loading="lazy"
                                            v-if="data.media_type==1 && data.media_details?.file_url !== ''"
                                            :src="getRootUrl() +'/img/thumbnail-video.png'" />
                                        <img class="w-100" loading="lazy"
                                            v-if="data.media_type==2 && data.media_details?.file_url !== ''"
                                            :src="getRootUrl() +'/img/thumbnail-audio.png'" />
                                        <img class="w-100" loading="lazy"
                                            v-if="data.media_type==3 && data.media_details?.file_url !== ''"
                                            :src="getRootUrl() +'/img/thumbnail_file.png'" />
                                                                    <!--Button Show on Hover start Here-->
                                        <content_hover_five :id="$attrs['id'] +'_content_hover_five_1'"
                                            :content="data" 
                                            :playNowBtnTxt="i18n($attrs['label1'])"
                                            :viewTrailerBtnTxt="i18n($attrs['label2'])"
                                            :playAllBtnTxt="i18n($attrs['label3'])"
                                            :watchNowBtnTxt="i18n($attrs['label4'])"
                                            :isLogedIn="isLogedIn" isAddOn="true"
                                            @audioAddOnObject=audioAddOnObject 
                                            :contentPermalinkAddon="contentPermalink"
                                            :playAddonContentDetails="contentDetails"/>
                                                                    <!--Button Show on Hover End Here--> 
                                                                        
                                                                </div>
                                                                <div class="data" v-if="data?.media_type==3">
                                                                        <a class="callByAjax" target="_blank" @click="isAuthorized(data.media_details.file_url)" >
                                                                                <span>{{data.label_name}} </span>
                                                                        </a>
                                                                       
                                                                        
                                                                </div>
                                                                <div class="data" v-else>
                                                                        
                                                                                <span>{{data.label_name}} </span>
                                                                       
                                                                        
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
				
			</div>
		</div>
	</section>
	
        <audio_player_lite_one :id="$attrs['id'] +'_audio_player_lite_one_1'" :key="resetAudioPlayer" :audioConfig="audioConfig" v-if="isAudioDisplay" />
</vd-component>`,
};

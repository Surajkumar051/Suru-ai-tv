let { getCookie, getConfigValue, CookiePreferences, getCookiePreferences } = await import(window.importAssetJs('js/webservices.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));

export default {
    name: "cookie_six",
    data() {
        return {
            isCookieEnabled: false,
            cookieMsg: "",
            showCookie: false,
            isCookieAcptd: false,
            cookieData: [],
            originalCategoryData: [],
            isEnableAdvanceCookie: false,
            fetchedAdvanceData: false,
            cookieConsentStatus: {},
            selectedCookies: [],
            notSelectedCookies: [],
            allCookies: [],

        };
    },

    async mounted() {
        try {

            await this.fetchCookieData();
            const cookieValue = this.get_Cookie("cookieAccepted");
            if (this.isCookieEnabled && cookieValue != "1") {
                $('#privacypolicy').modal('show');
            } else {
                $('#privacypolicy').modal('hide');
            }
        } catch (error) {
            console.error('Error during async operations:', error);
        }

    },

    methods: {
        i18n,
        async fetchCookiePreferenceData() {
            const res = await getCookiePreferences();
            this.cookieData = res?.data?.data || [];
            // Check if response status is 200 and if data exists
            var urlParams = new URLSearchParams(window.location.search);
            if (!urlParams.get('is_vd')) {
                if (res.status == 200 && res.data?.data && res.data.data.length > 0 && this.get_Cookie("cookieAccepted")
                    && this.isEnableAdvanceCookie) {
                    this.isCookieAcptd = false;
                    this.deleteCookie('cookieAccepted');
                    this.getCookieCategoryData(res);
                    $('#privacypolicy').modal('show');

                } else if (this.isEnableAdvanceCookie && res.data.data.length == 0) {
                    document.cookie = "cookieAccepted=1;path=/;";
                    this.isCookieAcptd = true;
                    $('#privacypolicy').modal('hide');
                }
            }
        },

        async getCookieCategoryData(result) {
            if (result.data.code === 200) {
                this.cookieData = result.data.data.map(category => ({
                    ...category,
                    is_active: category.is_active ? 1 : 0, // Convert true/false to 1/0
                    take_consent: category.take_consent ? 1 : 0, // Convert true/false to 1/0
                }));
                this.originalCategoryData = JSON.parse(JSON.stringify(this.cookieData));
            }
        },

        async fetchCookieData() {
            // get cookie cms
            const res = await getCookie()
            if (res.data.code == 200 && res.data.data !== null) {
                this.isCookieEnabled = res.data.data.enable_cookie_content;

                if (this.isCookieEnabled) {
                    this.cookieMsg = res.data.data.cookie_content;
                    await this.fetchAdvanceCookieData();
                } else {
                    this.isCookieEnabled = false;
                }
            }
        },

        //get advance opt enable
        async fetchAdvanceCookieData() {
            const cookieConfig = await getConfigValue({ "query": "{sections(code:\"cookie-page\"){section_uuid,code,comment,label,sequence,groups{group_uuid,code,comment,label,sequence,nodes(app_token:\":app_token\", product_key: \":product_key\", store_key: \":store_key\"){node_uuid,sequence,section_code,group_code,node_type,node_label,node_placeholder,node_code,node_value,node_comment,parent,options {option_uuid,config_node_uuid,option_value,option_label,sequence}}}}}" })

            if (cookieConfig?.data?.code == 200) {
                let node_value = cookieConfig?.data?.data?.sections[0]?.groups[0]?.nodes[0]?.node_value
                this.isEnableAdvanceCookie = (node_value !== "0" && node_value !== "" && node_value !== "null");
                // if (this.isEnableAdvanceCookie ) {
                await this.fetchCookiePreferenceData();
                //} 
            }
            this.fetchedAdvanceData = true;
        },

        toggleCookieConsent(cookieUid) {

            if (this.cookieConsentStatus[cookieUid] === 1) {
                this.cookieConsentStatus[cookieUid] = 0; // Uncheck
            } else {
                this.cookieConsentStatus[cookieUid] = 1; // Check
            }
        },
        checkSelectedCookies() {
            this.selectedCookies = Object.keys(this.cookieConsentStatus)
                .filter(cookieUid => this.cookieConsentStatus[cookieUid] === 1);
            this.notSelectedCookies = this.cookieData
                .filter(cookie => cookie.take_consent === 1)
                .map(cookie => cookie.cookie_uid);
        },

        saveCookiePreferences: function (acceptAll = false) {
            if (acceptAll) {
                this.selectedCookies = this.cookieData
                    .filter(cookie => cookie.take_consent === 1)
                    .map(cookie => cookie.cookie_uid);
            } else {
                this.checkSelectedCookies();
            }
            const payload = {
                cookie_uids: this.selectedCookies
            };
            CookiePreferences(payload)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        Toast.fire({
                            icon: "success",
                            text: res.data.message,
                        });
                        document.cookie = "cookieAccepted=1;path=/;";
                        $('#privacypolicy-customize').modal('hide');
                        $('#privacypolicy').modal('hide');
                    } else {
                        Toast.fire({
                            icon: "error",
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    console.log("error", err);
                });

        },

        customizepopup: function () {
            $('#privacypolicy-customize').modal('show');
        },
        acceptAllCookies: function () {
            this.saveCookiePreferences(true);
        },
        dismisspopup() {
            // this.showCookie = false;
            $('#privacypolicy').modal('hide');
        },
        acceptCookie: function () {
            document.cookie = "cookieAccepted=1;path=/;";
            this.isCookieAcptd = true;
            $('#privacypolicy').modal('hide');
        },
        deleteCookie(name) {
            //  document.cookie = name + '=; path=/;';
            document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/;';
            console.log(`Cookie "${name}" deleted.`);
        },
        get_Cookie: function (name) {
            var decodedCookie = document.cookie;
            var prefix = name + "=";
            var begin = decodedCookie.indexOf(prefix);

            if (begin == -1) {
                console.log(`Cookie "${name}" not found.`);
                return null;
            } else {
                begin += prefix.length;
                var end = decodedCookie.indexOf(";", begin);
                if (end == -1) {
                    end = decodedCookie.length;
                }
                let cookieValue = decodeURI(decodedCookie.substring(begin, end));
                console.log(`Cookie found: ${name}=${cookieValue}`);
                return cookieValue;
            }
        },
    },

    template: `<vd-component class="vd cookie-six" type="cookie-six">
    <!-- Privacy Policy Start Here-->
    
   <div id="privacypolicy" v-if="isCookieEnabled" class="modal fade privacyPolicy-modals" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-center">
    <div class="modal-content">
      <div class="modal-body mp-body">
        <!-- <div class="mp-mb-heading mp-wwText">Add Profile</div> -->
        <div class="mp-mb-profiles">
           <div class="mpmb-profile-input">
            <div class="mpmb-profinput-div">
              <span class="mpmb-profinput-lbl del-prof-lbl"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></span>
              <span class="mpmb-para mt-1 pb-1" v-html="cookieMsg"></span>
            </div>
          </div>
        </div>
        <div class="mp-mb-btn" v-if="fetchedAdvanceData">
       <div v-if="isCookieEnabled && isEnableAdvanceCookie" style="display: flex; gap: 8px;">
            <button class="mp-mb-btn-cancel w-auto" id="customize-pp" @click="customizepopup()" ><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></button>
            <button class="mp-mb-btn-done w-auto" id="acceptall-pp" @click="acceptAllCookies()"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></button>
        </div>
      <div v-else>
        <button type="button" class="btn dismiss" @click="dismisspopup()"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></button>
        <button type="button" class="btn btn-info" data-toggle="modal" @click="acceptCookie()" id="proceed"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></button>
       </div>
          
        </div>
      </div>
    </div>
  </div>
    </div>
    <!-- Privacy Policy End Here-->

     <!-- Privacy Policy Customize Start Here-->
 <div id="privacypolicy-customize" class="modal fade privacyPolicy-modals" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-center modal-lg">
    <div class="modal-content">
      <div class="modal-body mp-body">
        <!-- <div class="mp-mb-heading mp-wwText">Add Profile</div> -->
        <div class="mp-mb-profiles">
           <div class="mpmb-profile-input">
            <div class="mpmb-profinput-div">
              <span class="mpmb-profinput-lbl del-prof-lbl"><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
              <div class="mpmb-para mt-1 pb-4">
             <p>
              We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.
             </p>
             <p>
The cookies that are categorized as "Essential" are stored on your browser as they are essential for enabling the basic functionalities of the site.
</p>
<p>
We may also use third-party cookies that help us analyze how you use this website, store your preferences, and provide the content and advertisements that are relevant to you. These cookies will only be stored in your browser with your prior consent.
</p>
<p>
You can choose to enable or disable some or all of these cookies but disabling some of them may affect your browsing experience.
             </p>
            </div>
           <div v-if="cookieData.length" class="pp-toggleOptions">
            <template v-for="category in cookieData">
             <div class="ppto-childs" :key="category.cookie_uid"
             v-if="category.is_active === 1">
                <div class="pptoc-heading">{{ category.headline_text }}</div>
                <div class="pptoc-togglepara">
                  <div class="pptoctp-left">
                    {{ category.paragraph_text }}
                  </div>
                  <div class="pptoctp-right">
                    <!-- Show "Always Active" if take_consent is 0 -->
                  <span v-if="category.take_consent === 0" class="pptoctpr-badge">Always Active</span>
                   <!-- Toggle switch for other cookies with take_consent 1 -->
                    <div v-else class="form-check form-switch">
                        <input class="form-check-input ms-0" type="checkbox" role="switch"
                         :id="'fun-' + category.cookie_uid" v-model="category.take_consent" 
                          :checked="cookieConsentStatus[category.cookie_uid] === 1"
                      @change="toggleCookieConsent(category.cookie_uid)">
                   </div>
                  </div>
                </div>
              </div>
              </template>
            </div>
            </div>
          </div>
        </div>
        <div class="mp-mb-btn">
          <button class="mp-mb-btn-done w-auto" id="save-pp" @click="saveCookiePreferences()"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Privacy Policy Customize End Here-->

</vd-component>`,
    //    inheritAttrs: false
};
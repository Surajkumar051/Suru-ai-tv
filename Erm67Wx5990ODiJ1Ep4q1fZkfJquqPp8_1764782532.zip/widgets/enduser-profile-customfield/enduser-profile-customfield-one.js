//Sai
let {
  getFormSchema,
  getUserDetails,
  getEndUserRegdLoginSetting
} = await import(window.importAssetJs('js/webservices.js'));

export default {
name: 'enduser_profile_customfield_one',

data() {
  return {
      customFieldPayload:{
          "form_name":""
      },
      parsedCustomData: {},
      isCustomisedFormEnabled: false
  }
},

async mounted() {
  setTimeout(() => {
      $(".selectpicker").selectpicker();
      $(".selectpicker").selectpicker("refresh");
  }, 2000);
  let userRes = await getUserDetails();
  this.mapCustomFieldData(userRes.data.data.getUserDetails[0].custom_fields);
  this.getFormSchemaWithData();
  let regLogRes = await getEndUserRegdLoginSetting();
  if (regLogRes.data.code === 200 && regLogRes.data.data !== null) {
    const customisedForm = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[4].node_value);
    if (customisedForm == 1) {
      this.isCustomisedFormEnabled = true;
    }
  }
},

methods: {
    getFormSchemaWithData() { 
        this.customFieldPayload.form_name = "registration";
        getFormSchema(this.customFieldPayload).then(response=>{
            if (response.data.status === "SUCCESS") {
                this.formSchema = response.data.data;
                this.createCustomFormAndSetData();
            }else{
                this.formSchema = [];
            }
        });
    },

    createCustomFormAndSetData() {
        this.formSchema.forEach(schemaElement => {
          var isRequired = this.checkIsRequired(schemaElement);
          var options = this.getOptionValue(schemaElement);
            switch(schemaElement.field) {
                case 'Text Field':
                    $('#customField').append('<div class="form-group"><label class="white-color">'+schemaElement.name+'</label><input type="text" class="form-control" id="'+schemaElement.input+'" placeholder="'+schemaElement.placeholder+'"></div>');
                    $('#'+schemaElement.input).val(this.parsedCustomData[schemaElement.input])
                  break;
                case 'Text Area':
                    $('#customField').append('<div class="form-group"><label class="white-color">'+schemaElement.name+'</label><textarea class="form-control h-auto" id="'+schemaElement.input+'" placeholder="'+schemaElement.placeholder+'" rows="4" ></textarea></div>');      
                    $('#'+schemaElement.input).val(this.parsedCustomData[schemaElement.input])
                  break;
                case 'Checkbox':
                    $('#customField').append('<div class="form-group"><label class="white-color">'+schemaElement.name+'</label><div class="cf-checkboxes" id="'+schemaElement.input+'"></div></div>');
                    options.forEach(optionElement => {
                      if(this.parsedCustomData[schemaElement.input].includes(optionElement.option_value)) {
                        $('#'+schemaElement.input).append('<div class="d-flex align-items-center"><div class="checkbox-button mr-2"><input type="checkbox" id="'+optionElement.option_label+'" name="'+schemaElement.name+'" value="'+optionElement.option_value+'" checked><label for='+optionElement.option_label+' class="checkbox-label blue"></label></div><label class="cf-checkLabel" for='+optionElement.option_label+'>'+optionElement.option_label+'</label></div>');
                      } else {
                        $('#'+schemaElement.input).append('<div class="d-flex align-items-center"><div class="checkbox-button mr-2"><input type="checkbox" id="'+optionElement.option_label+'" name="'+schemaElement.name+'" value="'+optionElement.option_value+'"><label for='+optionElement.option_label+' class="checkbox-label blue"></label></div><label class="cf-checkLabel" for='+optionElement.option_label+'>'+optionElement.option_label+'</label></div>');
                      }
                    });
                break;
                case 'Radio':
                    $('#customField').append('<div class="form-group"><label class="white-color">'+schemaElement.name+'</label><ul class="cf-ul w-100" id="'+schemaElement.input+'"></ul></div>'); 
                    options.forEach(optionElement => {
                      if(this.parsedCustomData[schemaElement.input].includes(optionElement.option_value)) {
                        $('#'+schemaElement.input).append('<li class="radio-1"><input type="radio" value="'+optionElement.option_value+'" name="'+schemaElement.name+'" id="'+optionElement.option_value+'" name="radio-group" checked><label for="'+optionElement.option_value+'">'+optionElement.option_label+'</label></li>');
                      } else {
                        $('#'+schemaElement.input).append('<li class="radio-1"><input type="radio" value="'+optionElement.option_value+'" name="'+schemaElement.name+'" id="'+optionElement.option_value+'" name="radio-group"><label for="'+optionElement.option_value+'">'+optionElement.option_label+'</label></li>');
                      }
                    });
                break;
                case 'Dropdown':
                    $('#customField').append('<div class="form-group"><label class="white-color">'+schemaElement.name+'</label><select class="selectpicker form-control cf-select" id="'+schemaElement.input+'" placeholder="'+schemaElement.placeholder+'"></select></div>')
                    options.forEach(optionElement => {
                        $('#'+schemaElement.input).append('<option value="0" selected>'+optionElement.option_label+'</option>');
                    });
                break;
                case 'Date Picker':
                  break;
                default:
                  // code block
            }
        });
    },

    checkIsRequired(fieldSchema) {
        return fieldSchema.is_required == 1 ? '_required' : '';
    
    },

    getOptionValue(fieldSchema) {
         return fieldSchema.option_schemas;
    },

    mapCustomFieldData(customFields) {
        this.parsedCustomData = JSON.parse(customFields)
    },

    getCustomFieldData() {
        let jsonObject = {}; 
        this.formSchema.forEach(schemaElement => {
          if(schemaElement.field == 'Text Field' && $('#'+schemaElement.input).val() != '') {
            jsonObject[schemaElement.input] = $('#'+schemaElement.input).val();
          } else if (schemaElement.field == 'Text Area' && $('#'+schemaElement.input).val() != ''){
            jsonObject[schemaElement.input] = $('#'+schemaElement.input).val();
          } else if(schemaElement.field == 'Dropdown' && $('#'+schemaElement.input+' :selected').text() != ''){
            jsonObject[schemaElement.input] = $('#'+schemaElement.input+' :selected').text();
          } else if(schemaElement.field == 'Radio' && $("input[name='"+schemaElement.name+"']:checked").val() != '') {
            jsonObject[schemaElement.input] = $("input[name='"+schemaElement.name+"']:checked").val();
          } else if (schemaElement.field == 'Checkbox') {
            var selectedOptions = [];
            $("input[name='"+schemaElement.name+"']:checked").each(function() { 
              selectedOptions.push(this.value);
            });
            jsonObject[schemaElement.input] = selectedOptions;
          } else {
            // For date picker
          }
        });
        return JSON.stringify(jsonObject);
    },  
},

template: `
  <div id="customField" v-if="isCustomisedFormEnabled"/>
`,

};

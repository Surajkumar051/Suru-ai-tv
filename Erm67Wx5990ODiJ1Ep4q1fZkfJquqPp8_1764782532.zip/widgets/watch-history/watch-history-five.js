let {
    getWatchHistory,
    clearWatchHistory,
    getContentParentUuid,
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {default:content_purchase_two}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-two.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let uuid;
export default {
    name: "watch_history_five",
    props: {
        tab: String,
    },
    setup(props) {
        const tab = props.tab;
        return { tab };
    },
    data() {
        return {
            invoiceHtml: "",
            showplan: false,
            message: "",
            apiResponse: {},
            paymentHistory: [],
            isreason: false,
            valid: false,
            valid_card_min: true,
            valid_date: true,
            zip_min: true,
            valid_cvv_min: true,
            valid_cvv_max: true,
            show_device: "Watch_History",
            name: "",
            email: "",
            mobile: "",
            profile_image_url: "",
            watchHistory: [],
            displayImage: "",
            selectedImage: "",
            browseImgUrl: [],
            imagModel: "",
            checkpassword: true,
            noPlanMsg: "",
            file: "",
            planlist: [],
            ActivePlan: false,
            cancelReasons: [],
            user: "",
            cancelId: "",
            canceldMsg: "Cancel Plan",
            expiryplnMsg: "Valid till:",
            allDevices: [],
            user_uuid: JSON.parse(localStorage.getItem("user")),
            device_type: "",
            allDevices: [],
            noDevice: false,
            cardList: [],
            cardInfo: 0,
            deleteFlag: false,
            allContentDetail: [],
            contentUuid: "",
            videoDuration: "",
            audioDuration: "",
            nodatafound: false,
            cardform: [],
            errMessage: "",
            deletecarduuid: uuid,
            isAudioPlay: false,
            form_data: {
                card_name: "",
                card_number: "",
                card_expiry: "",
                card_cvv: "",
                address1: "",
                address2: "",
                city: "",
                state: "",
                country: "",
                zip: "",
            },
            cropperData: null,
            isShowcropImage: false,
            myPlan: [],
            subscriptionEnabled: Boolean,
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2,
            },
            enduserData: null,
            name_field: false,
            password: "",
            newPassword: "",
            confirmpassword: "",
            errors: {},
            endUserDetails: JSON.parse(localStorage.getItem("user")),
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            pswsnewFieldNotValidate: false,
            isFormValid: false,
            enduserURL: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isButtonShow: false,
            showDeleteModal: false,
            pageNo: 1,
            onScroll: false,
            isNextPageCallReqd: true,
            isWatchHistory: false,
            isloggedin: localStorage.getItem('isloggedin'),
            
        };
    },
    components: {
        audio_player_one,
        content_purchase_two,
    },
    beforeCreate() {},
    created() {
        let url = window.location.href;
        let spitUrl = url.split("/");
        this.enduserURL = spitUrl[0] + "//" + spitUrl[2];
    },
    beforeMount() {
        // if (notLoggedinUser()) {
        //     //window.location.href = "/";
        // }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        if (this.show_device == this.tab) {
            // JsLoadingOverlay.show();
        }
        if(this.isloggedin === 'true') {
            this.showWatchHistory(this.pageNo);
        }
        
    },
    methods: {
        i18n,
        async showWatchHistory(pageNo) {
            this.isNextPageCallReqd = false;
            let overlay = document.getElementById("overlay");
            let spinner = document.getElementById("spinner");
            if (spinner == null && overlay == null) {
                // JsLoadingOverlay.show();
            }
            let res = await getWatchHistory(pageNo);
            if (
                !this.onScroll &&
                res.data.code === 200 &&
                res.data.status === "SUCCESS"
            ) {
                this.watchHistory =
                    res.data.data.mediaPlayedHistory.content_list;
            } else if (
                this.onScroll &&
                res.data.code === 200 &&
                res.data.status === "SUCCESS" &&
                res.data.data.mediaPlayedHistory.content_list
            ) {
                this.watchHistory.push(
                    ...res.data.data.mediaPlayedHistory.content_list
                );
            }
            if (
                res.data.code == 200 &&
                this.watchHistory?.length <
                    res.data.data.mediaPlayedHistory.page_info.total_count
            ) {
                this.isNextPageCallReqd = true;
            }
            //BUTTON SHOW
            this.isButtonShow = this.watchHistory == null ? false : true;
            this.isWatchHistory = this.watchHistory == null ? false : true;
            // JsLoadingOverlay.hide();
            this.showDeleteModal == true
                ? $("#deleteConfirmModal").modal("show")
                : "";
            //LOAD MORE CONTENT ON LAZY LOADING
            this.loadMore();
        },
        loadMore() {
            window.onscroll = () => {
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                if (bottomOfWindow && this.isNextPageCallReqd == true && scrollLoad) {
                    this.pageNo++;
                    this.onScroll = true;
                    this.showWatchHistory(this.pageNo);
                }
            };
        },
        async redirect(data) {
            if (data.content_asset_type == 1) {
                window.location.href = "/player/" + data.content_permalink;
                return;
            } else {
                this.contentUuid = data.content_uuid;
                this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                this.isAudioPlay = true;
            }
        },
        async clearHistory() {
            $("#deleteWatchHistoryModal").modal("hide");
            // JsLoadingOverlay.show();
            let response = await clearWatchHistory();
            if (response.data.code == 200) {
                setTimeout(() => {
                    $("#deleteConfirmModal").modal("hide");
                }, 3000);
                this.onScroll = false;
                this.showDeleteModal = true;
                this.pageNo = 1;
                this.showWatchHistory(this.pageNo);
            } else {
                Toast.fire({
                    icon: "error",
                    title: "Error",
                    text: res.data.message,
                });
            }
        },
        redirectToDetails(url) {
            window.location.href = url;
        }, 
    },
    template: `<vd-component class="vd watch-history-five d-none" type="watch-history-five">  
    <div class="courses-area border-bottom category-slider-area overflow-hidden" v-if="isWatchHistory && watchHistory.length>0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading mb-0">
                    <h2>
                        <span class="text-blue">
                            <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                        </span> 
                        <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                    </h2>
                    </div>
                </div>
            </div>
            <div class="row slider-active vd-no-navigation">
                <div class="col-lg-2 col-md-6 col-sm-6" v-for="data in watchHistory" v-if="isWatchHistory">
                    <div class="single-topic-box"> 
                    <div class="topic-preview">
                        <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" class="img-fluid"  />
                        <img loading="lazy" v-if="data.posters.website === null"  :src="$attrs['root_url']+'img/no_img_available.png'" alt="No Image" class="img-fluid"  />
                 
                    </div>
                    <div class="topic-overlay">
                        <div class="topic-details d-none">
                            <span class="d-none">$400.00</span>
                            <p>{{data.content_name}}</p>
                            <span class="rating">
                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                </svg>
                                4.5
                            </span>
                        </div>
                        <!-- Hover Text Start -->
                        
                        <div class="hover-details col-12">
                            <div class="row justify-content-end gx-0 h-100">
                                <div class="col-12  align-self-start">
                                    <span class="d-block text-end wishlist d-none">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                                        </svg>
                                    </span>
                                    <p v-if="data.content_name">{{data.content_name}}</p>
                                </div>
                                <div class="col-12 align-self-end px-0">
                                    <div class="row gx-0 justify-content-between">
                                        <div class="col-auto">
                                            <div class="badge">
                                                {{contentTitle}}
                                            </div>
                                        </div>
                                        <div v-if="data.cast_details" class="col-auto" v-for="(cast,j) in data.cast_details" :key="j">
                                            <span class="author">{{cast.cast_name}}</span>
                                        </div>
                                    </div>
                                    <div class="row gx-0">
                                        <div class="col-12">
                                            <div class="course-info" v-if="data.content_desc">
                                                 {{data.content_desc.substring(0, 120)}}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row gx-0 justify-content-between align-items-center">
                                        <div class="col-auto">
                                            <span class="price d-none">$350.00</span>
                                        </div>
                                        <div class="col-auto d-none">
                                            <button class="buy-btn">Buy Now</button>
                                        </div>
                                       
                                    </div>
                                    <div class="row gx-0 justify-content-between align-items-center mt-3">
                                        <div class="col-auto d-none">
                                            <span class="rating">
                                                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                </svg>
                                                4.5
                                            </span>
                                        </div>
                                        <div class="col-auto">
                                      
                 
                                            <a :href="'/content/'+data.content_permalink" class="details-btn callByAjax">
                                                View Detail
                                                <div class="svg">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                                    </svg>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Hover Text End -->
                    </div>
                 </div>
                    </div>








            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-3 d-none" v-for="data in watchHistory" v-if="isWatchHistory">
         
            <a class="callByAjax" :href="'/content/'+data.content_permalink" >
            <div class="col-md-12">
                <div class="wishlist-area no-slide overflow-hidden pb-0">
                        <div class="">
                            <div class="">
                                <div class="single-wishlist">
                                <div class="image-preview">
                                    <img v-if="data.posters.website !== null" :src="data.posters.website[0].file_url"
                        :alt="data.content_name" class="img-fluid">
                        <img v-if="data.posters.website === null"
                        :src="$attrs['root_url']+'img/no_img_available.png'" alt="No Image"
                            class="img-fluid">
                                    </div>
                                    <div class="whitelist-overlay">
                                        <div class="row justify-content-end gx-0 h-100">
                                            <div class="col-6 align-self-start">
                                                <span class="d-block text-end d-none">
                                                    <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M7.94668e-08 5.39995C-0.000248434 3.95029 0.582385 2.5614 1.61681 1.54578C2.65124 0.530159 4.05058 -0.026895 5.5 -4.93311e-05C7.21732 -0.00916934 8.85599 0.719125 10 1.99995C11.144 0.719125 12.7827 -0.00916934 14.5 -4.93311e-05C15.9494 -0.026895 17.3488 0.530159 18.3832 1.54578C19.4176 2.5614 20.0002 3.95029 20 5.39995C20 10.756 13.621 14.8 10 18C6.387 14.773 7.94668e-08 10.76 7.94668e-08 5.39995Z" fill="white"/>
                                                    </svg>                                                
                                                </span>
                                            </div>
                                            <div class="col-12 align-self-end px-0">
                                                <div class="row gx-0 justify-content-between align-items-center">
                                                    <div class="col-12">
                                                        <span class="price d-none">$400.00</span>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="course-info">
                                                            {{data.content_name}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row gx-0 justify-content-between align-items-center d-none">
                                                    <div class="col-auto">
                                                        <span class="rating">
                                                            <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"></path>
                                                            </svg>
                                                            4.5
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
            </div>
            
    </div>

    <audio_player_one :contentUuid="contentUuid" v-if="isAudioPlay" :key="resetAudioPlayer" />
       
</vd-component>`,
};

let {
    courseProgress,
    getContentParentUuid,
    getParentCouseDetails,
    getPlayerParentPermarlinkDetails,
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { default: audio_player_one } = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let uuid;
export default {
    name: "watch_history_four",
    data() {
        return {
            course_progress: [],
            isloggedin: localStorage.getItem('isloggedin'),
            CouseDetails: [],
            updateslider: 0

        };
    },
    components: {
        audio_player_one,
    },
    beforeCreate() { },
    created() {
        let url = window.location.href;
        let spitUrl = url.split("/");
        this.enduserURL = spitUrl[0] + "//" + spitUrl[2];
    },
    mounted() {
        if (localStorage.getItem('isloggedin') == 'true') {
            this.courseProgress();
        }
    },
    updated() {
        if(this.course_progress.length > 0) {
            this.updateslider++;
            if(this.updateslider > 1) {
                $(".slider-active1").slick('destroy');
            }
            $('.slider-active1').slick({
                dots: true,
                infinite: false,
                arrows:true,
                autoplay:false,
                speed: 300,
                slidesToShow: 5,
                accessibility: true,
                prevArrow: '<button class="slide-arrow prev-arrow"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
                nextArrow: '<button class="slide-arrow next-arrow"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>',
                responsive: [
                    {
                    breakpoint: 1280,
                    settings: {
                        slidesToShow: 3.5,
                        variableWidth: true,
                    }
                    },
                    {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2.5,
                        variableWidth: true,
                        adaptiveHeight: true,
                    }
                    },
                    {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1.4,
                        variableWidth: false,
                        adaptiveHeight: true,
                        accessibility: true,
                    }
                    }
                ]
            });
        }
    },
    methods: {
        i18n,
        async courseProgress() {
            let res = await courseProgress();
            if (res.data.code == 200) {
                this.course_progress = res.data.data;
            }
            if (this.course_progress.length > 0) {
                var CouseDetails = await getParentCouseDetails(
                    this.course_progress[0]?.content_uuid
                );
                if (CouseDetails.data.code == 200) {
                    this.CouseDetails = CouseDetails.data.data;
                }
            }

        },
        async redirect(data) {
            if (data.content_asset_type == 1) {
                window.location.href = "/player/" + data.content_permalink;
                return;
            } else {
                this.contentUuid = data.content_uuid;
                this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                this.isAudioPlay = true;
            }
        },
        redirectToDetails(url) {
            window.location.href = url;
        },
    },
    template: `<vd-component class="vd watch-history-four" type="watch-history-four" v-if="isloggedin">
    <audio_player_one :contentUuid="contentUuid" v-if="isAudioPlay" :key="resetAudioPlayer" />  
   
    <div class="banner-area user-banner border-bottom overflow-hidden border-bottom" v-if="course_progress.length>0">
        <div class="container">

            <div class="row" v-if="course_progress">
                <div class="col-lg-5">
                    <div class="section-heading">
                        <h2>
                        You left 
                        <span class="text-blue fst-normal"> {{course_progress[0].content_name}} </span> 
                         here
                        </h2>
                    </div>
                    <p>{{course_progress[0].content_desc.substring(0, 120)}}</p>
                    
                    <ul>
                        <li class="">
                            <span v-html="i18n($attrs['label4'])"></span>
                            {{course_progress[0].total_lesson - course_progress[0].complete_lessons}} / {{course_progress[0].total_lesson}}
                        </li>
                        <li>
                            <span v-html="i18n($attrs['label7'])"></span>
                            {{ course_progress[0].percentage}}% <text v-html="i18n($attrs['label10'])"></text>
                        </li>
                        <li v-if="CouseDetails?.totalQuizRemain && CouseDetails?.totalQuizRemain.length > 0">
                        <span v-if="CouseDetails?.totalQuizRemain.length == 1" v-html="i18n($attrs['label6'])"></span>
                        <span v-else v-html="i18n($attrs['label5'])"></span>
                            {{CouseDetails.totalQuiz - CouseDetails.passedquiz.length}} /  {{CouseDetails.totalQuiz}}
                        </li>
                    </ul>
                    <a style="cursor: pointer;" class="btn-border"  @click='redirect(course_progress[0])'><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
                </div>
                <div class="col-lg-7">
                    <div class="video-wrap" >
                        <a class="callByAjax" href="javascript:void(0)" @click='redirect(course_progress[0])'>
                        <img v-if="course_progress[0].banners.website !== null" :src="course_progress[0].banners.website[0].file_url"
                            :alt="course_progress[0].content_name" class="img-fluid mw-100">
                        <img v-if="course_progress[0].banners.website === null"
                            src="https://muvi-assets.s3.amazonaws.com/no_image_available.png" alt="No Image"
                            class="mw-100">
                        </a>
                    </div>

                </div>

                



            </div>
        </div>
    </div>

    <div class="courses-area border-bottom category-slider-area overflow-hidden" v-if="course_progress.length > 0">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-heading">
                <h2><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h2>
                </div>
            </div>
        </div>
        <div class="row slider-active1">
            <div class="col-md" v-for="course in course_progress">
                <div class="single-topic-box">
                    <div class="topic-preview">
                        <img v-if="course?.posters?.website !== null" :src="course?.posters?.website[0]?.file_url" class="img-fluid" alt="">
                        <img v-if="course?.posters?.website == null" :src="course?.no_image_available_url" class="img-fluid" alt="">
                    </div>
                    <div class="topic-overlay">
                        <div class="topic-details">
                        <!--<span>$300.00</span> -->
                            <p>{{course.content_name}}</p>
                            <span class="rating">
                                <svg v-if="parseInt(course.avg_rating) >0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                </svg>
                                {{course.avg_rating}}

                                <svg v-if="parseInt(course.avg_rating)<=0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                </svg>
                            </span> 
                        </div>
                        <!-- Hover Text Start -->
                        <div class="hover-details col-12">
                            <div class="row justify-content-end gx-0 h-100">
                                <div class="col-12  align-self-start">
                                    <div class="completion">
                                    Completion: {{course.complete_lessons}}/{{course.total_lesson}} Session
                                         
                                    </div>
                                </div>
                                <div class="col-12 align-self-end px-0">
                                     <div class="row gx-0 justify-content-between">
                                        <div class="co-12">
                                            <p>{{course.content_name}}</p>
                                        </div>
                                        <div class="col-auto" v-if="course.categories.category_name">
                                            <div class="badge" v-for="cat in course.categories">
                                                {{cat.category_name}}
                                            </div>
                                        </div>
                                        <div v-if="course.cast_details" class="col-auto" v-for="(cast,j) in course.cast_details" :key="j">
                                            <span class="author">{{cast.cast_name}}</span>
                                        </div>
                                    </div>
                                    <div class="row gx-0">
                                        <div class="col-12">
                                            <div class="course-info">
                                            {{course.content_desc.substring(0, 120)}}...
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row gx-0 justify-content-between align-items-center">
                                        <div class="col-auto">
                                        <!-- <span class="price">$350.00</span>-->
                                        </div>
                                    </div>
                                    <div class="row gx-0 justify-content-between align-items-center mt-3">
                                        <div class="col-auto">
                                            <span class="rating">
                                                <svg v-if="parseInt(course.avg_rating) >0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                </svg>
                                                {{course.avg_rating}}

                                                <svg v-if="parseInt(course.avg_rating)<=0" width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                                </svg>
                                            </span> 
                                        </div>
                                        <div class="col-auto">
                                            <a :href="'/content/'+course.content_permalink" class="details-btn">
                                                View Detail
                                                <div class="svg">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z"
                                                            fill="white" />
                                                    </svg>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Hover Text End -->
                    </div>
                    <!-- Progress -->
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" :style="'width:'+course.percentage+'%'" :aria-valuenow="course.percentage"
                                aria-valuemin="0" :aria-valuemax="course.percentage"></div>
                        </div>

                        <!-- Progress -->
                    </div>
                </div>

            </div>
        </div>
    </div>

       
</vd-component>`,
};

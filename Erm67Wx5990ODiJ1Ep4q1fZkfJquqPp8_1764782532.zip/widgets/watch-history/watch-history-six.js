let { getWatchHistory, clearWatchHistory, getContentParentUuid } = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {default:content_purchase_four}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-four.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

let uuid;
export default {
    name: "watch_history_six",
    props: {
        tab: String,
    },
    setup(props) {
        const tab = props.tab;
        return { tab };
    },
    data() {
        return {
            rootUrl: getRootUrl(),
            invoiceHtml: "",
            showplan: false,
            message: "",
            apiResponse: {},
            paymentHistory: [],
            isreason: false,
            valid: false,
            valid_card_min: true,
            valid_date: true,
            zip_min: true,
            valid_cvv_min: true,
            valid_cvv_max: true,
            show_device: "Watch_History",
            name: "",
            email: "",
            mobile: "",
            profile_image_url: "",
            watchHistory: [],
            displayImage: "",
            selectedImage: "",
            browseImgUrl: [],
            imagModel: "",
            checkpassword: true,
            noPlanMsg: "",
            file: "",
            planlist: [],
            ActivePlan: false,
            cancelReasons: [],
            user: "",
            cancelId: "",
            canceldMsg: "Cancel Plan",
            expiryplnMsg: "Valid till:",
            allDevices: [],
            user_uuid: JSON.parse(localStorage.getItem("user")),
            device_type: "",
            allDevices: [],
            noDevice: false,
            cardList: [],
            cardInfo: 0,
            deleteFlag: false,
            allContentDetail: [],
            contentUuid: "",
            videoDuration: "",
            audioDuration: "",
            nodatafound: false,
            cardform: [],
            errMessage: "",
            deletecarduuid: uuid,
            isAudioPlay: false,
            form_data: {
                card_name: "",
                card_number: "",
                card_expiry: "",
                card_cvv: "",
                address1: "",
                address2: "",
                city: "",
                state: "",
                country: "",
                zip: "",
            },
            cropperData: null,
            isShowcropImage: false,
            myPlan: [],
            subscriptionEnabled: Boolean,
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2,
            },
            enduserData: null,
            name_field: false,
            password: "",
            newPassword: "",
            confirmpassword: "",
            errors: {},
            endUserDetails: JSON.parse(localStorage.getItem("user")),
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            pswsnewFieldNotValidate: false,
            isFormValid: false,
            enduserURL: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isButtonShow: false,
            showDeleteModal: false,
            pageNo: 1,
            onScroll: false,
            isNextPageCallReqd: true,
            isWatchHistory: true,
            tempContentId: "",
        };
    },
    components: {
        audio_player_one,
        content_purchase_four
    },
    beforeCreate() { },
    created() {
        let url = window.location.href;
        let spitUrl = url.split("/");
        this.enduserURL = spitUrl[0] + "//" + spitUrl[2];
    },
    beforeMount() {
        if(notLoggedinUser()){
            window.location.href = "/";
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        if (this.show_device == this.tab) {
            JsLoader.show();
        }
        this.showWatchHistory(this.pageNo);
    },
    unmounted() {
        // window.removeEventListener('scroll', null);
    },
    methods: {
        i18n,
        async showWatchHistory(pageNo) {
            this.isNextPageCallReqd = false;
            let overlay = document.getElementById('overlay');
            let spinner = document.getElementById('spinner');
            if (spinner == null && overlay == null) {
                JsLoader.show();
            }
            let res = await getWatchHistory(pageNo);
            if (!this.onScroll && res.data.code === 200 && res.data.status === "SUCCESS") {
                this.watchHistory = res.data.data.mediaPlayedHistory.content_list;
            } else if (this.onScroll && res.data.code === 200 && res.data.status === "SUCCESS" && res.data.data.mediaPlayedHistory.content_list) {
                this.watchHistory.push(...res.data.data.mediaPlayedHistory.content_list);
            }
            if (res.data.code == 200 && this.watchHistory?.length < res.data.data.mediaPlayedHistory.page_info.total_count) {
                this.isNextPageCallReqd = true;
            }
            //BUTTON SHOW
            this.isButtonShow = this.watchHistory == null ? false : true;
            this.isWatchHistory = this.watchHistory == null || this.watchHistory.length == 0 ? false : true;
            
            if(document.getElementById('spinner')) {
                document.getElementById('spinner').remove();
            }
            if(document.getElementById('overlay')) {
                document.getElementById('overlay').remove();
            }
            
            this.showDeleteModal == true ? $('#deleteConfirmModal').modal('show') : '';
            //LOAD MORE CONTENT ON LAZY LOADING
            this.loadMore();
        },
        loadMore() {
            window.onscroll = () => {
                let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight + 20 >= document.documentElement.scrollHeight;
                if (bottomOfWindow && this.isNextPageCallReqd == true && scrollLoad) {
                    this.pageNo++;
                    this.onScroll = true;
                    this.showWatchHistory(this.pageNo);
                }
            }
        },
        async redirect(data) {
            if (data.content_asset_type == 1) {
                window.location.href = "/player/" + data.content_permalink;
                return;
            } else {
                this.contentUuid = data.content_uuid;
                this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                this.isAudioPlay = true;
            }
        },
        async clearHistory(tempContentId = '') {
            this.tempContentId = tempContentId;
            jQuery(this.$refs.watch_modal_el).modal('hide');
            JsLoader.show();
            let response = await clearWatchHistory({ tempContentId: this.tempContentId });
            if (response.data.code == 200) {
                setTimeout(() => {
                    $('#deleteConfirmModal').modal('hide');
                }, 3000);
                this.onScroll = false;
                this.showDeleteModal = true;
                this.pageNo = 1;
                this.showWatchHistory(this.pageNo);
            } else {
                Toast.fire({ icon: "error", title: "Error", text: res.data.message });
            }
        },
        redirectToDetails(url) {
            window.location.href = url;
        },
        openWatchModal(tempContentId = '') {
            //this.tempContentId = tempContentId;
            jQuery(this.$refs.watch_modal_el).modal('show')
        },
        reloadComponentAudio(content_detail){
            this.contentUuid = content_detail.content_uuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        getShortTitle(text) {
            return text.length > 50 ? text.substring(0, 50) + "..." : text;
        },
    },
    template: /*html*/ `<vd-component class="vd watch-history-six" type="watch-history-six">
       <content_purchase_four
            id="$attrs['id'] +'_content_purchase_four_4'"
        />
        <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :contentUuid="contentUuid" v-if="isAudioPlay" :key="resetAudioPlayer" @reloadComponentAudio="reloadComponentAudio" />
        <!--dashboard tiles Start Here-->
        <div class="dashboard-tiles black-bg">
            <!--Title start here-->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <h1 class="dashboard-heading white-color mbottom-20"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                   <div v-if="watchHistory.length>0">
                        <button class="my-WH-CMH-btn wh-hover" @click="openWatchModal()">
                            <i class="fa fa-trash-alt"></i>{{i18n("Clear Watch History")}}
                        </button>
                    </div>
                </h1>
            </div>
        </div>
        <!--Title End here-->

            <!--Watch History start Here-->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <!--Loop File Start Here-->
                    <div class="watch-history" v-for="data in watchHistory" v-if="watchHistory.length > 0 && isWatchHistory">
                        <div class="picture">
                        
                            <a class="callByAjax" href="javascript:void(0)" @click='redirect(data)'>
                                    <img v-if="data.posters.website !== null" :src="data.posters.website[0].file_url" :alt="data.content_name" class="mw-100">
                                    <img v-if="data.posters.website === null" :src="rootUrl+'img/wh-img.png'" alt="No Image" class="mw-100">
                            </a>
                        </div>
                        <div class="data">
                            <div class="d-flex align-items-start justify-content-between">
                                <div>
                                    <h2>
                                        <a v-if="data.content_epg_details !== undefined && data.content_epg_details !== null && (data.content_epg_details.epg_url_xml !== null || data.content_epg_details.epg_url_json !== null)" class="wh-data-a callByAjax" v-bind:href="'/epg-display-details/'+data.content_permalink">{{getShortTitle(data.content_name)}}</a>
                                    <a v-if="(data.content_epg_details === undefined || (data.content_epg_details !== undefined && data.content_epg_details === null))" class="wh-data-a callByAjax" v-bind:href="'/content/'+data.content_permalink">{{getShortTitle(data.content_name)}}</a>
                                    </h2>
                                </div>
                                <div class="singleDlt-icon">
                                    <i class="fa fa-trash-alt" v-if="isButtonShow" @click="clearHistory(data.content_uuid)"></i>
                                </div>
                            </div>
                            <p>{{data.content_desc}}</p>
                        </div>
                    </div>

                <!--Loop File End Here-->
                <section class="no-result-found" v-if="watchHistory.length == 0 && !isWatchHistory">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <div class="w-100 text-center">
                                    <img :src="rootUrl+'img/no-result.gif'" alt="no result"
                                        class="mw-100" />
                                    <h2 v-if="watchHistory.length == 0">
                                        <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <!--Watch History End Here-->
    <!--Make your Card delete page start Here-->
    <div class="modal fade delete-massage" ref="watch_modal_el" tabindex="-1" role="dialog" 
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body mt-2">
                    <div class="d-flex align-items-start">
                        <section class="body-section">
                            <div class="title">{{i18n("Clear Watch History?")}}</div>
                            <p class="form-text mb-0 mt-2 pe-2">{{i18n("Your watch history will be cleared from your account forever. To confirm the action, please proceed.")}}</p>
                        </section>
                        <!--<div class="svg wh-24 reset mr-3">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23Z"
                                    fill="#118BA6"></path>
                                <path d="M12 7V13" stroke="#F2F2F2" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round"></path>
                                <path d="M12 17H12.01" stroke="#F2F2F2" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round"></path>
                            </svg>
                        </div>
                        <section>
                            <div class="title">{{i18n("Clear Watch History?")}}</div>
                            <p class="form-text mb-0 mt-2 pe-2">{{i18n("Your watch history will be cleared from your account forever. To confirm the action, please proceed.")}}</p>
                        </section>-->
                    </div>
                </div>
                <div class="modal-footer no-border">
                    <button type="button" class="btn dismiss" data-dismiss="modal">{{i18n("Dismiss")}}</button>
                    <button @click="clearHistory()" type="button" class="btn btnProceed">{{i18n("Proceed")}}</button>
                </div>
            </div>
        </div>
    </div>
    <!--Make your Card delete page End Here-->
    <!--Delete Confirmation page start Here-->
    <div class="modal fade update-model" id="deleteConfirmModal" tabindex="-1" role="dialog"
        aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="modal-data">
                        <svg width="106" height="106" viewBox="0 0 106 106" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <circle cx="53" cy="53" r="51.5" stroke="#363F38" stroke-width="3" />
                            <path d="M29 53L47 71L77 35" stroke="#9ECC8E" stroke-width="4" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        <h2>{{i18n("Deleted")}}</h2>
                        <p v-if="tempContentId">{{i18n("Successfully removed the content from watch history.")}}</p>
                        <p v-else>{{i18n("Watch history cleared successfully.")}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Delete Confirmation page End Here-->
</vd-component>`,
};

// let {
//     getVdConfig
// } = await import(window.importAssetJs('js/webservices.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
const { mapState} = Vuex;

export default {
    name: "coming_soon_one",

    data() {
        return {
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: false,
        }
    },
    methods: {
        i18n,
        getRootUrl
       
    },
    mounted() {
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             //this.logo = res.data.data;
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    computed: {
        ...mapState({
            logo_details: (state) => state.logo_details,
          })
    },
    template: /*html*/
    `<vd-component class="vd coming-soon-one" type="coming-soon-one">        
        <section class="header header-wrapper coming-soon-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a v-if="logo_details['logo']"  class="navbar-brand logo noheader-logo callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                                                :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                            <a v-else-if="logo_details['logo']!=false" class="navbar-brand logo noheader-logo callByAjax" href="/"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'"
                                                    alt="Phoenix" /></a> 
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!--Header Section End Here--> 
        <!--Coming soon Start Here-->
        <section class="coming-soon pb-100">
            <div class="inside-content">
                <div class="cs-heading">
                    <h1 class="cs-h1 pb-8 m-0"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h1>
                    <p class="cs-para mb-40 pb-0 fw-400"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p> 
                </div>             
                <section class="social-copyright copyright">
                    <div class="container-fluid">
                        <div class="row gap-24">
                            <div class="col-12">
                                <ul vd-node="socialIcon" id="socialIcon-1" vd-readonly="true">
                                    <li><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></li>
                                    <li><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></li>
                                    <li><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></li>
                                    <li><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></li>
                                </ul>
                            </div>
                            <div class="col-12">
                                <p><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>	
        </section>
</vd-component>`,
};

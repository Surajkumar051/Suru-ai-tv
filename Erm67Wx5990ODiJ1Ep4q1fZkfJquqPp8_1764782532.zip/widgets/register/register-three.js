let {
    registerUser,
    getUserDetails,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    getEndUserRegdLoginSetting,
    // getVdConfig,
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let {
    getRootUrl,
    getAsthuDomainUrl,
} = await import(window.importAssetJs('js/web-service-url.js'));
let {
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies,
    setCookie
} = await import(window.importAssetJs('js/main.js'));

const { mapState} = Vuex;

export default {
    name: 'register_three',

    data() {
        return {
            input: {
                first_name: '',
                last_name: '',
                user_email: '',
                password: '',
                confpassword: '',
                username: ''

            },
            errors: {},
            selTypeIndex: '',
            isFormValid: false,
            emailFieldNotValidate: false,
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            nameFiledNotValidate: false,
            lastnameFiledNotValidate: false,
            showPassword: false,
            showConfPassword: false,
            logo_src: '',
            logo_alt: '',
            logo_style: '',
            isLogoUpdated: Boolean,
            countryCode: 'US',
            enableMultiProfile: 0
        };
    },
   computed: {
        username() {
            this.input.username = this.input.first_name;
            return this.input.username;
        },
        last_name() {
            return this.input.last_name;
        },
        user_email() {
            return this.input.user_email;
        },
        password() {
            return this.input.password;
        },
        confirmPassword() {
            return this.input.confpassword;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
        })
    },
    watch: {
        username(value) {
            $('#regdFormButton').css('pointer-events','');
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = "First name field is required";
                this.nameFiledNotValidate = true;
            } else if (value.length < 1 || value.length > 25) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = "First name should be between 1 and 25 charaters.";
                this.nameFiledNotValidate = true;
            } else {
                this.errors.username = null;
                this.nameFiledNotValidate = false;
                if ((this.errors.username !== undefined && this.errors.username == null) &&
                    (this.errors.user_email !== undefined && this.errors.user_email == null) &&
                    (this.errors.password !== undefined && this.errors.password == null) &&
                    (this.errors.confpassword !== undefined && this.errors.confpassword == null) && this.input.selTypeIndex != '') {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        last_name(value) {
            $('#regdFormButton').css('pointer-events','');
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = "This field is required";
                this.lastnameFiledNotValidate = true;
                this.errors.username = null;
            } else if (value.length < 1 || value.length > 25) {
                this.errors.valid = false;
                this.isFormValid = false;
                // this.errors.username = null;
                this.errors.last_name = "Last name should be between 1 and 25 charaters.";
                this.lastnameFiledNotValidate = true;

            } else {
                this.errors.last_name = null;
                this.lastnameFiledNotValidate = false;
                if ((this.errors.last_name !== undefined && this.errors.last_name == null) &&
                    (this.errors.user_email !== undefined && this.errors.user_email == null) &&
                    (this.errors.password !== undefined && this.errors.password == null) &&
                    (this.errors.confpassword !== undefined && this.errors.confpassword == null) && this.input.selTypeIndex != '') {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        user_email(value) {
            $('#regdFormButton').css('pointer-events','');
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = "Email field is required";
                this.emailFieldNotValidate = true;
            } else if (!value.match(/^(?=.{1,64}@)[^@]+@([^@]{2,})+\.([^@.]{2,14})$/)) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = "Please enter a valid email";
                this.emailFieldNotValidate = true;
            } else {
                this.errors.user_email = null;
                this.emailFieldNotValidate = false;
                if ((this.errors.username !== undefined && this.errors.username == null) &&
                    (this.errors.user_email !== undefined && this.errors.user_email == null) &&
                    (this.errors.password !== undefined && this.errors.password == null) &&
                    (this.errors.confpassword !== undefined && this.errors.confpassword == null) && this.input.selTypeIndex != '') {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        password(value) {
            $('#regdFormButton').css('pointer-events','');
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = "Password field is required";
                this.passwordFieldNotValidate = true;
            } else if (value.length < 8) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = "Password should be more than 8 characters long.";
                this.passwordFieldNotValidate = true;
            } else if (value === this.input.confpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = null;
                this.passwordFieldNotValidate = true;
                this.errors.confpassword = null;
            } else {
                this.errors.password = null;
                this.passwordFieldNotValidate = false;
                if (value !== this.input.confpassword) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.confpassword = "Passwords do not match";
                    this.confirmPwdFieldNotValidate = true;
                }
                if (
                    (this.errors.username !== undefined && this.errors.username == null) &&
                    (this.errors.user_email !== undefined && this.errors.user_email == null) &&
                    (this.errors.password !== undefined && this.errors.password == null) &&
                    (this.errors.confpassword !== undefined && this.errors.confpassword == null) &&
                    this.input.selTypeIndex != '') {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }

            }
        },
        confirmPassword(value) {
            $('#regdFormButton').css('pointer-events','');
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = "Confirm Password field is required";
                this.confirmPwdFieldNotValidate = true;
            } else if (value !== this.input.password) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = "Passwords do not match";
                this.confirmPwdFieldNotValidate = true;
            } else {
                this.errors.confpassword = null;
                this.confirmPwdFieldNotValidate = false;
                if (
                    (this.errors.username !== undefined && this.errors.username == null) &&
                    (this.errors.user_email !== undefined && this.errors.user_email == null) &&
                    (this.errors.password !== undefined && this.errors.password == null) &&
                    (this.errors.confpassword !== undefined && this.errors.confpassword == null) &&
                    this.input.selTypeIndex != '') {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        }

    },
    beforeMount() {
        JsLoadingOverlay.show();
        getEndUserRegdLoginSetting().then((res) => {
            if (res.data.code == 200 && res.data.data !== null) {
                const requireRegistrationAndLogin = parseInt(res.data.data.sections[0].groups[0].nodes[0].node_value);
                this.enableMultiProfile = parseInt(
                    res.data.data.sections[0].groups[0].nodes[2].node_value
                );
                if (requireRegistrationAndLogin != 1) {
                    window.location.href = "/";
                }

            }
        });
    },

    async mounted() {

        JsLoadingOverlay.hide();
        let userGeoLocation = getUserGeoLocationFromCookies();
        if (!userGeoLocation) {
            await setUserGeoLocationOnCookies();
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        } else {
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        }
        this.countryCode = userGeoLocation.country_code;

        let isloggedIn = localStorage.getItem('isloggedin');
        if (isloggedIn) {
            window.location.href = "/home";
        }
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    methods: {
        getRootUrl,
        i18n,
        getAsthuDomainUrl,
        myPlanDetails() {
            getSubscriptionPlans(this.countryCode).then((res) => {
                if (res.data.code == 600 || res.data.status === "FAILED") {
                    window.location.href = "/home";
                } else if (res.data.code == 200 && res.data.status === "SUCCESS") {
                    getEndUserRegdLoginSetting().then((res) => {
                        if (res.data.code == 200 && res.data.data !== null) {
                            this.userConfig = res.data.data.sections[0].groups[0].nodes[1].node_value;
                            console.log("userConfig", this.userConfig);
                            window.location.href = "/all-plan";
                        }
                    });
                }
            });
        },
        submitRegisterForm() {
            $('#regdFormButton').css('pointer-events', 'none');
            if (!this.input.first_name.length && !this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = "Fullname field is required";
                this.nameFiledNotValidate = true;
                return;
            } else if (this.input.first_name.length < 1 || this.input.first_name.length > 25) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username =
                i18n("First name should be between 1 and 25 charaters.");
                this.nameFiledNotValidate = true;
                return;
            } else {
                this.errors.username = null;
                this.nameFiledNotValidate = false;
            }

            if (!this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = "Last name field is required";
                this.lastnameFiledNotValidate = true;
                return;
            } else if (this.input.last_name.length < 1 || this.input.last_name.length > 25) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name =
                i18n("Last name should be between 1 and 25 charaters.");
                this.lastnameFiledNotValidate = true;
                return;
            } else {
                this.errors.last_name = null;
                this.lastnameFiledNotValidate = false;
            }

            if (!this.input.user_email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = "Email field is required";
                this.emailFieldNotValidate = true;
                return;
            } else {
                this.errors.user_email = null;
                this.emailFieldNotValidate = false;
            }
            if (!this.input.password.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = "Password field is required";
                this.passwordFieldNotValidate = true;
                return;
            } else {
                this.errors.password = null;
                this.passwordFieldNotValidate = false;
            }

            if (this.input.password != this.input.confpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = "Confirm password field not matched";
                this.confirmPwdFieldNotValidate = true;
                return;
            }

            this.errors.valid = true;
            this.isFormValid = true;
            let userData = {
                username: this.input.username + ' ' + this.input.last_name,
                user_email: this.input.user_email,
                password: this.input.confpassword
            };
            registerUser(userData).then((res) => {
                if (res.data.code === 200 && res.data.status === 'SUCCESS') {
                    localStorage.setItem('end_user_access_token', res.data.data.access_token);
                    localStorage.setItem('end_user_reload_token', res.data.data.refresh_token);
                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,

                    });
                    // JsLoadingOverlay.show();
                    getUserDetails().then(userData => {
                        if (userData.data && userData.data.code == 200) {
                            var userProfile = userData.data.data.getUserDetails[0];
                            localStorage.setItem('isloggedin', 'true');
                            setCookie('isloggedin', 'true');
                            localStorage.setItem('user', JSON.stringify(userProfile));
                            this.checkUserSubscription();
                        }
                    });

                } else {
                    $('#regdFormButton').css('pointer-events','');
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    });
                }
            }).catch(err => {
                $('#regdFormButton').css('pointer-events','');
                console.log('error', err);
            });

        },

        checkUserSubscription() {
           
            //106237-start
            if (localStorage.getItem('redirectAfterlogin')) {
                localStorage.setItem("isHomePageRedirect", true);
                var uri = localStorage.getItem("redirectAfterlogin");
                localStorage.removeItem("redirectAfterlogin");
                window.location.href = uri;
            } else {
                if(this.enableMultiProfile === 1){
                    localStorage.setItem("isHomePageRedirect", true);  
                }
                isSubscriptionEnabled().then((res) => {
                    if (res.data.status === "SUCCESS") {
                        if (
                            res.data.data.isSubscriptionEnabled
                                .is_subscription_enabled === true
                        ) {
                            this.myPlanDetails();
                        } else {
                            window.location.href = "/home";
                        }
                    }
                });
            }
            //106237-end
        },

    },
    template: `
    <vd-component class="vd register-three" type="register-three">
    <section class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a v-if="logo_details['logo']" class="navbar-brand" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                <a v-else-if="logo_details['logo']!=false" class="navbar-brand" href="/"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'"
                alt="citrine" /></a>               
            </nav>
          </div>
        </div>
      </div>
    </section>
    <div class="card-box py-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 col-lg-7 text-center">
                <div class="form-wrapper">
                    <div class="section-heading mb-4">
                        <h2><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param> <span class="text-blue fst-italic"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></span></h2>  
                    </div>
                    <p class="fs-18 d-none"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></p>
                    <div class="row justify-content-center gx-4 d-none">
                        <div class="col-auto">
                            <a href="#/" class="btn-border with-icon">
                                <div class="svg">
                                    <svg width="12" height="20" viewBox="0 0 12 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.19873 19.5H7.19873V11.49H10.8027L11.1987 7.51H7.19873V5.5C7.19873 5.23478 7.30409 4.98043 7.49163 4.79289C7.67916 4.60536 7.93352 4.5 8.19873 4.5H11.1987V0.5H8.19873C6.87265 0.5 5.60088 1.02678 4.6632 1.96447C3.72552 2.90215 3.19873 4.17392 3.19873 5.5V7.51H1.19873L0.802734 11.49H3.19873V19.5Z" fill="url(#paint0_linear_379_1030)"/>
                                        <defs>
                                        <linearGradient id="paint0_linear_379_1030" x1="0.802734" y1="0.5" x2="15.0116" y2="3.99382" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#09C6F9"/>
                                        <stop offset="1" stop-color="#045DE9"/>
                                        </linearGradient>
                                        </defs>
                                    </svg>
                                </div>
                                Facebook
                            </a>
                        </div>
                        <div class="col-auto">
                            <a href="#/" class="btn-border with-icon">
                                <div class="svg">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.4565 8.15401C19.5795 8.81301 19.6465 9.50201 19.6465 10.221C19.6465 15.845 15.8825 19.844 10.1975 19.844C8.90467 19.8444 7.62442 19.59 6.42991 19.0955C5.23541 18.6009 4.15006 17.8758 3.23588 16.9616C2.3217 16.0475 1.59661 14.9621 1.10204 13.7676C0.607475 12.5731 0.353122 11.2929 0.353516 10C0.353122 8.70716 0.607475 7.42691 1.10204 6.2324C1.59661 5.0379 2.3217 3.95255 3.23588 3.03837C4.15006 2.12419 5.23541 1.3991 6.42991 0.904533C7.62442 0.409966 8.90467 0.155612 10.1975 0.156006C12.8555 0.156006 15.0765 1.13401 16.7805 2.72201L14.0055 5.49701V5.49001C12.9725 4.50601 11.6615 4.00101 10.1975 4.00101C6.94952 4.00101 4.30952 6.74501 4.30952 9.99401C4.30952 13.242 6.94952 15.992 10.1975 15.992C13.1445 15.992 15.1505 14.307 15.5625 11.993H10.1975V8.15401H19.4575H19.4565Z" fill="url(#paint0_linear_379_1035)"/>
                                        <defs>
                                        <linearGradient id="paint0_linear_379_1035" x1="0.353516" y1="0.156006" x2="23.7746" y2="10.4702" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#09C6F9"/>
                                        <stop offset="1" stop-color="#045DE9"/>
                                        </linearGradient>
                                        </defs>
                                    </svg>                                        
                                </div>
                                Google
                            </a>
                        </div>
                    </div>
                    <div class="row align-items-center d-none">
                        <div class="col">
                            <div class="border-line"></div>
                        </div>
                        <div class="col-auto">
                            <p><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></p>
                        </div>
                        <div class="col">
                            <div class="border-line"></div>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <form @submit.prevent action="" method="post" class="needs-validation" novalidate>
                        <div class="col-12">
                            <div class="input-group vd-form mb-30 _required">
                                <span class="input-group-text" id="name">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 21H3V20C3.00441 16.1358 6.13583 13.0044 10 13H14C17.8642 13.0044 20.9956 16.1358 21 20V21H19V20C18.9967 17.2399 16.7601 15.0033 14 15H10C7.23995 15.0033 5.00331 17.2399 5 20V21ZM12 12C9.23858 12 7 9.76142 7 7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7C16.9967 9.76005 14.7601 11.9967 12 12ZM12 4C10.3431 4 9 5.34315 9 7C9 8.65685 10.3431 10 12 10C13.6569 10 15 8.65685 15 7C15 5.34315 13.6569 4 12 4Z" fill="#91919F"/>
                                    </svg>                                        
                                </span>
                                <input type="text"  @keyup.enter="submitRegisterForm" v-model="input.first_name" class="form-control vd-component-attr" vd-component-attr-placeholder="label12" :placeholder=i18n($attrs['label12']) 
                                vd-component-attr-title="label17" :title=i18n($attrs['label17']) aria-label="Name" aria-describedby="name" autocomplet="off" :class="nameFiledNotValidate">
                                <template v-if="errors.username">
                                <div class="invalid-feedback d-block position-absolute" style="bottom:-20px;">{{ errors.username }}</div>
                                </template> 
                            </div>
                         
                            <div class="input-group vd-form mb-30 _required">
                                <span class="input-group-text" id="name">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 21H3V20C3.00441 16.1358 6.13583 13.0044 10 13H14C17.8642 13.0044 20.9956 16.1358 21 20V21H19V20C18.9967 17.2399 16.7601 15.0033 14 15H10C7.23995 15.0033 5.00331 17.2399 5 20V21ZM12 12C9.23858 12 7 9.76142 7 7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7C16.9967 9.76005 14.7601 11.9967 12 12ZM12 4C10.3431 4 9 5.34315 9 7C9 8.65685 10.3431 10 12 10C13.6569 10 15 8.65685 15 7C15 5.34315 13.6569 4 12 4Z" fill="#91919F"/>
                                    </svg>                                        
                                </span>
                                
                                <input type="text"  @keyup.enter="submitRegisterForm" v-model="input.last_name" class="form-control vd-component-attr" vd-component-attr-placeholder="label13" :placeholder=i18n($attrs['label13']) 
                                vd-component-attr-title="label18" :title=i18n($attrs['label18']) aria-label="Last Name" aria-describedby="last name" autocomplet="off" :class="lastnameFiledNotValidate">
                                <template v-if="errors.last_name">
                                <div class="invalid-feedback d-block position-absolute" style="bottom:-20px;">{{ errors.last_name }}</div>
                                </template>
                            </div>
                            <div class="input-group vd-form mb-30 _required">
                                <span class="input-group-text" id="email">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20 20H4C2.89543 20 2 19.1046 2 18V5.913C2.04661 4.84255 2.92853 3.99899 4 4H20C21.1046 4 22 4.89543 22 6V18C22 19.1046 21.1046 20 20 20ZM4 7.868V18H20V7.868L12 13.2L4 7.868ZM4.8 6L12 10.8L19.2 6H4.8Z" fill="#91919F"/>
                                    </svg>                                       
                                </span>
                                <input type="email" @keyup.enter="submitRegisterForm" class="form-control vd-component-attr" vd-component-attr-placeholder="label14" :placeholder=i18n($attrs['label14']) 
                                vd-component-attr-title="label19" :title=i18n($attrs['label19']) v-model="input.user_email"  aria-label="Email" aria-describedby="email" autocomplete="off" :class=" emailFieldNotValidate">
                                <template v-if="errors.user_email">
                                  <div class="invalid-feedback d-block position-absolute" style="bottom:-20px;">{{ errors.user_email }}</div>
                                </template>
                            </div>

                           
                        
                            <div class="input-group vd-form mb-30 _required">
                                    <span class="input-group-text">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>                                                                               
                                    </span>
                                    <input @keyup.enter="submitRegisterForm" v-bind:type="[showPassword ? 'text' : 'password']" v-model="input.password" class="form-control pe-5 vd-component-attr" vd-component-attr-placeholder="label15" :placeholder=i18n($attrs['label15']) 
                                    vd-component-attr-title="label20" :title=i18n($attrs['label20']) aria-label="Password"  aria-describedby="password" autocomplete="off" :class="passwordFieldNotValidate">

                                    <button type="button" class="border-0" @click="showPassword = !showPassword">
                                        <span toggle="#password" class="field-icon toggle-password" >
                                            <span class="material-icons" >
                                            <i :class="[showPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i>
                                        </span>
                                        </span>
                                    </button>
                                        
                                  

                                    <template v-if="errors.password">
                                    <div class="invalid-feedback d-block position-absolute" style="bottom:-20px;">{{ errors.password }}</div>
                                    </template>
                            </div>
                           

                            <div class="input-group vd-form mb-30 _required">
                                    <span class="input-group-text">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>                                                                               
                                    </span>
                                    <input @keyup.enter="submitRegisterForm" v-bind:type="[showConfPassword ? 'text' : 'password']" v-model="input.confpassword" class="form-control pe-5 vd-component-attr" vd-component-attr-placeholder="label16" :placeholder=i18n($attrs['label16']) 
                                    vd-component-attr-title="label21" :title=i18n($attrs['label21']) @copy.prevent @paste.prevent @cut.prevent autocomplete="off" :class="confirmPwdFieldNotValidate">
                                        

                                        <button type="button" class="disabled-button" @click="showConfPassword = !showConfPassword">
                                            <span toggle="#password" class="field-icon toggle-password" >
                                                <span class="material-icons"  >
                                                    <i :class="[showConfPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i>
                                            </span>
                                            </span>
                                        </button>
                                    <template v-if="errors.confpassword">
                                    <div class="invalid-feedback d-block position-absolute" style="bottom:-20px;">{{ errors.confpassword }}</div>
                                </template>

                            </div>
                           

                            <div class="form-check text-start">
                               <!-- <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">-->
                               <!-- <label class="form-check-label ms-1" for="flexCheckDefault">
                               <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>   
                               <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>   , 
                               <vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param> 
                               <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>  <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param> .
                               </label>-->
                               <label vd-node="text" class="form-check-label ms-1" for="flexCheckDefault">
                               <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
                               </label>

                            </div>
                            <button id="regdFormButton" href="javascript:void(0)" vd-node="styleOnly" class="btn-solid" :class="(isFormValid==0 || input.user_email==''  || input.confpassword =='' || input.first_name=='' )?'disabled_button':''"
                            :disabled="isFormValid==0 || input.user_email=='' || input.confpassword=='' || input.first_name=='' " @click="submitRegisterForm()"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></button>

                            <p><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></p>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</vd-component>`

};

let {
  registerUser,
  getUserDetails,
  isSubscriptionEnabled,
  getSubscriptionPlans,
  getEndUserRegdLoginSetting,
  // getVdConfig,
  getCountryCodes,
  sendOtp,
  resendOtp,
  validateOtp,
  ssoLogin,
  getSsoConfig,
  checkEndUserExist
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n }=await import(window.importAssetJs('js/i18n.js'));
let {
  getRootUrl,
  getAsthuDomainUrl
} = await import(window.importAssetJs('js/web-service-url.js'));
let {
  getUserGeoLocationFromCookies,
  setUserGeoLocationOnCookies,
  setCookie
} = await import(window.importAssetJs('js/main.js'));
const { mapState} = Vuex;

//let {getAuth, GoogleAuthProvider,signInWithPopup, OAuthProvider, FacebookAuthProvider, signOut,onAuthStateChanged }=await import(window.importAssetJs('js/sso-firebase-config/firebase-auth.js'));
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getAuth, GoogleAuthProvider,signInWithPopup, OAuthProvider, FacebookAuthProvider } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";

let timer1;

export default {
  name: "register_four",
components: {
      //enduser_signup_customfield_one
  },			 

  data() {
      return {
          isMobileSignin: true,
          input: {
              first_name: "",
              last_name: "",
              user_email: "",
              password: "",
              confpassword: "",
              username: "",
              mobile_number:"",
              otpNumber1:"",
              otpNumber2:"",
              otpNumber3:"",
              otpNumber4:""
          },
          errors: {},
          country_details:[],
          mobile_field:false,
          selTypeIndex: "",
          isFormValid: false,
          emailFieldNotValidate: false,
          passwordFieldNotValidate: false,
          confirmPwdFieldNotValidate: false,
          nameFiledNotValidate: false,
          lastnameFiledNotValidate: false,
          showPassword: false,
          showConfPassword: false,
          logo_src: "",
          logo_alt: "",
          logo_style: "",
          isLogoUpdated: Boolean,
          countryCode: "US",
          selectedCountry:"+91",
          selectCountry:"",
          otpSettingEnabled: false,
          muviAuthEmailOptSettingList : ['3','34','35'],
          muviAuthSettingType : '',
          isEmailVerificationDuringRegdEnable : false,
          enableResendButton: false,
          timer1:null,
          google_sso:"G-Auth",
          apple_sso: "A-Auth",
          facebook_sso:"F-Auth",
          is_sso: false,
          sso_enabled: false,
          google_sso_enabled:false,
          apple_sso_enabled:false,
          facebook_sso_enabled:false,
          email:"",
          userName:"",
          registration_mode:"",
          otp_time_interval: 0,
          message: "You have exceeded the limit for resending the OTP",
          errorMsgs:[],
          socialId:"",
          endUserExist:true,
          mobile_number_sso:"",
          ssoEmailverification: false,
          enableMultiProfile: 0
      };
  },
  computed: {
      username() {
          this.input.username = this.input.first_name;
          return this.input.username;
      },
      last_name() {
          return this.input.last_name;
      },
      user_email() {
          return this.input.user_email;
      },
      mobile() {
          return this.input.mobile_number;
      },
      password() {
          return this.input.password;
      },
      confirmPassword() {
          return this.input.confpassword;
      },
      ...mapState({
          logo_details: (state) => state.logo_details,
      })

  },
  watch: {
      username(value) {
          $('#regdFormButton').css('pointer-events','');
          if (!value.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username = i18n("First name field is required");
              this.nameFiledNotValidate = true;
          } else if (value.length < 1 || value.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username =
              i18n("First name should be between 1 and 25 charaters.");
              this.nameFiledNotValidate = true;
          } else {
              this.errors.username = null;
              this.nameFiledNotValidate = false;
              if (
                  this.errors.username !== undefined &&
                  this.errors.username == null &&
                  this.errors.user_email !== undefined &&
                  this.errors.user_email == null &&
                  this.errors.password !== undefined &&
                  this.errors.password == null &&
                  this.errors.confpassword !== undefined &&
                  this.errors.confpassword == null &&
                  this.input.selTypeIndex != ""
              ) {
                  this.errors.valid = true;
                  this.isFormValid = true;
              }
          }
      },
      last_name(value) {
          $('#regdFormButton').css('pointer-events','');
          if (!value.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name = i18n("Last name field is required");
              this.lastnameFiledNotValidate = true;
          } else if (value.length < 1 || value.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name =
              i18n("Last name should be between 1 and 25 charaters.");
              this.lastnameFiledNotValidate = true;
          } else {
              this.errors.last_name = null;
              this.lastnameFiledNotValidate = false;
              if (
                  this.errors.last_name !== undefined &&
                  this.errors.last_name == null &&
                  this.errors.user_email !== undefined &&
                  this.errors.user_email == null &&
                  this.errors.password !== undefined &&
                  this.errors.password == null &&
                  this.errors.confpassword !== undefined &&
                  this.errors.confpassword == null &&
                  this.input.selTypeIndex != ""
              ) {
                  this.errors.valid = true;
                  this.isFormValid = true;
              }
          }
      },
      mobile(value) {
          $('#regdFormButton').css('pointer-events','');
          if (!value.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.mobile = i18n("Mobile field is required");
              this.mobile_field = true;
              return;
          } else if (
              !value.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)
          ) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.mobile = i18n("Mobile field is required");;
              this.mobile_field = true;
          }else {
              this.errors.mobile = null;
              this.mobile_field = false;
          }


      },
      user_email(value) {
          $('#regdFormButton').css('pointer-events','');
          if(this.muviAuthSettingType == "3" && (value == null || !value.length)){
              this.errors.email = null;
              this.email_filed = false;
          }else{
          if (!value.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.user_email = i18n("Email field is required");
              this.emailFieldNotValidate = true;
          } else if (!value.match(/^(?=.{1,64}@)[^@]+@([^@]{2,})+\.([^@.]{2,14})$/)) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.user_email = i18n("Please enter a valid email");
              this.emailFieldNotValidate = true;
          } else {
              this.errors.user_email = null;
              this.emailFieldNotValidate = false;
              if (
                  this.errors.username !== undefined &&
                  this.errors.username == null &&
                  this.errors.user_email !== undefined &&
                  this.errors.user_email == null &&
                  this.errors.password !== undefined &&
                  this.errors.password == null &&
                  this.errors.confpassword !== undefined &&
                  this.errors.confpassword == null &&
                  this.input.selTypeIndex != ""
              ) {
                  this.errors.valid = true;
                  this.isFormValid = true;
              }
          }
      }
      },
      password(value) {
          $('#regdFormButton').css('pointer-events','');
          if (!value.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.password = i18n("Password field is required");
              this.passwordFieldNotValidate = true;
          } else if (value.length < 8) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.password =
              i18n("Password should be more than 8 characters long.");
              this.passwordFieldNotValidate = true;
          } else if (value === this.input.confpassword) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.password = null;
              this.passwordFieldNotValidate = true;
              this.errors.confpassword = null;
          } else {
              this.errors.password = null;
              this.passwordFieldNotValidate = false;
              if (value !== this.input.confpassword) {
                  this.errors.valid = false;
                  this.isFormValid = false;
                  this.errors.confpassword = i18n("Passwords do not match");
                  this.confirmPwdFieldNotValidate = true;
              }
              if (
                  this.errors.username !== undefined &&
                  this.errors.username == null &&
                  this.errors.user_email !== undefined &&
                  this.errors.user_email == null &&
                  this.errors.password !== undefined &&
                  this.errors.password == null &&
                  this.errors.confpassword !== undefined &&
                  this.errors.confpassword == null &&
                  this.input.selTypeIndex != ""
              ) {
                  this.errors.valid = true;
                  this.isFormValid = true;
              }
          }
      },
      confirmPassword(value) {
          $('#regdFormButton').css('pointer-events','');
          if (!value.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.confpassword = i18n("Confirm Password field is required");
              this.confirmPwdFieldNotValidate = true;
          } else if (value !== this.input.password) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.confpassword = i18n("Passwords do not match");
              this.confirmPwdFieldNotValidate = true;
          } else {
              this.errors.confpassword = null;
              this.confirmPwdFieldNotValidate = false;
              if (
                  this.errors.username !== undefined &&
                  this.errors.username == null &&
                  this.errors.user_email !== undefined &&
                  this.errors.user_email == null &&
                  this.errors.password !== undefined &&
                  this.errors.password == null &&
                  this.errors.confpassword !== undefined &&
                  this.errors.confpassword == null &&
                  this.input.selTypeIndex != ""
              ) {
                  this.errors.valid = true;
                  this.isFormValid = true;
              }
          }
      },
  },
  beforeCreate(){
    if(localStorage.getItem('isloggedin')) {
        window.location.href = "/";
    }
},
  created(){
      getSsoConfig().then((res) => {
          if (res.data.code === 200 && res.data.status === "SUCCESS") {
            var ssoConfiguration = res.data.data.getSsoConfigDetails;
            if(ssoConfiguration.length){
                const firebaseConfigForGoogleSso = {
                  apiKey: ssoConfiguration[0].api_key,
                  authDomain: ssoConfiguration[0].auth_domain,
                  projectId: ssoConfiguration[0].project_id,
                  storageBucket: ssoConfiguration[0].storage_bucket,
                  messagingSenderId: ssoConfiguration[0].messaging_sender_id,
                  appId: ssoConfiguration[0].app_id
                };
                // Initialize Firebase
                const app = initializeApp(firebaseConfigForGoogleSso);
            }else{
              console.log("Error in firebase config");
            }
          } else {
            console.log("Error in get sso config");
          }
      })
      .catch((err) => {
         console.log("Error during initializing firebase//////",err)
      });
  },
  beforeMount() {
      //JsLoadingOverlay.show();
      getEndUserRegdLoginSetting().then((res) => {
          if (res.data.code == 200 && res.data.data !== null) {
              const requireRegistrationAndLogin = parseInt(
                  res.data.data.sections[0].groups[0].nodes[0].node_value
              );
              const emailVerificationDuringRegd = parseInt(
                  res.data.data.sections[0].groups[2].nodes[5].node_value
              );
              this.enableMultiProfile = parseInt(
                res.data.data.sections[0].groups[0].nodes[2].node_value
              );
              if(requireRegistrationAndLogin == 1){
                  
                  if(emailVerificationDuringRegd == 1){
                      this.isEmailVerificationDuringRegdEnable = true;
                      $("#nextButton").css('display','');
                  }else{
                      $("#regdFormButton").css('display','');
                  }
              }
              if (requireRegistrationAndLogin != 1) {
                  $("body").css("opacity",0);
                  window.location.href = "/";
              }
          }
      });
  },

  async mounted() {
      this.gotoVerifyotp();
      this.selectDropdown();


      setTimeout(() => {
          $(".selectpicker").selectpicker();
          $(".selectpicker").selectpicker("refresh");
      }, 2000);
      $(".signup-google-otp").hide();

      $(document).on("click", ".edit-input-btn", function () {
          const button = document.querySelector(".otp-verify-btn");
          button.classList.add("disabled-button");
          $('#validateOtpButton').css('pointer-events','none');
          const inputs = document.querySelectorAll(".otp-digit");
          inputs[0].value = "";
          inputs[1].value = "";
          inputs[2].value = "";
          inputs[3].value = "";
          inputs[0].focus();
          if($(this).attr("id") == "edit-input-btn-email-verification"){
              $(".verify-otp").hide();
              $(".regd-form").show();
          }else if($(this).attr("id") == "edit-input-btn-sso"){
              $(".verify-otp").hide();
              $(".signup-google-otp").show();
          }else{
              $(".verify-otp").hide();
              $(".get-otp").show();
          }     
      });


      $(".otp-digit").bind("paste", function(e){

           var pastedData = e.originalEvent.clipboardData.getData('text'); 
           if (pastedData) {
              const onlyContainsNumbers = (pastedData) => /^\d+$/.test(pastedData);
              if(onlyContainsNumbers(pastedData) && pastedData.length >= 4){
                  var split = pastedData.split("");
                  const inputs = document.querySelectorAll(".otp-digit");
                  inputs[0].value ="";
                  inputs[1].value ="";
                  inputs[2].value ="";
                  inputs[3].value ="";
                  inputs[0].value = split[0];
                  inputs[1].value = split[1];
                  inputs[2].value = split[2];
                  inputs[3].value = split[3];
                  const button = document.querySelector(".otp-verify-btn");
                  button.classList.remove("disabled-button");
                  $('#validateOtpButton').css('pointer-events','');
              }
          
              return false
           }
          } );



      JsLoadingOverlay.hide();
      getUserDetails().then((res) => {
          if (res.data.code === 200 && res.data.status == "SUCCESS") {
            if(res.data.data.getUserDetails[0].muvi_auth_setting_type != null){
              this.otpSettingEnabled = this.muviAuthEmailOptSettingList.includes(res.data.data.getUserDetails[0].muvi_auth_setting_type);
              localStorage.setItem('adminId',res.data.data.getUserDetails[0].user_uuid);
              this.muviAuthSettingType = res.data.data.getUserDetails[0].muvi_auth_setting_type;
              this.muviAuthEmailOptSettingType = this.muviAuthEmailOptSettingList.includes(this.muviAuthSettingType);
              var sso_enabled_list = JSON.parse(res.data.data.getUserDetails[0].sso_enabled_list);
              this.sso_enabled = sso_enabled_list.length != 0 ? true : false;
              this.google_sso_enabled = sso_enabled_list.includes(this.google_sso);
              this.apple_sso_enabled = sso_enabled_list.includes(this.apple_sso);
              this.facebook_sso_enabled = sso_enabled_list.includes(this.facebook_sso);
              this.otp_time_interval = res.data.data.getUserDetails[0].otp_time_interval * 60 *1000;
              this.ssoEmailverification = this.sso_enabled && this.muviAuthSettingType === '1' ? true : false;
            }
          }
        });
      try {
          let userGeoLocation = getUserGeoLocationFromCookies();
          if (!userGeoLocation) {
              setUserGeoLocationOnCookies();
              userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
          } else {
              userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
          }
          this.countryCode = userGeoLocation?.country_code;
          
      } catch (error) {
          
      }
      
      let isloggedIn = localStorage.getItem("isloggedin");
      if (isloggedIn) {
          window.location.href = "/home";
      }
      // getVdConfig("logo")
      //     .then((res) => {
      //         if (res.data.code == 200 && res.data.data !== null) {
      //             this.isLogoUpdated = true;
      //             this.logo_alt = res.data.data.alt;
      //             this.logo_src = res.data.data.src;
      //             this.logo_style = res.data.data.style;
      //         } else {
      //             this.isLogoUpdated = false;
      //         }
      //     })
      //     .catch((ex) => {
      //         console.log(ex);
      //     });
  },
  updated(){
      $(".selectpicker").selectpicker("refresh");
  },
  methods: {
      getRootUrl,
      i18n,
      getAsthuDomainUrl,
      clearOtpValue(){
          const inputs = document.querySelectorAll(".otp-digit");
                inputs[0].value = "";
                inputs[1].value = "";
                inputs[2].value = "";
                inputs[3].value = "";

                inputs[0].focus();

      },
      gotoVerifyotp(){
          const inputs = document.querySelectorAll(".otp-digit");
          const button = document.querySelector(".otp-verify-btn");
          // iterate over all inputs
          inputs.forEach((input, index1) => {
              input.addEventListener("keyup", (e) => {
              // This code gets the current input element and stores it in the currentInput variable
              // This code gets the next sibling element of the current input element and stores it in the nextInput variable
              // This code gets the previous siblinginput element of the current input element and stores it in the prevInput variable
              const currentInput = input,
                  nextInput = input.nextElementSibling,
                  prevInput = input.previousElementSibling;
          
              // if the value has more than one character then clear it
              if (currentInput.value.length > 1) {
                  currentInput.value = "";
                  return;
              }
              // if the next input is disabled and the current value is not empty
              //  enable the next input and focus on it
              if (nextInput && currentInput.value !== "") {
                  nextInput.removeAttribute("disabled");
                  nextInput.focus();
              }
          
              // if the backspace key is pressed
              if (e.key === "Backspace") {
                  input.value = "";
                  if(prevInput !== null){
                      prevInput.focus();
                  }else{
                      currentInput.focus();
                  }
                  }
              if (inputs[0].value !== "" && inputs[1].value !== "" && inputs[2].value !== "" && inputs[3].value !== "") {
                  button.classList.remove("disabled-button");
                  $('#validateOtpButton').css('pointer-events','');
                  return;
              }
              button.classList.add("disabled-button");
              $('#validateOtpButton').css('pointer-events','none');
              });
          });
          //focus the first input which index is 0 on window load
          window.addEventListener("load", () => inputs[0].focus());
      },
      myPlanDetails() {
          getSubscriptionPlans(this.countryCode).then((res) => {
              if (res.data.code == 600 || res.data.status === "FAILED") {
                  window.location.href = "/home";
              } else if (
                  res.data.code == 200 &&
                  res.data.status === "SUCCESS"
              ) {
                  getEndUserRegdLoginSetting().then((res) => {
                      if (res.data.code == 200 && res.data.data !== null) {
                          this.userConfig =
                              res.data.data.sections[0].groups[0].nodes[1].node_value;
                          window.location.href =  "/all-plan";
                      }
                  });
              }
          });
      },
      checkMobileNum(value) {
          var re = new RegExp(/^(\+\d{1,3}[-]?)?\d{4,20}$|^$/); //biswa
          if (re.test(value)) {
              //console.log("Valid");
              return true;
          } else {
              //console.log("Invalid");
              return false;
          }
      },
      getOtpRegistraion(){
          if (!this.input.first_name.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username = i18n("First name field is required");
              this.nameFiledNotValidate = true;
              return;
          } else if (this.input.first_name.length < 1 || this.input.first_name.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username =
              i18n("First name should be between 1 and 25 charaters.");
              this.nameFiledNotValidate = true;
              return;
          } else {
              this.errors.username = null;
              this.nameFiledNotValidate = false;
          }
          
          if (!this.input.last_name.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name = i18n("Last name field is required");
              this.lastnameFiledNotValidate = true;
              return;
          } else if (this.input.last_name.length < 1 || this.input.last_name.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name =
              i18n("Last name should be between 1 and 25 charaters.");
              this.lastnameFiledNotValidate = true;
              return;
          } else {
              this.errors.last_name = null;
              this.lastnameFiledNotValidate = false;
          }
          if(this.muviAuthSettingType == "34" || this.muviAuthSettingType == "3"){
              this.errors.email = null;
              this.email_filed = false;
          }else{
          if (!this.input.user_email.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.user_email = i18n("Email field is required");
              this.emailFieldNotValidate = true;
              return;
          } else if (
              !this.input.user_email.match(
                  /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9À-ÿ]+\.)+[a-zA-ZÀ-ÿ]{2,}))$/
              )
          ) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.user_email = i18n("Please enter a valid email");
              this.emailFieldNotValidate = true;
              return;
          }else{
              this.errors.user_email = null;
              this.emailFieldNotValidate = false;
          }
      }
          if (!this.input.mobile_number.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.mobile = i18n("Mobile field is required");
              this.mobile_field = true;
              return;
          } else if (
              !this.input.mobile_number.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)
          ) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.mobile = i18n("Please enter a valid mobile number");;
              this.mobile_field = true;
              return;
          }
          this.errors.valid = true;
          this.isFormValid = true;
          //this.enableResendButton = false;
          let getOtpPayload = {
              otp_request_event_type: 'registration',
              otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
              otp_request_mobile: this.selectedCountry.concat(this.mobile),
              otp_application_id:'end_user'
          };
          // this.isChecked = false;
          sendOtp(getOtpPayload)
              .then((res) => {
                  if (res.data.code == 200 && res.data.status == "SUCCESS") {
                      Toast.fire({
                          icon: "success",
                          title: "OTP sent Successfully",
                          text: res.data.message,
                      });
                      setTimeout(() => {
                          $("#selectpicker2").selectpicker("refresh");
                          $("#selectpicker2").selectpicker();
                      }, 1000);
                      this.selectCountry = this.selectedCountry;
                          $(".get-otp").hide();
                          $(".verify-otp").show();
                          const inputs = document.querySelectorAll(".otp-digit");
                          inputs[0].focus();
                          this.countdown(this.otp_time_interval);//ER-106410
                  } else {

                      if(res.data.message.includes(this.message)){
                          this.enableResendButton = true;
                          clearInterval(timer1);
                          $(".get-otp").hide();
                          $(".verify-otp").show();
                          const inputs = document.querySelectorAll(".otp-digit");
                          inputs[0].focus();
                      }else{
                          Toast.fire({
                              icon: "error",
                              title: res.data.status,
                              text: res.data.message,
                          });
                      }
                      
                  }
              })
              .catch((err) => {
                  Toast.fire({
                      icon: "error",
                      title: err.response.data.status,
                      text: err.response.data.message,
                  });
              });
      },
      submitRegisterForm() {
    //this.input.customfield = this.$refs.$getCustomFieldDataRef.getCustomFieldData();																				
          $('#regdFormButton').css('pointer-events','none');
          if (!this.input.first_name.length && !this.input.last_name.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username = i18n("Fullname field is required");
              this.nameFiledNotValidate = true;
              return;
          } else if (this.input.first_name.length < 1 || this.input.first_name.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username =
              i18n("First name should be between 1 and 25 charaters.");
              this.nameFiledNotValidate = true;
              return;
          } else {
              this.errors.username = null;
              this.nameFiledNotValidate = false;
          }

          if (!this.input.last_name.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name = i18n("Last name field is required");
              this.lastnameFiledNotValidate = true;
              return;
          } else if (this.input.last_name.length < 1 || this.input.last_name.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name =
              i18n("Last name should be between 1 and 25 charaters.");
              this.lastnameFiledNotValidate = true;
              return;
          } else {
              this.errors.last_name = null;
              this.lastnameFiledNotValidate = false;
          }

          if (!this.input.user_email.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.user_email = i18n("Email field is required");
              this.emailFieldNotValidate = true;
              return;
          } else {
              this.errors.user_email = null;
              this.emailFieldNotValidate = false;
          }
          if (!this.input.password.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.password = i18n("Password field is required");
              this.passwordFieldNotValidate = true;
              return;
          } else {
              this.errors.password = null;
              this.passwordFieldNotValidate = false;
          }

          if (this.input.password != this.input.confpassword) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.confpassword = i18n("Confirm password field not matched");
              this.confirmPwdFieldNotValidate = true;
              return;
          }

          this.errors.valid = true;
          this.isFormValid = true;
          let userData = {
              username: this.input.username + " " + this.input.last_name,
              user_email: this.input.user_email,
              password: this.input.confpassword,
      //custom_fields: this.input.customfield									 
          };
          registerUser(userData)
              .then((res) => {
                  if (
                      res.data.code === 200 &&
                      res.data.status === "SUCCESS"
                  ) {
                      localStorage.setItem(
                          "end_user_access_token",
                          res.data.data.access_token
                      );
                      localStorage.setItem(
                          "end_user_reload_token",
                          res.data.data.refresh_token
                      );
                      Toast.fire({
                          icon: "success",
                          text: res.data.message,
                      });
                      getUserDetails().then((userData) => {
                          if (userData.data && userData.data.code == 200) {
                              var userProfile =
                                  userData.data.data.getUserDetails[0];
                              localStorage.setItem("isloggedin", "true");
                              setCookie('isloggedin', 'true');
                              localStorage.setItem(
                                  "user",
                                  JSON.stringify(userProfile)
                              );
                              this.checkUserSubscription();
                          }
                      });
                  } else {
                  $('#regdFormButton').css('pointer-events','');
                      Toast.fire({
                          icon: "error",
                          text: res.data.message,
                      });
                  }
              })
              .catch((err) => {
              $('#regdFormButton').css('pointer-events','');
                  console.log("error", err);
              });
      },
      getOtpForRegThroughEmail() {
          if (!this.input.first_name.length && !this.input.last_name.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username = i18n("Fullname field is required");
              this.nameFiledNotValidate = true;
              return;
          } else if (this.input.first_name.length < 1 || this.input.first_name.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.username =
              i18n("First name should be between 1 and 25 charaters.");
              this.nameFiledNotValidate = true;
              return;
          } else {
              this.errors.username = null;
              this.nameFiledNotValidate = false;
          }

          if (!this.input.last_name.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name = i18n("Last name field is required");
              this.lastnameFiledNotValidate = true;
              return;
          } else if (this.input.last_name.length < 1 || this.input.last_name.length > 25) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.last_name =
              i18n("Last name should be between 1 and 25 charaters.");
              this.lastnameFiledNotValidate = true;
              return;
          } else {
              this.errors.last_name = null;
              this.lastnameFiledNotValidate = false;
          }

          if (!this.input.user_email.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.user_email = i18n("Email field is required");
              this.emailFieldNotValidate = true;
              return;
          } else {
              this.errors.user_email = null;
              this.emailFieldNotValidate = false;
          }
          if (!this.input.password.length) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.password = i18n("Password field is required");
              this.passwordFieldNotValidate = true;
              return;
          } else {
              this.errors.password = null;
              this.passwordFieldNotValidate = false;
          }

          if (this.input.password != this.input.confpassword) {
              this.errors.valid = false;
              this.isFormValid = false;
              this.errors.confpassword = i18n("Confirm password field not matched");
              this.confirmPwdFieldNotValidate = true;
              return;
          }

          this.errors.valid = true;
          this.isFormValid = true;
         // this.enableResendButton = false;
          let getOtpPayload = {
              otp_request_event_type: 'registration',
              otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
              otp_request_email: this.input.user_email,
              otp_application_id:'end_user',
              username: this.input.username + " " + this.input.last_name
          };
          sendOtp(getOtpPayload)
              .then((res) => {
                  if (res.data.code == 200 && res.data.status == "SUCCESS") {
                      Toast.fire({
                          icon: "success",
                          title: "OTP sent Successfully",
                          text: res.data.message,
                      });

                      $(".regd-form").hide();
                      $(".verify-otp").show();
                      const inputs = document.querySelectorAll(".otp-digit");
                      inputs[0].focus();
                      this.countdown(this.otp_time_interval);//ER-106410
                  } else {
                      
                      if(res.data.message.includes(this.message)){
                          this.enableResendButton = true;
                          clearInterval(timer1);
                          $(".regd-form").hide();
                          $(".verify-otp").show();
                          const inputs = document.querySelectorAll(".otp-digit");
                          inputs[0].focus();
                      }else{
                          Toast.fire({
                              icon: "error",
                              title: res.data.status,
                              text: res.data.message,
                          });
                      }
                      
                  }
              })
              .catch((err) => {
                  Toast.fire({
                      icon: "error",
                      title: err.response.data.status,
                      text: err.response.data.message,
                  });
              });

      },

      checkUserSubscription() {
          //JsLoadingOverlay.show();
          //106237-start
          if (localStorage.getItem('redirectAfterlogin')) {
            localStorage.setItem("isHomePageRedirect", true);
              var uri = localStorage.getItem("redirectAfterlogin");
              localStorage.removeItem("redirectAfterlogin");
              window.location.href = uri;
          }else{
            if(this.enableMultiProfile === 1){
                localStorage.setItem("isHomePageRedirect", true);  
            }
              isSubscriptionEnabled().then((res) => {
                  if (res.data.status === "SUCCESS"){
                      if (
                          res.data.data.isSubscriptionEnabled
                              .is_subscription_enabled === true
                      ) {
                          this.myPlanDetails();
                      } else {
                          window.location.href = "/home";
                      }
                  }
              });
          }
          //106237-end
          
      },
      selectDropdown(event){
          getCountryCodes().then((res) => {
              if (res.data.code == 200) {
                  this.country_details = res.data.data.country;
                  setTimeout(() => {
                      $("#selectpicker1").selectpicker();
                  }, 1700);
              }

              
          });
           
      },
      validateOtpPart(){
          $('#validateOtpButton').css('pointer-events','none');
          let validateOtpPayload = {};
          const inputs = document.querySelectorAll(".otp-digit");
          if(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification){
              validateOtpPayload['otp_request_event_type'] ='registration';
              validateOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              validateOtpPayload['otp_request_email']= this.input.user_email;
              validateOtpPayload['otp_application_id'] = 'end_user';
              validateOtpPayload['username'] = this.is_sso ? this.userName : this.input.username + " " + this.input.last_name;
              validateOtpPayload['otp_value'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
          }else{
              validateOtpPayload['otp_request_event_type'] ='registration';
              validateOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              validateOtpPayload['otp_request_mobile']= this.selectedCountry.concat(this.mobile);
              validateOtpPayload['otp_application_id'] = 'end_user';
              validateOtpPayload['otp_value'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
          }
          if(this.is_sso && !(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification)){
              validateOtpPayload['otp_request_sso'] = true;
          }
          validateOtp(validateOtpPayload)
          .then((res) => {
              if (res.data.code == 200 && res.data.status == "SUCCESS") {
                  let userData = {};
                  if(this.isEmailVerificationDuringRegdEnable){
                      userData['username']=this.input.username + " " + this.input.last_name;
                      userData['user_email']=this.input.user_email;
                      userData['password']= this.input.confpassword
                  }else{
                      userData['username']=this.input.username + " " + this.input.last_name;
                      userData['user_email']=this.input.user_email;
                      userData['mobile']=validateOtpPayload.otp_request_mobile
                  }
                  if(this.is_sso){
                      userData['username']=this.userName;
                      userData['user_email']=this.email;
                      userData['mobile']=validateOtpPayload.otp_request_mobile;
                      userData['authentication_mode']= this.registration_mode;
                      userData['social_sso_user_id']= this.socialId;
                      this.registrationWithSso(userData);
                  }else{
                      this.registrationWithoutSsoForOtp(userData);
                  }  
              } else {
                  $('#validateOtpButton').css('pointer-events','');
                  Toast.fire({
                      icon: "error",
                      title: "Error",
                      text: res.data.message,
                  });
              }
          })
          .catch((err) => {
              $('#validateOtpButton').css('pointer-events','');
              Toast.fire({
                  icon: "error",
                  title: "Error",
                  text: err.response.data.message,
              });
          });
          this.otpNumber1="";
                              this.otpNumber2="";
                              this.otpNumber3="";
                              this.otpNumber4=""
        },
        resendOtp() {
          this.clearOtpValue();
          this.enableResendButton = true;
          let getOtpPayload = {};
          if(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification){
                getOtpPayload['otp_request_event_type'] ='registration';
                getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
                getOtpPayload['otp_request_email']= this.input.user_email;
                getOtpPayload['otp_application_id'] = 'end_user';
                getOtpPayload['username'] = this.is_sso ? this.userName : this.input.username + " " + this.input.last_name;
                getOtpPayload['resend_otp_request'] =true;
          }else{

          getOtpPayload['otp_request_event_type'] ='registration';
              getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              getOtpPayload['otp_request_mobile']= this.selectedCountry.concat(this.mobile);
              getOtpPayload['otp_application_id'] = 'end_user';
              getOtpPayload['resend_otp_request'] =true;
          }

          if(this.is_sso){
              getOtpPayload['otp_request_sso'] = true;
          }

         // console.log(getOtpPayload);
          resendOtp(getOtpPayload)
            .then((res) => {
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    Toast.fire({
                        icon: "success",
                        title: "OTP sent Successfully",
                        text: res.data.message,
                    });
                   // console.log(res);
                          // Disable the resend button
                         // this.enableResendButton = false;
                          // Call countdown function with 1 minute (60 seconds)
                     this.countdown(this.otp_time_interval);
               
                } else {
                    Toast.fire({
                        icon: "error",
                        title: res.data.status,
                        text: res.data.message,
                    });
                  //   this.enableResendButton = false;
                }
            })
            .catch((err) => {
                Toast.fire({
                    icon: "error",
                    title: err.response.data.status,
                    text: err.response.data.message,
                });
                this.enableResendButton = false;
            });
        },
        countdown(otp_time_interval) {
          clearInterval(timer1);
          var timer = document.getElementById("countdown-timer");
          timer.innerHTML = ""
          var timeUnit = ""
          var countDownDate = otp_time_interval;
          var now = 0
          var self = this; // Save reference to `this` to access within the inner function

           timer1 = setInterval(function() { 
              var counter = document.getElementById("countdown-timer");
              // Find the distance between now an the count down date
              var distance = countDownDate - now;

              // Time calculations for days, hours, minutes and seconds
              var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
              var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
              var seconds = Math.floor((distance % (1000 * 60)) / 1000);

              if(hours>0){
                  timeUnit = "hours";
                  counter.innerHTML = (hours < 10 ? "0" : "")+ String(hours) + ":" + (minutes < 10 ? "0" : "")+ String(minutes) + ":" + (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
              }else if(minutes > 0){
                   timeUnit = "minutes";
                   counter.innerHTML = (minutes < 10 ? "0" : "")+ String(minutes) + ":" + (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
              }else{
                  timeUnit = seconds > 1 ? "seconds" : "second";
                  counter.innerHTML = (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
              }

              // Output the result in an element with id="demo"
             // counter.innerHTML = (hours < 10 ? "0" : "")+ String(hours) + " H " + (minutes < 10 ? "0" : "")+ String(minutes) + " M " + (seconds < 10 ? "0" : "") + String(seconds) + " S";
              self.enableResendButton = false;

              // If the count down is over, write some text 
              if (distance < 0) {
                  clearInterval(timer1);
                  self.enableResendButton = true;
              }
              now = now + 1000
          }, 1000);
     },

      async googleSignIn() {
          const provider = new GoogleAuthProvider();
          const auth = getAuth();
          provider.setCustomParameters({
              prompt: 'select_account'
          });
      
          try {
              // Use await to wait for the signInWithPopup to complete
              const result = await signInWithPopup(auth, provider);
              
              // Signed in successfully
              const user = result.user;
              //console.log("Signed in user:", result);
              this.userName = result.user.displayName;
              this.email = result.user.email;
              this.socialId = result.user.uid;
              this.registration_mode = "Google SSO";
              
              if (!this.email || this.otpSettingEnabled) {
                  let checkEndUserPayload = {
                      user_email: this.email,
                      social_sso_user_id: this.socialId
                  };
                  //console.log(checkEndUserPayload);
      
                  // Await the checkEndUserExist function
                  const res = await checkEndUserExist(checkEndUserPayload);
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      this.endUserExist = res.data.data.is_end_user_exists;
                      if(this.endUserExist){
                          this.email = res.data.data.email;
                          this.mobile_number_sso = res.data.data.mobile;
                      }
                  }
              }
              
              if (this.otpSettingEnabled) {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          mobile:this.mobile_number_sso,
                          social_sso_user_id: this.socialId
                      };
                      this.registrationWithSso(userData);
                  } else{
                      this.input.user_email = this.email;
                      $(".get-otp").hide();
                      $(".signup-google-otp").show();
                  }
              } else {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          social_sso_user_id: this.socialId
                      };
                      this.registrationWithSso(userData);
                  } else {
                      $(".regd-form").hide();
                      $(".signup-google-otp").show();
                  }
              }
          } catch (error) {
              // Handle sign-in error
              console.error("Sign-in error:", error);
          }
      },

     async appleSignIn() {
          const provider = new OAuthProvider('apple.com');
          const auth = getAuth();
          
          // Set custom parameters
          provider.setCustomParameters({
              prompt: 'select_account'
          });
          
          // Add scopes
          provider.addScope('email');
          provider.addScope('name');
          
          try {
              // Use await to wait for the signInWithPopup to complete
              const result = await signInWithPopup(auth, provider);
              
              // Signed in successfully
              const user = result.user;
              //console.log("Signed in user:", result);
              this.userName = result.user.displayName;
              this.email = result.user.email;
              this.socialId = result.user.uid;
              this.registration_mode = "Apple SSO";
              
              if (!this.email || this.otpSettingEnabled) {
                  let checkEndUserPayload = {
                      user_email: this.email,
                      social_sso_user_id: this.socialId
                  };
                  //console.log(checkEndUserPayload);
      
                  // Await the checkEndUserExist function
                  const res = await checkEndUserExist(checkEndUserPayload);
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      this.endUserExist = res.data.data.is_end_user_exists;
                      if(this.endUserExist){
                          this.email = res.data.data.email;
                          this.mobile_number_sso = res.data.data.mobile;
                      }  
                  }
              }
              
              if (this.otpSettingEnabled) {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          mobile:this.mobile_number_sso,
                          social_sso_user_id: this.socialId
                      };
                      this.registrationWithSso(userData);
                  } else{
                      this.input.user_email = this.email;
                      $(".get-otp").hide();
                      $(".signup-google-otp").show();
                  }
              } else {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          social_sso_user_id: this.socialId
                      };
                      this.registrationWithSso(userData);
                  } else {
                      $(".regd-form").hide();
                      $(".signup-google-otp").show();
                  }
              }
          } catch (error) {
              // Handle sign-in error
              console.error("Sign-in error:", error);
          }
      },

     async facebookSignIn() {
          const provider = new FacebookAuthProvider();
          const auth = getAuth();

          // Set custom parameters
          provider.setCustomParameters({
              prompt: 'select_account'
          });

          provider.addScope('email');

          provider.setCustomParameters({
              'display': 'popup'
            });
          
          try {
              // Use await to wait for the signInWithPopup to complete
              const result = await signInWithPopup(auth, provider);
              
              // Signed in successfully
              const user = result.user;
              //console.log("Signed in user:", result);
              this.userName = result.user.displayName;
              this.email = result.user.email;
              this.socialId = result.user.uid;
              this.registration_mode = "Facebook SSO";
              
              if (!this.email || this.otpSettingEnabled) {
                  let checkEndUserPayload = {
                      user_email: this.email,
                      social_sso_user_id: this.socialId
                  };
                  //console.log(checkEndUserPayload);
      
                  // Await the checkEndUserExist function
                  const res = await checkEndUserExist(checkEndUserPayload);
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      this.endUserExist = res.data.data.is_end_user_exists;
                      if(this.endUserExist){
                          this.email = res.data.data.email;
                          this.mobile_number_sso = res.data.data.mobile;
                      } 
                  }
              }
              
              if (this.otpSettingEnabled) {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          mobile:this.mobile_number_sso,
                          social_sso_user_id: this.socialId
                      };
                      this.registrationWithSso(userData);
                  } else{
                      this.input.user_email = this.email;
                      $(".get-otp").hide();
                      $(".signup-google-otp").show();
                  }
              } else {
                  if (this.endUserExist) {
                      let userData = {
                          username: this.userName,
                          user_email: this.email,
                          authentication_mode: this.registration_mode,
                          social_sso_user_id: this.socialId
                      };
                      this.registrationWithSso(userData);
                  } else {
                      $(".regd-form").hide();
                      $(".signup-google-otp").show();
                  }
              }
          } catch (error) {
              // Handle sign-in error
              console.error("Sign-in error:", error);
          }
      },

      registrationWithSso(userData){
          ssoLogin(userData).then((res) => {
              if (res.data.code === 200 && res.data.status === "SUCCESS") {
                  localStorage.setItem(
                      "end_user_access_token",
                      res.data.data.access_token
                  );
                  localStorage.setItem(
                      "end_user_reload_token",
                      res.data.data.refresh_token
                  );
                  Toast.fire({
                      icon: "success",
                      text: res.data.message,
                  });
                  getUserDetails().then((userData) => {
                      if (userData.data && userData.data.code == 200) {
                          var userProfile =
                              userData.data.data.getUserDetails[0];
                          localStorage.setItem("isloggedin", "true");
                          setCookie('isloggedin', 'true');
                          localStorage.setItem(
                              "user",
                              JSON.stringify(userProfile)
                          );
                          this.checkUserSubscription();
                      }
                  });  
              } else {
                  $('#validateOtpButton').css('pointer-events','');
                  //console.log("error", res.data.message);
                  Toast.fire({
                      icon: "error",
                      title: "Error",
                      text: res.data.message,
                  });
              }
          }).catch((err) => {
              $('#validateOtpButton').css('pointer-events','');
              console.log("error", err);
          });    
      },

      getOtpRegistraionForSso(){
          if(this.validateSsoPopupForm()){
              if(this.input.user_email){
                  this.email = this.input.user_email;
              }
              let getOtpPayload = {
                  otp_request_event_type: 'registration',
                  otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                  otp_request_mobile: this.selectedCountry.concat(this.input.mobile_number),
                  otp_application_id:'end_user',
                  otp_request_sso:true,
                  sso_email: this.email
              };
              //console.log(getOtpPayload);
              // this.isChecked = false;
              sendOtp(getOtpPayload).then((res) => {
                  if (res.data.code == 200 && res.data.status == "SUCCESS") {
                      Toast.fire({
                          icon: "success",
                          title: "OTP sent Successfully",
                          text: res.data.message,
                      });
                      this.is_sso = true ;
                      this.selectCountry = this.selectedCountry;
                      //console.log(this.selectCountry,"this.selectCountry");
                          $(".signup-google-otp").hide();
                          $(".verify-otp").show();
                          const inputs = document.querySelectorAll(".otp-digit");
                          inputs[0].focus();
                          this.countdown(this.otp_time_interval);//ER-106410
                      console.log(res);
                  } else {
                      
                      if(res.data.message.includes(this.message)){
                          this.enableResendButton = true;
                          clearInterval(timer1);
                          $(".get-otp").hide();
                          $(".verify-otp").show();
                          const inputs = document.querySelectorAll(".otp-digit");
                          inputs[0].focus();
                      }else{
                          Toast.fire({
                              icon: "error",
                              title: res.data.status,
                              text: res.data.message,
                          });
                      }
                      
                  }
              })
              .catch((err) => {
                  Toast.fire({
                      icon: "error",
                      title: err.response.data.status,
                      text: err.response.data.message,
                  });
              });
          }
          
      },

      registrationWithoutSsoForOtp(userData){
          registerUser(userData).then((res) => {
              if (res.data.code === 200 && res.data.status === "SUCCESS") {
                  localStorage.setItem(
                      "end_user_access_token",
                      res.data.data.access_token
                  );
                  localStorage.setItem(
                      "end_user_reload_token",
                      res.data.data.refresh_token
                  );
                  Toast.fire({
                      icon: "success",
                      text: res.data.message,
                  });
                  getUserDetails().then((userData) => {
                      if (userData.data && userData.data.code == 200) {
                          var userProfile =
                              userData.data.data.getUserDetails[0];
                          localStorage.setItem("isloggedin", "true");
                          setCookie('isloggedin', 'true');
                          localStorage.setItem(
                              "user",
                              JSON.stringify(userProfile)
                          );
                          this.checkUserSubscription();
                      }
                  });  
              } else {
                  $('#validateOtpButton').css('pointer-events','');
                  Toast.fire({
                      icon: "error",
                      title: "Error",
                      text: res.data.message,
                  });
              }
          }).catch((err) => {
              $('#validateOtpButton').css('pointer-events','');
              console.log("error", err);
          });    
      },

      validateSsoPopupForm(){
          let status = true;
          if(this.muviAuthSettingType !== '3' && this.muviAuthSettingType !== '34'){
              if (!this.input.user_email.length) {
                  this.errorMsgs[0] = i18n("Email field is required");
                  status = false;
              } else if (
                  !this.input.user_email.match(
                      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9À-ÿ]+\.)+[a-zA-ZÀ-ÿ]{2,}))$/
                  )
              ) {
                  this.errorMsgs[0] = i18n("Please enter a valid email");
                  status = false;
              } else {
                  this.errorMsgs[0] = "";
              }   
          }
          
          if(this.otpSettingEnabled){
              if (!this.input.mobile_number.length) {
                  this.errorMsgs[1] = i18n("Mobile field is required");
                  status = false;
              } else if (!this.input.mobile_number.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)) {
                  this.errorMsgs[1] = i18n("Please enter a valid mobile number");;
                  status = false;
              }else {
                  this.errorMsgs[1]="";
              }
          }
          return status;
      },

      getOtpForRegThroughEmailWithSso() {
          if(this.validateSsoPopupForm()){
              if(this.input.user_email){
                  this.email = this.input.user_email;
              }
              let getOtpPayload = {
                  otp_request_event_type: 'registration',
                  otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                  otp_request_email: this.input.user_email,
                  otp_application_id:'end_user',
                  username: this.userName
              };
              //console.log(getOtpPayload);
              // this.isChecked = false;
              sendOtp(getOtpPayload).then((res) => {
                  if (res.data.code == 200 && res.data.status == "SUCCESS") {
                      this.is_sso = true ;
                      Toast.fire({
                          icon: "success",
                          title: "OTP sent Successfully",
                          text: res.data.message,
                      });
  
                      $(".signup-google-otp").hide();
                      $(".verify-otp").show();
                      const inputs = document.querySelectorAll(".otp-digit");
                      inputs[0].focus();
                      this.countdown(this.otp_time_interval);//ER-106410
                      //console.log(res);
                  } else { 
                      if(res.data.message.includes(this.message)){
                          this.enableResendButton = true;
                          clearInterval(timer1);
                          $(".signup-google-otp").hide();
                          $(".verify-otp").show();
                          const inputs = document.querySelectorAll(".otp-digit");
                          inputs[0].focus();
                      }else{
                          Toast.fire({
                              icon: "error",
                              title: res.data.status,
                              text: res.data.message,
                          });
                      }
                      
                  }
              })
              .catch((err) => {
                  Toast.fire({
                      icon: "error",
                      title: err.response.data.status,
                      text: err.response.data.message,
                  });
              });
          }

      },   
  },
  template: /*html*/ `
  <vd-component class="vd register-four" type="register-four">
  <section class="header" style="background: transparent;">
      <div class="container-fluid plr-65">
          <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <nav class="navbar navbar-expand-lg navbar-light flex-nowrap p-0 ">
                
                                       <a v-if="logo_details['logo']"  class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                     :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                  <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="getRootUrl() +'img/garnetLogo.png'"
                     alt="Garnet" /></a> 
                      
                    </nav>
              </div>
          </div>
      </div>
  </section>
<div class="main-container ptb-10 mh-750">
<section class="box-section">

  <div class="sign-first mobile-input regd-form" v-if="otpSettingEnabled==false">
    <div class="all-content">
      <h2 class="heading-h2"><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param>
      </h2>
      <div class="social-buttons" v-if="google_sso_enabled  || facebook_sso_enabled || apple_sso_enabled">
        <button class="social-btn" v-if="google_sso_enabled" @click="googleSignIn">
          <span class="span-svg">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 9.81836V14.4656H18.4582C18.1746 15.9602 17.3236 17.2257 16.0472 18.0766L19.9417 21.0984C22.2108 19.0039 23.5199 15.9276 23.5199 12.273C23.5199 11.4221 23.4436 10.6039 23.3017 9.81849L12 9.81836Z"
                fill="#4285F4" />
              <path
                d="M5.27461 14.2842L4.39625 14.9566L1.28711 17.3783C3.26165 21.2947 7.30862 24.0002 11.9995 24.0002C15.2394 24.0002 17.9557 22.9311 19.9412 21.0984L16.0467 18.0765C14.9776 18.7965 13.614 19.2329 11.9995 19.2329C8.87951 19.2329 6.22868 17.1275 5.27952 14.2911L5.27461 14.2842Z"
                fill="#34A853" />
              <path
                d="M1.28718 6.62158C0.469042 8.23606 0 10.0579 0 11.9997C0 13.9415 0.469042 15.7633 1.28718 17.3778C1.28718 17.3886 5.27997 14.2796 5.27997 14.2796C5.03998 13.5596 4.89812 12.796 4.89812 11.9996C4.89812 11.2031 5.03998 10.4395 5.27997 9.71951L1.28718 6.62158Z"
                fill="#FBBC05" />
              <path
                d="M11.9997 4.77818C13.767 4.77818 15.3379 5.38907 16.5925 6.56727L20.0288 3.13095C17.9452 1.18917 15.2398 0 11.9997 0C7.30887 0 3.26165 2.69454 1.28711 6.62183L5.27978 9.72001C6.22882 6.88362 8.87976 4.77818 11.9997 4.77818Z"
                fill="#EA4335" />
            </svg>
          </span>
          <vd-component-param type="label52" v-html="i18n($attrs['label52'])"></vd-component-param>

        </button>
        <button class="social-btn" v-if="facebook_sso_enabled" @click="facebookSignIn">
          <span class="span-svg">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_1019_8818)">
                <path
                  d="M23.25 11.625C23.25 17.4375 18.9844 22.2656 13.4062 23.1094V15H16.125L16.6406 11.625H13.4062V9.46875C13.4062 8.53125 13.875 7.64062 15.3281 7.64062H16.7812V4.78125C16.7812 4.78125 15.4688 4.54688 14.1562 4.54688C11.5312 4.54688 9.79688 6.1875 9.79688 9.09375V11.625H6.84375V15H9.79688V23.1094C4.21875 22.2656 0 17.4375 0 11.625C0 5.20312 5.20312 0 11.625 0C18.0469 0 23.25 5.20312 23.25 11.625Z"
                  fill="#1877F2" />
              </g>
              <defs>
                <clipPath id="clip0_1019_8818">
                  <rect width="24" height="24" fill="white" />
                </clipPath>
              </defs>
            </svg>
          </span>
          <vd-component-param type="label63"
            v-html="i18n($attrs['label63'])"></vd-component-param>
        </button>
        <button class="social-btn" v-if="apple_sso_enabled" @click="appleSignIn">
        <span class="span-svg">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M13.0709 3.19287C13.8 2.34788 14.2914 1.17098 14.1569 0C13.1063 0.04 11.8352 0.671147 11.0819 1.51514C10.4054 2.26413 9.81484 3.4609 9.97359 4.60889C11.1456 4.69588 12.3418 4.03885 13.0709 3.19287ZM15.699 10.625C15.7283 13.652 18.4697 14.6589 18.5 14.6719C18.4778 14.7429 18.0622 16.1066 17.056 17.5166C16.1854 18.7346 15.2824 19.9476 13.8596 19.9736C12.4621 19.9986 12.0122 19.1797 10.4135 19.1797C8.81577 19.1797 8.31624 19.9475 6.9936 19.9985C5.62039 20.0475 4.5738 18.6808 3.6971 17.4668C1.90323 14.9838 0.533065 10.4501 2.37344 7.39014C3.28756 5.87116 4.92064 4.90779 6.69428 4.88379C8.04221 4.85879 9.31531 5.75293 10.1394 5.75293C10.9636 5.75293 12.5107 4.67794 14.1367 4.83594C14.8172 4.86294 16.7284 5.09885 17.955 6.81982C17.8559 6.87882 15.6747 8.09504 15.699 10.625Z"
              fill="white"></path>
          </svg>
        </span>
        <vd-component-param type="label61" v-html="i18n($attrs['label61'])"></vd-component-param>
        </button>
      </div>
      <div class="input-section">
        <div class="mobile-input-container vd-form">
          <input vd-readonly="true" type="text" @keyup.enter="submitRegisterForm" v-model="input.first_name"
            class="enter-input vd-component-attr" vd-component-attr-placeholder="label9"
            :placeholder=i18n($attrs['label9']) vd-component-attr-title="label14" :title=i18n($attrs['label14'])
            autocomplet="off" :class="nameFiledNotValidate ? '_required' : ''">
        </div>
        <span v-if="errors.username" class="validationError mt-min10">{{ errors.username }}</span>

        <div class="mobile-input-container vd-form">
          <input vd-readonly="true" type="text" @keyup.enter="submitRegisterForm" v-model="input.last_name"
            class="form-control enter-input vd-component-attr" vd-component-attr-placeholder="label10"
            :placeholder=i18n($attrs['label10']) vd-component-attr-title="label15" :title=i18n($attrs['label15'])
            autocomplet="off" :class="lastnameFiledNotValidate ? '_required' : ''">
        </div>
        <span v-if="errors.last_name" class="validationError mt-min10">{{errors.last_name }}</span>
        <div class="mobile-input-container vd-form">
          <input vd-readonly="true" type="text" @keyup.enter="submitRegisterForm"
            class="form-control enter-input vd-component-attr" v-model="input.user_email"
            vd-component-attr-placeholder="label11" :placeholder=i18n($attrs['label11'])
            vd-component-attr-title="label16" :title=i18n($attrs['label16']) autocomplete="off"
            :class=" emailFieldNotValidate ? '_required' : ''">
        </div>
        <span v-if="errors.user_email" class="validationError mt-min10">{{ errors.user_email }}</span>
        <div class="mobile-input-container position-relative vd-form">

          <input vd-readonly="true" id="Password-old" @keyup.enter="submitRegisterForm"
            v-bind:type="[showPassword ? 'text' : 'password']" v-model="input.password"
            class="form-control enter-input pr-46 vd-component-attr" vd-component-attr-placeholder="label12"
            :placeholder=i18n($attrs['label12']) vd-component-attr-title="label17" :title=i18n($attrs['label17'])
            autocomplete="off" :class="passwordFieldNotValidate ? '_required' : ''">


          <button type="button" class="showhide-pwd-btn" id="showhide-pwd-btnOld"
            @click="showPassword = !showPassword">
            <svg v-if="!showPassword" class="closeEye" xmlns="http://www.w3.org/2000/svg" width="18" height="18"
              viewBox="0 0 18 18" fill="none">
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M17.6652 7.37587C17.8993 7.52223 17.9705 7.8307 17.8242 8.06487C17.2831 8.93052 16.6369 9.71486 15.9004 10.393L17.4149 11.9075C17.6102 12.1028 17.6102 12.4194 17.4149 12.6147C17.2197 12.8099 16.9031 12.8099 16.7078 12.6147L15.1308 11.0376C14.1421 11.7888 13.0218 12.3631 11.7987 12.7125L12.3631 14.819C12.4346 15.0858 12.2763 15.3599 12.0096 15.4314C11.7428 15.5029 11.4687 15.3446 11.3972 15.0779L10.8241 12.9387C10.2355 13.0446 9.62656 13.0999 9.00016 13.0999C8.37376 13.0999 7.76483 13.0446 7.17623 12.9387L6.60313 15.0778C6.53167 15.3446 6.25751 15.5029 5.99077 15.4314C5.72404 15.36 5.56574 15.0858 5.6372 14.8191L6.20156 12.7125C4.97845 12.3631 3.85816 11.7888 2.86952 11.0376L1.29246 12.6146C1.0972 12.8099 0.780619 12.8099 0.585357 12.6146C0.390094 12.4194 0.390094 12.1028 0.585357 11.9075L2.09991 10.393C1.36345 9.71484 0.717194 8.93051 0.176166 8.06487C0.0298103 7.8307 0.100996 7.52223 0.335164 7.37587C0.569332 7.22952 0.877807 7.3007 1.02416 7.53487C1.60553 8.46505 2.31593 9.28806 3.13336 9.97003C3.14483 9.97874 3.15601 9.98801 3.16686 9.99785C4.76179 11.3163 6.76015 12.0999 9.00016 12.0999C12.408 12.0999 15.2566 10.2862 16.9762 7.53487C17.1225 7.3007 17.431 7.22952 17.6652 7.37587Z"
                fill="#C1C1C1" />
            </svg>
            <svg v-if="showPassword" class="openEye" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
              viewBox="0 0 20 20" fill="none">
              <path
                d="M0.833496 10.0002C0.833496 10.0002 4.16683 3.3335 10.0002 3.3335C15.8335 3.3335 19.1668 10.0002 19.1668 10.0002C19.1668 10.0002 15.8335 16.6668 10.0002 16.6668C4.16683 16.6668 0.833496 10.0002 0.833496 10.0002Z"
                stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
              <path
                d="M10 12.5C11.3807 12.5 12.5 11.3807 12.5 10C12.5 8.61929 11.3807 7.5 10 7.5C8.61929 7.5 7.5 8.61929 7.5 10C7.5 11.3807 8.61929 12.5 10 12.5Z"
                stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </button>
        </div>
        <span v-if="errors.password" class="validationError mt-min10">{{ errors.password }}</span>
        <div class="mobile-input-container position-relative vd-form">
          <input id="Password-new" vd-readonly="true" @keyup.enter="submitRegisterForm"
            v-bind:type="[showConfPassword ? 'text' : 'password']" v-model="input.confpassword"
            class="form-control enter-input pr-46 vd-component-attr" vd-component-attr-placeholder="label13"
            :placeholder=i18n($attrs['label13']) vd-component-attr-title="label18" :title=i18n($attrs['label18'])
            @copy.prevent @paste.prevent @cut.prevent autocomplete="off"
            :class="confirmPwdFieldNotValidate ? '_required' : ''">

          <button type="button" class="showhide-pwd-btn" id="showhide-pwd-btnNew"
            @click="showConfPassword = !showConfPassword">
            <svg v-if="!showConfPassword" class="closeEye" xmlns="http://www.w3.org/2000/svg" width="18" height="18"
              viewBox="0 0 18 18" fill="none">
              <path fill-rule="evenodd" clip-rule="evenodd"
                d="M17.6652 7.37587C17.8993 7.52223 17.9705 7.8307 17.8242 8.06487C17.2831 8.93052 16.6369 9.71486 15.9004 10.393L17.4149 11.9075C17.6102 12.1028 17.6102 12.4194 17.4149 12.6147C17.2197 12.8099 16.9031 12.8099 16.7078 12.6147L15.1308 11.0376C14.1421 11.7888 13.0218 12.3631 11.7987 12.7125L12.3631 14.819C12.4346 15.0858 12.2763 15.3599 12.0096 15.4314C11.7428 15.5029 11.4687 15.3446 11.3972 15.0779L10.8241 12.9387C10.2355 13.0446 9.62656 13.0999 9.00016 13.0999C8.37376 13.0999 7.76483 13.0446 7.17623 12.9387L6.60313 15.0778C6.53167 15.3446 6.25751 15.5029 5.99077 15.4314C5.72404 15.36 5.56574 15.0858 5.6372 14.8191L6.20156 12.7125C4.97845 12.3631 3.85816 11.7888 2.86952 11.0376L1.29246 12.6146C1.0972 12.8099 0.780619 12.8099 0.585357 12.6146C0.390094 12.4194 0.390094 12.1028 0.585357 11.9075L2.09991 10.393C1.36345 9.71484 0.717194 8.93051 0.176166 8.06487C0.0298103 7.8307 0.100996 7.52223 0.335164 7.37587C0.569332 7.22952 0.877807 7.3007 1.02416 7.53487C1.60553 8.46505 2.31593 9.28806 3.13336 9.97003C3.14483 9.97874 3.15601 9.98801 3.16686 9.99785C4.76179 11.3163 6.76015 12.0999 9.00016 12.0999C12.408 12.0999 15.2566 10.2862 16.9762 7.53487C17.1225 7.3007 17.431 7.22952 17.6652 7.37587Z"
                fill="#C1C1C1" />
            </svg>
            <svg v-if="showConfPassword" class="openEye" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
              viewBox="0 0 20 20" fill="none">
              <path
                d="M0.833496 10.0002C0.833496 10.0002 4.16683 3.3335 10.0002 3.3335C15.8335 3.3335 19.1668 10.0002 19.1668 10.0002C19.1668 10.0002 15.8335 16.6668 10.0002 16.6668C4.16683 16.6668 0.833496 10.0002 0.833496 10.0002Z"
                stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
              <path
                d="M10 12.5C11.3807 12.5 12.5 11.3807 12.5 10C12.5 8.61929 11.3807 7.5 10 7.5C8.61929 7.5 7.5 8.61929 7.5 10C7.5 11.3807 8.61929 12.5 10 12.5Z"
                stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </button>
        </div>
        <span v-if="errors.confpassword" class="validationError mt-min10">{{ errors.confpassword }}</span>

        <div class="otp-btn-div">
          <button id="regdFormButton" type="button" vd-node="styleOnly" vd-readonly="true"
            style="text-transform: none; display:none;" class="common-btn blue" @click="submitRegisterForm">
            <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
          </button>
          <button id="nextButton" type="button" vd-node="styleOnly" vd-readonly="true"
            style="text-transform: none; display:none;" class="common-btn blue" @click="getOtpForRegThroughEmail">
            <vd-component-param type="label47" v-html="i18n($attrs['label47'])"></vd-component-param>
          </button>
        </div>

        <div class="create-account-div">
          <span class="no-account"><vd-component-param type="label6"
              v-html="i18n($attrs['label6'])"></vd-component-param> </span>
          <span class="span-create-account">
            <vd-component-param type="label7"
                v-html="i18n($attrs['label7'])"></vd-component-param>
          </span>
        </div>
      </div>
    </div>
  </div>

  <!-- From section for Mobile OTP end here-->
  <!--Verify otp Section Start Here-->
  <div class="sign-first get-otp mobile-input" v-else>
    <div class="all-content">
      <h2 class="heading-h2"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
      </h2>
      <div class="social-buttons" v-if="google_sso_enabled  || facebook_sso_enabled || apple_sso_enabled">
        <button class="social-btn" v-if="google_sso_enabled" @click="googleSignIn">
          <span class="span-svg">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 9.81836V14.4656H18.4582C18.1746 15.9602 17.3236 17.2257 16.0472 18.0766L19.9417 21.0984C22.2108 19.0039 23.5199 15.9276 23.5199 12.273C23.5199 11.4221 23.4436 10.6039 23.3017 9.81849L12 9.81836Z"
                fill="#4285F4" />
              <path
                d="M5.27461 14.2842L4.39625 14.9566L1.28711 17.3783C3.26165 21.2947 7.30862 24.0002 11.9995 24.0002C15.2394 24.0002 17.9557 22.9311 19.9412 21.0984L16.0467 18.0765C14.9776 18.7965 13.614 19.2329 11.9995 19.2329C8.87951 19.2329 6.22868 17.1275 5.27952 14.2911L5.27461 14.2842Z"
                fill="#34A853" />
              <path
                d="M1.28718 6.62158C0.469042 8.23606 0 10.0579 0 11.9997C0 13.9415 0.469042 15.7633 1.28718 17.3778C1.28718 17.3886 5.27997 14.2796 5.27997 14.2796C5.03998 13.5596 4.89812 12.796 4.89812 11.9996C4.89812 11.2031 5.03998 10.4395 5.27997 9.71951L1.28718 6.62158Z"
                fill="#FBBC05" />
              <path
                d="M11.9997 4.77818C13.767 4.77818 15.3379 5.38907 16.5925 6.56727L20.0288 3.13095C17.9452 1.18917 15.2398 0 11.9997 0C7.30887 0 3.26165 2.69454 1.28711 6.62183L5.27978 9.72001C6.22882 6.88362 8.87976 4.77818 11.9997 4.77818Z"
                fill="#EA4335" />
            </svg>
          </span>
          <vd-component-param type="label52" v-html="i18n($attrs['label52'])"></vd-component-param>
        </button>
        <button class="social-btn" v-if="facebook_sso_enabled" @click="facebookSignIn">
          <span class="span-svg">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_1019_8818)">
                <path
                  d="M23.25 11.625C23.25 17.4375 18.9844 22.2656 13.4062 23.1094V15H16.125L16.6406 11.625H13.4062V9.46875C13.4062 8.53125 13.875 7.64062 15.3281 7.64062H16.7812V4.78125C16.7812 4.78125 15.4688 4.54688 14.1562 4.54688C11.5312 4.54688 9.79688 6.1875 9.79688 9.09375V11.625H6.84375V15H9.79688V23.1094C4.21875 22.2656 0 17.4375 0 11.625C0 5.20312 5.20312 0 11.625 0C18.0469 0 23.25 5.20312 23.25 11.625Z"
                  fill="#1877F2" />
              </g>
              <defs>
                <clipPath id="clip0_1019_8818">
                  <rect width="24" height="24" fill="white" />
                </clipPath>
              </defs>
            </svg>
          </span>
          <vd-component-param type="label62"
            v-html="i18n($attrs['label62'])"></vd-component-param>
        </button>
        <button class="social-btn" v-if="apple_sso_enabled" @click="appleSignIn">
        <span class="span-svg">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M13.0709 3.19287C13.8 2.34788 14.2914 1.17098 14.1569 0C13.1063 0.04 11.8352 0.671147 11.0819 1.51514C10.4054 2.26413 9.81484 3.4609 9.97359 4.60889C11.1456 4.69588 12.3418 4.03885 13.0709 3.19287ZM15.699 10.625C15.7283 13.652 18.4697 14.6589 18.5 14.6719C18.4778 14.7429 18.0622 16.1066 17.056 17.5166C16.1854 18.7346 15.2824 19.9476 13.8596 19.9736C12.4621 19.9986 12.0122 19.1797 10.4135 19.1797C8.81577 19.1797 8.31624 19.9475 6.9936 19.9985C5.62039 20.0475 4.5738 18.6808 3.6971 17.4668C1.90323 14.9838 0.533065 10.4501 2.37344 7.39014C3.28756 5.87116 4.92064 4.90779 6.69428 4.88379C8.04221 4.85879 9.31531 5.75293 10.1394 5.75293C10.9636 5.75293 12.5107 4.67794 14.1367 4.83594C14.8172 4.86294 16.7284 5.09885 17.955 6.81982C17.8559 6.87882 15.6747 8.09504 15.699 10.625Z"
              fill="white"></path>
          </svg>
        </span>
        <vd-component-param type="label60" v-html="i18n($attrs['label60'])"></vd-component-param>
        </button>
      </div>
      <div class="input-section">
        <!-- <div class="or-text">
        Or create your account using your 
  phone number
      </div> -->
        <div class="mobile-input-container vd-form">
          <input vd-readonly="true" type="text" @keyup.enter="getOtpRegistraion" v-model="input.first_name"
            class="form-control enter-input vd-component-attr" vd-component-attr-placeholder="label32"
            :placeholder=i18n($attrs['label32']) vd-component-attr-title="label36" :title=i18n($attrs['label36'])
            autocomplet="off" :class="nameFiledNotValidate ? '_required' : ''">
        </div>
        <span v-if="errors.username" class="validationError mt-min10">{{ errors.username }}</span>

        <div class="mobile-input-container vd-form">
          <input vd-readonly="true" type="text" @keyup.enter="getOtpRegistraion" v-model="input.last_name"
            class="form-control enter-input vd-component-attr" vd-component-attr-placeholder="label33"
            :placeholder=i18n($attrs['label33']) vd-component-attr-title="label37" :title=i18n($attrs['label37'])
            autocomplet="off" :class="lastnameFiledNotValidate ? '_required' : ''">
        </div>
        <span v-if="errors.last_name" class="validationError mt-min10">{{errors.last_name }}</span>

        <div class="mobile-input-container">
          <select class="selectpicker select-countrycode" aria-label="Default select example" id="selectpicker1"
            v-model="selectedCountry">
            <option class="no-check" v-for="(countryDetail,i) in country_details" :key="i"
              :value="countryDetail.phone_code" :data-subtext=" countryDetail.name">{{countryDetail.phone_code}}
            </option>
          </select>
          <input @keyup.enter="getOtpRegistraion" v-model="input.mobile_number" type="text"
            class="form-control enter-input vd-component-attr" vd-component-attr-placeholder="label35"
            :placeholder=i18n($attrs['label35']) vd-component-attr-title="label39" :title=i18n($attrs['label39'])
            :class="mobile_field ? '_required' : ''" required id="">
        </div>
        <span v-if="errors.mobile" class="validationError mt-min10">{{errors.mobile }}</span>
        <div class="mobile-input-container vd-form" v-if="muviAuthSettingType == '35'|| muviAuthSettingType == '34'">
          <input vd-readonly="true" type="text" @keyup.enter="getOtpRegistraion"
            class="form-control enter-input vd-component-attr" v-model="input.user_email"
            vd-component-attr-placeholder="label34" :placeholder=i18n($attrs['label34'])
            vd-component-attr-title="label38" :title=i18n($attrs['label38']) autocomplete="off"
            :class=" emailFieldNotValidate ? '_required' : ''">
        </div>
        <span v-if="(errors.user_email) && (muviAuthSettingType == '35'|| muviAuthSettingType == '34')"
          class="validationError mt-min10">{{ errors.user_email }}</span>
        <div class="otp-btn-div">
          <button vd-node="styleOnly" vd-readonly="true" type="button" style="text-transform: none;"
            @keyup.enter="getOtpRegistraion" class="get-otp-btn common-btn blue" @click="getOtpRegistraion">
            <vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param>
          </button>
        </div>

        <div class="create-account-div">
          <span class="no-account"><vd-component-param type="label27"
              v-html="i18n($attrs['label27'])"></vd-component-param>
          </span>
          <span  class="span-create-account">
            <a class="create-account-a" vd-node="link" href="/sign-in"> <vd-component-param type="label28"
                v-html="i18n($attrs['label28'])"></vd-component-param></a>
          </span>
        </div>
      </div>
    </div>
  </div>
  <div class="sign-second otp-verify verify-otp">
    <div class="otp-verify-content">
      <div class="otp-vc-first" v-if="!(isEmailVerificationDuringRegdEnable || ssoEmailverification)">
        <h2 class="heading-h2"> <vd-component-param type="label40"
            v-html="i18n($attrs['label40'])"></vd-component-param></h2>
        <div class="otpsent-to">
          <span class="sent-to-txt"><vd-component-param type="label25"
              v-html="i18n($attrs['label25'])"></vd-component-param></span>
          <span class="emailEdit">
            <span class="sent-to-mobile phone-countrycode">{{selectCountry}} {{mobile}}</span>
            <span class="editemail " id="edit-input-btn-sso" v-if="is_sso">
              <svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
                <path
                  d="M11.8333 2.00001C12.0084 1.82491 12.2163 1.68602 12.4451 1.59126C12.6738 1.4965 12.919 1.44772 13.1666 1.44772C13.4143 1.44772 13.6595 1.4965 13.8882 1.59126C14.117 1.68602 14.3249 1.82491 14.5 2.00001C14.6751 2.1751 14.814 2.38297 14.9087 2.61175C15.0035 2.84052 15.0523 3.08572 15.0523 3.33334C15.0523 3.58096 15.0035 3.82616 14.9087 4.05494C14.814 4.28371 14.6751 4.49158 14.5 4.66668L5.49998 13.6667L1.83331 14.6667L2.83331 11L11.8333 2.00001Z"
                  stroke="#bf000a" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            </span>
            <span class="editemail" v-else>
              <svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
                <path
                  d="M11.8333 2.00001C12.0084 1.82491 12.2163 1.68602 12.4451 1.59126C12.6738 1.4965 12.919 1.44772 13.1666 1.44772C13.4143 1.44772 13.6595 1.4965 13.8882 1.59126C14.117 1.68602 14.3249 1.82491 14.5 2.00001C14.6751 2.1751 14.814 2.38297 14.9087 2.61175C15.0035 2.84052 15.0523 3.08572 15.0523 3.33334C15.0523 3.58096 15.0035 3.82616 14.9087 4.05494C14.814 4.28371 14.6751 4.49158 14.5 4.66668L5.49998 13.6667L1.83331 14.6667L2.83331 11L11.8333 2.00001Z"
                  stroke="#bf000a" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            </span>
          </span>
        </div>
      </div>
      <div class="otp-vc-first" v-else>
        <h2 class="heading-h2"> <vd-component-param type="label40"
            v-html="i18n($attrs['label40'])"></vd-component-param></h2>
        <div class="otpsent-to">
          <span class="sent-to-txt"><vd-component-param type="label25"
              v-html="i18n($attrs['label25'])"></vd-component-param></span>
          <span class="emailEdit">
            <span class="sent-to-mobile ">{{mobile}}</span>
            <span class="editemail edit-input-btn" id="edit-input-btn-sso" v-if="is_sso">
              <svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
                <path
                  d="M11.8333 2.00001C12.0084 1.82491 12.2163 1.68602 12.4451 1.59126C12.6738 1.4965 12.919 1.44772 13.1666 1.44772C13.4143 1.44772 13.6595 1.4965 13.8882 1.59126C14.117 1.68602 14.3249 1.82491 14.5 2.00001C14.6751 2.1751 14.814 2.38297 14.9087 2.61175C15.0035 2.84052 15.0523 3.08572 15.0523 3.33334C15.0523 3.58096 15.0035 3.82616 14.9087 4.05494C14.814 4.28371 14.6751 4.49158 14.5 4.66668L5.49998 13.6667L1.83331 14.6667L2.83331 11L11.8333 2.00001Z"
                  stroke="#bf000a" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            </span>
            <span class="editemail" id="edit-input-btn-email-verification" v-else>
              <svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
                <path
                  d="M11.8333 2.00001C12.0084 1.82491 12.2163 1.68602 12.4451 1.59126C12.6738 1.4965 12.919 1.44772 13.1666 1.44772C13.4143 1.44772 13.6595 1.4965 13.8882 1.59126C14.117 1.68602 14.3249 1.82491 14.5 2.00001C14.6751 2.1751 14.814 2.38297 14.9087 2.61175C15.0035 2.84052 15.0523 3.08572 15.0523 3.33334C15.0523 3.58096 15.0035 3.82616 14.9087 4.05494C14.814 4.28371 14.6751 4.49158 14.5 4.66668L5.49998 13.6667L1.83331 14.6667L2.83331 11L11.8333 2.00001Z"
                  stroke="#bf000a" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            </span>
          </span>
        </div>
      </div>
      <div class="otp-vc-second" :style="{ 'display': !enableResendButton ? 'flex' : 'none' }">
        <div class="otp-timer">
          <span  id="countdown-timer"></span>
        </div>
        <!--OTP input start Here-->
        <div class="recived-code d-flex flex-wrap">
          <div class="code">
            <input type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitOne"
              maxlength="1">
            <input type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitTwo"
              disabled="true" maxlength="1">
            <input type="number" class="form-control otp-digit" id="" placeholder="" v-model="otpDigitThree"
              disabled="true" maxlength="1">
            <input @keyup.enter="validateOtpPart" type="number" class="form-control otp-digit" id="" placeholder=""
              v-model="otpDigitFour" disabled="true" maxlength="1">
          </div>
          <!--<div class="invalid-otp">
            <span>Incorrect OTP, please try again</span>
          </div>-->
          <div class="resend" :style="{ 'pointer-events': !enableResendButton ? 'none' : null }">
            <!--Get Code in time-->
            <div class="getcode text-right">
              <span class="not-get-otp"><vd-component-param type="label14"
                  v-html="i18n($attrs['label14'])"></vd-component-param></span>
              <a href="javascript:void(0);" class="resend-a"
                :style="{ 'pointer-events': enableResendButton ? '' : 'none' }"
                :style="{ 'cursor': enableResendButton ? '' : 'not-allowed !important' }"
                :style="{ 'opacity': enableResendButton ? '' : '0.5' }" href="javascript:void(0);"
                @click="resendOtp()">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_747_11578)">
                    <path d="M0.75 3V7.5H5.25" stroke="#bf000a" stroke-width="1.67" stroke-linecap="round"
                      stroke-linejoin="round" />
                    <path
                      d="M2.6325 11.2501C3.1188 12.6304 4.0405 13.8152 5.25874 14.6261C6.47698 15.437 7.92576 15.83 9.38679 15.7459C10.8478 15.6618 12.2419 15.1052 13.3591 14.1599C14.4763 13.2146 15.2559 11.9318 15.5807 10.5049C15.9054 9.07789 15.7576 7.58405 15.1595 6.24841C14.5614 4.91277 13.5454 3.80768 12.2646 3.09966C10.9839 2.39163 9.50768 2.11903 8.05851 2.32292C6.60934 2.52681 5.26568 3.19615 4.23 4.23008L0.75 7.50008"
                      stroke="#bf000a" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                  </g>
                  <defs>
                    <clipPath id="clip0_747_11578">
                      <rect width="18" height="18" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param>
              </a>
            </div>
            <!--Get Code in time-->

          </div>
        </div>
      </div>
      <div class="otp-vc-third">
        <button type="button" id="validateOtpButton" class="common-btn blue disabled-button otp-verify-btn"
          style="pointer-events: none;" @click="validateOtpPart">
          <vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param>
        </button>
      </div>

    </div>
  </div>



  <!--verify otp Section End Here-->
</section>
</div>
</vd-component>`,
};

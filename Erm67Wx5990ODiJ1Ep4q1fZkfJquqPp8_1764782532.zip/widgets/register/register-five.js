let {
    registerUser,
    getUserDetails,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    getEndUserRegdLoginSetting,
    // getVdConfig,
    getCountryCodes,
    sendOtp,
    resendOtp,
    validateOtp,
    ssoLogin,
    getSsoConfig,
    checkEndUserExist
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let {
    getRootUrl,
    getAsthuDomainUrl,
} = await import(window.importAssetJs('js/web-service-url.js'));
let {
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies,
    setCookie
} = await import(window.importAssetJs('js/main.js'));

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getAuth, GoogleAuthProvider,signInWithPopup, OAuthProvider, FacebookAuthProvider, linkWithCredential } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";

let timer1;

const { mapState} = Vuex;

export default {
    name: "register_five",

    data() {
        return {
            isMobileSignin: true,
            input: {
                first_name: "",
                last_name: "",
                user_email: "",
                password: "",
                confpassword: "",
                username: "",
                mobile_number: "",
                otpNumber1: "",
                otpNumber2: "",
                otpNumber3: "",
                otpNumber4: ""
            },
            errors: {},
            country_details: [],
            mobile_field: false,
            selTypeIndex: "",
            isFormValid: false,
            emailFieldNotValidate: false,
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            nameFiledNotValidate: false,
            lastnameFiledNotValidate: false,
            showPassword: false,
            showConfPassword: false,
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            countryCode: "US",
            selectedCountry: "+91",
            selectCountry: "",
            otpSettingEnabled: false,
            muviAuthEmailOptSettingList: ['3', '34', '35'],
            muviAuthSettingType: '',
            isEmailVerificationDuringRegdEnable: false,
            enableResendButton: false,
            timer1:null,
            google_sso:"G-Auth",
            apple_sso: "A-Auth",
            facebook_sso:"F-Auth",
            is_sso: false,
            sso_enabled: false,
            google_sso_enabled:false,
            apple_sso_enabled:false,
            facebook_sso_enabled:false,
            email:"",
            userName:"",
            registration_mode:"",
            otp_time_interval: 0,
            message: "You have exceeded the limit for resending the OTP",
            errorMsgs:[],
            socialId:"",
            endUserExist:true,
            mobile_number_sso:"",
            ssoEmailverification: false,
            credential:"",
            enableMultiProfile: 0
            
        };
    },
    computed: {
        username() {
            this.input.username = this.input.first_name;
            return this.input.username;
        },
        last_name() {
            return this.input.last_name;
        },
        user_email() {
            return this.input.user_email;
        },
        mobile() {
            return this.input.mobile_number;
        },
        password() {
            return this.input.password;
        },
        confirmPassword() {
            return this.input.confpassword;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
         })
    },
    watch: {
        username(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = i18n("First name field is required");
                this.nameFiledNotValidate = true;
            } else if (value.length < 2 || value.length > 30) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username =
                    i18n("Name should be between 2 to 30 charaters");
                this.nameFiledNotValidate = true;
            } else if (
                !value.match("^[A-Za-zÀ-ÿ0-9-]*$")
            ) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = i18n("Please enter a valid First name.");
                this.nameFiledNotValidate = true;
            } else {
                this.errors.username = null;
                this.nameFiledNotValidate = false;
                if (
                    this.errors.username !== undefined &&
                    this.errors.username == null &&
                    this.errors.user_email !== undefined &&
                    this.errors.user_email == null &&
                    this.errors.password !== undefined &&
                    this.errors.password == null &&
                    this.errors.confpassword !== undefined &&
                    this.errors.confpassword == null &&
                    this.input.selTypeIndex != ""
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        last_name(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = i18n("Last name field is required");
                this.lastnameFiledNotValidate = true;
                //this.errors.username = null;
            } else if (value.length < 2 || value.length > 30) {
                this.errors.valid = false;
                this.isFormValid = false;
                // this.errors.username = null;
                this.errors.last_name =
                    i18n("Name should be between 2 to 30 charaters");
                this.lastnameFiledNotValidate = true;
            } else if (
                !value.match("^[A-Za-zÀ-ÿ0-9-]*$")
            ) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = i18n("Please enter a valid Last name.");
                this.lastnameFiledNotValidate = true;
                // this.errors.username = null;
            } else {
                this.errors.last_name = null;
                this.lastnameFiledNotValidate = false;
                if (
                    this.errors.last_name !== undefined &&
                    this.errors.last_name == null &&
                    this.errors.user_email !== undefined &&
                    this.errors.user_email == null &&
                    this.errors.password !== undefined &&
                    this.errors.password == null &&
                    this.errors.confpassword !== undefined &&
                    this.errors.confpassword == null &&
                    this.input.selTypeIndex != ""
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        mobile(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.mobile = i18n("Mobile field is required");
                this.mobile_field = true;
                return;
            } else if (
                !value.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)
            ) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.mobile = i18n("Mobile field is required");;
                this.mobile_field = true;
            } else {
                this.errors.mobile = null;
                this.mobile_field = false;
            }


        },
        user_email(value) {
            if (this.muviAuthSettingType == "3" && (value == null || !value.length)) {
                this.errors.email = null;
                this.email_filed = false;
            } else {
                if (!value.length) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.user_email = i18n("Email field is required");
                    this.emailFieldNotValidate = true;
                } else if (!value.match(/^(?=.{1,64}@)[^@]+@([^@]{2,})+\.([^@.]{2,14})$/)) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.user_email = i18n("Please enter a valid email");
                    this.emailFieldNotValidate = true;
                } else {
                    this.errors.user_email = null;
                    this.emailFieldNotValidate = false;
                    if (
                        this.errors.username !== undefined &&
                        this.errors.username == null &&
                        this.errors.user_email !== undefined &&
                        this.errors.user_email == null &&
                        this.errors.password !== undefined &&
                        this.errors.password == null &&
                        this.errors.confpassword !== undefined &&
                        this.errors.confpassword == null &&
                        this.input.selTypeIndex != ""
                    ) {
                        this.errors.valid = true;
                        this.isFormValid = true;
                    }
                }
            }
        },
        password(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
            } else if (value.length < 8) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password =
                    i18n("Password should be more than 8 characters long.");
                this.passwordFieldNotValidate = true;
            } else if (value === this.input.confpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = null;
                this.passwordFieldNotValidate = true;
                this.errors.confpassword = null;
            } else {
                this.errors.password = null;
                this.passwordFieldNotValidate = false;
                if (value !== this.input.confpassword) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.confpassword = i18n("Passwords do not match");
                    this.confirmPwdFieldNotValidate = true;
                }
                if (
                    this.errors.username !== undefined &&
                    this.errors.username == null &&
                    this.errors.user_email !== undefined &&
                    this.errors.user_email == null &&
                    this.errors.password !== undefined &&
                    this.errors.password == null &&
                    this.errors.confpassword !== undefined &&
                    this.errors.confpassword == null &&
                    this.input.selTypeIndex != ""
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        confirmPassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = i18n("Confirm Password field is required");
                this.confirmPwdFieldNotValidate = true;
            } else if (value !== this.input.password) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = i18n("Passwords do not match");
                this.confirmPwdFieldNotValidate = true;
            } else {
                this.errors.confpassword = null;
                this.confirmPwdFieldNotValidate = false;
                if (
                    this.errors.username !== undefined &&
                    this.errors.username == null &&
                    this.errors.user_email !== undefined &&
                    this.errors.user_email == null &&
                    this.errors.password !== undefined &&
                    this.errors.password == null &&
                    this.errors.confpassword !== undefined &&
                    this.errors.confpassword == null &&
                    this.input.selTypeIndex != ""
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
    },
    created(){
        getSsoConfig().then((res) => {
            if (res.data.code === 200 && res.data.status === "SUCCESS") {
              var ssoConfiguration = res.data.data.getSsoConfigDetails;
              if(ssoConfiguration.length){
                  const firebaseConfigForGoogleSso = {
                    apiKey: ssoConfiguration[0].api_key,
                    authDomain: ssoConfiguration[0].auth_domain,
                    projectId: ssoConfiguration[0].project_id,
                    storageBucket: ssoConfiguration[0].storage_bucket,
                    messagingSenderId: ssoConfiguration[0].messaging_sender_id,
                    appId: ssoConfiguration[0].app_id
                  };
                  // Initialize Firebase
                  const app = initializeApp(firebaseConfigForGoogleSso);
              }else{
                console.log("Error in firebase config");
              }
            } else {
              console.log("Error in get sso config");
            }
        })
        .catch((err) => {
           console.log("Error during initializing firebase//////",err)
        });
    },
    beforeMount() {
        // JsLoadingOverlay.show();
        getEndUserRegdLoginSetting().then((res) => {
            if (res.data.code == 200 && res.data.data !== null) {
                const requireRegistrationAndLogin = parseInt(
                    res.data.data.sections[0].groups[0].nodes[0].node_value
                );
                const emailVerificationDuringRegd = parseInt(
                    res.data.data.sections[0].groups[2].nodes[5].node_value
                );
                this.enableMultiProfile = parseInt(
                    res.data.data.sections[0].groups[0].nodes[2].node_value
                );
                if (requireRegistrationAndLogin == 1) {

                    if (emailVerificationDuringRegd == 1) {
                        this.isEmailVerificationDuringRegdEnable = true;
                        $("#nextButton").css('display', '');
                    } else {
                        $("#regdFormButton").css('display', '');
                        //$("#nextButton").css('display','');
                    }
                }
                if (requireRegistrationAndLogin != 1) {
                    $("body").css("opacity", 0);
                    window.location.href = "/";
                }
            }
        });
    },
    updated(){
        $(".selectpicker").selectpicker("refresh");
    },
    async mounted() {
        this.gotoVerifyotp();
        this.selectDropdown();

        setTimeout(() => {
            $(".selectpicker").selectpicker();
            $(".selectpicker").selectpicker("refresh");
        }, 2000);
        $(".signup-google-otp").hide();

        $(document).on("click", ".edit-input-btn", function () {
            const button = document.querySelector(".otp-verify-btn");
            button.classList.add("disabled-button");
            $('#validateOtpButton').css('pointer-events','none');
            const inputs = document.querySelectorAll(".otp-digit");
            inputs[0].value = "";
            inputs[1].value = "";
            inputs[2].value = "";
            inputs[3].value = "";
            inputs[0].focus();
            if($(this).attr("id") == "edit-input-btn-email-verification"){
                $(".verify-otp").hide();
                $(".regd-form").show();
            }else if($(this).attr("id") == "edit-input-btn-sso"){
                $(".verify-otp").hide();
                $(".signup-google-otp").show();
            }else{
                $(".verify-otp").hide();
                $(".get-otp").show();
            }     
        });


        $(".otp-digit").bind("paste", function (e) {

            var pastedData = e.originalEvent.clipboardData.getData('text');
            if (pastedData) {
                const onlyContainsNumbers = (pastedData) => /^\d+$/.test(pastedData);
                if (onlyContainsNumbers(pastedData) && pastedData.length >= 4) {
                    var split = pastedData.split("");
                    // $("#inputbox").val( split[0])
                    // $("#textarea").val( split[1])
                    const inputs = document.querySelectorAll(".otp-digit");
                    inputs[0].value = "";
                    inputs[1].value = "";
                    inputs[2].value = "";
                    inputs[3].value = "";
                    inputs[0].value = split[0];
                    inputs[1].value = split[1];
                    inputs[2].value = split[2];
                    inputs[3].value = split[3];
                    const button = document.querySelector(".otp-verify-btn");
                    button.classList.remove("disabled-button");
                    $('#validateOtpButton').css('pointer-events','');
                }

                return false;
            }
        });



        JsLoadingOverlay.hide();
        getUserDetails().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                console.log(res.data.data.getUserDetails[0], "res.data.data.getUserDetails[0]");
                if (res.data.data.getUserDetails[0].muvi_auth_setting_type != null) {
                    this.otpSettingEnabled = this.muviAuthEmailOptSettingList.includes(res.data.data.getUserDetails[0].muvi_auth_setting_type);
                    console.log(this.otpSettingEnabled, "this.otpSettingEnabled");
                    localStorage.setItem('adminId', res.data.data.getUserDetails[0].user_uuid);
                    this.muviAuthSettingType = res.data.data.getUserDetails[0].muvi_auth_setting_type;
                    this.muviAuthEmailOptSettingType = this.muviAuthEmailOptSettingList.includes(this.muviAuthSettingType);
                    var sso_enabled_list = JSON.parse(res.data.data.getUserDetails[0].sso_enabled_list);
                    this.sso_enabled = sso_enabled_list.length != 0 ? true : false;
                    this.google_sso_enabled = sso_enabled_list.includes(this.google_sso);
                    this.apple_sso_enabled = sso_enabled_list.includes(this.apple_sso);
                    this.facebook_sso_enabled = sso_enabled_list.includes(this.facebook_sso);
                    this.otp_time_interval = res.data.data.getUserDetails[0].otp_time_interval * 60 *1000;
                    this.ssoEmailverification = this.sso_enabled && this.muviAuthSettingType === '1' ? true : false;

                }
            }
        });
        let userGeoLocation = getUserGeoLocationFromCookies();
        if (!userGeoLocation) {
            setUserGeoLocationOnCookies();
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        } else {
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        }
        this.countryCode = userGeoLocation.country_code;

        let isloggedIn = localStorage.getItem("isloggedin");
        if (isloggedIn) {
            window.location.href = "/home";
        }
        //logo url
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    methods: {
        getRootUrl,
        i18n,
        getAsthuDomainUrl,
        clearOtpValue() {
            const inputs = document.querySelectorAll(".otp-digit");
            inputs[0].value = "";
            inputs[1].value = "";
            inputs[2].value = "";
            inputs[3].value = "";

            inputs[0].focus();

        },
        gotoVerifyotp() {
            const inputs = document.querySelectorAll(".otp-digit");
            const button = document.querySelector(".otp-verify-btn");
            // iterate over all inputs
            inputs.forEach((input, index1) => {
                input.addEventListener("keyup", (e) => {
                    // This code gets the current input element and stores it in the currentInput variable
                    // This code gets the next sibling element of the current input element and stores it in the nextInput variable
                    // This code gets the previous siblinginput element of the current input element and stores it in the prevInput variable
                    const currentInput = input,
                        nextInput = input.nextElementSibling,
                        prevInput = input.previousElementSibling;

                    // if the value has more than one character then clear it
                    if (currentInput.value.length > 1) {
                        currentInput.value = "";
                        return;
                    }
                    // if the next input is disabled and the current value is not empty
                    //  enable the next input and focus on it
                    if (nextInput && currentInput.value !== "") {
                        nextInput.removeAttribute("disabled");
                        nextInput.focus();
                    }

                    // if the backspace key is pressed
                    if (e.key === "Backspace") {
                        input.value = "";
                        if (prevInput !== null) {
                            prevInput.focus();
                        } else {
                            currentInput.focus();
                        }
                    }
                    if (inputs[0].value !== "" && inputs[1].value !== "" && inputs[2].value !== "" && inputs[3].value !== "") {
                        button.classList.remove("disabled-button");
                        $('#validateOtpButton').css('pointer-events','');
                        return;
                    }
                    button.classList.add("disabled-button");
                    $('#validateOtpButton').css('pointer-events','none');
                });
            });

            //focus the first input which index is 0 on window load
            window.addEventListener("load", () => inputs[0].focus());
        },
        myPlanDetails() {
            getSubscriptionPlans(this.countryCode).then((res) => {
                if (res.data.code == 600 || res.data.status === "FAILED") {
                    window.location.href = "/home";
                } else if (
                    res.data.code == 200 &&
                    res.data.status === "SUCCESS"
                ) {
                    getEndUserRegdLoginSetting().then((res) => {
                        if (res.data.code == 200 && res.data.data !== null) {
                            this.userConfig =
                                res.data.data.sections[0].groups[0].nodes[1].node_value;
                            console.log("userConfig", this.userConfig);
                            window.location.href = "/all-plan";
                        }
                    });
                }
            });
        },
        checkMobileNum(value) {
            var re = new RegExp(/^(\+\d{1,3}[-]?)?\d{4,20}$|^$/); //biswa
            if (re.test(value)) {
                console.log("Valid");
                return true;
            } else {
                console.log("Invalid");
                return false;
            }
        },
        getOtpRegistraion() {
            if (!this.input.first_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = i18n("First name field is required");
                this.nameFiledNotValidate = true;
                return;
            } else {
                this.errors.username = null;
                this.nameFiledNotValidate = false;
            }

            if (!this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = i18n("Last name field is required");
                this.lastnameFiledNotValidate = true;
                return;
            } else {
                this.errors.last_name = null;
                this.lastnameFiledNotValidate = false;
            }
            if (this.muviAuthSettingType == "34" || this.muviAuthSettingType == "3") {
                this.errors.email = null;
                this.email_filed = false;
            } else {
                if (!this.input.user_email.length) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.user_email = i18n("Email field is required");
                    this.emailFieldNotValidate = true;
                    return;
                } else if (
                    !this.input.user_email.match(
                        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9À-ÿ]+\.)+[a-zA-ZÀ-ÿ]{2,}))$/
                    )
                ) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.user_email = i18n("Please enter a valid email");
                    this.emailFieldNotValidate = true;
                    return;
                } else {
                    this.errors.user_email = null;
                    this.emailFieldNotValidate = false;
                }
            }
            if (!this.input.mobile_number.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.mobile = i18n("Mobile field is required");
                this.mobile_field = true;
                return;
            } else if (
                !this.input.mobile_number.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)
            ) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.mobile = i18n("Please enter a valid mobile number");;
                this.mobile_field = true;
                return;
            }
            this.errors.valid = true;
            this.isFormValid = true;
            this.enableResendButton = false;
            let getOtpPayload = {
                otp_request_event_type: 'registration',
                otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                otp_request_mobile: this.selectedCountry.concat(this.mobile),
                otp_application_id: 'end_user'
            };
            console.log(getOtpPayload);
            // this.isChecked = false;
            sendOtp(getOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: "OTP sent Successfully",
                            text: res.data.message,
                        });
                        setTimeout(() => {
                            $("#selectpicker2").selectpicker("refresh");
                            $("#selectpicker2").selectpicker();
                        }, 1000);
                        this.selectCountry = this.selectedCountry;
                        console.log(this.selectCountry, "this.selectCountry");
                        $(".get-otp").hide();
                        $(".verify-otp").show();
                        const inputs = document.querySelectorAll(".otp-digit");
                        inputs[0].focus();
                        console.log(res);
                        this.countdown(this.otp_time_interval)
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                    this.countdown(this.otp_time_interval);//ER-106410
                });
        },
        submitRegisterForm() {
            $('#regdFormButton').css('pointer-events', 'none');
            if (!this.input.first_name.length && !this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = i18n("Fullname field is required");
                this.nameFiledNotValidate = true;
                return;
            } else {
                this.errors.username = null;
                this.nameFiledNotValidate = false;
            }

            if (!this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = i18n("Last name field is required");
                this.lastnameFiledNotValidate = true;
                return;
            } else {
                this.errors.last_name = null;
                this.lastnameFiledNotValidate = false;
            }

            if (!this.input.user_email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = i18n("Email field is required");
                this.emailFieldNotValidate = true;
                return;
            } else {
                this.errors.user_email = null;
                this.emailFieldNotValidate = false;
            }
            if (!this.input.password.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
                return;
            } else {
                this.errors.password = null;
                this.passwordFieldNotValidate = false;
            }

            if (this.input.password != this.input.confpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = i18n("Confirm password field not matched");
                this.confirmPwdFieldNotValidate = true;
                return;
            }

            this.errors.valid = true;
            this.isFormValid = true;
            let userData = {
                username: this.input.username + " " + this.input.last_name,
                user_email: this.input.user_email,
                password: this.input.confpassword,
            };
            registerUser(userData)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        localStorage.setItem(
                            "end_user_access_token",
                            res.data.data.access_token
                        );
                        localStorage.setItem(
                            "end_user_reload_token",
                            res.data.data.refresh_token
                        );
                        Toast.fire({
                            icon: "success",
                            text: res.data.message,
                        });
                        // JsLoadingOverlay.show();
                        getUserDetails().then((userData) => {
                            if (userData.data && userData.data.code == 200) {
                                var userProfile =
                                    userData.data.data.getUserDetails[0];
                                localStorage.setItem("isloggedin", "true");
                                setCookie('isloggedin', 'true');
                                localStorage.setItem(
                                    "user",
                                    JSON.stringify(userProfile)
                                );
                                this.checkUserSubscription();
                            }
                        });
                    } else {
                        $('#regdFormButton').css('pointer-events', '');
                        Toast.fire({
                            icon: "error",
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    $('#regdFormButton').css('pointer-events', '');
                    console.log("error", err);
                });
        },
        getOtpForRegThroughEmail() {
            if (!this.input.first_name.length && !this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.username = i18n("Fullname field is required");
                this.nameFiledNotValidate = true;
                return;
            } else {
                this.errors.username = null;
                this.nameFiledNotValidate = false;
            }

            if (!this.input.last_name.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.last_name = i18n("Last name field is required");
                this.lastnameFiledNotValidate = true;
                return;
            } else {
                this.errors.last_name = null;
                this.lastnameFiledNotValidate = false;
            }

            if (!this.input.user_email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.user_email = i18n("Email field is required");
                this.emailFieldNotValidate = true;
                return;
            } else {
                this.errors.user_email = null;
                this.emailFieldNotValidate = false;
            }
            if (!this.input.password.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
                return;
            } else {
                this.errors.password = null;
                this.passwordFieldNotValidate = false;
            }

            if (this.input.password != this.input.confpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confpassword = i18n("Confirm password field not matched");
                this.confirmPwdFieldNotValidate = true;
                return;
            }

            this.errors.valid = true;
            this.isFormValid = true;
            this.enableResendButton = false;
            let getOtpPayload = {
                otp_request_event_type: 'registration',
                otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                otp_request_email: this.input.user_email,
                otp_application_id: 'end_user',
                username: this.input.username + " " + this.input.last_name
            };
            console.log(getOtpPayload);
            // this.isChecked = false;
            sendOtp(getOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: "OTP sent Successfully",
                            text: res.data.message,
                        });

                        $(".regd-form").hide();
                        $(".verify-otp").show();
                        const inputs = document.querySelectorAll(".otp-digit");
                        inputs[0].focus();
                        console.log(res);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                    this.countdown(this.otp_time_interval);//ER-106410
                });

        },

        checkUserSubscription() {
            // JsLoadingOverlay.show();
            //106237-start
            if (localStorage.getItem('redirectAfterlogin')) {
                localStorage.setItem("isHomePageRedirect", true);
                var uri = localStorage.getItem("redirectAfterlogin");
                localStorage.removeItem("redirectAfterlogin");
                window.location.href = uri;
            } else {
                if(this.enableMultiProfile === 1){
                    localStorage.setItem("isHomePageRedirect", true);  
                }
                isSubscriptionEnabled().then((res) => {
                    if (res.data.status === "SUCCESS") {
                        if (
                            res.data.data.isSubscriptionEnabled
                                .is_subscription_enabled === true
                        ) {
                            this.myPlanDetails();
                        } else {
                            window.location.href = "/home";
                        }
                    }
                });
            }
            //106237-end
        },
        selectDropdown(event) {
            // console.log(item,"countryDetail");
            getCountryCodes().then((res) => {
                if (res.data.code == 200) {
                    this.country_details = res.data.data.country;
                    console.log(res.data.data.country, "response");
                    console.log(this.country_details[0].name, "this.country_details");
                    setTimeout(() => {
                        $("#selectpicker1").selectpicker();
                    }, 1700);
                }


            });

        },
        validateOtpPart() {

            $('#validateOtpButton').css('pointer-events', 'none');
            let validateOtpPayload = {};
            const inputs = document.querySelectorAll(".otp-digit");
            if(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification){
                validateOtpPayload['otp_request_event_type'] ='registration';
                validateOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
                validateOtpPayload['otp_request_email']= this.input.user_email;
                validateOtpPayload['otp_application_id'] = 'end_user';
                validateOtpPayload['username'] = this.is_sso ? this.userName : this.input.username + " " + this.input.last_name;
                validateOtpPayload['otp_value'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
            }else{
                validateOtpPayload['otp_request_event_type'] ='registration';
                validateOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
                validateOtpPayload['otp_request_mobile']= this.selectedCountry.concat(this.mobile);
                validateOtpPayload['otp_application_id'] = 'end_user';
                validateOtpPayload['otp_value'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
            }
            if(this.is_sso && !(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification)){
                validateOtpPayload['otp_request_sso'] = true;
            }
            validateOtp(validateOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        let userData = {};
                        if(this.isEmailVerificationDuringRegdEnable){
                            userData['username']=this.input.username + " " + this.input.last_name;
                            userData['user_email']=this.input.user_email;
                            userData['password']= this.input.confpassword
                        }else{
                            userData['username']=this.input.username + " " + this.input.last_name;
                            userData['user_email']=this.input.user_email;
                            userData['mobile']=validateOtpPayload.otp_request_mobile
                        }
                        if(this.is_sso){
                            userData['username']=this.userName;
                            userData['user_email']=this.email;
                            userData['mobile']=validateOtpPayload.otp_request_mobile;
                            userData['authentication_mode']= this.registration_mode;
                            userData['social_sso_user_id']= this.socialId;
                            this.registrationWithSso(userData);
                        }else{
                            this.registrationWithoutSsoForOtp(userData);
                        } 
                    } else {
                        $('#validateOtpButton').css('pointer-events', '');
                        Toast.fire({
                            icon: "error",
                            title: "Error",
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    $('#validateOtpButton').css('pointer-events', '');
                    Toast.fire({
                        icon: "error",
                        title: "Error",
                        text: err.response.data.message,
                    });
                });
            this.otpNumber1 = "";
            this.otpNumber2 = "";
            this.otpNumber3 = "";
            this.otpNumber4 = "";
        },
        resendOtp() {
            this.clearOtpValue();
            this.enableResendButton = true;

            let getOtpPayload = {};
            if(this.isEmailVerificationDuringRegdEnable || this.ssoEmailverification){
                getOtpPayload['otp_request_event_type'] ='registration';
                getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
                getOtpPayload['otp_request_email']= this.input.user_email;
                getOtpPayload['otp_application_id'] = 'end_user';
                getOtpPayload['username'] = this.is_sso ? this.userName : this.input.username + " " + this.input.last_name;
                getOtpPayload['resend_otp_request'] =true;
          }else{

              getOtpPayload['otp_request_event_type'] ='registration';
              getOtpPayload['otp_request_role']= 'A7782ABDC61C4D05A465555FFB29AEAF',
              getOtpPayload['otp_request_mobile']= this.selectedCountry.concat(this.mobile);
              getOtpPayload['otp_application_id'] = 'end_user';
              getOtpPayload['resend_otp_request'] =true;
          }

          if(this.is_sso){
              getOtpPayload['otp_request_sso'] = true;
          }

            console.log(getOtpPayload);
            // this.isChecked = false;
            resendOtp(getOtpPayload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: "success",
                            title: "OTP sent Successfully",
                            text: res.data.message,
                        });
                        console.log(res);
                        // Disable the resend button
                        this.enableResendButton = false;
                        // Call countdown function with 1 minute (60 seconds)
                        this.countdown(this.otp_time_interval);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                        // this.enableResendButton = false;
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                    this.enableResendButton = false;
                });
        },
        countdown(otp_time_interval) {
            clearInterval(timer1);
            var timer = document.getElementById("timer");
            timer.innerHTML = ""
            var timeUnit = ""
            var countDownDate = otp_time_interval;
            var now = 0
            var self = this; // Save reference to `this` to access within the inner function

             timer1 = setInterval(function() { 
                var counter = document.getElementById("timer");
                // Find the distance between now an the count down date
                var distance = countDownDate - now;

                // Time calculations for days, hours, minutes and seconds
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                if(hours>0){
                    timeUnit = "hours";
                    counter.innerHTML = (hours < 10 ? "0" : "")+ String(hours) + ":" + (minutes < 10 ? "0" : "")+ String(minutes) + ":" + (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
                }else if(minutes > 0){
                     timeUnit = "minutes";
                     counter.innerHTML = (minutes < 10 ? "0" : "")+ String(minutes) + ":" + (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
                }else{
                    timeUnit = seconds > 1 ? "seconds" : "second";
                    counter.innerHTML = (seconds < 10 ? "0" : "") + String(seconds) + " " + timeUnit;
                }

                // Output the result in an element with id="demo"
               // counter.innerHTML = (hours < 10 ? "0" : "")+ String(hours) + " H " + (minutes < 10 ? "0" : "")+ String(minutes) + " M " + (seconds < 10 ? "0" : "") + String(seconds) + " S";
                self.enableResendButton = false;

                // If the count down is over, write some text 
                if (distance < 0) {
                    clearInterval(timer1);
                    self.enableResendButton = true;
                }
                now = now + 1000
            }, 1000);
       },
       async googleSignIn() {
        const provider = new GoogleAuthProvider();
        const auth = getAuth();
        provider.setCustomParameters({
            prompt: 'select_account'
        });
    
        try {
            // Use await to wait for the signInWithPopup to complete
            const result = await signInWithPopup(auth, provider);

            if(this.credential){
                let user = await linkWithCredential(result.user, this.credential);
                this.credential = "";
            }

            // Signed in successfully
            const user = result.user;
            console.log("Signed in user:", result);
            this.userName = result.user.displayName ? result.user.displayName :result._tokenResponse.displayName;
            this.email = result.user.email;
            this.socialId = result.user.uid;
            this.registration_mode = "Google SSO";
            
            if (!this.email || this.otpSettingEnabled) {
                let checkEndUserPayload = {
                    user_email: this.email,
                    social_sso_user_id: this.socialId
                };
                console.log(checkEndUserPayload);
    
                // Await the checkEndUserExist function
                const res = await checkEndUserExist(checkEndUserPayload);
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserExist = res.data.data.is_end_user_exists;
                    if(this.endUserExist){
                        this.email = res.data.data.email;
                        this.mobile_number_sso = res.data.data.mobile;
                    }
                }
            }
            
            if (this.otpSettingEnabled) {
                if (this.endUserExist) {
                    let userData = {
                        username: this.userName,
                        user_email: this.email,
                        authentication_mode: this.registration_mode,
                        mobile:this.mobile_number_sso,
                        social_sso_user_id: this.socialId
                    };
                    this.registrationWithSso(userData);
                } else{
                    this.input.user_email = this.email;
                    $(".get-otp").hide();
                    $(".signup-google-otp").show();
                }
            } else {
                if (this.endUserExist) {
                    let userData = {
                        username: this.userName,
                        user_email: this.email,
                        authentication_mode: this.registration_mode,
                        social_sso_user_id: this.socialId
                    };
                    this.registrationWithSso(userData);
                } else {
                    $(".regd-form").hide();
                    $(".signup-google-otp").show();
                }
            }
        } catch (error) {
            // Handle sign-in error
            console.error("Sign-in error:", error);
        }
    },

   async appleSignIn() {
        const provider = new OAuthProvider('apple.com');
        const auth = getAuth();
        
        // Set custom parameters
        provider.setCustomParameters({
            prompt: 'select_account'
        });
        
        // Add scopes
        provider.addScope('email');
        provider.addScope('name');
        
        try {
            // Use await to wait for the signInWithPopup to complete
            const result = await signInWithPopup(auth, provider);
            
            if(this.credential){
                let user = await linkWithCredential(result.user, this.credential);
                this.credential = "";
            }

            // Signed in successfully
            const user = result.user;
            console.log("Signed in user:", result);
            this.userName = result.user.displayName ? result.user.displayName :result._tokenResponse.displayName;
            this.email = result.user.email;
            this.socialId = result.user.uid;
            this.registration_mode = "Apple SSO";
            
            if (!this.email || this.otpSettingEnabled) {
                let checkEndUserPayload = {
                    user_email: this.email,
                    social_sso_user_id: this.socialId
                };
                console.log(checkEndUserPayload);
    
                // Await the checkEndUserExist function
                const res = await checkEndUserExist(checkEndUserPayload);
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserExist = res.data.data.is_end_user_exists;
                    if(this.endUserExist){
                        this.email = res.data.data.email;
                        this.mobile_number_sso = res.data.data.mobile;
                    }  
                }
            }
            
            if (this.otpSettingEnabled) {
                if (this.endUserExist) {
                    let userData = {
                        username: this.userName,
                        user_email: this.email,
                        authentication_mode: this.registration_mode,
                        mobile:this.mobile_number_sso,
                        social_sso_user_id: this.socialId
                    };
                    this.registrationWithSso(userData);
                } else{
                    this.input.user_email = this.email;
                    $(".get-otp").hide();
                    $(".signup-google-otp").show();
                }
            } else {
                if (this.endUserExist) {
                    let userData = {
                        username: this.userName,
                        user_email: this.email,
                        authentication_mode: this.registration_mode,
                        social_sso_user_id: this.socialId
                    };
                    this.registrationWithSso(userData);
                } else {
                    $(".regd-form").hide();
                    $(".signup-google-otp").show();
                }
            }
        } catch (error) {
            // Handle sign-in error
            console.error("Sign-in error:", error);
        }
    },

   async facebookSignIn() {
        const provider = new FacebookAuthProvider();
        const auth = getAuth();

        // Set custom parameters
        provider.setCustomParameters({
            prompt: 'select_account'
        });

        provider.addScope('email');

        provider.setCustomParameters({
            'display': 'popup'
          });
        
        try {
            // Use await to wait for the signInWithPopup to complete
            const result = await signInWithPopup(auth, provider);
            
            // Signed in successfully
            const user = result.user;
            console.log("Signed in user:", result);
            this.userName = result.user.displayName ? result.user.displayName :result._tokenResponse.displayName;
            this.email = result.user.email;
            this.socialId = result.user.uid;
            this.registration_mode = "Facebook SSO";
            
            if (!this.email || this.otpSettingEnabled) {
                let checkEndUserPayload = {
                    user_email: this.email,
                    social_sso_user_id: this.socialId
                };
                console.log(checkEndUserPayload);
    
                // Await the checkEndUserExist function
                const res = await checkEndUserExist(checkEndUserPayload);
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserExist = res.data.data.is_end_user_exists;
                    if(this.endUserExist){
                        this.email = res.data.data.email;
                        this.mobile_number_sso = res.data.data.mobile;
                    } 
                }
            }
            
            if (this.otpSettingEnabled) {
                if (this.endUserExist) {
                    let userData = {
                        username: this.userName,
                        user_email: this.email,
                        authentication_mode: this.registration_mode,
                        mobile:this.mobile_number_sso,
                        social_sso_user_id: this.socialId
                    };
                    this.registrationWithSso(userData);
                } else{
                    this.input.user_email = this.email;
                    $(".get-otp").hide();
                    $(".signup-google-otp").show();
                }
            } else {
                if (this.endUserExist) {
                    let userData = {
                        username: this.userName,
                        user_email: this.email,
                        authentication_mode: this.registration_mode,
                        social_sso_user_id: this.socialId
                    };
                    this.registrationWithSso(userData);
                } else {
                    $(".regd-form").hide();
                    $(".signup-google-otp").show();
                }
            }
        } catch (error) {
            // Handle sign-in error
            console.error("Sign-in error:", error);
            if (error.code === "auth/account-exists-with-different-credential") {
                var ssoName='';
                console.error("Sign-in error:", error.customData);
                 this.credential = FacebookAuthProvider.credentialFromError(error);
                 var verifiedProvider = error.customData._tokenResponse.verifiedProvider;
                if(verifiedProvider.includes('google.com')){
                    ssoName = "Google";
                }else{
                    ssoName = "Apple";
                }
                var message = "You have already signup with " + ssoName + ".  Please login once using " + ssoName + ". So we can link your Facebook account to it. Afterward, you'll be able to login seamlessly with either " + ssoName + " or Facebook.";
                $("#signup-error").html(message);
                $("#signup-error").css("display", "block");
                setTimeout(() => {
                    $("#signup-error").css("display", "none");
                    $("#signup-error").html("");
                }, 8000);
            }
        }
    },

    registrationWithSso(userData){
        ssoLogin(userData).then((res) => {
            if (res.data.code === 200 && res.data.status === "SUCCESS") {
                localStorage.setItem(
                    "end_user_access_token",
                    res.data.data.access_token
                );
                localStorage.setItem(
                    "end_user_reload_token",
                    res.data.data.refresh_token
                );
                Toast.fire({
                    icon: "success",
                    text: res.data.message,
                });
                getUserDetails().then((userData) => {
                    if (userData.data && userData.data.code == 200) {
                        var userProfile =
                            userData.data.data.getUserDetails[0];
                        localStorage.setItem("isloggedin", "true");
                        setCookie('isloggedin', 'true');
                        localStorage.setItem(
                            "user",
                            JSON.stringify(userProfile)
                        );
                        this.checkUserSubscription();
                    }
                });  
            } else {
                $('#validateOtpButton').css('pointer-events','');
                console.log("error", res.data.message);
                Toast.fire({
                    icon: "error",
                    title: "Error",
                    text: res.data.message,
                });
            }
        }).catch((err) => {
            $('#validateOtpButton').css('pointer-events','');
            console.log("error", err);
        });    
    },

    getOtpRegistraionForSso(){
        if(this.validateSsoPopupForm()){
            if(this.input.user_email){
                this.email = this.input.user_email;
            }
            let getOtpPayload = {
                otp_request_event_type: 'registration',
                otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                otp_request_mobile: this.selectedCountry.concat(this.input.mobile_number),
                otp_application_id:'end_user',
                otp_request_sso:true,
                sso_email: this.email
            };
            console.log(getOtpPayload);
            // this.isChecked = false;
            sendOtp(getOtpPayload).then((res) => {
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    Toast.fire({
                        icon: "success",
                        title: "OTP sent Successfully",
                        text: res.data.message,
                    });
                    this.is_sso = true ;
                    this.selectCountry = this.selectedCountry;
                    console.log(this.selectCountry,"this.selectCountry");
                        $(".signup-google-otp").hide();
                        $(".verify-otp").show();
                        const inputs = document.querySelectorAll(".otp-digit");
                        inputs[0].focus();
                        this.countdown(this.otp_time_interval);//ER-106410
                    console.log(res);
                } else {
                    
                    if(res.data.message.includes(this.message)){
                        this.enableResendButton = true;
                        clearInterval(timer1);
                        $(".get-otp").hide();
                        $(".verify-otp").show();
                        const inputs = document.querySelectorAll(".otp-digit");
                        inputs[0].focus();
                    }else{
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                    
                }
            })
            .catch((err) => {
                Toast.fire({
                    icon: "error",
                    title: err.response.data.status,
                    text: err.response.data.message,
                });
            });
        }
        
    },

    registrationWithoutSsoForOtp(userData){
        registerUser(userData).then((res) => {
            if (res.data.code === 200 && res.data.status === "SUCCESS") {
                localStorage.setItem(
                    "end_user_access_token",
                    res.data.data.access_token
                );
                localStorage.setItem(
                    "end_user_reload_token",
                    res.data.data.refresh_token
                );
                Toast.fire({
                    icon: "success",
                    text: res.data.message,
                });
                getUserDetails().then((userData) => {
                    if (userData.data && userData.data.code == 200) {
                        var userProfile =
                            userData.data.data.getUserDetails[0];
                        localStorage.setItem("isloggedin", "true");
                        setCookie('isloggedin', 'true');
                        localStorage.setItem(
                            "user",
                            JSON.stringify(userProfile)
                        );
                        this.checkUserSubscription();
                    }
                });  
            } else {
                $('#validateOtpButton').css('pointer-events','');
                Toast.fire({
                    icon: "error",
                    title: "Error",
                    text: res.data.message,
                });
            }
        }).catch((err) => {
            $('#validateOtpButton').css('pointer-events','');
            console.log("error", err);
        });    
    },

    validateSsoPopupForm(){
        let status = true;
        if(this.muviAuthSettingType !== '3' && this.muviAuthSettingType !== '34'){
            if (!this.input.user_email.length) {
                this.errorMsgs[0] = i18n("Email field is required");
                status = false;
            } else if (
                !this.input.user_email.match(
                    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9À-ÿ]+\.)+[a-zA-ZÀ-ÿ]{2,}))$/
                )
            ) {
                this.errorMsgs[0] = i18n("Please enter a valid email");
                status = false;
            } else {
                this.errorMsgs[0] = "";
            }   
        }
        
        if(this.otpSettingEnabled){
            if (!this.input.mobile_number.length) {
                this.errorMsgs[1] = i18n("Mobile field is required");
                status = false;
            } else if (!this.input.mobile_number.match(/^(\d{4,15}|\d{3}[-\s]\d{3}[-\s]\d{4})$/)) {
                this.errorMsgs[1] = i18n("Please enter a valid mobile number");;
                status = false;
            }else {
                this.errorMsgs[1]="";
            }
        }
        return status;
    },

    getOtpForRegThroughEmailWithSso() {
        if(this.validateSsoPopupForm()){
            if(this.input.user_email){
                this.email = this.input.user_email;
            }
            let getOtpPayload = {
                otp_request_event_type: 'registration',
                otp_request_role: 'A7782ABDC61C4D05A465555FFB29AEAF',
                otp_request_email: this.input.user_email,
                otp_application_id:'end_user',
                username: this.userName
            };
            console.log(getOtpPayload);
            // this.isChecked = false;
            sendOtp(getOtpPayload).then((res) => {
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    this.is_sso = true ;
                    Toast.fire({
                        icon: "success",
                        title: "OTP sent Successfully",
                        text: res.data.message,
                    });

                    $(".signup-google-otp").hide();
                    $(".verify-otp").show();
                    const inputs = document.querySelectorAll(".otp-digit");
                    inputs[0].focus();
                    this.countdown(this.otp_time_interval);//ER-106410
                    console.log(res);
                } else { 
                    if(res.data.message.includes(this.message)){
                        this.enableResendButton = true;
                        clearInterval(timer1);
                        $(".signup-google-otp").hide();
                        $(".verify-otp").show();
                        const inputs = document.querySelectorAll(".otp-digit");
                        inputs[0].focus();
                    }else{
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                    
                }
            })
            .catch((err) => {
                Toast.fire({
                    icon: "error",
                    title: err.response.data.status,
                    text: err.response.data.message,
                });
            });
        }
    }, 
    },
    template: `
    <vd-component class="vd register-five" type="register-five">
    <!--Header Section Start Here-->
    <section class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a v-if="logo_details['logo']" class="navbar-brand " href="/"><img vd-node="logo" vd-readonly="true" :src="logo_details['logo']['src']"
                        :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                        <a v-else-if="logo_details['logo']!=false" class="navbar-brand " href="/"><img vd-node="logo" vd-readonly="true" :src="getRootUrl() +'img/logo.png'"
                        alt="Phoenix" /></a>  
                        <div class="nav-right-content">
                            <span vd-node="text" class="span-txt"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></span>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <!--Sign Up From Start Here-->
    <section class="sign-process" vd-node="styleOnly" vd-readonly='true'>
        <div class="content d-flex justify-content-center">
            <!--From Section Start Here-->
            <div class="sign-form-layout regd-form ml-0"  v-if="otpSettingEnabled==false">
                <h2 class="mb-32"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2>
                <p id="signup-error" style="text-align: left; font-size: 12px; color: red; display: none;"></p>
                <div class="form-group mb-16" v-if="google_sso_enabled">
                <button type="button" class="primary-button d-flex align-items-center justify-content-center google" @click="googleSignIn">
                    <span>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_7_462)">
                            <path d="M19.7618 10.1871C19.7618 9.36767 19.6954 8.76974 19.5515 8.14966H10.1948V11.848H15.687C15.5763 12.7671 14.9783 14.1512 13.6496 15.0813L13.6309 15.2051L16.5893 17.4969L16.7943 17.5174C18.6767 15.7789 19.7618 13.221 19.7618 10.1871Z" fill="#4285F4"/>
                            <path d="M10.1947 19.9313C12.8853 19.9313 15.1442 19.0454 16.7941 17.5174L13.6494 15.0813C12.8079 15.6682 11.6784 16.0779 10.1947 16.0779C7.55932 16.0779 5.3226 14.3395 4.52527 11.9366L4.4084 11.9466L1.33222 14.3273L1.29199 14.4391C2.93077 17.6945 6.29695 19.9313 10.1947 19.9313Z" fill="#34A853"/>
                            <path d="M4.52526 11.9367C4.31488 11.3166 4.19313 10.6522 4.19313 9.96568C4.19313 9.27912 4.31488 8.61476 4.51419 7.99469L4.50862 7.86263L1.39389 5.4437L1.29198 5.49217C0.616561 6.84308 0.229004 8.36011 0.229004 9.96568C0.229004 11.5713 0.616561 13.0882 1.29198 14.4391L4.52526 11.9367Z" fill="#FBBC05"/>
                            <path d="M10.1947 3.85336C12.066 3.85336 13.3282 4.66168 14.048 5.33718L16.8605 2.59107C15.1332 0.985496 12.8853 0 10.1947 0C6.29695 0 2.93077 2.23672 1.29199 5.49214L4.51421 7.99466C5.3226 5.59183 7.55932 3.85336 10.1947 3.85336Z" fill="#EB4335"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_7_462">
                                <rect width="19.542" height="20" fill="white" transform="translate(0.229004)"/>
                            </clipPath>
                            </defs>
                        </svg>
                    </span>
                    <span style="text-transform:none;">
                        <vd-component-param type="label50" v-html="i18n($attrs['label52'])"></vd-component-param>
                    </span>
                </button>
                </div>
                <div class="form-group mb-16"  v-if="apple_sso_enabled">
                <button type="button"  @click="appleSignIn" class="primary-button d-flex align-items-center justify-content-center apple">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0709 3.19287C13.8 2.34788 14.2914 1.17098 14.1569 0C13.1063 0.04 11.8352 0.671147 11.0819 1.51514C10.4054 2.26413 9.81484 3.4609 9.97359 4.60889C11.1456 4.69588 12.3418 4.03885 13.0709 3.19287ZM15.699 10.625C15.7283 13.652 18.4697 14.6589 18.5 14.6719C18.4778 14.7429 18.0622 16.1066 17.056 17.5166C16.1854 18.7346 15.2824 19.9476 13.8596 19.9736C12.4621 19.9986 12.0122 19.1797 10.4135 19.1797C8.81577 19.1797 8.31624 19.9475 6.9936 19.9985C5.62039 20.0475 4.5738 18.6808 3.6971 17.4668C1.90323 14.9838 0.533065 10.4501 2.37344 7.39014C3.28756 5.87116 4.92064 4.90779 6.69428 4.88379C8.04221 4.85879 9.31531 5.75293 10.1394 5.75293C10.9636 5.75293 12.5107 4.67794 14.1367 4.83594C14.8172 4.86294 16.7284 5.09885 17.955 6.81982C17.8559 6.87882 15.6747 8.09504 15.699 10.625Z" fill="white"></path>
                        </svg>
                    </span>
                    <span style="text-transform:none;">
                        <vd-component-param type="label60" v-html="i18n($attrs['label60'])"></vd-component-param>
                    </span>
                </button>
                </div>
                <div class="form-group mb-16" v-if="facebook_sso_enabled">
                <button type="button" @click="facebookSignIn" class="primary-button d-flex align-items-center justify-content-center facebook">
                    <span>
                        <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_7_469)">
                            <path d="M19.3962 20.0001C20.0057 20.0001 20.5 19.5059 20.5 18.8962V1.10383C20.5 0.494141 20.0057 0 19.3962 0H1.60383C0.994062 0 0.5 0.494141 0.5 1.10383V18.8962C0.5 19.5059 0.994062 20.0001 1.60383 20.0001H19.3962Z" fill="white"></path>
                            <path d="M14.2995 20.0001V12.255H16.8993L17.2885 9.23663H14.2995V7.30944C14.2995 6.43553 14.5423 5.83999 15.7955 5.83999L17.3938 5.83928V3.13968C17.1173 3.10288 16.1685 3.02069 15.0648 3.02069C12.7602 3.02069 11.1826 4.42733 11.1826 7.01061V9.23663H8.57617V12.255H11.1826V20.0001H14.2995Z" fill="#335092"></path>
                            </g>
                            <defs>
                            <clipPath id="clip0_7_469">
                                <rect x="0.5" width="20" height="20" rx="4" fill="white"></rect>
                            </clipPath>
                            </defs>
                        </svg>
                    </span>
                    <span style="text-transform:none;">
                        <vd-component-param type="label62" v-html="i18n($attrs['label62'])"></vd-component-param>
                    </span>
                </button>
                </div>
                <div class="form-group or mb-32 mt-32" v-if="sso_enabled">
                <span>
                    <vd-component-param type="label49" v-html="i18n($attrs['label51'])"></vd-component-param>
                </span>
                </div>
                <form @submit.prevent action="" method="post" class="needs-validation" novalidate>
                    <div class="form-group vd-form float-left form-label _required">
                        <div class="form-box pr-6 vd-form">
                            <input vd-readonly="true" type="text" @keyup.enter="submitRegisterForm" v-model="input.first_name" class="form-control vd-component-attr" vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9']) 
                                vd-component-attr-title="label14" :title=i18n($attrs['label14']) autocomplet="off" :class="nameFiledNotValidate ? 'is-invalid' : ''">
                            <template v-if="errors.username">
                                <div class="invalid-feedback">{{ errors.username }}</div>
                            </template>
                        </div>
                        <div class="form-box pl-6 mb-0 vd-form">
                            <input vd-readonly="true" type="text" @keyup.enter="submitRegisterForm" v-model="input.last_name" class="form-control vd-component-attr" vd-component-attr-placeholder="label10" :placeholder=i18n($attrs['label10']) 
                                vd-component-attr-title="label15" :title=i18n($attrs['label15']) autocomplet="off" :class="lastnameFiledNotValidate ? 'is-invalid' : ''">
                            <template v-if="errors.last_name">
                                <div class="invalid-feedback">{{ errors.last_name }}</div>
                            </template>
                        </div>
                    </div>
                    <div class="form-group form-label _required" style="padding-top:50px">
                        <div class="vd-form">
                            <input vd-readonly="true" type="text" @keyup.enter="submitRegisterForm" class="form-control vd-component-attr" v-model="input.user_email" vd-component-attr-placeholder="label11" :placeholder=i18n($attrs['label11']) 
                                vd-component-attr-title="label16" :title=i18n($attrs['label16']) autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''">
                            <template v-if="errors.user_email">
                                <div class="invalid-feedback">{{ errors.user_email }}</div>
                            </template>
                        </div>
                    </div>
                    <div class="form-group float-left form-label _required">
                        <div class="form-box show-password password-input pr-6 vd-form">
                            <input vd-readonly="true" @keyup.enter="submitRegisterForm" v-bind:type="[showPassword ? 'text' : 'password']" v-model="input.password" class="form-control pr-42 vd-component-attr" vd-component-attr-placeholder="label12" :placeholder=i18n($attrs['label12']) 
                                vd-component-attr-title="label17" :title=i18n($attrs['label17']) autocomplete="off" :class="passwordFieldNotValidate ? 'is-invalid' : ''">
                            <button type="button" class="" @click="showPassword = !showPassword"><i :class="[showPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                            <template v-if="errors.password">
                                <div class="invalid-feedback">{{ errors.password }}</div>
                            </template>
                        </div>
                        <div class="form-box show-password pl-6 mb-0 vd-form">
                            <input vd-readonly="true" @keyup.enter="submitRegisterForm" v-bind:type="[showConfPassword ? 'text' : 'password']" v-model="input.confpassword" class="form-control pr-42 vd-component-attr" vd-component-attr-placeholder="label13" :placeholder=i18n($attrs['label13']) 
                                vd-component-attr-title="label18" :title=i18n($attrs['label18']) @copy.prevent @paste.prevent @cut.prevent autocomplete="off" :class="confirmPwdFieldNotValidate ? 'is-invalid' : ''">
                            <button type="button" class="" @click="showConfPassword = !showConfPassword"><i :class="[showConfPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                            <template v-if="errors.confpassword">
                                <div class="invalid-feedback">{{ errors.confpassword }}</div>
                            </template>
                        </div>
                    </div>
                    <div class="form-group mb-40">
                        <label vd-node="text" class="mr-1"><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></label>
                        <label><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></label>
                        <label vd-node="text" class="mx-1"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></label>
                        <label class="mb-16"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></label>
                        <button id="regdFormButton" type="button" vd-node="styleOnly" vd-readonly="true" style="text-transform: none; display:none;"
                            class="primary-button"  @click="submitRegisterForm"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></button>&nbsp;
                        <button id="nextButton" type="button" vd-node="styleOnly" vd-readonly="true" style="text-transform: none; display:none;"
                            class="primary-button"  @click="getOtpForRegThroughEmail"><vd-component-param type="label47" v-html="i18n($attrs['label47'])"></vd-component-param></button>
                    </div>
                    <p class="text-center"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param> </p>
                </form>
            </div>
            <!--From Section End Here-->
            <!-- From section for Mobile OTP start here-->
            <div class="sign-form-layout get-otp bg-login-dark p-6448 ml-0" v-else>
                <h2 class="mb-32"><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param></h2>
                <p id="signup-error" style="text-align: left; font-size: 12px; color: red; display: none;"></p>
                <div class="form-group mb-16" v-if="google_sso_enabled">
                <button type="button" class="primary-button d-flex align-items-center justify-content-center google" @click="googleSignIn">
                    <span>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_7_462)">
                            <path d="M19.7618 10.1871C19.7618 9.36767 19.6954 8.76974 19.5515 8.14966H10.1948V11.848H15.687C15.5763 12.7671 14.9783 14.1512 13.6496 15.0813L13.6309 15.2051L16.5893 17.4969L16.7943 17.5174C18.6767 15.7789 19.7618 13.221 19.7618 10.1871Z" fill="#4285F4"/>
                            <path d="M10.1947 19.9313C12.8853 19.9313 15.1442 19.0454 16.7941 17.5174L13.6494 15.0813C12.8079 15.6682 11.6784 16.0779 10.1947 16.0779C7.55932 16.0779 5.3226 14.3395 4.52527 11.9366L4.4084 11.9466L1.33222 14.3273L1.29199 14.4391C2.93077 17.6945 6.29695 19.9313 10.1947 19.9313Z" fill="#34A853"/>
                            <path d="M4.52526 11.9367C4.31488 11.3166 4.19313 10.6522 4.19313 9.96568C4.19313 9.27912 4.31488 8.61476 4.51419 7.99469L4.50862 7.86263L1.39389 5.4437L1.29198 5.49217C0.616561 6.84308 0.229004 8.36011 0.229004 9.96568C0.229004 11.5713 0.616561 13.0882 1.29198 14.4391L4.52526 11.9367Z" fill="#FBBC05"/>
                            <path d="M10.1947 3.85336C12.066 3.85336 13.3282 4.66168 14.048 5.33718L16.8605 2.59107C15.1332 0.985496 12.8853 0 10.1947 0C6.29695 0 2.93077 2.23672 1.29199 5.49214L4.51421 7.99466C5.3226 5.59183 7.55932 3.85336 10.1947 3.85336Z" fill="#EB4335"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_7_462">
                                <rect width="19.542" height="20" fill="white" transform="translate(0.229004)"/>
                            </clipPath>
                            </defs>
                        </svg>
                    </span>
                    <span style="text-transform:none;">
                        <vd-component-param type="label52" v-html="i18n($attrs['label52'])"></vd-component-param>
                    </span>
                </button>
                </div>
                <div class="form-group mb-16"  v-if="apple_sso_enabled">
                <button type="button"  @click="appleSignIn" class="primary-button d-flex align-items-center justify-content-center apple">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M13.0709 3.19287C13.8 2.34788 14.2914 1.17098 14.1569 0C13.1063 0.04 11.8352 0.671147 11.0819 1.51514C10.4054 2.26413 9.81484 3.4609 9.97359 4.60889C11.1456 4.69588 12.3418 4.03885 13.0709 3.19287ZM15.699 10.625C15.7283 13.652 18.4697 14.6589 18.5 14.6719C18.4778 14.7429 18.0622 16.1066 17.056 17.5166C16.1854 18.7346 15.2824 19.9476 13.8596 19.9736C12.4621 19.9986 12.0122 19.1797 10.4135 19.1797C8.81577 19.1797 8.31624 19.9475 6.9936 19.9985C5.62039 20.0475 4.5738 18.6808 3.6971 17.4668C1.90323 14.9838 0.533065 10.4501 2.37344 7.39014C3.28756 5.87116 4.92064 4.90779 6.69428 4.88379C8.04221 4.85879 9.31531 5.75293 10.1394 5.75293C10.9636 5.75293 12.5107 4.67794 14.1367 4.83594C14.8172 4.86294 16.7284 5.09885 17.955 6.81982C17.8559 6.87882 15.6747 8.09504 15.699 10.625Z" fill="white"></path>
                        </svg>
                    </span>
                    <span style="text-transform:none;">
                        <vd-component-param type="label61" v-html="i18n($attrs['label61'])"></vd-component-param>
                    </span>
                </button>
                </div>
                <div class="form-group mb-16" v-if="facebook_sso_enabled">
                <button type="button" @click="facebookSignIn" class="primary-button d-flex align-items-center justify-content-center facebook">
                    <span>
                        <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_7_469)">
                            <path d="M19.3962 20.0001C20.0057 20.0001 20.5 19.5059 20.5 18.8962V1.10383C20.5 0.494141 20.0057 0 19.3962 0H1.60383C0.994062 0 0.5 0.494141 0.5 1.10383V18.8962C0.5 19.5059 0.994062 20.0001 1.60383 20.0001H19.3962Z" fill="white"></path>
                            <path d="M14.2995 20.0001V12.255H16.8993L17.2885 9.23663H14.2995V7.30944C14.2995 6.43553 14.5423 5.83999 15.7955 5.83999L17.3938 5.83928V3.13968C17.1173 3.10288 16.1685 3.02069 15.0648 3.02069C12.7602 3.02069 11.1826 4.42733 11.1826 7.01061V9.23663H8.57617V12.255H11.1826V20.0001H14.2995Z" fill="#335092"></path>
                            </g>
                            <defs>
                            <clipPath id="clip0_7_469">
                                <rect x="0.5" width="20" height="20" rx="4" fill="white"></rect>
                            </clipPath>
                            </defs>
                        </svg>
                    </span>
                    <span style="text-transform:none;">
                        <vd-component-param type="label63" v-html="i18n($attrs['label63'])"></vd-component-param>
                    </span>
                </button>
                </div>
                <div class="form-group or mb-32 mt-32" v-if="sso_enabled">
                <span>
                    <vd-component-param type="label51" v-html="i18n($attrs['label51'])"></vd-component-param>
                </span>
                </div>
                <form @submit.prevent action="" method="post" class="needs-validation" novalidate>
                    <div class="form-group   form-label _required">
                        <input vd-readonly="true" type="text" @keyup.enter="getOtpRegistraion" v-model="input.first_name" class="form-control vd-component-attr" vd-component-attr-placeholder="label32" :placeholder=i18n($attrs['label32']) 
                        vd-component-attr-title="label36" :title=i18n($attrs['label36']) autocomplet="off" :class="nameFiledNotValidate ? 'is-invalid' : ''">
                        <template v-if="errors.username">
                        <div class="invalid-feedback">{{ errors.username }}</div>
                        </template>
                    </div>
                    <div class="form-group   form-label _required">
                        <input vd-readonly="true" type="text" @keyup.enter="getOtpRegistraion" v-model="input.last_name" class="form-control vd-component-attr" vd-component-attr-placeholder="label33" :placeholder=i18n($attrs['label33']) 
                            vd-component-attr-title="label37" :title=i18n($attrs['label37']) autocomplet="off" :class="lastnameFiledNotValidate ? 'is-invalid' : ''">
                        <template v-if="errors.last_name">
                            <div class="invalid-feedback">{{ errors.last_name }}</div>
                        </template>
                    </div>
                    <div class="form-group form-label _required" v-if="muviAuthSettingType == '35'|| muviAuthSettingType == '34'">
                        <input vd-readonly="true" type="text" @keyup.enter="getOtpRegistraion" class="form-control vd-component-attr" v-model="input.user_email" vd-component-attr-placeholder="label34" :placeholder=i18n($attrs['label34']) 
                            vd-component-attr-title="label38" :title=i18n($attrs['label38']) autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''">
                        <template v-if="errors.user_email">
                            <div class="invalid-feedback">{{ errors.user_email }}</div>
                        </template>
                    </div>
                    <div class="form-group form-label _required">
                        <div class="row">
                            <div class="col-md-12 phone-countrycode">
                                <select class="selectpicker"  aria-label="Default select example" id = "selectpicker1" v-model="selectedCountry">
                                    <option class="no-check" v-for="(countryDetail,i) in country_details" :key="i" :value="countryDetail.phone_code" :data-subtext=" countryDetail.name">{{countryDetail.phone_code}}</option> 
                                </select>
                                <input @keyup.enter="getOtpRegistraion" v-model="input.mobile_number" type="text" class="form-control pl-100 vd-component-attr"
                                    vd-component-attr-placeholder="label35" :placeholder=i18n($attrs['label35']) 
                                    vd-component-attr-title="label39" :title=i18n($attrs['label39']) :class="mobile_field ? 'is-invalid' : ''" required id="" >
                                <template v-if="errors.mobile">
                                    <div class="invalid-feedback">{{ errors.mobile}}</div>
                                </template>
                            </div>
                        </div>
                    </div> 
                    <div class="form-group mb-40">
                        <label class="mr-1"><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></label>
                        <label><a style="text-decoration: none;" :href=getAsthuDomainUrl()+languageCode+"/agreements/muvi-terms-service/"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></a></vd-component-param></label>
                        <label class="mx-1"><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></label>
                        <label class="mb-16"><a style="text-decoration: none;" :href=this.getAsthuDomainUrl()+languageCode+"/agreements/muvi-privacy-policy/"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></a></vd-component-param></label>
                        <button vd-node="styleOnly" vd-readonly="true" type="button" style="text-transform: none; display:block;" @keyup.enter="getOtpRegistraion"
                            class="primary-button get-otp-btn"  @click="getOtpRegistraion"><vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param>
                        </button>
                    </div>
                    <p class="text-center"><vd-component-param type="label27" v-html="i18n($attrs['label27'])"></vd-component-param> <a vd-node="link" class="" :href="'/'+languageCode+'/sign-in'"><vd-component-param type="label28" v-html="i18n($attrs['label28'])"></vd-component-param></a></p>
                </form>
            </div>
            <!-- From section for Mobile OTP end here-->
            <!--Verify otp Section Start Here-->
            <div class="sign-form-layout verify-otp bg-login-dark p-6448 ml-0">
                <h2 class="mb-32"><vd-component-param type="label40" v-html="i18n($attrs['label40'])"></vd-component-param></h2>
                <form action="" method="" class="" id="">
                <div class="form-group position-relative"  v-if="!(isEmailVerificationDuringRegdEnable || ssoEmailverification)">
                    <div class="row" style="pointer-events: none;">
                        <div class="col-md-12 phone-countrycode ">
                            <select class="selectpicker" aria-label="Default select example" id = "selectpicker2" v-model="selectCountry">
                            <option class="no-check" :value="selectCountry">{{selectCountry}}</option>
                            </select>
                            <input @keyup.enter="getOtpRegistraion" v-model="input.mobile_number" type="tel" class="form-control pl-100"
                            vd-component-attr-placeholder="label45" :placeholder=i18n($attrs['label45']) 
                            vd-component-attr-title="label46" :title=i18n($attrs['label46']) :class="mobile_field ? 'is-invalid' : ''" required id="" >
                            <template v-if="errors.mobile">
                            <div class="invalid-feedback">{{ errors.mobile}}</div>
                            </template>
                        </div>
                    </div>
                    <button type="button" class="edit-input-btn" id="edit-input-btn-sso" v-if="is_sso">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                            </defs>
                        </svg>
                    </button>
                    <button type="button" class="edit-input-btn" v-else>
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                            </defs>
                        </svg>
                    </button>
                </div>
                <div class="form-group position-relative" v-else>
                    <div class="row">
                        <div class="col-md-12 phone-countrycode is-email">
                            <input type="tel" name="" id="" class="form-control pl-75 pr-40" v-model="input.user_email" vd-component-attr-placeholder="label48" :placeholder=i18n($attrs['label48']) >
                        </div>
                    </div>
                    <button type="button" class="edit-input-btn" id="edit-input-btn-sso" v-if="is_sso">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                            </defs>
                        </svg>
                    </button>
                    <button v-else type="button" class="edit-input-btn"  id="edit-input-btn-email-verification">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_3058_20206)">
                            <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                            <clipPath id="clip0_3058_20206">
                                <rect width="16" height="16" fill="white"/>
                            </clipPath>
                            </defs>
                        </svg>
                    </button>
                </div>
                    <!--OTP input start Here-->
                    <div class="recived-code d-flex flex-wrap justify-content-center">
                        <div class="code d-flex justify-content-between mb-3">
                            <input vd-readonly="true" type="text"  class="form-control otp-digit"  autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''" maxlength="1" value="">
                            <input vd-readonly="true" type="text" class="form-control otp-digit"  autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''"  maxlength="1" value="">
                            <input vd-readonly="true" type="text"  class="form-control otp-digit"  autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''"  maxlength="1" value="">
                            <input vd-readonly="true" type="text" @keyup.enter="validateOtpPart" class="form-control otp-digit"  autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''" maxlength="1" value="">
                        </div>
                        <div class="resend pl-0">
                        <!--Get Code in time-->
                            <div class="getcode text-center">
                                <p><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></p>
                                <p :style="{ 'pointer-events': enableResendButton ? '' : 'none' }" :style="{ 'cursor': enableResendButton ? '' : 'not-allowed !important' }" :style="{ 'opacity': enableResendButton ? '' : '0.5' }"><a href="javascript:void(0);" @click="resendOtp()">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_3058_11668)">
                                        <path d="M0.664062 2.66602V6.66602H4.66406" stroke="#2C6ECB" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M2.3374 9.99964C2.76966 11.2266 3.58895 12.2798 4.67183 13.0006C5.75471 13.7214 7.04252 14.0707 8.34121 13.996C9.63989 13.9212 10.8791 13.4264 11.8721 12.5861C12.8652 11.7459 13.5582 10.6056 13.8469 9.33722C14.1355 8.06881 14.0041 6.74094 13.4725 5.55371C12.9408 4.36647 12.0377 3.38417 10.8993 2.75482C9.76083 2.12546 8.44867 1.88315 7.16051 2.06438C5.87236 2.24562 4.678 2.84059 3.7574 3.75964L0.664062 6.66631" stroke="#2C6ECB" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
                                        </g>
                                        <defs>
                                        <clipPath id="clip0_3058_11668">
                                        <rect width="16" height="16" fill="white"/>
                                        </clipPath>
                                        </defs>
                                    </svg>
                                    &nbsp;<vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param>
                                    </a>
                                </p>
                            </div>
                            <!--Get Code in time-->
                        </div>
                    </div>
                    <div class="form-group mb-24 text-center" :style="{ 'display': !enableResendButton ? 'block' : 'none' }">
                        <!-- <label class="info">Your OTP will be expired in 3 min</label> -->
                        <label class="info">OTP can be resent in <span class="text-white" id="timer"></span></label>
                    </div>
                    <!--OTP input End Here-->
                    <div class="form-group mb-32 text-center">    
                        <button style="pointer-events: none;" type="button" id="validateOtpButton" class="primary-button disabled-button otp-verify-btn" @click="validateOtpPart"><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param></button>         
                    </div> 
                    <p class="text-center"><vd-component-param type="label43" v-html="i18n($attrs['label43'])"></vd-component-param> <a vd-node="link" class="" :href="'/'+languageCode+'/sign-in'"><vd-component-param type="label44" v-html="i18n($attrs['label44'])"></vd-component-param></a></p>
                </form>
            </div>
            <!--verify otp Section End Here-->
                     <!--Sso mobile popup Start Here-->
         <div class="sign-form-layout bg-login-dark p-4048 signup-google-otp ml-0" style=" width: 500px;">
            <h2 class="mb-2">
               <vd-component-param type="label53" v-html="i18n($attrs['label53'])"></vd-component-param>
            </h2>
            <span class="subtext mb-32">
               <vd-component-param type="label54" v-html="i18n($attrs['label54'])"></vd-component-param>
            </span>
            <form action="" method="" class="needs-validation mt-3" id=""  novalidate>
               <div class="form-group form-label _required"  v-if="otpSettingEnabled==false || muviAuthSettingType == '35'">
                  <label class="form-label">
                     <vd-component-param type="label67" v-html="i18n($attrs['label67'])"></vd-component-param>
                  </label>
                  <input vd-readonly="true" type="text" class="form-control vd-component-attr" v-model="input.user_email" vd-component-attr-placeholder="label69" :placeholder=i18n($attrs['label69']) 
                     vd-component-attr-title="label38" :title=i18n($attrs['label38']) autocomplete="off" :class=" emailFieldNotValidate ? 'is-invalid' : ''">
                  <template v-if="errorMsgs[0]!='' && this.errorMsgs[0]!=undefined">
                     <div class="invalid-feedback" :style="errorMsgs[0]!='' && this.errorMsgs[0]!=undefined ? 'display: block;' : 'display: none;'">{{ errorMsgs[0] }}</div>
                  </template>
               </div>
               <div class="form-group form-label _required position-relative"  v-if="otpSettingEnabled==true">
                  <label class="form-label">
                     <vd-component-param type="label68" v-html="i18n($attrs['label68'])"></vd-component-param>
                  </label>
                  <div class="row">
                     <div class="col-md-12 phone-countrycode">
                        <select class="selectpicker"  aria-label="Default select example" id = "selectpicker1" v-model="selectedCountry">
                           <option class="no-check" v-for="(countryDetail,i) in country_details" :key="i" :value="countryDetail.phone_code" :data-subtext="countryDetail.name">{{countryDetail.phone_code}}</option>
                        </select>
                        <input  v-model="input.mobile_number" type="text" class="form-control pl-40 vd-component-attr"
                           vd-component-attr-placeholder="label66" :placeholder=i18n($attrs['label66']) 
                           vd-component-attr-title="label39" :title=i18n($attrs['label39']) :class="mobile_field ? 'is-invalid' : ''" required id="" >
                     </div>
                     <template v-if="errorMsgs[1]!='' && this.errorMsgs[1]!=undefined">
                        <div class="col-md-12 invalid-feedback" :style="errorMsgs[1]!='' && this.errorMsgs[1]!=undefined ? 'display: block;' : 'display: none;'">{{ errorMsgs[1]}}</div>
                     </template>
                  </div>
               </div>
               <div class="form-group mb-4">
                  <button id="nextButton" v-if="muviAuthSettingType == '1' || muviAuthSettingType == '13'" type="button" vd-node="styleOnly" vd-readonly="true" style="text-transform: none;"
                     class="primary-button"  @click="getOtpForRegThroughEmailWithSso">
                     <vd-component-param type="label65" v-html="i18n($attrs['label65'])"></vd-component-param>
                  </button>
                  <button type="button" v-else class="primary-button getOtp" @click="getOtpRegistraionForSso">
                     <vd-component-param type="label57" v-html="i18n($attrs['label57'])"></vd-component-param>
                  </button>
               </div>
            </form>
         </div>
         <!--Sso mobile popup End Here-->
        </div>
    </section>
    <!--Sign Up From End Here-->
</vd-component>`,
};

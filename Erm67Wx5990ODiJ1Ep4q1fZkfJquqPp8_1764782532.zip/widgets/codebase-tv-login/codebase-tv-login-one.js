let {
    getVdConfig,
    validateSigninCode,
}=await import(window.importAssetJs('js/webservices.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

export default {
    name: "codebase_tv_login_one",
    data() {
        return {
            errors: {},
            email_filed: true,
            domainName: "",
            email: "",
            userDetails: {},
            getAppToken: "",
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            userProfile: "",
            errorMessage:"",
            isDisabled: true

        };
    },
    computed: {
        email_id() {
            return this.email;
        },
    },
    watch: {
        
    },

    created(){
        let isloggedIn = localStorage.getItem("isloggedin");
        if(!isloggedIn){
            window.location.href = "/sign-in";
        }   
    },
    mounted() {
          $(document).ready(function() {
            window.history.pushState(null, "", window.location.href);        
            window.onpopstate = function() {
                window.history.pushState(null, "", window.location.href);
            };
        });
        var userData = JSON.parse(localStorage.getItem("user"));   
        if(userData){
            this.userProfile = i18n(userData.name.slice(0,12) + " !");
        }
        this.gotoVerifyotp();
        $(".otp-digit").bind("paste", function(e){
             var pastedData = e.originalEvent.clipboardData.getData('text'); 
             $("#spanid").html("");
             if (pastedData) {
                var split = pastedData.split("");
                const onlyContainsalphanumeric = (pastedData) => /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/.test(pastedData);
                const inputs = document.querySelectorAll(".otp-digit");
                    inputs[0].value ="";
                    inputs[1].value ="";
                    inputs[2].value ="";
                    inputs[3].value ="";
                    inputs[0].value = split[0];
                    inputs[1].value = split[1];
                    inputs[2].value = split[2];
                    inputs[3].value = split[3];
                if(pastedData.length >= 4){
                    const button = document.querySelector(".otp-verify-btn");
                    this.errorMessage = "";
                    this.isDisabled = false;
                    button.classList.remove("disabled-button");
                }else{
                    this.isDisabled = true;
                }
                inputs[3].focus();
                return false;
             }
            } );
        getVdConfig("logo")
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    //this.logo = res.data.data;
                    this.isLogoUpdated = true;
                    this.logo_alt = res.data.data.alt;
                    this.logo_src = res.data.data.src;
                    this.logo_style = res.data.data.style;
                } else {
                    this.isLogoUpdated = false;
                }
            })
            .catch((ex) => {
                console.log(ex);
            });
    },
    methods: {
        getRootUrl,
        i18n,
        gotoVerifyotp(){
            const inputs = document.querySelectorAll(".otp-digit");
            const button = document.querySelector(".otp-verify-btn");
            inputs.forEach((input, index1) => {
                input.addEventListener("keyup", (e) => {
                    const currentInput = input,
                    nextInput = input.nextElementSibling,
                    prevInput = input.previousElementSibling;
                    if (currentInput.value.length > 1) {
                        currentInput.value = "";
                        return;
                    }
                    if (nextInput && currentInput.value !== "") {
                        nextInput.removeAttribute("disabled");
                        nextInput.focus();
                    }
                    if (e.key === "Backspace") {
                        input.value = "";
                        if(prevInput !== null){
                            prevInput.focus();
                        }else{
                            currentInput.focus();
                        }
                    }
                    if (inputs[0].value !== "" && inputs[1].value !== "" && inputs[2].value !== "" && inputs[3].value !== "") {
                        var siginCode = inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
                        const onlyContainsalphanumeric = (siginCode) => /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/.test(siginCode);
                        if(siginCode.length >= 4){
                            $("#spanid").html("");
                            $("input").removeClass("is-invalid");
                            this.errorMessage = "";
                            this.isDisabled = false;
                            button.classList.remove("disabled-button");
                        }else{
                            this.isDisabled = true;
                        }
                        return;
                    }
                    this.isDisabled = true;
                    button.classList.add("disabled-button");
                });
            });
            window.addEventListener("load", () => inputs[0].focus());
        },

        verifySigninCode(){
            $('#validateOtpButton').css('pointer-events','none');
            let validateSigninCodePayload = {};
            const inputs = document.querySelectorAll(".otp-digit");
            validateSigninCodePayload['signin_code'] =inputs[0].value.concat(inputs[1].value).concat(inputs[2].value).concat(inputs[3].value);
            validateSigninCode(validateSigninCodePayload).then((res) => {
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    $("#verifySection").removeClass("d-block");
                    $("#verifySuccess").removeClass("d-none")
                    this.errorMessage = ""
                }else{
                    this.errorMessage = i18n("Incorrect code. Please Try again.");
                    this.clearOtpValue();
                    $("#spanid").html(this.errorMessage);
                    button.classList.add("disabled-button");
                }
            })
            .catch((err) => {
                $('#validateOtpButton').css('pointer-events','');
                this.clearOtpValue();
                Toast.fire({
                    icon: "error",
                    title: "Error",
                    text: err.response.data.message,
                });
            });
        },
        clearOtpValue(){
            const inputs = document.querySelectorAll(".otp-digit");
            inputs[0].value = "";
            inputs[1].value = "";
            inputs[2].value = "";
            inputs[3].value = "";
            inputs[0].focus();
        },

    },
    template: `
    <vd-component class="vd codebase-tv-login-one" type="codebase-tv-login-one">
        <!--Header Section Start Here-->
        <section class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
												<a v-if="isLogoUpdated && logo_src" class="navbar-brand" href="javascript:void(0);" style="cursor: auto;"><img vd-node="logo" :src="logo_src"
                                                :alt="logo_alt" :style="logo_style"/></a>
                            <a v-else-if="!isLogoUpdated" class="navbar-brand" href="javascript:void(0);" style="cursor: auto;"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'"
                                                alt="Phoenix" /></a> 
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!--Header Section End Here-->
        <section class="sign-process h-100 pt-110">
            <div class="content pb-2">
                <!--Verify otp Section Start Here-->
                <div id="verifySection" class="sign-form-layout verify-otp bg-login-dark p-6448 pt-48 d-block text-center w-432 codeVerify-form">
                    <div class="ltac-top">
                        <h2 class="ltact-h2">
                            <label vd-node="text" class="mr-2"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></label>
                            <label v-if="userProfile !== ''">{{userProfile}}</label>
                        </h2>
                        <span class="ltact-span">
                            <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                        </span>
                    </div>
                    <form action="" method="" class="" id="">
                        <!--OTP input start Here-->
                        <div class="recived-code d-flex flex-wrap justify-content-center mb-4">
                        <div class="code d-flex justify-content-between mb-8 gap-16 w-auto">
                            <input vd-readonly="true" type="text"  class="form-control otp-digit" autocomplete="off"  maxlength="1" value="">
                            <input vd-readonly="true" type="text"  class="form-control otp-digit" autocomplete="off" maxlength="1" value="">
                            <input vd-readonly="true" type="text"  class="form-control otp-digit" autocomplete="off"  maxlength="1" value="">
                            <input vd-readonly="true" type="text" @keyup.enter="verifySigninCode()"  class="form-control otp-digit" autocomplete="off"  maxlength="1" value="">
                        </div>
                        <div class="invalid-otp">
                            <span id="spanid">{{errorMessage}}</span>
                        </div>
                        </div>
                        <!--OTP input End Here-->
                        <div class="form-group mb-0">          
                        <button type="button" class="primary-button disabled-button otp-verify-btn codeConnect-btn w-224" @click="verifySigninCode()" :disabled = isDisabled>
                            <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
                        </button>          
                        </div>
                    </form>
                </div>
                <!--verify otp Section End Here-->
                <div id="verifySuccess" class="code-success d-none">
                    <div class="cs-div">
                        <div class="csd-svg">
                        <svg width="106" height="106" viewBox="0 0 106 106" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="53" cy="53" r="51.5" stroke="#363F38" stroke-width="3"/>
                            <path d="M29 53L47 71L77 35" stroke="#9ECC8E" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        </div>
                        <div class="csd-message">
                        <span class="csdm-top">
                            <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
                        </span>
                        <span class="csdm-bottom">
                            <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                            <br>
                            <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                        </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Sign Up From End Here-->
    </vd-component>
    `,
};
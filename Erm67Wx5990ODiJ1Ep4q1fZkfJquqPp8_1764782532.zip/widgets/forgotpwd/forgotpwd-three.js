let {
    forgotPwd,
    getTokenDetails,
    // getVdConfig,
    getParentAppToken,
}=await import(window.importAssetJs('js/webservices.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

const { mapState} = Vuex;

export default {
    name: 'forgotpwd_three',
    data() {
        return {
            logo_src: '',
            logo_alt: '',
            logo_style: '',
            isLogoUpdated: Boolean,
            errors: {},
            email_filed: true,
            domainName: '',
            email: '',
            userDetails: {},
            getAppToken: ''
        }
    },
    computed: {
        email_id() {
            return this.email;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
        })
    },
    watch: {
        email_id(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.email = "Email field is required";
            } else if (!value.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.email = "Please enter a valid email Id";
            } else {
                this.errors.email = null;
                this.email_filed = false;
            }
        }
    },
    mounted() {
        JsLoadingOverlay.hide();
        var path = window.location.href;
        var str = path.split("//")[1].split(".")[0];
        this.domainName = str;
        //getTokenDetails(this.domainName).then((res) => {
        getParentAppToken().then((res) => {
            if (res.data.code === 200 && res.data.status === "SUCCESS") {
                this.getAppToken = res.data.data.getUserDetails[0].app_token;
            }
        });
        //logo url starts here
        // getVdConfig('logo').then((res) => {
        //     if (res.data.code == 200 && res.data.data !== null) {
        //         this.isLogoUpdated = true;
        //         this.logo_alt = res.data.data.alt;
        //         this.logo_src = res.data.data.src;
        //         this.logo_style = res.data.data.style;
        //     }
        //     else {
        //         this.isLogoUpdated = false;
        //     }
        // }).catch(ex => {
        //     console.log(ex);
        // });
        //logo url ends here
    },
    methods: {
        getRootUrl,
        i18n,
        submitForgotForm() {
            if (!this.email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.email = "Email field is required";
                this.email_filed = true;
                return;
            } else {
                this.errors.email = null;
                this.email_filed = false;
            }
            this.userDetails = {
                app_token: this.getAppToken,
                account_type: 3,
                email: this.email
            }
            forgotPwd(this.userDetails).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    // this.email = "";
                    Toast.fire({
                        icon: 'success',
                        title: 'Password reseted successfully',
                        text: res.data.message,
                    });
                    window.location.href = "/password-success"
                } else {
                    Toast.fire({
                        icon: 'error',
                        title: res.data.status,
                        text: res.data.message,
                    });
                }
            })
        },
    },
    template: `
    <vd-component class="vd forgotpwd-three" type="forgotpwd-three">
    <section class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a v-if="logo_details['logo']" class="navbar-brand" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                        :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                        <a v-else-if="logo_details['logo']!=false" class="navbar-brand" href="/"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'"
                        alt="citrine" /></a>
                    </nav>
                    </div>
                </div>
            </div>
        </section>
    <div class="card-box py-4 full-height">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 col-lg-7">
                <div class="form-wrapper mb-md-5">
                    <div class="section-heading mb-3 text-start">
                        <h2><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param><span class="text-blue fst-italic"> <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></span></h2>  
                    </div>
                    <p class="mb-30"> <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></p>

                    <div class="row">
                        <div class="col-12">
                        <form>
                            <div class="input-group mb-30">
                                <span class="input-group-text" id="email">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20 20H4C2.89543 20 2 19.1046 2 18V5.913C2.04661 4.84255 2.92853 3.99899 4 4H20C21.1046 4 22 4.89543 22 6V18C22 19.1046 21.1046 20 20 20ZM4 7.868V18H20V7.868L12 13.2L4 7.868ZM4.8 6L12 10.8L19.2 6H4.8Z" fill="#91919F"/>
                                    </svg>                                       
                                </span>
                                <input v-model="email"  type="email" class="form-control vd-component-attr" vd-component-attr-placeholder="label7" :placeholder=i18n($attrs['label7']) 
                                vd-component-attr-title="label8" :title=i18n($attrs['label8']) aria-label="Email" aria-describedby="email" :class="email_filed" autocomplete="false">
                                
                            </div>
                            <template v-if="errors.email">
                                    <h3 class="invalid-feedback validation-msg d-block">{{ errors.email }}</h3>
                                </template>
                            <a href="javascript:void(0);" class="btn-solid" @click="submitForgotForm()" 
                            :class="(email_filed)?'disabled_button':''" :disabled="email_filed"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></a>
                   
                            
                            <p class="mb-30 text-center"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param><a href="/sign-in" class="txt-theme"><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></a></p>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</vd-component>
    `
}
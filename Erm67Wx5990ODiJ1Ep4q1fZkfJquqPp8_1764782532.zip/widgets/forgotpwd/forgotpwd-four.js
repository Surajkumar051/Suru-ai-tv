let {
    forgotPwd,
    // getVdConfig,
    getParentAppToken,
  }=await import(window.importAssetJs('js/webservices.js'));
  let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
  let {i18n}=await import(window.importAssetJs('js/i18n.js'));
  let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
  const { mapState} = Vuex;
  
  export default {
    name: "forgotpwd_four",
     data() {
          return {
              errors: {},
              email_filed: false,
              domainName: "",
              email: "",
              userDetails: {},
              getAppToken: "",
          };
      },
      computed: {
          email_id() {
              return this.email;
          },
          ...mapState({
              logo_details: (state) => state.logo_details,
          })
      },
      watch: {
          email_id(value) {
              if (!value.length) {
                  this.errors.valid = false;
                  this.email_filed = true;
                  this.errors.email = i18n("Email field is required");
              } else if (
                  !value.match(
                      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                  )
              ) {
                  this.errors.valid = false;
                  this.email_filed = true;
                  this.errors.email = i18n("Please enter a valid email Id");
              } else {
                  this.errors.email = null;
                  this.email_filed = false;
              }
          },
      },
      beforeCreate(){
        if(localStorage.getItem('isloggedin')) {
            window.location.href = "/";
        }
    },
      mounted() {
          JsLoadingOverlay.hide();
          var path = window.location.href;
          var str = path.split("//")[1].split(".")[0];
          this.domainName = str;
          //getTokenDetails(this.domainName).then((res) => {
          getParentAppToken().then((res) => {
              //console.log("response////", res.data);
              if (res.data.code === 200 && res.data.status === "SUCCESS") {
                  this.getAppToken = res.data.data.getUserDetails[0].app_token;
              }
          });
  
          // getVdConfig("logo")
          //     .then((res) => {
          //         if (res.data.code == 200 && res.data.data !== null) {
          //             //this.logo = res.data.data;
          //             this.isLogoUpdated = true;
          //             this.logo_alt = res.data.data.alt;
          //             this.logo_src = res.data.data.src;
          //             this.logo_style = res.data.data.style;
          //         } else {
          //             this.isLogoUpdated = false;
          //         }
          //     })
          //     .catch((ex) => {
          //         console.log(ex);
          //     });
      },
      methods: {
          getRootUrl,
          i18n,
          submitForgotForm() {
              if (!this.email.length) {
                  this.errors.valid = false;
                  this.isFormValid = false;
                  this.errors.email = i18n("Email ID field is required");
                  this.email_filed = true;
                  return;
              } else {
                  this.errors.email = null;
                  this.email_filed = false;
              }
              this.userDetails = {
                  app_token: this.getAppToken,
                  account_type: 3,
                  email: this.email,
              };
              forgotPwd(this.userDetails).then((res) => {
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      // this.email = "";
                      Toast.fire({
                          icon: "success",
                          title: res.data.message,
                          text: '',
                      });
                      JsLoadingOverlay.show();
                      window.location.href = "/password-success";
                  } else {
                      Toast.fire({
                          icon: "error",
                          title: res.data.status,
                          text: res.data.message,
                      });
                  }
              });
          },
      },
    template: /*html*/ `
    <vd-component class="vd forgotpwd-four" type="forgotpwd-four">
    <section class="header" style="background: transparent;">
      <div class="container-fluid plr-65">
          <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <nav class="navbar navbar-expand-lg navbar-light flex-nowrap p-0 ">
                
                                       <a v-if="logo_details['logo']"  class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                     :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                  <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="getRootUrl() +'img/garnetLogo.png'"
                     alt="Garnet" /></a> 
                      
                    </nav>
              </div>
          </div>
      </div>
  </section>
   <div class="main-container ptb-10">
  <section class="box-section">
    <div class="sign-first mobile-input">
      <div class="all-content fp-ac">
        <h2 class="heading-h2"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2>
        <p class="fp-subHeading mb-4 fp-notSubmit"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
        <p class="fp-subHeading mb-4 pb-2 mt-3 fp-submitted d-none">If you have an account with us, you should receive a
          password reset email momentarily. Please check your inbox.</p>
        <div class="input-section">
          <div class="mobile-input-container position-relative fp-notSubmit">
            <input type="text" @keyup.enter="submitForgotForm" v-model="email" 
            class="form-control enter-input pr-46 vd-component-attr" 
            :class="email_filed ? '_required' : ''"
            vd-component-attr-placeholder="label5" :placeholder=i18n($attrs['label5']) vd-component-attr-title="label5" :title=i18n($attrs['label5'])>
                
            <span class="emailIcon" style="top:14px">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path
                  d="M3.33317 3.3335H16.6665C17.5832 3.3335 18.3332 4.0835 18.3332 5.00016V15.0002C18.3332 15.9168 17.5832 16.6668 16.6665 16.6668H3.33317C2.4165 16.6668 1.6665 15.9168 1.6665 15.0002V5.00016C1.6665 4.0835 2.4165 3.3335 3.33317 3.3335Z"
                  stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M18.3332 5L9.99984 10.8333L1.6665 5" stroke="#C1C1C1" stroke-width="1.33"
                  stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            </span>
            
          </div>
          <span v-if="errors.email" class="validationError mt-min10">{{ errors.email }}</span>
          <div class="otp-btn-div fp-notSubmit">
            <button vd-node="styleOnly" vd-readonly="true" class="common-btn blue fp-submit" @click="submitForgotForm()"><span><vd-component-param type="label3"
              v-html="i18n($attrs['label3'])"></vd-component-param></span>
              </button>
          </div>
  
          <div class="create-account-div">
            <span class="span-create-account">
              <a class="create-account-a" vd-node="link" href="/sign-in">
                <span class="d-flex">
                  <svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
                    <path d="M13.1666 8H3.83331" stroke="#bf000a" stroke-width="1.33" stroke-linecap="round"
                      stroke-linejoin="round" />
                    <path d="M8.49998 12.6667L3.83331 8.00004L8.49998 3.33337" stroke="#bf000a" stroke-width="1.33"
                      stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                </span>
                <span><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></span>
              </a>
            </span>
          </div>
        </div>
      </div>
    </div>
  </section>
  </div>
  
    </vd-component>
    `,
  };
  
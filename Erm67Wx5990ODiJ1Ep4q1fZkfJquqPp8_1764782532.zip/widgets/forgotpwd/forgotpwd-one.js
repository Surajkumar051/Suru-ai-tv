let {
    forgotPwd,
    getTokenDetails,
    // getVdConfig,
    getParentAppToken
}=await import(window.importAssetJs('js/webservices.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

const { mapState} = Vuex;

export default {
    name: "forgotpwd_one",
    data() {
        return {
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            errors: {},
            email_filed: true,
            domainName: "",
            email: "",
            userDetails: {},
            getAppToken: "",
        };
    },
    computed: {
        email_id() {
            return this.email;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
        })
    },
    watch: {
        email_id(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.email = i18n("Email field is required");
            } else if (
                !value.match(
                    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                )
            ) {
                this.errors.valid = false;
                this.email_filed = true;
                this.errors.email = i18n("Please enter a valid email Id");
            } else {
                this.errors.email = null;
                this.email_filed = false;
            }
        },
    },
    mounted() {
        JsLoadingOverlay.hide();
        // var path = window.location.href;
        // var str = path.split("//")[1].split(".")[0];
        // this.domainName = str;
        //getTokenDetails(this.domainName).then((res) => {
        getParentAppToken().then((res) => {
            if (res.data.code === 200 && res.data.status === "SUCCESS") {
                //this.getAppToken = res.data.data.app_token;
                this.getAppToken = res.data.data.getUserDetails[0].app_token;

            }
        });
        //logo url starts here
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
        //logo url ends here
    },
    methods: {
        getRootUrl,
        i18n,
        submitForgotForm() {
            if (!this.email.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.email = i18n("Email field is required");
                this.email_filed = true;
                return;
            } else {
                this.errors.email = null;
                this.email_filed = false;
            }
            this.userDetails = {
                app_token: this.getAppToken,
                account_type: 3,
                email: this.email,
            };
            forgotPwd(this.userDetails).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    // this.email = "";
                    Toast.fire({
                        icon: "success",
                        title: "Password resetted successfully",
                        text: res.data.message,
                    });
                    JsLoadingOverlay.show();
                    window.location.href = "/password-success";
                } else {
                    Toast.fire({
                        icon: "error",
                        title: res.data.status,
                        text: res.data.message,
                    });
                }
            });
        },
    },
    template: `
    <vd-component class="vd forgotpwd-one" type="forgotpwd-one">
        <!--Header Section Start Here-->
        <section class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a v-if="logo_details['logo']"  class="navbar-brand" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                            :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                            <a v-else-if="logo_details['logo']!=false" class="navbar-brand" href="/"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'"
                            alt="Phoenix" /></a>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!--Header Section End Here-->
        <!--Sign Up From Start Here-->
        <section class="sign-process">
            <div class="content">
                <!--From Section Start Here-->
                <div class="sign-form-layout">
                    <h2><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2>
                    <p><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
                    <form>
                        <div class="form-group form-label _required">
                        <input @keyup.enter="submitForgotForm" v-model="email" type="email" class="form-control mb-16 is-invalid vd-component-attr" :class="email_filed ? 'is-invalid' : ''" vd-component-attr-placeholder="label5" :placeholder=i18n($attrs['label5']) 
                        vd-component-attr-title="label6" :title=i18n($attrs['label6'])>
                            <template v-if="errors.email">
                                <h3 class="invalid-feedback validation-msg">{{ errors.email }}</h3>
                            </template>
                        </div>
                        <div class="form-group">
                            <button type="button" class="primary-button" @click="submitForgotForm()"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></button>
                        </div>
                    </form>
                    <p class="text-center back"><a vd-node="link" class="callByAjax" href="/sign-in"><span class="mr-10"><img :src="getRootUrl() +'img/left-arrow-icon.png'" al="left"></span><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></a></p>
                </div>
                <!--From Section End Here-->
            </div>
        </section>
</vd-component>
    `,
};

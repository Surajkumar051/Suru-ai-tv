let {
    getUserDetails,
    getAdminUserDetails,
    updateUserDetails,
    changePassword,
    getMyPlan,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    generateSST,
    removeProfilePic,
    getEndUserRegdLoginSetting,
    removeCoverPic,
    DeleteUser,
    getUgcSettingStatus
} = await import(window.importAssetJs('js/webservices.js'));
let {
    TOGGLE_ACCOUNT_CANCELLATION_MODAL,
} = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:Cropper} = await import(window.importAssetJs('js/cropper.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl }  = await import(window.importAssetJs('js/web-service-url.js'));
let {
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies,
    notLoggedinUser
} = await import(window.importAssetJs('js/main.js'));
const { defineAsyncComponent } = Vue;
const { useVuelidate } = Vuelidate;
const { required, minLength, maxLength, sameAs, helpers } = VuelidateValidators;
const { mapState, mapGetters } = Vuex;

const passwordStrength = helpers.withMessage(
    'Password must be between 8 to 30 characters long which should contain at least a numeric digit, an uppercase, a lowercase and a special character(@#$%^&+=)',
    helpers.regex(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[@#$%^&+=])[a-zA-Z0-9@#$%^&+=]{8,30}$/),
);

export default {
    name: "profile_two",
    template: `
    <vd-component class="vd profile-two" type="profile-two">
        <section id="muvi-MyProfile2">
            <div v-if="show_device != 'showplan'">
                   <div class="my-profile-process" v-if="shouldShowProfileProcess">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <label class="dashboard-heading white-color mbottom-20">
                                    <vd-component-param type="label25" v-html="dynamicLabel"></vd-component-param>
                                </label>  
                                <div class="form-group">
                                    <div class="pro-cover-photo-div mb-24">
                                        <!-- Profile Photo -->
                                        <div v-if="isProfilePhotoVisible" class="pro-photo-div">
                                            <img class="profile-photo w-100 h-100 profileImages" v-if="profile_image_url !== ''" :src="profile_image_url" alt="profile"/>  
                                            <img class="profile-photo w-100 h-100 profileImages" v-if="profile_image_url === ''" :src="getRootUrl() +'img/no-avatar.png'" alt="profile" />                   
                                        </div>
                                        
                                        <!-- Cover Photo -->
                                        <img v-if="isCoverPhotoVisible" class="cover-photo w-100" :src="cover_image_url !== '' ? cover_image_url : getRootUrl() + 'img/cover-photo-dummy.png'" />
                                    </div>
                                    
                                    <!-- Edit Buttons -->
                                    <div class="buttons-div edit-profile-picture">
                                        <!-- Profile Photo Edit Button -->
                                        <button v-if="isProfileEditButtonVisible" class="primary-button btn-groups">
                                            <input type="file" id="profile-dp" class="form-control type-file" ref="image" :title="i18n('No file chosen')" @change="handelfileupload($event)" accept="image/*" />
                                            <span class="first-span">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14 10V12.6667C14 13.0203 13.8595 13.3594 13.6095 13.6095C13.3594 13.8595 13.0203 14 12.6667 14H3.33333C2.97971 14 2.64057 13.8595 2.39052 13.6095C2.14048 13.3594 2 13.0203 2 12.6667V10" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M11.3307 5.33333L7.9974 2L4.66406 5.33333" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M8 2V10" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <span class="second-span"><vd-component-param type="label26" v-html="i18n($attrs['label26'])"></vd-component-param></span>
                                            </span>
                                            <span class="third-span" v-if="profile_image_url !== ''" @click="removeProfilePic()">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2 4H3.33333H14" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M5.33594 3.9987V2.66536C5.33594 2.31174 5.47641 1.9726 5.72646 1.72256C5.97651 1.47251 6.31565 1.33203 6.66927 1.33203H9.33594C9.68956 1.33203 10.0287 1.47251 10.2787 1.72256C10.5288 1.9726 10.6693 2.31174 10.6693 2.66536V3.9987M12.6693 3.9987V13.332C12.6693 13.6857 12.5288 14.0248 12.2787 14.2748C12.0287 14.5249 11.6896 14.6654 11.3359 14.6654H4.66927C4.31565 14.6654 3.97651 14.5249 3.72646 14.2748C3.47641 14.0248 3.33594 13.6857 3.33594 13.332V3.9987H12.6693Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M6.66406 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M9.33594 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>                            
                                            </span>
                                        </button>
                                        
                                        <!-- Cover Photo Edit Button -->
                                        <button v-if="isCoverEditButtonVisible" class="primary-button btn-groups">
                                            <input type="file" id="cover-dp" class="form-control type-file" ref="image" :title="i18n('No file chosen')" @change="handelfileuploadForCoverImge($event)" accept="image/*" />
                                            <span class="first-span">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14 10V12.6667C14 13.0203 13.8595 13.3594 13.6095 13.6095C13.3594 13.8595 13.0203 14 12.6667 14H3.33333C2.97971 14 2.64057 13.8595 2.39052 13.6095C2.14048 13.3594 2 13.0203 2 12.6667V10" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M11.3307 5.33333L7.9974 2L4.66406 5.33333" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M8 2V10" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <span class="second-span"><vd-component-param type="label27" v-html="i18n($attrs['label27'])"></vd-component-param></span>
                                            </span>
                                            <span class="third-span" v-if="cover_image_url !== ''" @click="removeCoverPic()">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2 4H3.33333H14" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M5.33594 3.9987V2.66536C5.33594 2.31174 5.47641 1.9726 5.72646 1.72256C5.97651 1.47251 6.31565 1.33203 6.66927 1.33203H9.33594C9.68956 1.33203 10.0287 1.47251 10.2787 1.72256C10.5288 1.9726 10.6693 2.31174 10.6693 2.66536V3.9987M12.6693 3.9987V13.332C12.6693 13.6857 12.5288 14.0248 12.2787 14.2748C12.0287 14.5249 11.6896 14.6654 11.3359 14.6654H4.66927C4.31565 14.6654 3.97651 14.5249 3.72646 14.2748C3.47641 14.0248 3.33594 13.6857 3.33594 13.332V3.9987H12.6693Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M6.66406 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M9.33594 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>                            
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

          
                    <div class="my-profile-process">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <label class="dashboard-heading white-color mbottom-20 mb-32">
                                <vd-component-param type="label28" v-html="i18n($attrs['label28'])"></vd-component-param>
                                </label>  
                                <form @submit.prevent="UpdateAbout" novalidate>
                                    <div class="form-group form-label">
                                        <div class="text-div mb-32" >
                                            <textarea class="about-text" v-model="about"
                                            :class="about_field ? 'is-invalid' : ''" id="about"></textarea>
                                            <div class="invalid-feedback validation-msg" style="display: block;">{{errors.about}}</div>
                                        </div>
                                        <div class="update-btn-div">
                                            <button type = "submit" class="primary-button update-btn" :disabled="about_field || isDisabled">
                                            <vd-component-param type="label36" v-html="i18n($attrs['label36'])"></vd-component-param>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--Profile Step Here-->
                    <div class="account-info-divs">
                        <div class="my-profile-process w-50">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <label class="dashboard-heading white-color mbottom-20">
                                    <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                                    </label>
                                    <form @submit.prevent="UpdateProfile" novalidate>
                                        <div class="form-group form-label _required">       
                                            <label>
                                                <vd-component-param type="label29" v-html="i18n($attrs['label29'])"></vd-component-param>
                                                <span class="mandatory-indicate">*</span>
                                            </label>
                                            <input v-model="name" type="text" class="form-control mb-16"
                                            :class="name_field ? 'is-invalid' : ''" id="p_name">
                                            <div class="invalid-feedback pb-2 validation-msg">{{ errors.name }}</div>    
                                    
                                            <label><vd-component-param type="label30" v-html="i18n($attrs['label30'])"></vd-component-param></label>
                                            <input v-model="email" type="text" readonly class="form-control" id="p_mail">     
                        
                                            <label><vd-component-param type="label31" v-html="i18n($attrs['label31'])"></vd-component-param></label>
                                            <input v-model="mobile" type="text" class="form-control mb-16"
                                            placeholder="Please Enter Phone Number" :class="mobile_field ? 'is-invalid' : ''"
                                            id="p_mobile" v-if="muviAuthSettingType == '1' || muviAuthSettingType == '13'">
                                            <input v-model="mobile" type="text" class="form-control mb-16"
                                            placeholder="Please Enter Phone Number" :class="mobile_field ? 'is-invalid' : ''"
                                            id="p_mobile" v-if="muviAuthSettingType !== '1' && muviAuthSettingType !== '13'" readonly>
                                            <div class="invalid-feedback pb-2 validation-msg">{{ errors.mobile }}</div>
    
                                            <div class="form-group form-label _required">
                                                <button type="submit" class="primary-button update-btn mt-32"
                                                :disabled="name_field || isProfileDisabled" :class="(name_field)?'disabled_button':''">
                                                    <vd-component-param type="label2" v-html="i18n($attrs['label2'])">
                                                    </vd-component-param>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="my-profile-process w-50"  :style="{ 'pointer-events': muviAuthSettingType != '1' && muviAuthSettingType != '13' ? 'none' : '' }">
                            <div class="row" :style="{'opacity': muviAuthSettingType != '1'  && muviAuthSettingType != '13' ? '0.6' : '' }">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <label class="dashboard-heading white-color mbottom-20">
                                    <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
                                    </label>
                                    <form @submit.prevent="updatePassword" novalidate>
                                        <div class="form-group">
                                            <div class="show-password form-box password-input _required" v-if = "is_sso_change_password || (muviAuthSettingType != '1' && muviAuthSettingType != '13')">
                                                <label><vd-component-param type="label32" v-html="i18n($attrs['label32'])"></vd-component-param></label>
                                                <input v-bind:type="[showOldPassword ? 'text' : 'password']" id="password"
                                                    placeholder="Old Password" autocomplete="off" v-model="form.password"
                                                    :class="['form-control pr-42', v$.form.password.$error ? 'is-invalid' : '']" />
                                                <button type="button" @click="showOldPassword = !showOldPassword">
                                                    <i :class="[showOldPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                                                <div class="invalid-feedback pb-2 validation-msg" v-if="v$.form.password.$error">
                                                    {{v$.form.password.$errors[0].$message}}
                                                </div>
                                            </div>
                                            <div class="show-password form-box password-input _required">
                                                <label><vd-component-param type="label33" v-html="i18n($attrs['label33'])"></vd-component-param></label>
                                                <input v-bind:type="[showNewPassword ? 'text' : 'password']" id="new_password"
                                                    placeholder="New Password" autocomplete="off" v-model="form.new_password"
                                                    :class="['form-control pr-42', v$.form.new_password.$error ? 'is-invalid' : '']" />
                                                <button type="button" @click="showNewPassword = !showNewPassword">
                                                    <i :class="[showNewPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                                                <div class="invalid-feedback pb-2 validation-msg"
                                                    v-if="v$.form.new_password.$error">
                                                    {{v$.form.new_password.$errors[0].$message}}
                                                </div>

                                            </div>
                                            <div class="show-password form-box password-input _required">
                                                <label><vd-component-param type="label34" v-html="i18n($attrs['label34'])"></vd-component-param></label>
                                                <input v-bind:type="[showConfirmPassword ? 'text' : 'password']"
                                                    id="confirm_password" placeholder="Confirm Password" autocomplete="off"
                                                    v-model="form.confirm_password"
                                                    :class="['form-control pr-42', v$.form.confirm_password.$error ? 'is-invalid' : '']"
                                                    @copy.prevent @paste.prevent @cut.prevent />
                                                <button type="button" @click="showConfirmPassword = !showConfirmPassword">
                                                    <i
                                                        :class="[showConfirmPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                                                <div class="invalid-feedback pb-2 validation-msg"
                                                    v-if="v$.form.confirm_password.$error">
                                                    {{v$.form.confirm_password.$errors[0].$message}}
                                                </div>
                                            </div>
                                            <div class="form-group form-label _required">
                                                <button type="submit" class="primary-button update-btn mt-32">
                                                    <vd-component-param type="label4" v-html="i18n($attrs['label4'])">
                                                    </vd-component-param>
                                                </button>
                                            </div>  
                                        </div>
                                    </form>
                                </div>            
                            </div>
                        </div>
                    </div>
                    <div class="my-profile-process">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <label class="dashboard-heading white-color mbottom-20 mb-2">
                                    <vd-component-param type="label37" v-html="i18n($attrs['label37'])"></vd-component-param>
                                </label>  
                                <div class="form-group">
                                    <div class="text-div mb-32">
                                        <p class="pda-para">
                                            <vd-component-param type="label38" v-html="i18n($attrs['label38'])"></vd-component-param>
                                        </p>
                                    </div>
                                    <div class="update-btn-div">
                                        <button class="primary-button update-btn" data-toggle="modal" data-target="#deleteaccount">
                                            <vd-component-param type="label39" v-html="i18n($attrs['label39'])"></vd-component-param>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="my-profile-process" v-if="is_subscription_enabled">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                            <label class="dashboard-heading white-color mbottom-20">
                                <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                            </label>
                            <div v-for="({ plan_name, next_billing_date },i) in my_plans">
                                <h2 class="planname">
                                    {{plan_name}}
                                    <small class="text-warning" v-if="is_cancelled">Cancelled</small>
                                    <small class="text-danger" v-if="is_expired">Expired</small>
				    <small class="text-primary" v-if="is_free_Trial(i)">On Free Trial</small>
                                </h2>
                                <p class="plandate">Valid till {{next_billing_date}}</p>
                            </div>
                            <p v-if="noPlanMsg">{{noPlanMsg}}</p>
                            <ul>
                                <!--<li class="choose-plan-button" @click="showPlan();">
                                    <button
                                        type="button"
                                        class="primary-button plans"
                                    >
                                        Change Plan
                                    </button>
                                </li>
                                <li v-if="is_subscribed">
                                    <button
                                        type="button"
                                        class="primary-button"
                                        @click="openAccountCancellationModal"
                                    >
                                        Cancel Plan
                                    </button>
                                </li>
                                <li class="choose-plan-button" @click="showPlan();" v-if="(!is_subscribed && !is_cancelled) || is_expired">
                                    <button
                                        type="button"
                                        class="primary-button plans"
                                    >
                                        Choose Plan
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>-->

                <!--Profile picture popup start here-->
                <div class="modal fade upload-picture-model" id="uploadModalCenter" tabindex="-1" role="dialog"
                    data-backdrop="static" data-keyboard="false" aria-labelledby="uploadModalCenterTitle"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="uploadModalLongTitle">
                                    <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                                </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                    @click="closeModal">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body" style="overflow-y: auto;max-height: 400px;">
                                <form>
                                    <h2 v-if="isShowcropImage">
                                        <vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param>
                                    </h2>
                                    <div class="Crop-image" id="crop-div" v-if="isShowcropImage">
                                        <img id="cropedImage" class="uploaded-image mw-100" alt="image" />
                                    </div>                                    
                                </form>
                            </div>
                            <div class="modal-footer" style="padding: 16px;">
                                <button type="button" class="btn btn-primary" @click="uploadImage"
                                    :disabled="displayImage===null">
                                    <vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <!--profile Picture popup end here-->
                <!--cover Picture popup start here-->
                <div class="modal fade upload-picture-model" id="uploadModalCover" tabindex="-1" role="dialog"
                data-backdrop="static" data-keyboard="false" aria-labelledby="uploadModalCoverTitle"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="uploadModalLongTitle">
                                <vd-component-param type="label35" v-html="i18n($attrs['label35'])"></vd-component-param>
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                @click="closeModalCover">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" style="overflow-y: auto;max-height: 400px;">
                            <form>
                                <h2 v-if="isShowcropCoverImage">
                                    <vd-component-param type="label8" v-html="i18n($attrs['label8'])">
                                    </vd-component-param>
                                </h2>
                                <div class="Crop-image" id="crop-div" v-if="isShowcropCoverImage">
                                    <img  id="cropedImageCover" class="uploaded-image mw-100" alt="image" />
                                </div> 
                            </form>
                        </div>
                        <div class="modal-footer" style="padding: 16px;">
                            <button type="button" class="btn btn-primary" @click="uploadImageForCoverPhoto"
                                :disabled="displayImage===null">
                                <vd-component-param type="label24" v-html="i18n($attrs['label24'])">
                                </vd-component-param>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!--cover Picture popup end here-->
            <!--delete account start Here-->    
            <div class="modal fade delete-massage delete-watch-history" id="deleteaccount" tabindex="-1" role="dialog" aria-labelledby="deletehistoryLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <section class="body-section">
                                <div class="title">
                                    <vd-component-param type="label40" v-html="i18n($attrs['label40'])"></vd-component-param>
                                </div>
                                <p class="form-text mb-0 mt-2 pe-2">
                                    <vd-component-param type="label41" v-html="i18n($attrs['label41'])"></vd-component-param>
                                </p>
                            </section>
                        </div>
                        <div class="modal-footer no-border">
                            <button type="button" class="btn dismiss" data-dismiss="modal" @click="cancelModal">
                                <vd-component-param type="label42" v-html="i18n($attrs['label42'])"></vd-component-param>
                            </button>
                            <button type="button" class="btn btnProceed" id="proceedWH" @click="deleteAccount">
                                <vd-component-param type="label43" v-html="i18n($attrs['label43'])"></vd-component-param>
                            </button>
                        </div>
                        <div class="w-100 ms-4 ps-3">
                            <div class="form-check mb-0 mt-2" style="padding-bottom: 15px;line-height: inherit;">
                                <input class="form-check-input" type="checkbox" value="" name="permanent_end_user_delete" id="permanent_end_user_delete" v-model="isPermanentDelete" @change="check($event)">
                                <!--<label class="form-check-label" for="mandatory" style="color: rgba(255, 255, 255, 0.56);">Delete all historical data permanently from store</label>-->
                                <label class="form-check-label" for="mandatory" style="color: rgba(255, 255, 255, 0.56);"><vd-component-param type="label44" v-html="i18n($attrs['label44'])"></vd-component-param></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--delete account End Here-->
                <account_cancellation_modal :label9="$attrs['label9']" :label10="$attrs['label10']"
                    :label11="$attrs['label11']" />
            </div>
            <!--Subscription Cancellation Popup start Here-->
            <!--All plan starts Here-->
            <!--<section class="all-plans-page" v-if="show_device === 'showplan'">
                <!--Heading
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <h1 class="dashboard-heading white-color mbottom-20">
                            <vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                        </h1>
                    </div>
                </div>
                <div class="all-plans-page" v-if="is_subscription_enabled">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 d-flex" v-for="(itemData,index) in myPlan">
                            <div class="w-100 plans-data align-items-stretch" :class="{'selected-plan': selectedindex == index}" @click="selectedPlan(index)">
                                <h3>
                                    {{itemData.plan_name.toUpperCase()}}
                                    <span :class="{selected: selectedindex == index}" v-if="selectedindex == index">
                                        <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                                    </span>
                                </h3>
                                <span class="price" v-for="price of itemData.price">
                                    {{price.currency_code}} {{price.subscription_plan_price}}<span>/{{price.plan_interval}} {{price.plan_interval_unit}}(s) </span>
                                    <p v-if="price.plan_free_trial_interval === 0">No free trial!</p>
                                    <p v-else-if="price.plan_free_trial_interval === 1">First {{price.plan_free_trial_interval}} {{price.plan_free_trial_unit}} is free!</p>
                                    <p v-else>First {{price.plan_free_trial_interval}} {{price.plan_free_trial_unit}}s are free!</p>
                                    <p class="plan-description">{{displayDescription(itemData.plan_description)}}</p>
                                    <button
                                        type="button"
                                        class="primary-button fw-700"
                                        :class="{'active-checkout': (isSelected && selectedindex == index) || isActive }"
                                        @click="() => {
                                            if(isSelected && selectedindex == index) {
                                                redirectCheckout(index,itemData);
                                            }
                                        }"
                                    >
                                        {{isSelected && selectedindex == index?'Proceed to Checkout':'Subscribe'}}
                                    </button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blank-card-info" v-else>
                    <p>
                        <vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param>
                    </p>
                </div>
            </section>-->
            <!--Choose Your plan End Here-->
            <!--Subscription Cancellation Popup End Here-->
        </section>
    </vd-component>
    `,
    components: {
        account_cancellation_modal: defineAsyncComponent(() => import(window.importAssetJs('js/modals/account-cancellation-modal.js'))),
    },
    props: {
        tab: String
    },
    setup(props) {
        const tab = props.tab;
        return {
            tab,
            v$: useVuelidate()
        };
    },
    validations() {
        return {
            form: {
                password: {
                    required: helpers.withMessage(i18n('Please enter your current password.'), required),
                    $autoDirty: true
                },
                new_password: {
                    required: helpers.withMessage(i18n('Password field is required.'), required),
                    minLength: helpers.withMessage(i18n('Password should be more than 8 characters long.'), minLength(8)),
		            //maxLength: helpers.withMessage('Password length exceeded(Max 30 char).', maxLength(30)),
		            $autoDirty: true
                },
                confirm_password: {
                    required: helpers.withMessage(i18n('Please enter confirm password'), required),
                    sameAs: helpers.withMessage(i18n('New Password and Confirm password must be identical.'), sameAs(this.form.new_password)) ,
                    $autoDirty: true
                }
            }
        }
    },
    data() {
        return {
            show_modal: false,
            isreason: false,
            is_user_subscribed: false,
            valid: false,
            show_device: 'profile_two',
            name: '',
            email: '',
            mobile: '',
            profile_image_url: '',
            cover_image_url: '',
            displayImage: '',
            selectedImage: '',
            about:'',
            tempAbout:'',
            my_plans: [],
            subscription_plans: [],
            browseImgUrl: [],
            noPlanMsg: '',
            file: '',
            planlist: [],
            ActivePlan: false,
            cancelReasons: [],
            user: '',
            cancelId: '',
            user_uuid: JSON.parse(localStorage.getItem('user')),
            cropperData: null,
            cropperDataCover:null,
            isShowcropImage: false,
            isShowcropCoverImage: false,
            myPlan: [],
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2
            },
            name_field: false,
            //Er/76686
            mobile_field: false,
            password: '',
            new_password: '',
            confirm_password: '',
            errors: {},
            endUserDetails: JSON.parse(localStorage.getItem('user')),
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            pswsnewFieldNotValidate: false,
            isFormValid: false,
            about_field:false,
            form: {
                password: '',
                new_password: '',
                confirm_password: ''
            },
            countryCode: 'US',
            showOldPassword: false,
            showNewPassword: false,
            showConfirmPassword: false,
            isDisabled:true,
            tempName:'',
            tempPhone:'',
            tempEmail:'',
            isProfileDisabled:'true',
            adminUserUuid: localStorage.getItem('adminId'),
            muviAuthEmailOptSettingType : false,
            muviAuthEmailOptSettingList : ['3','34'],
            muviAuthSettingType : '',
            email_filed: false,
            isPermanentDelete:false,
             // ER 107900
             isMultipleProfileEnabled: false,
             ugcEnabled: false,
             is_sso_change_password: true

 
        }
    },
    computed: {
        ...mapGetters({
            is_subscription_enabled: 'is_subscription_enabled'
        }),
        ...mapState({
            show_account_cancellation_modal: state => state.show_account_cancellation_modal
        }),
        username() {
            return this.name;
        },
        is_subscribed() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 1;
            } else {
                return false;
            }
        },
        is_cancelled() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 2;
            } else {
                return false;
            }
        },
        is_expired() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 0;
            } else {
                return false;
            }
        },
        shouldShowProfileProcess() {
            return !this.isMultipleProfileEnabled && !this.ugcEnabled ||
                   !this.isMultipleProfileEnabled && this.ugcEnabled ||
                   this.isMultipleProfileEnabled && this.ugcEnabled;
          },
          isProfilePhotoVisible() {
            return !this.isMultipleProfileEnabled ;
          },
          isCoverPhotoVisible() {
            return this.ugcEnabled;
          },
          isProfileEditButtonVisible() {
            return !this.isMultipleProfileEnabled ;
          },
          isCoverEditButtonVisible() {
            return this.ugcEnabled;
          },
          dynamicLabel() {
            if (!this.isMultipleProfileEnabled && this.ugcEnabled) {
              return this.i18n(this.$attrs['label25']);
            } else if (this.isMultipleProfileEnabled && this.ugcEnabled) {
              return this.i18n(this.$attrs['label27']);
            } else if (!this.isMultipleProfileEnabled && !this.ugcEnabled) {
              return this.i18n(this.$attrs['label26']);
            }
          },
    },
    watch: {
        async show_account_cancellation_modal(cv) {
            if (!cv) {
                const my_plans_response = await getMyPlan();
                if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
                    this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
                } else {
                    this.noPlanMsg = my_plans_response.data.message;
                }
            }
        },
        name(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = i18n("The Name field is required.");
            }
            //Er/76685
            else if (value.length < 2 || value.length > 50) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = i18n("The Name should be between 2 to 50 characters.");
            }
            //Er/76685
            else if (!value.match("^[ A-Za-z0-9-À-ÿ]*$")) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = i18n("The Name field contains only alphanumeric values.");
            } else {
                this.errors.name = null;
                this.name_field = false;
            } 
            
            if(this.tempName !== value){
                this.isProfileDisabled = false;
            }
        },
        // er- Er/76686 start validation
        mobile(value) {
            if (!this.checkMobileNum(value)) {
                this.errors.valid = false;
                this.mobile_field = true;
                this.errors.mobile = i18n("Please enter a valid phone number");
            }
            else {
                this.errors.mobile = null;
                this.mobile_field = false;
            }

            if(this.tempPhone !== value){
                this.isProfileDisabled = false;
            }
        },
        email(value){
            if(this.muviAuthEmailOptSettingType && (value == null || !value.length)){
                this.errors.email = null;
                this.email_filed = false;
            }else{
                if (!value.length) {
                    this.errors.valid = false;
                    this.email_filed = true;
                    this.errors.email = i18n("Email field is required");
                } else if (
                    !value.match(/^(?=.{1,64}@)[^@]+@([^@]{2,})+\.([^@.]{2,14})$/)) {
                    this.errors.valid = false;
                    this.email_filed = true;
                    this.errors.email = i18n("Please enter a valid email");
                } else {
                    this.errors.email = null;
                    this.email_filed = false;
                }
            }
            if(this.tempEmail !== value){
                this.isProfileDisabled = false;
            }
        },
        // er- Er/76686 end validation
        about(value){
            if (value != null && value.length > 500) {
                this.errors.valid = false;
                this.about_field = true;
                this.errors.about = i18n("The About field should be less than 500 characters.");
            }else if(value != null && value.trim().length == 0){
                if(value == ""){
                    this.errors.about= null;
                    this.about_field = false;
                }else{
                    this.errors.valid = false;
                    this.about_field = true;
                    this.errors.about = i18n("Please enter valid info under About.");
                }
            } else {
                this.errors.about= null;
                this.about_field = false;
            }
            if(this.tempAbout !== value){
                this.isDisabled = false;
            }
        }
    },
    methods: {
        getRootUrl,
        i18n,
         // ER -107900
         fetchUGCSettingStatus() {
            getUgcSettingStatus().then((res) => {
                if(res.data.status == 'SUCCESS' && res.data.code==200){
                    console.log("FETCH",res);
                    res.data.data.sections[0].groups[0].nodes.forEach(element => {
                      if(element.node_code == 'ugc'){
                        this.ugcEnabled = (element.node_value && element.node_value ==1)?true:false;
                      }
                    });
                    
                }
            });
        },
        is_free_Trial(i){
            const plan=this.my_plans[i];
            if(plan.plan_free_trial_unit === 'Day'){
                const subscriptionDate= new Date(plan.subscription_start_date);
                subscriptionDate.setDate(subscriptionDate.getDate()+plan.plan_free_trial_interval);
                const nextBillingDate=new Date(plan.next_billing_date);
                subscriptionDate.setHours(0,0,0);
                nextBillingDate.setHours(0,0,0);
                if (subscriptionDate.getTime() === nextBillingDate.getTime() && plan.plan_status === 1) {
                    return true;
                }else{
                   return false; 
                }
            }else if(plan.plan_free_trial_unit === 'Month'){
                const subscriptionDate= new Date(plan.subscription_start_date);
                subscriptionDate.setMonth(subscriptionDate.getMonth()+plan.plan_free_trial_interval);
                const nextBillingDate=new Date(plan.next_billing_date);
                subscriptionDate.setHours(0,0,0);
                nextBillingDate.setHours(0,0,0);
                if (subscriptionDate.getTime() === nextBillingDate.getTime() && plan.plan_status === 1) {
                    return true;
                }else{
                   return false; 
                } 
            }
        },
        checkMobileNum(value) {
            var re = new RegExp(/^(\+\d{1,3}[-]?)?\d{4,20}$|^$/); //biswa
            if (re.test(value)) {
                console.log("Valid");
                return true;
            } else {
                console.log("Invalid");
                return false;
            }
        },
        displayDescription(plan_description) {
            if (plan_description.length > 500) {
                return plan_description.slice(0, 500).concat('...');
            } else {
                return plan_description;
            }
        },
        openAccountCancellationModal() {
            this.$store.dispatch(TOGGLE_ACCOUNT_CANCELLATION_MODAL, true);
        },
        removeProfilePic() {
            JsLoader.show();
            removeProfilePic().then(res => {
                JsLoader.hide();
                if (res.data.code === 200) {
                    this.profile_image_url = '';
                    this.getProfileDetails(true, false);
                }
            });
        },
        removeCoverPic() {
            JsLoader.show();
            removeCoverPic().then(res => {
                JsLoader.hide();
                if (res.data.code === 200) {
                    this.cover_image_url = '';
                    this.getProfileDetails(false,false);
                }
            });
        },
        getProfileDetails: function (is_deleted = false, is_profile = false) {
            getUserDetails().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    if (is_deleted) {
                        $(".profileImages").attr("src", this.getRootUrl() +'img/no-avatar.png');
                        this.endUserDetails.profile_image_url = res.data.data.getUserDetails[0].profile_image_url;
                    } else {
                        this.profile_image_url = res.data.data.getUserDetails[0].profile_image_url;
                        this.cover_image_url = res.data.data.getUserDetails[0].cover_image_url;
                        if(is_profile){
                            $(".profileImages").attr("src", this.profile_image_url);
                        }
                        this.endUserDetails.profile_image_url = this.profile_image_url;
                        this.endUserDetails.cover_image_url = this.cover_image_url;
                    }
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                }
            });
        },
        checkPlan: function () {
            getMyPlan().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    JsLoadingOverlay.hide();
                    this.planlist = res.data.data.myPlans.my_plans_list;
                    this.planlist.forEach((elment) => {
                        //this.isActive = true;
                        if (elment.plan_status === 1) {
                            this.ActivePlan = elment;
                        } else if (elment.plan_status === 0) {
                            this.ActivePlan = elment;
                        }
                    });
                } else {
                    this.noPlanMsg = res.data.message;
                    JsLoadingOverlay.hide();
                }
            });
        },
        showPlan() {
            JsLoadingOverlay.show();
            this.showplan = true;
            this.getPlan();
            this.show_device = 'showplan';
        },
        getPlan: function () {
            getSubscriptionPlans(this.countryCode).then((res) => {
                if (res.data.code == 200 && res.data.status === "SUCCESS") {
                    this.myPlan = res.data.data.subscriptionPlans.subscription_plans_list;
                    JsLoadingOverlay.hide();
                }
                if ((res.data.code === 600 || res.data.code === 601) && res.data.status === "FAILED") {
                    JsLoadingOverlay.hide();
                } else {
                    JsLoadingOverlay.hide();
                }
            })
        },
        selectedPlan: function (data) {
            this.selectedindex = data;
            this.isSelected = true;
        },
        redirectCheckout(i, plan) {
            this.selectedPlanIndex = i + 1;
            if (localStorage.getItem('isloggedin') == "true") {
                const user = JSON.parse(window.localStorage.getItem("user"));
                const parts = user.name.split(' ');
                this.planDetail = {
                    plan_uuid: plan.subscription_plan_uuid,
                    pricing_uuid: plan.price[0].subscription_pricing_uuid,
                    billing_type: 2,
                    gateway_order: {
                        first_name: parts[0],
                        last_name: parts[1],
                        email: user.email,
                        subscription_plan_uuid:plan.subscription_plan_uuid,
                        plan_free_trial_interval: plan.price[0].plan_free_trial_interval,
                        subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                        return_url: window.location.origin + '/checkout-success?billing_type=2'
                    }
                };
                if (this.selectedPlanIndex !== undefined) {
                    generateSST(this.planDetail).then((res) => {
                        let sst_token = res.data.data.sst_token;
                        window.location.href = "/checkout/" + sst_token + "/" + this.planDetail.billing_type;
                    });
                }
            } else {
                window.location.href = "/sign-up";
            }
        },
        closeModal: function () {
            $('#uploadModalCenter').modal('hide');
            $('input[type="file"]').val(''); //biswa
            this.cropperData.destroy();
        },
        closeModalCover: function () {
            $('#uploadModalCover').modal('hide');
            $('input[type="file"]').val(''); //biswa
            this.cropperDataCover.destroy();
        },
        handelfileupload: function (event) {
            console.log("inside handelfileupload");
            this.selectedImage = event.target.files[0];
            const fileSizeInBytes = this.selectedImage.size;
            const fileSizeInMB = fileSizeInBytes / (1024 * 1024);

            if (event.target.files[0]) {
                if (!this.validateFiles(this.selectedImage.name)) {
                    $("#profile-dp").val("");
                    Toast.fire({
                        icon: 'error',
                        text: "Uploaded file is in the wrong format. It should be in jpg/jpeg/png format.",
                    });
                } else if (fileSizeInMB > 5) {
                    $("#profile-dp").val("");
                    Toast.fire({
                        icon: 'error',
                        text: "The profile image exceeds the maximum allowed size 5 MB.",
                    });
                } else {
                    console.log("inside handelfileupload else")
                    this.isShowcropImage = true;

                    $('#uploadModalCenter').modal('show');

                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#cropedImage').attr('src', e.target.result);
                    };
                    reader.readAsDataURL(this.selectedImage);

                    setTimeout(this.initCropper, 1200);     
                }
                event.target.value = ""; // Reset file input
            }
        },

        initCropper() {
            var image = document.getElementById('cropedImage');
            this.cropperData = new Cropper(image, {
                dragMode: 'move',
                autoCropArea: 0.6,
                restore: false,
                guides: false,
                center: false,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false,
                aspectRatio: 1 / 1,
                viewMode: 1,
                data: { //define cropbox size
                    width: 250,
                    height: 250,
                },
            });
        },
        handelfileuploadForCoverImge: function (event) {
            console.log("inside handelfileuploadForCoverImge");
            this.selectedImage = event.target.files[0];
            const fileSizeInBytes = this.selectedImage.size;
            const fileSizeInMB = fileSizeInBytes / (1024 * 1024);
            if (event.target.files[0]) {
                if (!this.validateFiles(this.selectedImage.name)) {
                    $("#cover-dp").val("")
                    Toast.fire({
                        icon: 'error',
                        text: "Uploaded file is in wrong format.It should be in jpg/jpeg/png formate.",
                    })

                }else if(fileSizeInMB > 5) {
                    $("#profile-dp").val("");
                    Toast.fire({
                        icon: 'error',
                        text: "The cover image exceeds the maximum allowed size 5 MB.",
                    });
                }else {
                    console.log("inside handelfileuploadForCoverImge else");
                    this.isShowcropCoverImage = true;
                    $('#uploadModalCover').modal('show');
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#cropedImageCover').attr('src', e.target.result)
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    setTimeout(this.initCropperForCoverImage, 1200);
                }
                event.target.value = "";
            }

        },
        initCropperForCoverImage() {
            var image = document.getElementById('cropedImageCover');
            this.cropperDataCover = new Cropper(image, {
                dragMode: 'move',
                autoCropArea: 0.6,
                restore: false,
                guides: false,
                center: false,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false,
                aspectRatio: 3.6 / 1,
                viewMode: 1,
                data: { //define cropbox size
                    width: 900,
                    height: 240,
                },
            });
        },
        uploadImage: function () {
            JsLoader.show();
            const croppedCanvas = this.cropperData.getCroppedCanvas();
            const imageType = this.selectedImage.type; // Get original image type
            const isPng = imageType === 'image/png'; // Check if the image is PNG
            const format = isPng ? 'image/png' : 'image/jpeg'; // Use PNG or JPEG format
            const maxFileSize = 5 * 1024 * 1024; // 2 MB in bytes
            let quality = isPng ? undefined : 0.9; // PNG doesn't use quality, JPEG starts at 90%

            let dataURL = croppedCanvas.toDataURL(format, quality); // Initial conversion
            let base64String = dataURL.split(',')[1];
            let byteSize = (base64String.length * (3 / 4)) - (base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0);

            console.log(`Original File Size: ${byteSize} bytes`);

            // Compress only if the file size exceeds the maxFileSize
            if (byteSize > maxFileSize) {
                console.log(`File size exceeds 2 MB. Compressing...`);

                // For JPEG/JPG, reduce quality iteratively
                if (!isPng) {
                    do {
                        quality -= 0.1; // Decrease quality
                        dataURL = croppedCanvas.toDataURL(format, quality); // Adjust quality
                        base64String = dataURL.split(',')[1];
                        byteSize = (base64String.length * (3 / 4)) - (base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0);
                        console.log(`Compressed File Size: ${byteSize} bytes at Quality: ${quality}`);
                    } while (byteSize > maxFileSize && quality > 0.1);
                } else {
                    // For PNG, resize to reduce file size (no lossy compression)
                    let width = croppedCanvas.width;
                    let height = croppedCanvas.height;
                    const aspectRatio = width / height;

                    while (byteSize > maxFileSize && width > 200) { // Resize iteratively until size is under limit
                        width -= 100; // Decrease width
                        height = Math.round(width / aspectRatio); // Adjust height
                        const resizedCanvas = document.createElement('canvas');
                        const ctx = resizedCanvas.getContext('2d');
                        resizedCanvas.width = width;
                        resizedCanvas.height = height;
                        ctx.drawImage(croppedCanvas, 0, 0, width, height);

                        dataURL = resizedCanvas.toDataURL(format); // Convert resized image
                        base64String = dataURL.split(',')[1];
                        byteSize = (base64String.length * (3 / 4)) - (base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0);
                        console.log(`Resized PNG File Size: ${byteSize} bytes at Dimensions: ${width}x${height}`);
                    }
                }
            }

            console.log(`Final File Size: ${byteSize} bytes`);

            // Convert compressed Data URL to File
            const compressedFile = this.dataURLtoFile(dataURL, this.selectedImage.name);

            // Prepare FormData
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('profile_image', compressedFile);
            formData.append('account_type', '3');
            formData.append('is_end_user', true);

            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    JsLoader.hide();
                    $('#cropedImage').removeAttr('src');
                    $('#uploadModalCenter').modal('hide');
                    this.getProfileDetails(false, true);
                    this.cropperData.destroy();
                    this.isShowcropImage = false;
                    // window.location.replace("/profile");
                } else {
                    JsLoader.hide();
                    $('#cropedImage').removeAttr('src');
                    $('#uploadModalCenter').modal('hide');
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    });
                    this.cropperData.destroy();
                    this.isShowcropImage = false;
                }
            });
        },
        uploadImageForCoverPhoto: function () {
            JsLoader.show();
            const canvas = this.cropperDataCover.getCroppedCanvas();
            const imageType = this.selectedImage.type; // Get original image type
            const isPng = imageType === 'image/png'; // Check if the image is PNG
            const format = isPng ? 'image/png' : 'image/jpeg'; // Use PNG or JPEG format
            const maxFileSize = 5 * 1024 * 1024; // 2 MB in bytes
            let quality = isPng ? undefined : 0.9; // PNG doesn't use quality, JPEG starts at 90%

            let dataURL = canvas.toDataURL(format, quality); // Initial conversion
            let base64String = dataURL.split(',')[1];
            let byteSize = (base64String.length * (3 / 4)) - (base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0);

            console.log(`Original File Size: ${byteSize} bytes`);

            // Compress only if the file size exceeds the maxFileSize
            if (byteSize > maxFileSize) {
                console.log("File size exceeds 2 MB. Compressing...");

                if (!isPng) {
                    // For JPEG/JPG: Reduce quality iteratively
                    do {
                        quality -= 0.1; // Decrease quality
                        dataURL = canvas.toDataURL(format, quality);
                        base64String = dataURL.split(',')[1];
                        byteSize = (base64String.length * (3 / 4)) - (base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0);
                        console.log(`Compressed JPEG File Size: ${byteSize} bytes at Quality: ${quality}`);
                    } while (byteSize > maxFileSize && quality > 0.1);
                } else {
                    // For PNG: Resize canvas dimensions to reduce file size
                    let width = canvas.width;
                    let height = canvas.height;
                    const aspectRatio = width / height;

                    while (byteSize > maxFileSize && width > 200) { // Resize iteratively until size is under limit
                        width -= 100; // Decrease width
                        height = Math.round(width / aspectRatio); // Adjust height
                        const resizedCanvas = document.createElement('canvas');
                        const ctx = resizedCanvas.getContext('2d');
                        resizedCanvas.width = width;
                        resizedCanvas.height = height;
                        ctx.drawImage(canvas, 0, 0, width, height);

                        dataURL = resizedCanvas.toDataURL(format); // Convert resized image
                        base64String = dataURL.split(',')[1];
                        byteSize = (base64String.length * (3 / 4)) - (base64String.endsWith('==') ? 2 : base64String.endsWith('=') ? 1 : 0);
                        console.log(`Resized PNG File Size: ${byteSize} bytes at Dimensions: ${width}x${height}`);
                    }
                }
            }

            console.log(`Final File Size: ${byteSize} bytes`);

            // Convert compressed Data URL to File
            const compressedFile = this.dataURLtoFile(dataURL, this.selectedImage.name);

            // Prepare FormData
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('cover_image', compressedFile);
            formData.append('account_type', '3');
            formData.append('is_end_user', true);

            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    JsLoader.hide();
                    $('#cropedImageCover').removeAttr('src');
                    $('#uploadModalCover').modal('hide');
                    this.getProfileDetails(false, false);
                    this.cropperDataCover.destroy();
                    this.isShowcropCoverImage = false;
                    // window.location.replace("/profile");
                } else {
                    JsLoader.hide();
                    $('#cropedImageCover').removeAttr('src');
                    $('#uploadModalCover').modal('hide');
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    });
                    this.cropperDataCover.destroy();
                    this.isShowcropCoverImage = false;
                }
            });
        },

        dataURLtoFile(dataurl, filename) {
            var arr = dataurl.split(','),
                mime = arr[0].match(/:(.*?);/)[1],
                bstr = atob(arr[1]),
                n = bstr.length,
                u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
        },
        //validate image type
        validateFiles: function (fileName) {
            const re = /(\.jpg|\.jpeg|\.png)$/i;
            if (!re.exec(fileName)) {
                return false;
            } else {
                return true;
            }
        },
        UpdateProfile: function () {
            let formData = new FormData();
            formData.append('username', this.name.trim());
            formData.append('mobile', this.mobile);
            if(this.email !== "" && this.tempEmail !== this.email){
                formData.append('email', this.email);
            }
            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserDetails.name = this.name.trim();
                    $("#userProfileName").html(this.name.trim().slice(0,12));
                    this.tempName = this.name.trim();
                    this.tempPhone = this.mobile;
                    if(this.email !== "" && this.tempEmail !== this.email){
                        this.tempEmail = this.email;
                        this.endUserDetails.email = this.email;
                    }
                    //Er/76686
                    this.endUserDetails.mobile = this.mobile;
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                   // window.location.replace("/profile");
                   this.isProfileDisabled = true;
                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,
                    })
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                }
            })
        },

        UpdateAbout: function () {
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('is_end_user', true);
            formData.append('about', this.about);
            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserDetails.about = this.about;
                    this.tempAbout = this.about;
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                   // window.location.replace("/profile");
                    Toast.fire({
                        icon: 'success',
                        text: "About section updated successfully",
                    })
                    this.isDisabled = true;
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: "About section not updated successfully",
                    })
                }
            })
        },

        deleteAccount: function () {
            let endUserDeletePayload = {};
            if(this.isPermanentDelete){
                endUserDeletePayload["permanent_end_user_delete"]=this.isPermanentDelete;
            }
            DeleteUser(endUserDeletePayload).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    $('#deleteaccount').modal('hide');
                    Toast.fire({
                        icon: 'success',
                        text: "Your account deleted successfully",
                    })
                    this.isPermanentDelete= false;
                    this.autoLogout();
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: "Your account not deleted successfully",
                    })
                    this.isPermanentDelete= false;
                }
            })
        },

        autoLogout: function () {
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            $cookies.remove("token");
            this.userInfo = false;
            window.location.href = "/";
        },
        check(e){
            if(e.target.name == "permanent_end_user_delete"){
              this.isPermanentDelete = e.target.checked ? true : false;
            }
        },
        cancelModal(){
            this.isPermanentDelete = false;
        },

        async updatePassword() {
            const isFormCorrect = await this.v$.$validate();

            if (this.v$.form.$pending || (this.v$.form.$error && this.is_sso_change_password)) {
                return;
            }

            if(!this.is_sso_change_password){
                console.log(" this.form.password/////", this.form.password)
                this.form.password= null;
                console.log(" this.form.password/////", this.form.password)
            }

            changePassword(this.form).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {


                    for (let key in this.form) {
                        if (this.form.hasOwnProperty(key)) {
                            this.form[key] = '';
                        }
                    }

                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,
                    })
                    this.v$.$reset();
                    this.is_sso_change_password = true;
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                }
            })
        }
    },
    async beforeMount() {

        if(notLoggedinUser()){
            window.location.href = "/";
        }

        let regLogRes = await getEndUserRegdLoginSetting();
        if (regLogRes.data.code === 200 && regLogRes.data.data !== null) {
            const requireRegistrationAndLogin = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[0].node_value);
            this.isMultipleProfileEnabled = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[2].node_value) === 1 ? true:false;
            if (requireRegistrationAndLogin !== 1) {
                window.location.href = "/";
            }

        }

    },
    async mounted() {
        this.fetchUGCSettingStatus();
        let userRes = await getUserDetails();
        let cmsUserRes = await getAdminUserDetails(this.adminUserUuid);
        this.muviAuthSettingType = cmsUserRes.data.data.getUserDetails[0].muvi_auth_setting_type;
        this.muviAuthEmailOptSettingType = this.muviAuthEmailOptSettingList.includes(this.muviAuthSettingType);
        if (userRes.data.code === 200 && userRes.data.status == "SUCCESS") {
            this.is_sso_change_password = userRes.data.data.getUserDetails[0].is_sso_change_password;
            var userData = JSON.parse(localStorage.getItem("user"));
            console.log(userRes.data.data.getUserDetails[0].profile_image_url);
            this.profile_image_url = userRes.data.data.getUserDetails[0].profile_image_url;
            this.cover_image_url = userRes.data.data.getUserDetails[0].cover_image_url;
            //this.profile_image_url = userData.profile_image_url;
        }
        if (this.show_device == localStorage.getItem('profile.currenttab')) {
            JsLoadingOverlay.show();
        }
        let userGeoLocation = getUserGeoLocationFromCookies();
        if (!userGeoLocation) {
            await setUserGeoLocationOnCookies();
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        } else {
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        }
        this.countryCode = userGeoLocation.country_code;

        this.name = this.user_uuid.name;
        this.tempName = this.user_uuid.name;
        this.email = this.user_uuid.email;
        this.tempEmail = this.user_uuid.email;
        //Er/76686
        this.mobile = this.user_uuid.mobile;
        this.tempPhone = this.user_uuid.mobile;
        this.about = this.user_uuid.about;
        this.tempAbout = this.user_uuid.about;
        console.log(this.profile_image_url, "this.profile_image_url");
        // this.profile_image_url = this.profile_image_url;
        const subsciption_enabled_response = await isSubscriptionEnabled(this.countryCode);
        if (subsciption_enabled_response.data.code === 200) {
            this.is_user_subscribed = subsciption_enabled_response.data.data.isSubscriptionEnabled.is_user_subscribed;
        }

        const my_plans_response = await getMyPlan();
        if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
            this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
        } else {
            this.noPlanMsg = my_plans_response.data.message;
        }

        const subscription_plans_response = await getSubscriptionPlans(this.countryCode);
        if (subscription_plans_response.data.code === 200 && subscription_plans_response.data.status === "SUCCESS") {
            this.subscription_plans = subscription_plans_response.data.data.subscriptionPlans.subscription_plans_list;
            this.selectedindex = this.subscription_plans.findIndex(sp => sp.is_default === 1);
            this.isSelected = true;
        }
        JsLoadingOverlay.hide();
    }
};

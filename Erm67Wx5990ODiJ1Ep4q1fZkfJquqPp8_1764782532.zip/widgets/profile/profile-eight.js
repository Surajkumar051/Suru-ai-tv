let {
    getUserDetails,
    getAdminUserDetails,
    updateUserDetails,
    changePassword,
    getMyPlan,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    generateSST,
    removeProfilePic,
    getEndUserRegdLoginSetting,
    removeCoverPic,
    DeleteUser
} = await import(window.importAssetJs('js/webservices.js'));
let {
    TOGGLE_ACCOUNT_CANCELLATION_MODAL,
} = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:Cropper} = await import(window.importAssetJs('js/cropper.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl }  = await import(window.importAssetJs('js/web-service-url.js'));
let {
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies,
    notLoggedinUser
} = await import(window.importAssetJs('js/main.js'));
let { getLocale } = await import(window.importAssetJs('js/web-service-url.js'));

const { defineAsyncComponent } = Vue;
const { useVuelidate } = Vuelidate;
const { required, minLength, maxLength, sameAs, helpers } = VuelidateValidators;
const { mapState, mapGetters } = Vuex;

const passwordStrength = helpers.withMessage(
    'Password must be between 8 to 30 characters long which should contain at least a numeric digit, an uppercase, a lowercase and a special character(@#$%^&+=)',
    helpers.regex(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[@#$%^&+=])[a-zA-Z0-9@#$%^&+=]{8,30}$/),
);

export default {
    name: "profile_eight",
    template: `
    <vd-component class="vd profile-eight" type="profile-eight">
     <div class="album-details-banner d-md-flex d-lg-flex align-items-center">
        <div class="left-thambl">
            <div class="profile-picture-section">
                <div class="profile-image">
                    <img v-if="profile_image_url !== ''" :src="profile_image_url" alt="profile" />
                    <img v-if="profile_image_url == ''" :src="getRootUrl() +'img/no-avatar.png'"
                        alt="profile" />
                    <div class="edit-profile-picture">
                        <ul>
                            <li>
                                <a class="callByAjax" href="javascript:void(0);">
                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M16 1.94441C16.2626 1.68664 16.5744 1.48216 16.9176 1.34265C17.2608 1.20315 17.6286 1.13135 18 1.13135C18.3714 1.13135 18.7392 1.20315 19.0824 1.34265C19.4256 1.48216 19.7374 1.68664 20 1.94441C20.2626 2.20218 20.471 2.5082 20.6131 2.84499C20.7553 3.18179 20.8284 3.54276 20.8284 3.90731C20.8284 4.27185 20.7553 4.63283 20.6131 4.96962C20.471 5.30642 20.2626 5.61244 20 5.87021L6.5 19.1198L1 20.592L2.5 15.194L16 1.94441Z"
                                            stroke="white" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                    <label for="profile-dp" class="selectbox-profile">
                                        <input type="file" id="profile-dp" ref="image"
                                            @change="handelfileupload($event)" accept="image/*" />
                                    </label>
                                </a>
                            </li>
                            <li>
                                <a class="callByAjax" href="javascript:void(0);"
                                    v-if="profile_image_url !== ''" @click="removeProfilePic()">
                                    <svg width="19" height="20" viewBox="0 0 19 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M14.9282 20H4.9704C3.8705 20 2.97885 19.1046 2.97885 18V5H0.987305V3H4.9704V2C4.9704 0.89543 5.86205 0 6.96195 0H12.9366C14.0365 0 14.9282 0.89543 14.9282 2V3H18.9112V5H16.9197V18C16.9197 19.1046 16.0281 20 14.9282 20ZM4.9704 5V18H14.9282V5H4.9704ZM6.96195 2V3H12.9366V2H6.96195ZM12.9366 16H10.9451V7H12.9366V16ZM8.9535 16H6.96195V7H8.9535V16Z"
                                            fill="white" />
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="data-content">
            <p class="white-color f-14 mbottom-4"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
            <h1 class="sub-heading white-color separate-page-heading">{{name}}</h1>
        </div>    
   </div>     

    <!--Profile picture popup start here-->
    <div class="modal fade upload-picture-model" id="uploadModalCenter" tabindex="-1" role="dialog"
        data-backdrop="static" data-keyboard="false" aria-labelledby="uploadModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadModalLongTitle">
                        <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        @click="closeModal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <h2 v-if="isShowcropImage">
                            <vd-component-param type="label8" v-html="i18n($attrs['label8'])">
                            </vd-component-param>
                        </h2>
                        <img v-if="isShowcropImage" id="cropedImage" class="uploaded-image" alt="image" />
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" @click="uploadImage"
                                :disabled="displayImage===null">
                                <vd-component-param type="label1" v-html="i18n($attrs['label1'])">
                                </vd-component-param>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--Profile Picture popup end here-->
    </vd-component>
    `,
    components: {
        account_cancellation_modal: defineAsyncComponent(() => import(window.importAssetJs('js/modals/account-cancellation-modal.js'))),
    },
    props: {
        tab: String
    },
    setup(props) {
        const tab = props.tab;
        return {
            tab,
            v$: useVuelidate()
        };
    },
    validations() {
        return {
            form: {
                password: {
                    required: helpers.withMessage(i18n('Please enter your current password.'), required),
                    $autoDirty: true
                },
                new_password: {
                    required: helpers.withMessage(i18n('Password field is required.'), required),
                    minLength: helpers.withMessage(i18n('Password should be more than 8 characters long.'), minLength(8)),
		            //maxLength: helpers.withMessage('Password length exceeded(Max 30 char).', maxLength(30)),
		            $autoDirty: true
                },
                confirm_password: {
                    required: helpers.withMessage(i18n('Please enter confirm password'), required),
                    sameAs: helpers.withMessage(i18n('New Password and Confirm password must be identical.'), sameAs(this.form.new_password)) ,
                    $autoDirty: true
                }
            }
        }
    },
    data() {
        return {
            show_modal: false,
            isreason: false,
            is_user_subscribed: false,
            valid: false,
            show_device: 'profile_eight',
            name: '',
            email: '',
            mobile: '',
            profile_image_url: '',
            cover_image_url: '',
            displayImage: '',
            selectedImage: '',
            about:'',
            tempAbout:'',
            my_plans: [],
            subscription_plans: [],
            browseImgUrl: [],
            noPlanMsg: '',
            file: '',
            planlist: [],
            ActivePlan: false,
            cancelReasons: [],
            user: '',
            cancelId: '',
            user_uuid: JSON.parse(localStorage.getItem('user')),
            cropperData: null,
            isShowcropImage: false,
            isShowcropCoverImage: false,
            myPlan: [],
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2
            },
            name_field: false,
            //Er/76686
            mobile_field: false,
            password: '',
            new_password: '',
            confirm_password: '',
            errors: {},
            endUserDetails: JSON.parse(localStorage.getItem('user')),
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            pswsnewFieldNotValidate: false,
            isFormValid: false,
            about_field:false,
            form: {
                password: '',
                new_password: '',
                confirm_password: ''
            },
            countryCode: 'US',
            showOldPassword: false,
            showNewPassword: false,
            showConfirmPassword: false,
            isDisabled:true,
            tempName:'',
            tempPhone:'',
            tempEmail:'',
            isProfileDisabled:'true',
            adminUserUuid: localStorage.getItem('adminId'),
            muviAuthEmailOptSettingType : false,
            muviAuthEmailOptSettingList : ['3','34'],
            muviAuthSettingType : '',
            email_filed: false,
            languageCode:getLocale(),
        }
    },
    computed: {
        ...mapGetters({
            is_subscription_enabled: 'is_subscription_enabled'
        }),
        ...mapState({
            show_account_cancellation_modal: state => state.show_account_cancellation_modal
        }),
        username() {
            return this.name;
        },
        is_subscribed() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 1;
            } else {
                return false;
            }
        },
        is_cancelled() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 2;
            } else {
                return false;
            }
        },
        is_expired() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 0;
            } else {
                return false;
            }
        }
    },
    watch: {
        async show_account_cancellation_modal(cv) {
            if (!cv) {
                const my_plans_response = await getMyPlan();
                if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
                    this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
                } else {
                    this.noPlanMsg = my_plans_response.data.message;
                }
            }
        },
        name(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = i18n("The Name field is required.");
            }
            //Er/76685
            else if (value.length < 2 || value.length > 51) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = i18n("Name must be 2 to 51 characters.");
            }
            //Er/76685
            else {
                this.errors.name = null;
                this.name_field = false;
            } 
            
            if(this.tempName !== value){
                this.isProfileDisabled = false;
            }
        },
        // er- Er/76686 start validation
        mobile(value) {
            if (!this.checkMobileNum(value)) {
                this.errors.valid = false;
                this.mobile_field = true;
                this.errors.mobile = i18n("Please enter a valid phone number");
            }
            else {
                this.errors.mobile = null;
                this.mobile_field = false;
            }

            if(this.tempPhone !== value){
                this.isProfileDisabled = false;
            }
        },
        email(value){
            if(this.muviAuthEmailOptSettingType && (value == null || !value.length)){
                this.errors.email = null;
                this.email_filed = false;
            }else{
                if (!value.length) {
                    this.errors.valid = false;
                    this.email_filed = true;
                    this.errors.email = i18n("Email field is required");
                } else if (!value.match(/^(?=.{1,64}@)[^@]+@([^@]{2,})+\.([^@.]{2,14})$/)) {
                    this.errors.valid = false;
                    this.email_filed = true;
                    this.errors.email = i18n("Please enter a valid email");
                } else {
                    this.errors.email = null;
                    this.email_filed = false;
                }
            }
            if(this.tempEmail !== value){
                this.isProfileDisabled = false;
            }
        },
        // er- Er/76686 end validation
        about(value){
            if (value != null && value.length > 500) {
                this.errors.valid = false;
                this.about_field = true;
                this.errors.about = i18n("The About field should be less than 500 characters.");
            }else if(value != null && value.trim().length == 0){
                if(value == ""){
                    this.errors.about= null;
                    this.about_field = false;
                }else{
                    this.errors.valid = false;
                    this.about_field = true;
                    this.errors.about = i18n("Please enter valid info under About.");
                }
            } else {
                this.errors.about= null;
                this.about_field = false;
            }
            if(this.tempAbout !== value){
                this.isDisabled = false;
            }
        }
    },
    methods: {
        getRootUrl,
        i18n,
        is_free_Trial(i){
            const plan=this.my_plans[i];
            if(plan.plan_free_trial_unit === 'Day'){
                const subscriptionDate= new Date(plan.subscription_start_date);
                subscriptionDate.setDate(subscriptionDate.getDate()+plan.plan_free_trial_interval);
                const nextBillingDate=new Date(plan.next_billing_date);
                subscriptionDate.setHours(0,0,0);
                nextBillingDate.setHours(0,0,0);
                if (subscriptionDate.getTime() === nextBillingDate.getTime() && plan.plan_status === 1) {
                    return true;
                }else{
                   return false; 
                }
            }else if(plan.plan_free_trial_unit === 'Month'){
                const subscriptionDate= new Date(plan.subscription_start_date);
                subscriptionDate.setMonth(subscriptionDate.getMonth()+plan.plan_free_trial_interval);
                const nextBillingDate=new Date(plan.next_billing_date);
                subscriptionDate.setHours(0,0,0);
                nextBillingDate.setHours(0,0,0);
                if (subscriptionDate.getTime() === nextBillingDate.getTime() && plan.plan_status === 1) {
                    return true;
                }else{
                   return false; 
                } 
            }
        },
        checkMobileNum(value) {
            var re = new RegExp(/^(\+\d{1,3}[-]?)?\d{4,20}$|^$/); //biswa
            if (re.test(value)) {
                // console.log("Valid");
                return true;
            } else {
                // console.log("Invalid");
                return false;
            }
        },
        displayDescription(plan_description) {
            if (plan_description.length > 500) {
                return plan_description.slice(0, 500).concat('...');
            } else {
                return plan_description;
            }
        },
        openAccountCancellationModal() {
            this.$store.dispatch(TOGGLE_ACCOUNT_CANCELLATION_MODAL, true);
        },
        removeProfilePic() {
            JsLoadingOverlay.show();
            removeProfilePic().then(res => {
                JsLoadingOverlay.hide();
                if (res.data.code === 200) {
                    this.profile_image_url = '';
                    this.getProfileDetails(true, false);
                }
            });
        },
        removeCoverPic() {
            JsLoadingOverlay.show();
            removeCoverPic().then(res => {
                JsLoadingOverlay.hide();
                if (res.data.code === 200) {
                    this.cover_image_url = '';
                    this.getProfileDetails(false,false);
                }
            });
        },
        getProfileDetails: function (is_deleted = false, is_profile = false) {
            getUserDetails().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    if (is_deleted) {
                        $(".profileImages").attr("src", this.getRootUrl() +'img/no-avatar.png');
                        this.endUserDetails.profile_image_url = res.data.data.getUserDetails[0].profile_image_url;
                    } else {
                        this.profile_image_url = res.data.data.getUserDetails[0].profile_image_url;
                        this.cover_image_url = res.data.data.getUserDetails[0].cover_image_url;
                        if(is_profile){
                            $(".profileImages").attr("src", this.profile_image_url);
                        }
                        this.endUserDetails.profile_image_url = this.profile_image_url;
                        this.endUserDetails.cover_image_url = this.cover_image_url;
                    }
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                }
            });
        },
        checkPlan: function () {
            getMyPlan().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    JsLoadingOverlay.hide();
                    this.planlist = res.data.data.myPlans.my_plans_list;
                    this.planlist.forEach((elment) => {
                        //this.isActive = true;
                        if (elment.plan_status === 1) {
                            this.ActivePlan = elment;
                        } else if (elment.plan_status === 0) {
                            this.ActivePlan = elment;
                        }
                    });
                } else {
                    this.noPlanMsg = res.data.message;
                    JsLoadingOverlay.hide();
                }
            });
        },
        showPlan() {
            JsLoadingOverlay.show();
            this.showplan = true;
            this.getPlan();
            this.show_device = 'showplan';
        },
        getPlan: function () {
            getSubscriptionPlans(this.countryCode).then((res) => {
                if (res.data.code == 200 && res.data.status === "SUCCESS") {
                    this.myPlan = res.data.data.subscriptionPlans.subscription_plans_list;
                    JsLoadingOverlay.hide();
                }
                if ((res.data.code === 600 || res.data.code === 601) && res.data.status === "FAILED") {
                    JsLoadingOverlay.hide();
                } else {
                    JsLoadingOverlay.hide();
                }
            })
        },
        selectedPlan: function (data) {
            this.selectedindex = data;
            this.isSelected = true;
        },
        redirectCheckout(i, plan) {
            this.selectedPlanIndex = i + 1;
            if (localStorage.getItem('isloggedin') == "true") {
                const user = JSON.parse(window.localStorage.getItem("user"));
                const parts = user.name.split(' ');
                this.planDetail = {
                    plan_uuid: plan.subscription_plan_uuid,
                    pricing_uuid: plan.price[0].subscription_pricing_uuid,
                    billing_type: 2,
                    gateway_order: {
                        first_name: parts[0],
                        last_name: parts[1],
                        email: user.email,
                        subscription_plan_uuid:plan.subscription_plan_uuid,
                        plan_free_trial_interval: plan.price[0].plan_free_trial_interval,
                        subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        cancel_url: window.location.origin +' /' + this.languageCode + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                        return_url: window.location.origin + '/' + this.languageCode + '/checkout-success?billing_type=2'
                    }
                };
                if (this.selectedPlanIndex !== undefined) {
                    generateSST(this.planDetail).then((res) => {
                        let sst_token = res.data.data.sst_token;
                        window.location.href = '/' + this.languageCode + "/checkout/" + sst_token + "/" + this.planDetail.billing_type;
                    });
                }
            } else {
                window.location.href = '/' + this.languageCode + "/sign-up";
            }
        },
        closeModal: function () {
            $('#uploadModalCenter').modal('hide');
            $('input[type="file"]').val(''); //biswa
            this.cropperData.destroy();
        },
        closeModalCover: function () {
            $('#uploadModalCover').modal('hide');
            $('input[type="file"]').val(''); //biswa
            this.cropperData.destroy();
        },
        handelfileupload: function (event) {
            // console.log("inside handelfileupload");
            this.selectedImage = event.target.files[0];
            if (event.target.files[0]) {
                if (!this.validateFiles(this.selectedImage.name)) {
                    $("#profile-dp").val("")
                    Toast.fire({
                        icon: 'error',
                        text: "Uploaded file is in wrong format.It should be in jpg/jpeg/png formate.",
                    })
                } else {
                    // console.log("inside handelfileupload else")
                    this.isShowcropImage = true;
                    $('#uploadModalCenter').modal('show');
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#cropedImage').attr('src', e.target.result)
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    setTimeout(this.initCropper, 1000);
                }
                event.target.value = "";
            }

        },
        initCropper() {
            var image = document.getElementById('cropedImage');
            this.cropperData = new Cropper(image, {
                dragMode: 'move',
                // autoCropArea: 1,
                restore: false,
                guides: false,
                center: false,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: false,
                toggleDragModeOnDblclick: false,
                aspectRatio: 1 / 1,
                viewMode: 1,
                data: { //define cropbox size
                    width: 250,
                    height: 250,
                },
            });
        },
        handelfileuploadForCoverImge: function (event) {
            // console.log("inside handelfileuploadForCoverImge");
            this.selectedImage = event.target.files[0];
            if (event.target.files[0]) {
                if (!this.validateFiles(this.selectedImage.name)) {
                    $("#cover-dp").val("")
                    Toast.fire({
                        icon: 'error',
                        text: "Uploaded file is in wrong format.It should be in jpg/jpeg/png formate.",
                    })

                } else {
                    // console.log("inside handelfileuploadForCoverImge else");
                    this.isShowcropCoverImage = true;
                    $('#uploadModalCover').modal('show');
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#cropedImage').attr('src', e.target.result)
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    setTimeout(this.initCropperForCoverImage, 1000);
                }
                event.target.value = "";
            }

        },
        initCropperForCoverImage() {
            var image = document.getElementById('cropedImage');
            this.cropperData = new Cropper(image, {
                dragMode: 'move',
                // autoCropArea: 1,
                restore: false,
                guides: false,
                center: false,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: false,
                toggleDragModeOnDblclick: false,
                aspectRatio: 3.6 / 1,
                viewMode: 1,
                data: { //define cropbox size
                    width: 900,
                    height: 240,
                },
            });
        },
        uploadImage: function () {
            const canvas = this.cropperData.getCroppedCanvas().toDataURL();
            const browseImgUrl = this.dataURLtoFile(canvas, this.selectedImage.name);
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('profile_image', browseImgUrl);
            formData.append('account_type', '3');
            formData.append('is_end_user', true);
            JsLoadingOverlay.show();
            updateUserDetails(formData).then((res) => {
                JsLoadingOverlay.hide();
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    $('#cropedImage').removeAttr('src');
                    $('#uploadModalCenter').modal('hide');
                    this.getProfileDetails(false, true);
                    this.cropperData.destroy();
                    this.isShowcropImage = false;
                    // window.location.replace("/profile");
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                    this.cropperData.destroy();
                    this.isShowcropImage = false;
                }
            })
        },
        uploadImageForCoverPhoto: function () {
            const canvas = this.cropperData.getCroppedCanvas().toDataURL();
            const browseImgUrl = this.dataURLtoFile(canvas, this.selectedImage.name);
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('cover_image', browseImgUrl);
            formData.append('account_type', '3');
            formData.append('is_end_user', true);
            JsLoadingOverlay.show();
            updateUserDetails(formData).then((res) => {
                JsLoadingOverlay.hide();
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    $('#cropedImage').removeAttr('src');
                    $('#uploadModalCover').modal('hide');
                    this.getProfileDetails(false, false);
                    this.cropperData.destroy();
                    this.isShowcropCoverImage = false;
                    // window.location.replace("/profile");
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                    this.cropperData.destroy();
                    this.isShowcropCoverImage = false;
                }
            })
        },
        dataURLtoFile(dataurl, filename) {
            var arr = dataurl.split(','),
                mime = arr[0].match(/:(.*?);/)[1],
                bstr = atob(arr[1]),
                n = bstr.length,
                u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
        },
        //validate image type
        validateFiles: function (fileName) {
            const re = /(\.jpg|\.jpeg|\.png)$/i;
            if (!re.exec(fileName)) {
                return false;
            } else {
                return true;
            }
        },
        UpdateProfile: function () {
            let formData = new FormData();
            formData.append('username', this.name.trim());
            formData.append('mobile', this.mobile);
            if(this.email !== "" && this.tempEmail !== this.email){
                formData.append('email', this.email);
            }
            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserDetails.name = this.name.trim();
                    $("#userProfileName").html(this.name.trim().slice(0,12));
                    this.tempName = this.name.trim();
                    this.tempPhone = this.mobile;
                    if(this.email !== "" && this.tempEmail !== this.email){
                        this.tempEmail = this.email;
                        this.endUserDetails.email = this.email;
                    }
                    //Er/76686
                    this.endUserDetails.mobile = this.mobile;
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                   // window.location.replace("/profile");
                   this.isProfileDisabled = true;
                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,
                    })
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                }
            })
        },

        UpdateAbout: function () {
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('is_end_user', true);
            formData.append('about', this.about);
            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserDetails.about = this.about;
                    this.tempAbout = this.about;
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                   // window.location.replace("/profile");
                    Toast.fire({
                        icon: 'success',
                        text: "About section updated successfully",
                    })
                    this.isDisabled = true;
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: "About section not updated successfully",
                    })
                }
            })
        },

        deleteAccount: function () {
            DeleteUser().then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    $('#deleteaccount').modal('hide');
                    Toast.fire({
                        icon: 'success',
                        text: "Your account deleted successfully",
                    })
                    this.autoLogout();
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: "Your account not deleted successfully",
                    })
                }
            })
        },

        autoLogout: function () {
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            $cookies.remove("token");
            this.userInfo = false;
            window.location.href = "/";
        },


        async updatePassword() {
            const isFormCorrect = await this.v$.$validate();

            if (this.v$.form.$pending || this.v$.form.$error) {
                return;
            }

            changePassword(this.form).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {


                    for (let key in this.form) {
                        if (this.form.hasOwnProperty(key)) {
                            this.form[key] = '';
                        }
                    }

                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,
                    })
                    this.v$.$reset();
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                }
            })
        }
    },
    async beforeMount() {
        if(notLoggedinUser()){
            window.location.href = "/";
        }

        let regLogRes = await getEndUserRegdLoginSetting();
        if (regLogRes.data.code === 200 && regLogRes.data.data !== null) {
            const requireRegistrationAndLogin = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[0].node_value);
            if (requireRegistrationAndLogin !== 1) {
                window.location.href = "/";
            }

        }

    },
    async mounted() {
        let userRes = await getUserDetails();
        let cmsUserRes = await getAdminUserDetails(this.adminUserUuid);
        this.muviAuthSettingType = cmsUserRes.data.data.getUserDetails[0].muvi_auth_setting_type;
        this.muviAuthEmailOptSettingType = this.muviAuthEmailOptSettingList.includes(this.muviAuthSettingType);
        if (userRes.data.code === 200 && userRes.data.status == "SUCCESS") {
            var userData = JSON.parse(localStorage.getItem("user"));
            // console.log(userRes.data.data.getUserDetails[0].profile_image_url);
            this.profile_image_url = userRes.data.data.getUserDetails[0].profile_image_url;
            this.cover_image_url = userRes.data.data.getUserDetails[0].cover_image_url;
            //this.profile_image_url = userData.profile_image_url;
        }
        if (this.show_device == localStorage.getItem('profile.currenttab')) {
            JsLoadingOverlay.show();
        }
        let userGeoLocation = getUserGeoLocationFromCookies();
        if (!userGeoLocation) {
            await setUserGeoLocationOnCookies();
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        } else {
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        }
        this.countryCode = userGeoLocation.country_code;

        this.name = this.user_uuid.name;
        this.tempName = this.user_uuid.name;
        this.email = this.user_uuid.email;
        this.tempEmail = this.user_uuid.email;
        //Er/76686
        this.mobile = this.user_uuid.mobile;
        this.tempPhone = this.user_uuid.mobile;
        this.about = this.user_uuid.about;
        this.tempAbout = this.user_uuid.about;
        // console.log(this.profile_image_url, "this.profile_image_url");
        // this.profile_image_url = this.profile_image_url;
        const subsciption_enabled_response = await isSubscriptionEnabled(this.countryCode);
        if (subsciption_enabled_response.data.code === 200) {
            this.is_user_subscribed = subsciption_enabled_response.data.data.isSubscriptionEnabled.is_user_subscribed;
        }

        const my_plans_response = await getMyPlan();
        if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
            this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
        } else {
            this.noPlanMsg = my_plans_response.data.message;
        }

        const subscription_plans_response = await getSubscriptionPlans(this.countryCode);
        if (subscription_plans_response.data.code === 200 && subscription_plans_response.data.status === "SUCCESS") {
            this.subscription_plans = subscription_plans_response.data.data.subscriptionPlans.subscription_plans_list;
            this.selectedindex = this.subscription_plans.findIndex(sp => sp.is_default === 1);
            this.isSelected = true;
        }
        JsLoadingOverlay.hide();
    }
};

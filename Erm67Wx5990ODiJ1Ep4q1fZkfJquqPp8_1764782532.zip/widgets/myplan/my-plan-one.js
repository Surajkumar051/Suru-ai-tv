let {
    getUserDetails,
    updateUserDetails,
    changePassword,
    getMyPlan,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    generateSST,
    removeProfilePic,
    getEndUserRegdLoginSetting,
    getMonetizationSettings,
} = await import(window.importAssetJs('js/webservices.js'));
let {
    TOGGLE_ACCOUNT_CANCELLATION_MODAL,
} = await import(window.importAssetJs('js/configurations/actions.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let {default:Cropper}=await import(window.importAssetJs('js/cropper.js'));
let { getUserGeoLocationFromCookies, setUserGeoLocationOnCookies }=await import(window.importAssetJs('js/main.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
const { defineAsyncComponent } = Vue;
const { useVuelidate } = Vuelidate;
const { required, minLength, maxLength, sameAs, helpers } = VuelidateValidators;
const { mapState } = Vuex;

const passwordStrength = helpers.withMessage(
    'Password must be between 8 to 30 characters which contain at least 1 numeric digit, 1 uppercase, 1 lowercase and 1 special character',
    helpers.regex(/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,30}$/),
);

export default {
    name: 'myplan_one',
    template: `
    <vd-component class="vd myplan-one" type="myplan-one">
        <section id="muvi-MyProfile1">
            <div v-if="show_device != 'showplan'">
                <div class="my-profile-process" v-if= "isSubscriptionButton">
                <div class="right-box">
                        <div class="information-box my-plan">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-auto">
                            <h3 class="mb-5">
                                <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
    </h3>
                            <div v-for="({ plan_name, next_billing_date }) in my_plans">
                                <h2 class="planname">
                                    {{plan_name}}
                                    <small class="text-warning" v-if="is_cancelled">Cancelled</small>
                                    <small class="text-danger" v-if="is_expired">Expired</small>
                                </h2>
                                <p class="plandate">Valid till {{next_billing_date}}</p>
                            </div>
                            <div class="redeem-info mt-5">
                            <p v-if="noPlanMsg" >{{noPlanMsg}}</p>
                            </div>
                            <ul>
                                <!--<li class="choose-plan-button" @click="showPlan();">
                                    <button
                                        type="button"
                                        class="primary-button plans"
                                    >
                                        Change Plan
                                    </button>
                                </li>-->
                                <li v-if="is_subscribed">
                                    <button
                                        type="button"
                                        class="btn-solid w-100 border-0"
                                        @click="openAccountCancellationModal"
                                    >
                                        Cancel Plan
                                    </button>
                                </li>
                                <li class="choose-plan-button" @click="showPlan();" v-if="(!is_subscribed && !is_cancelled && havePlan) || is_expired">
                                    <button
                                        type="button"
                                        class="btn-solid w-100 border-0 plans"
                                    >
                                        Choose Plan
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!--Profile picture popup start here-->
                <div class="modal fade upload-picture-model" id="uploadModalCenter" tabindex="-1" role="dialog"
                    data-backdrop="static" data-keyboard="false" aria-labelledby="uploadModalCenterTitle"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="uploadModalLongTitle">
                                    <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                                </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                    @click="closeModal">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <h2 v-if="isShowcropImage">
                                        <vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param>
                                    </h2>
                                    <img v-if="isShowcropImage" id="cropedImage" class="uploaded-image" alt="image" />
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" @click="uploadImage"
                                            :disabled="displayImage===null">
                                            <vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Profile Picture popup end here-->
                <account_cancellation_modal :label9="$attrs['label9']" :label10="$attrs['label10']" :label11="$attrs['label11']" />
            </div>
                </div>
            </div>


            <section class="all-plans-page" v-if="show_device === 'showplan'">
            <div class="right-box">
                        <div class="information-box my-plan">
                <!--Heading-->
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <h1 class="dashboard-heading white-color mbottom-20">
                            <vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                        </h1>
                    </div>
                </div>

                <div class="all-plans-page" v-if="is_subscription_enabled">
                        <div v-for="(itemData,index) in myPlan">
                            <div class=" align-items-stretch border-0" :class="{'selected-plan': selectedindex == index}" @click="selectedPlan(index)">
                            <div class="col-lg-8 order-lg-1">
                                    <div class="form-check price-check" :class="{'checked': (isSelected && selectedindex == index) || isActive }" style="flex-wrap:wrap">
                                        <div class="w-100 d-flex align-items-center">
                                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked>
                                        <label class="form-check-label" for="flexRadioDefault1">
                                          <div class="pack-info">
                                            <span>{{itemData.plan_name.toUpperCase()}}</span>
                                            <p class="plan-description">{{displayDescription(itemData.plan_description)}}</p>
                                          </div>
                                          <div class="price-details">
                                          <span v-for="price of itemData.price">
                                    {{price.currency_code}} {{price.subscription_plan_price}}<span>/{{price.plan_interval}} {{price.plan_interval_unit}}(s) </span></span>
                                          </div>
                                        </label>
                                        </div>
                                        <button
                                        type="button"
                                        class="btn-solid px-3 border-0 w-auto ms-auto me-3 mb-3 mt-0"
                                        :class="{'active-checkout': (isSelected && selectedindex == index) || isActive }"
                                        @click="() => {
                                            if(isSelected && selectedindex == index) {
                                                redirectCheckout(index,itemData);
                                            }
                                        }"
                                    >
                                        {{isSelected && selectedindex == index?'Proceed to Checkout':'Subscribe'}}
                                    </button>


                                    </div>



                            </div>
                            </div>
                        </div>
                </div>



                <div class="blank-card-info" v-else>
                    <p>
                        <vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param>
                    </p>
                </div>
                        </div></div>
            </section>
            <!--Subscription Cancellation Popup start Here-->
            <!--All plan starts Here-->


            <!--Choose Your plan End Here-->
            <!--Subscription Cancellation Popup End Here-->

        </section>
    </vd-component>
    `,
    components: {
        account_cancellation_modal: defineAsyncComponent(() => import(window.importAssetJs('js/modals/account-cancellation-modal.js'))),
    },
    props: {
        tab: String
    },
    setup(props) {
        const tab = props.tab;
        return {
            tab,
            v$: useVuelidate()
        };
    },
    validations() {
        return {
            form: {
                password: {
                    required: helpers.withMessage('Please enter your current password.', required),
                    $autoDirty: true
                },
                new_password: {
                    required: helpers.withMessage('Password field is required.', required),
                    minLength: helpers.withMessage('Password must be atleast 8 characters.', minLength(8)),
                    maxLength: helpers.withMessage('Password length exceeded(Max 30 char).', maxLength(30)),
                    passwordStrength, $autoDirty: true
                },
                confirm_password: {
                    required: helpers.withMessage('Please enter confirm password', required),
                    sameAs: helpers.withMessage('New Password and Confirm password must be identical.', sameAs(this.form.new_password)),
                    $autoDirty: true
                }
            }
        }
    },
    data() {
        return {
            isSubscriptionButton: false,
            show_modal: false,
            isreason: false,
            is_user_subscribed: false,
            valid: false,
            show_device: 'Profile',
            name: '',
            email: '',
            mobile: '',
            profile_image_url: '',
            displayImage: '',
            selectedImage: '',
            my_plans: [],
            subscription_plans: [],
            browseImgUrl: [],
            noPlanMsg: '',
            file: '',
            planlist: [],
            ActivePlan: false,
            cancelReasons: [],
            user: '',
            cancelId: '',
            user_uuid: JSON.parse(localStorage.getItem('user')),
            cropperData: null,
            isShowcropImage: false,
            myPlan: [],
            is_subscription_enabled: Boolean,
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2
            },
            name_field: false,
            //Er/76686
            mobile_field: false,
            password: '',
            new_password: '',
            confirm_password: '',
            errors: {},
            endUserDetails: JSON.parse(localStorage.getItem('user')),
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            pswsnewFieldNotValidate: false,
            isFormValid: false,
            form: {
                password: '',
                new_password: '',
                confirm_password: ''
            },
            countryCode: 'US',
            havePlan: false,
        }
    },
    computed: {
        ...mapState({
            show_account_cancellation_modal: state => state.show_account_cancellation_modal
        }),
        username() {
            return this.name;
        },
        is_subscribed() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 1;
            } else {
                return false;
            }
        },
        is_cancelled() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 2;
            } else {
                return false;
            }
        },
        is_expired() {
            if (this.my_plans.length > 0) {
                return this.my_plans[0].plan_status === 0;
            } else {
                return false;
            }
        }
    },
    watch: {
        async show_account_cancellation_modal(cv) {
            if (!cv) {
                const my_plans_response = await getMyPlan();
                if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
                    this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
                } else {
                    this.noPlanMsg = my_plans_response.data.message;
                }
            }
        },
        name(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = "The Full Name field is required.";
            }
            //Er/76685
            else if (!value.match(/^[a-zA-Z ]+$/)) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = "The Full Name field contains only alphabets.";
            }
            //Er/76685
            else if (value.length < 2 || value.length > 30) {
                this.errors.valid = false;
                this.name_field = true;
                this.errors.name = "The Full Name should be between 2 to 30 characters.";
            } else {
                this.errors.name = null;
                this.name_field = false;
            }
        },
        // er- Er/76686 start validation
        mobile(value) {
            if (!this.checkMobileNum(value)) {
                this.errors.valid = false;
                this.mobile_field = true;
                this.errors.mobile = "Please enter a valid phone number";
            }
            else {
                this.errors.mobile = null;
                this.mobile_field = false;
            }
        },
        // er- Er/76686 end validation
    },
    methods: {
        i18n,
        uploadProfile() {
            alert('dfghjk');
            $('#profile-dp').click();

        },
        checkMobileNum(value) {
            var re = new RegExp("^(?!0+$)[0-9+\\s-()/]{4,20}$|^$");
            if (re.test(value)) {
                console.log("Valid");
                return true;
            } else {
                console.log("Invalid");
                return false;
            }
        },
        displayDescription(plan_description) {
            if (plan_description.length > 500) {
                return plan_description.slice(0, 500).concat('...');
            } else {
                return plan_description;
            }
        },
        openAccountCancellationModal() {
            this.$store.dispatch(TOGGLE_ACCOUNT_CANCELLATION_MODAL, true);
        },
        removeProfilePic() {
            //JsLoadingOverlay.show();
            removeProfilePic().then(res => {
                JsLoadingOverlay.hide();
                if (res.data.code === 200) {
                    this.profile_image_url = '';
                    this.endUserDetails.profile_image_url = '';
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                    window.location.reload();
                }
            });
        },
        getProfileDetails: function () {
            getUserDetails().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    this.profile_image_url = res.data.data.getUserDetails[0].profile_image_url;
                    this.endUserDetails.profile_image_url = this.profile_image_url;
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                    window.location.reload();
                    console.log(" this.profile_image_url", res)
                    // JsLoadingOverlay.hide();
                }
            });
        },
        checkPlan: function () {
            getMyPlan().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    JsLoadingOverlay.hide();
                    this.planlist = res.data.data.myPlans.my_plans_list;
                    this.planlist.forEach((elment) => {
                        //this.isActive = true;
                        if (elment.plan_status === 1) {
                            this.ActivePlan = elment;
                        } else if (elment.plan_status === 0) {
                            this.ActivePlan = elment;
                        }
                    });
                } else {
                    this.noPlanMsg = res.data.message;
                    JsLoadingOverlay.hide();
                }
            });
        },
        showPlan() {
            ////JsLoadingOverlay.show();
            this.showplan = true;
            this.getPlan();
            this.show_device = 'showplan';
        },
        getPlan: function () {
            getSubscriptionPlans(this.countryCode).then((res) => {
                if (res.data.code == 200 && res.data.status === "SUCCESS") {
                    this.is_subscription_enabled = true;
                    this.myPlan = res.data.data.subscriptionPlans.subscription_plans_list;
                    JsLoadingOverlay.hide();
                }
                if ((res.data.code === 600 || res.data.code === 601) && res.data.status === "FAILED") {
                    this.is_subscription_enabled = false;
                    JsLoadingOverlay.hide();
                } else {
                    JsLoadingOverlay.hide();
                }
            })
        },
        selectedPlan: function (data) {
            this.selectedindex = data;
            this.isSelected = true;
        },
        redirectCheckout(i, plan) {
            this.selectedPlanIndex = i + 1;
            if (localStorage.getItem('isloggedin') == "true") {
                this.planDetail = {
                    plan_uuid: plan.subscription_plan_uuid,
                    pricing_uuid: plan.price[0].subscription_pricing_uuid,
                    billing_type: 2
                };
                if (this.selectedPlanIndex !== undefined) {
                    generateSST(this.planDetail).then((res) => {
                        let sst_token = res.data.data.sst_token;
                        window.location.href = "/checkout/" + sst_token + "/" + this.planDetail.billing_type;
                    });
                }
            } else {
                window.location.href = "/sign-up";
            }
        },
        closeModal: function () {
            $('#uploadModalCenter').modal('hide');
            this.cropperData.destroy();
        },
        handelfileupload: function (event) {
            alert('hiii');
            this.selectedImage = event.target.files[0];
            if (event.target.files[0]) {
                if (!this.validateFiles(this.selectedImage.name)) {
                    toastr.error("File should be in jpg or jpeg or png formate");
                } else {
                    this.isShowcropImage = true;
                    $('#uploadModalCenter').modal('show');
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#cropedImage').attr('src', e.target.result)
                    };
                    reader.readAsDataURL(event.target.files[0]);
                    setTimeout(this.initCropper, 1000);
                }
            }

        },
        initCropper() {
            var image = document.getElementById('cropedImage');
            this.cropperData = new Cropper(image, {
                dragMode: 'move',
                // autoCropArea: 1,
                restore: false,
                guides: false,
                center: false,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: false,
                toggleDragModeOnDblclick: false,
                aspectRatio: 1 / 1,
                viewMode: 3,
                data: { //define cropbox size
                    width: 250,
                    height: 250,
                },
            });
        },
        uploadImage: function () {
            const canvas = this.cropperData.getCroppedCanvas().toDataURL();
            const browseImgUrl = this.dataURLtoFile(canvas, this.selectedImage.name);
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('profile_image', browseImgUrl);
            formData.append('account_type', '3')
            //JsLoadingOverlay.show();
            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    $('#cropedImage').removeAttr('src');
                    $('#uploadModalCenter').modal('hide');
                    this.getProfileDetails();
                    this.cropperData.destroy();
                    this.isShowcropImage = false;
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                    this.cropperData.destroy();
                    this.isShowcropImage = false;
                }
            })
        },
        dataURLtoFile(dataurl, filename) {
            var arr = dataurl.split(',');
            var mime = arr[0].match(/:(.*?);/)[1];
            var bstr = atob(arr[1]);
            var n = bstr.length;
            var u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
        },
        //validate image type
        validateFiles: function (fileName) {
            const re = /(\.jpg|\.jpeg|\.png)$/i;
            if (!re.exec(fileName)) {
                return false;
            } else {
                return true;
            }
        },
        UpdateProfile: function () {
            let formData = new FormData();
            formData.append('username', this.name);
            formData.append('mobile', this.mobile);
            updateUserDetails(formData).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.endUserDetails.name = this.name;
                    //Er/76686
                    this.endUserDetails.mobile = this.mobile;
                    localStorage.setItem('user', JSON.stringify(this.endUserDetails));
                    window.location.reload();
                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,
                    })
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                }
            })
        },
        async updatePassword() {
            const isFormCorrect = await this.v$.$validate();

            if (this.v$.form.$pending || this.v$.form.$error) {
                return;
            }

            changePassword(this.form).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {

                    for (let key in this.form) {
                        if (this.form.hasOwnProperty(key)) {
                            this.form[key] = '';
                        }
                    }

                    Toast.fire({
                        icon: 'success',
                        text: res.data.message,
                    })
                    this.v$.$reset();
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: res.data.message,
                    })
                }
            })
        }
    },
    async beforeMount() {
        //JsLoadingOverlay.show();
        let regLogRes = await getEndUserRegdLoginSetting();
        if (regLogRes.data.code === 200 && regLogRes.data.data !== null) {
            const requireRegistrationAndLogin = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[0].node_value);
            // console.log("requireRegistrationAndLogin", requireRegistrationAndLogin);
            // console.log("this.isLogedIn", this.isLoggedIn);
            if (requireRegistrationAndLogin !== 1) {
                window.location.href = "/";
            }

        }

    },
    async mounted() {
        window.setInterval(() => {
            //Plans Radio
            $('.price-check input:radio').click(function () {
                console.log("onclick radio");
                $('input:radio[name=' + $(this).attr('name') + ']').parent().removeClass('checked');
                $(this).parent().addClass('checked');

            });
        }, 3000)

        let userGeoLocation = getUserGeoLocationFromCookies();
        if (!userGeoLocation) {
            await setUserGeoLocationOnCookies();
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
        } else {
            userGeoLocation = JSON.parse(getUserGeoLocationFromCookies())
        }
        this.countryCode = userGeoLocation.country_code;

        let res = await getMonetizationSettings();
        if (res.data.code === 200 && res.data.data !== null) {
            const subscriptionDetails = JSON.parse(res.data.data.sections[0].groups[0].nodes[0].node_value).sort_order_data;
            for (const index of subscriptionDetails) {
                // if (subscriptionDetails[index].key == 1) {
                // }
                this.isSubscriptionButton = true;

            }
        }

        this.name = this.user_uuid.name;
        this.email = this.user_uuid.email;
        //Er/76686
        this.mobile = this.user_uuid.mobile;
        this.profile_image_url = this.user_uuid.profile_image_url;

        const subsciption_enabled_response = await isSubscriptionEnabled(this.countryCode);
        if (subsciption_enabled_response.data.code === 200) {
            this.is_subscription_enabled = subsciption_enabled_response.data.data.isSubscriptionEnabled.is_subscription_enabled;
            this.is_user_subscribed = subsciption_enabled_response.data.data.isSubscriptionEnabled.is_user_subscribed;
        }

        const my_plans_response = await getMyPlan();
        if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
            this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
        } else {
            this.noPlanMsg = my_plans_response.data.message;
        }

        const subscription_plans_response = await getSubscriptionPlans(this.countryCode);
        if (subscription_plans_response.data.code === 200 && subscription_plans_response.data.status === "SUCCESS") {
            this.subscription_plans = subscription_plans_response.data.data.subscriptionPlans.subscription_plans_list;
            this.selectedindex = this.subscription_plans.findIndex(sp => sp.is_default === 1);
            this.isSelected = true;
            this.havePlan = true;
        }
        JsLoadingOverlay.hide();
    }
};

let { getSubscribedContentDeatils, getSubscribedContents, getMonetizationDetails } = await import(window.importAssetJs('js/webservices.js'));
let { getAllContentDeatils } = await import(window.importAssetJs('js/webservices.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {notLoggedinUser}=await import(window.importAssetJs('js/main.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

export default {
    name: "my_library_four",

    data() {
        return {
            allContentDetail: [],
            is_ppv_enabled: false
        };
    },
    beforeMount() {
        // JsLoadingOverlay.show();
        if (notLoggedinUser()) {
            window.location.href = "/";
        }
    },
    async mounted() {
        let response = await getMonetizationDetails();
        if (response.data && response.data.data && response.data.data.monetization_methods) {
            // Iterate over monetization_methods array
            response.data.data.monetization_methods.forEach(method => {
                // Check if 'monetization_code' property contains 'ppv'
                if (method.monetization_code.includes('payperview')) {
                    this.is_ppv_enabled = true;
                }
            });
        }
        owlCarousal();
        if (this.is_ppv_enabled) {
            this.getSubscribedContents();
        }
    },
    methods: {
        i18n,
        getRootUrl,
        async getSubscribedContents(){
            let contentUuids = [];
                    let res = await getSubscribedContents().then(res => {
                        if (res.data.status === "SUCCESS") {
                            console.log(res.data.data)
                            contentUuids = res.data.data.subscribedContents.subscribed_content_list;
                            if(contentUuids.length > 0){
                                this.MyLibrary(contentUuids.join(','));
                               } else {
                                console.log("No data found");
                                this.nodatafound = true;
                               }
                        }else{
                            console.log("No data found");
                            this.nodatafound = true;
                        }
                    });
             },
        MyLibrary: function(contentUuids) {
            getSubscribedContentDeatils(contentUuids).then((res) => {
                if (res.data.code === 200) {
                    JsLoadingOverlay.hide();
                    this.allContentDetail = res.data.data.contentList.content_list;
                    this.allContentDetail.forEach(ele => {
                        if (ele.video_details !== null) {
                            const vDuration = ele.video_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                        if (ele.audio_details !== null) {
                            const aDuration = ele.audio_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                    })
                } else {
                    console.log("No data found");
                    this.nodatafound = true;
                }
            });
        }
    },
    template: /*html*/ `<vd-component class="vd my-library-four" type="my-library-four">
    <!--Profile Step Here-->
        <div class="my-profile-process">
            <!--Headind Section Start Here-->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <h5 class="mb-3 pb-3 a-border"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h5>
                </div>
            </div>
        <div class="profile">
         <ul v-if="allContentDetail.length > 0" class=" row list-inline  mb-0 iq-rtl-direction iq_genres-contents">
                <!--Loop Section Here-->
                <li class="slide-item" v-for="data in allContentDetail">
                    <div class="block-images position-relative watchlist-first">
                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                <span><span><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></span></span>
                            </div>
                            <img vd-node="image" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                :src="data.posters.website[0].file_url" alt="" class="img-fluid" />
                            <img vd-node="image" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                :src="data.no_image_available_url" alt="Godzilla vs Kong" class="img-fluid" />
                            <!--Button Show on Hover start Here-->
                        
                        <div class="block-description d-flex justify-content-center flex-column text-center">
                        <h6 class="iq-title">
                            <a class="callByAjax" :href="'/content/'+data.content_permalink" @click="getContentId(data.content_uuid)">
                                <span>{{data.content_name}}</span>
                            </a>
                            </h6>
                            <p v-if="data.video_details !== null">{{videoDuration}}</p>
                            <p v-if="data.audio_details !== null">{{audioDuration}}</p>
                            <!-- <p v-if="data.video_details === null && data.content_asset_type == 1">No Video</p>
                            <p v-if="data.audio_details === null && data.content_asset_type == 2">No Audio</p> -->

                            
                        </div>
                    </div>
                </li>
            </ul>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-else>
                    <section class="no-result-found">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <div class="w-100 text-center">
                                        <img :src="getRootUrl() + 'img/no-result.gif'" alt="no result" class="mw-100" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="no-result-found" v-if="allContentDetail.length == 0">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <div class="w-100 text-center">
                                        <h2 v-if="allContentDetail.length == 0">
                                            <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
</vd-component>`,
};

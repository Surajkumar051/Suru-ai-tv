let { getSubscribedContentDeatils, getSubscribedContents, getMonetizationDetails,makeContentFavorite,getContentFavoriteStatus, getContentSettingsDetails } = await import(window.importAssetJs('js/webservices.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {notLoggedinUser}=await import(window.importAssetJs('js/main.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

export default {
    name: "my_library_two",
    data() {
        return {
            allContentDetail: [],
            is_ppv_enabled: false,
            isFavourite: 0,
            isFavouriteEnabled: false,
			isLogedIn: localStorage.getItem("isloggedin"),

        }
    },
    beforeMount() {
        JsLoadingOverlay.show();
        if (notLoggedinUser()) {
            window.location.href = "/";
        }
    },
   async mounted() {
       let response = await getMonetizationDetails();
       this.getContentSettingsDetails();
        if (response.data && response.data.data && response.data.data.monetization_methods) {
            // Iterate over monetization_methods array
            response.data.data.monetization_methods.forEach(method => {
                // Check if 'monetization_code' property contains 'ppv'
                if (method.monetization_code.includes('payperview')) {
                    this.is_ppv_enabled = true;
                }
            });
        }
        owlCarousal();
        if (this.is_ppv_enabled) {
            this.getSubscribedContents();
        }
        JsLoadingOverlay.hide();
    },
    methods: {
        i18n,
        getRootUrl,
        async getSubscribedContents(){
            let contentUuids = [];
                    let res = await getSubscribedContents().then(res => {
                        if (res.data.status === "SUCCESS") {
                            console.log(res.data.data)
                            contentUuids = res.data.data.subscribedContents.subscribed_content_list;
                            if(contentUuids.length > 0){
                                this.MyLibrary(contentUuids.join(','));
                               } else {
                                console.log("No data found");
                                this.nodatafound = true;
                               }
                        }else{
                            console.log("No data found");
                            this.nodatafound = true;
                        }
                    });
             },
        MyLibrary: function(contentUuids) {
            getSubscribedContentDeatils(contentUuids).then((res) => {
                if (res.data.code === 200) {
                    JsLoadingOverlay.hide();
                    this.allContentDetail = res.data.data.contentList.content_list;
                    this.allContentDetail.forEach(ele => {
                        if (ele.video_details !== null) {
                            const vDuration = ele.video_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                        if (ele.audio_details !== null) {
                            const aDuration = ele.audio_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                    })
                } else {
                    console.log("No data found");
                    this.nodatafound = true;
                }
            });
        },
        getContentSettingsDetails() {
			getContentSettingsDetails().then((res) => {
				if (res.data.code == 200) {
				 this.isFavouriteEnabled = (res.data.data.contentSettings.content_favourite_settings != null) ? res.data.data.contentSettings.content_favourite_settings ?.is_enabled : false;
			    }
		    });
		},
        getFavoriteContents(page, onScroll) {
            if (this.isNextPageCallReqd) {
                (this.isNextPageCallReqd = false), JsLoadingOverlay.show();
					getFavoriteContents(page).then((res) => {
							JsLoadingOverlay.hide();
							if (
									!onScroll &&
									res.data.code == 200 &&
									res.data.data.favouriteContentList
											.content_favourite_list
							) {
									this.favoriteContents =
											res.data.data.favouriteContentList.content_favourite_list;
									let contents = [];
									this.favoriteContents.forEach(element => {
											contents.push(element.content_details);
									});    
									//contentHelper.getPartnerAndUserUuids(contents,this.userList);
							} else if (
									onScroll &&
									res.data.code == 200 &&
									res.data.data.favouriteContentList
											.content_favourite_list
							) {
									this.favoriteContents.push(
											...res.data.data.favouriteContentList
													.content_favourite_list
									);
									let contents = [];
									res.data.data.favouriteContentList
													.content_favourite_list.forEach(element => {
											contents.push(element.content_details);
									});    
								 // contentHelper.getPartnerAndUserUuids(contents,this.userList);
							}
							if (!onScroll && page == 1 && res.data.status == "FAILED") {
									this.favoriteContents = [];
							}

							if (
									res.data.code == 200 &&
									this.favoriteContents?.length <
											res.data.data.favouriteContentList.page_info
													.total_count
							) {
									this.isNextPageCallReqd = true;
							}
							if (
									this.favoriteContents == null ||
									this.favoriteContents?.length <= 0
							) {
									this.noRecordMsgShow = true;
							}
					});
			    }
			},
			getContentFavouriteAction(contentUuid) {
				getContentFavoriteStatus(contentUuid).then((res) => {
						if (res.data.code == 200 && res.data.data !== null) {
								this.isFavourite = res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
						} else {
								this.isFavourite = 0;
						}
				});
		},
		favouriteEvent(contentDetails) {
			if (this.isLogedIn) {
					const param = {
							"app_token": ":app_token",
							"product_key": ":product_key",
							"store_key": ":store_key",
							"end_user_uuid": ":me",
							"content_uuid": contentDetails.content_uuid,
							"is_favourite": this.isFavourite == 0 ? 1 : 0,
					}
					makeContentFavorite(param).then((res) => {
							if (res.data.code == 200 && res.data.status == "SUCCESS") {
									this.getContentFavouriteAction(contentDetails.content_uuid);
							}
					})
			} else {
					window.location.href = "/sign-up";
			}
		},
    },
    template: `<vd-component class="vd my-library-two" type="my-library-two">
    <!--Profile Step Here-->
    <div class="row backColor">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" >
            <h1 class="dashboard-heading">
                <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
            </h1>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" >
            <div class="raiden-product-slider videoallseasion-grids" >
                <div class="row">
                    <div v-if="allContentDetail.length > 0" class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4" v-for="data in allContentDetail">
                        <div class="product-slider-container" >
                            <div class="product-slider-image">
                                <div class="icons-apply">
                                    <img v-if="data.content_asset_type == 1" :src="getRootUrl() + 'img/video-icons.png'"/>
                                    <img v-if="data.content_asset_type == 2" :src="getRootUrl() + 'img/audio-icon.png'"/>
                                </div>
                                <div class="freeContent-tag" v-if="data?.is_free_content">
                                    <span><span><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></span></span>
                                </div>
                                <img v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                    :src="data.posters.website[0].file_url" alt="" />
                                <img v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                    :src="data.no_image_available_url" alt="Godzilla vs Kong"/>
                                <!--<div class="product-like-option">
                                    <div class="like like-heart" v-show="isFavouriteEnabled">
                                        <div class="ulike ulike_is_not_liked">
                                            <button type="button" class="ulike_btn dislike-image" @click="favouriteEvent(data.content_details)"></button>
                                        </div>
                                    </div>
                                </div> -->   
                            </div>
                            <div class="gen-info-contain">
                                <div class="gen-movie-info">
                                    <h3>
                                        <a class="callByAjax" :href="'/content/'+data.content_permalink" @click="getContentId(data.content_uuid)">
                                            <span>{{data.content_name}}</span>
                                        </a>
                                    </h3>
                                </div>
                                <div class="gen-movie-meta-holder">
                                    <ul>
                                        <li v-if="data.video_details !== null">{{videoDuration}}</li>
                                        <li v-if="data.audio_details !== null">{{audioDuration}}</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-else>
                        <section class="no-result-found">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="w-100 text-center">
                                            <img :src="getRootUrl() + 'img/no-result.gif'" alt="no result" class="mw-100" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="no-result-found" v-if="allContentDetail.length == 0">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="w-100 text-center">
                                            <h2 v-if="allContentDetail.length == 0">
                                                <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div> 
    </div>
</vd-component>`,
};

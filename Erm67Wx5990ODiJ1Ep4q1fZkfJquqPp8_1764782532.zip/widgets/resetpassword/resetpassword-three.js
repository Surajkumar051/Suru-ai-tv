let {
    resetPassword,
    // getVdConfig,
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {i18n} = await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
const { mapState} = Vuex;

export default {
    name: "resetpassword_three",
    data() {
        return {
            newpassword: "",
            confirmpassword: "",
            passkey: "",
            isFormValid: false,
            showPassword: false,
            showConfPassword: false,
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            errors: {},
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
        };
    },
    mounted() {
        this.passkey = new URLSearchParams(window.location.search).get(
            "pass_key"
        );
        setTimeout(() => {
            JsLoadingOverlay.hide();
        }, 1000);
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             // this.logo = res.data.data;
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    computed: {
        newpassword() {
            return this.newpassword;
        },
        confirmpassword() {
            return this.confirmpassword;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
          })
    },
    watch: {
        newpassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.newpassword = "Password field is required";
                this.passwordFieldNotValidate = true;
            } else if (value.length < 8) {
                this.errors.valid = false;

                this.isFormValid = false;
                this.errors.newpassword =
                    "Password should be more than 8 characters long.";
                this.passwordFieldNotValidate = true;
            } else if (value === this.confirmpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = null;
                this.passwordFieldNotValidate = true;
                this.errors.confirmpassword = null;
                this.errors.newpassword = null;
            } else {
                this.errors.newpassword = null;
                this.passwordFieldNotValidate = false;
                if (value !== this.confirmpassword) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.confirmpassword = "Password do not match";
                    this.confirmPwdFieldNotValidate = true;
                }
                if (
                    this.errors.newpassword !== undefined &&
                    this.errors.newpassword == null &&
                    this.errors.confirmpassword !== undefined &&
                    this.errors.confirmpassword == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        confirmpassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword =
                    "Confirm Password field is required";
                this.confirmPwdFieldNotValidate = true;
            } else if (value !== this.newpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword = "Passwords do not match";
                this.confirmPwdFieldNotValidate = true;
            } else {
                this.errors.confirmpassword = null;
                this.confirmPwdFieldNotValidate = false;

                if (
                    this.errors.newpassword !== undefined &&
                    this.errors.newpassword == null &&
                    this.errors.confirmpassword !== undefined &&
                    this.errors.confirmpassword == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
    },

    methods: {
        getRootUrl,
        i18n,
        submitResetPassword() {
            if (!this.newpassword.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.newpassword = "Password field is required";
                this.passwordFieldNotValidate = true;
                return;
            } else {
                this.errors.newpassword = null;
                this.passwordFieldNotValidate = false;
            }

            if (this.newpassword != this.confirmpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword =
                    "Confirm password field not matched";
                this.confirmPwdFieldNotValidate = true;
                return;
            }

            this.errors.valid = true;
            this.isFormValid = true;

            let passwordData = {
                password_key: this.passkey,
                new_password: this.newpassword,
                confirm_password: this.confirmpassword,
            };
            resetPassword(passwordData)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        Toast.fire({
                            icon: "success",
                            text: res.data.message,
                        });

                        window.location.href = "/sign-in";
                        // setTimeout(() => {
                        //     window.location.href = "/login";
                        // }, 1000);
                    } else {
                        Toast.fire({
                            icon: "error",
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    console.log("error", err);
                });
        },
    },
    template: `
     <vd-component class="vd resetpassword-three" type="resetpassword-three">
         <!--Header Section Start Here-->
         <section class="header"> 
            <div class="container-fluid"> 
                <div class="row"> 
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"> 
                    <nav class="navbar navbar-expand-lg navbar-light"> <a v-if="logo_details['logo']" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']" :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a> <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'" alt="citrine" /></a> </nav> 
                    </div> 
                </div> 
            </div> 
        </section>
         <!--Header Section End Here-->
         <!--Sign Up From Start Here--> 
         <section class="sign-process container-fluid row justify-content-center"> 
            <div class="col-md-9 col-lg-7 text-center"> 
                <!--From Section Start Here--> 
                <div class="sign-form-layout"> 
                    <h2 class="mt-3 text-center"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2> 
                    <p class="mt-2 text-center"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
                        <form action="" method="" class="w-100" id=""> 
                            <div class="col-12"> 
                                <div class="input-group mb-30"> 
                                    <span class="input-group-text"> 
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> 
                                                <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/> 
                                                <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/> 
                                            </svg> 
                                    </span> 
                                    <input @keyup.enter="submitResetPassword" v-bind:type="[showPassword ? 'text' : 'password']" v-model="newpassword" class="form-control vd-component-attr" vd-component-attr-placeholder="label5" :placeholder=i18n($attrs['label5']) 
                                    vd-component-attr-title="label7" :title=i18n($attrs['label7']) autocomplete="off" :class="passwordFieldNotValidate ? 'is-invalid' : ''"> 
                                    <button type="button" class="border-0" @click="showPassword = !showPassword">
                                        <span toggle="#password" class="field-icon toggle-password"> 
                                            <span class="material-icons"> 
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> 
                                                    <path d="M19.97 21.385L16.614 18.029C15.1661 18.6882 13.5908 19.0204 12 19.002C10.3599 19.0223 8.73671 18.6684 7.254 17.967C6.10468 17.4062 5.07264 16.6317 4.213 15.685C3.30049 14.7068 2.5833 13.5633 2.1 12.316L2 12.002L2.105 11.686C2.82781 9.84224 4.04426 8.23312 5.621 7.03495L3 4.41395L4.413 3.00195L21.382 19.971L19.972 21.385H19.97ZM7.036 8.45095C5.75792 9.34687 4.74865 10.5747 4.117 12.002C5.47142 15.1269 8.59587 17.1086 12 17.002C13.0498 17.0106 14.0936 16.8415 15.087 16.502L13.287 14.702C12.8863 14.8984 12.4462 15.0009 12 15.002C10.3475 14.9916 9.01037 13.6545 9 12.002C9.00048 11.5547 9.10309 11.1135 9.3 10.712L7.036 8.45095ZM19.852 15.612L18.46 14.221C19.0456 13.5589 19.5256 12.8104 19.883 12.002C18.5304 8.87553 15.4047 6.89303 12 7.00195C11.753 7.00195 11.505 7.01095 11.265 7.02795L9.5 5.26095C10.3216 5.08519 11.1598 4.99835 12 5.00195C13.6401 4.9816 15.2633 5.33557 16.746 6.03695C17.8953 6.59769 18.9274 7.37215 19.787 8.31895C20.6991 9.29592 21.4163 10.438 21.9 11.684L22 12.002L21.895 12.318C21.4268 13.536 20.7342 14.6554 19.853 15.618L19.852 15.612Z" fill="#91919F"/> 
                                                    </svg> 
                                            </span> 
                                        </span> 
                                    </button>
                                <template v-if="errors.newpassword"> 
                                    <h3 class="invalid-feedback pb-2 validation-msg d-block" style="position: absolute;bottom: -25px;">{{ errors.newpassword }}</h3> 
                                </template> 
                                </div> 
                                <div class="input-group mb-3"> 
                                    <span class="input-group-text"> 
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> 
                                            <path d="M19 11H5C3.89543 11 3 11.8954 3 13V20C3 21.1046 3.89543 22 5 22H19C20.1046 22 21 21.1046 21 20V13C21 11.8954 20.1046 11 19 11Z" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/> 
                                            <path d="M7 11V7C7 5.67392 7.52678 4.40215 8.46447 3.46447C9.40215 2.52678 10.6739 2 12 2C13.3261 2 14.5979 2.52678 15.5355 3.46447C16.4732 4.40215 17 5.67392 17 7V11" stroke="#91919F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/> 
                                        </svg> 
                                </span> 
                                <input @keyup.enter="submitResetPassword" v-bind:type="[showConfPassword ? 'text' : 'password']" v-model="confirmpassword" class="form-control vd-component-attr" vd-component-attr-placeholder="label6" :placeholder=i18n($attrs['label6']) 
                                vd-component-attr-title="label8" :title=i18n($attrs['label8']) @copy.prevent @paste.prevent @cut.prevent autocomplete="off" :class="confirmPwdFieldNotValidate ? 'is-invalid' : ''"> 
                                <button type="button" class="border-0" @click="showConfPassword = !showConfPassword"> 
                                    <!-- <i :class="[showConfPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i> --> 
                                    <span toggle="#password" class="field-icon toggle-password"> 
                                        <span class="material-icons"> <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> 
                                            <path d="M19.97 21.385L16.614 18.029C15.1661 18.6882 13.5908 19.0204 12 19.002C10.3599 19.0223 8.73671 18.6684 7.254 17.967C6.10468 17.4062 5.07264 16.6317 4.213 15.685C3.30049 14.7068 2.5833 13.5633 2.1 12.316L2 12.002L2.105 11.686C2.82781 9.84224 4.04426 8.23312 5.621 7.03495L3 4.41395L4.413 3.00195L21.382 19.971L19.972 21.385H19.97ZM7.036 8.45095C5.75792 9.34687 4.74865 10.5747 4.117 12.002C5.47142 15.1269 8.59587 17.1086 12 17.002C13.0498 17.0106 14.0936 16.8415 15.087 16.502L13.287 14.702C12.8863 14.8984 12.4462 15.0009 12 15.002C10.3475 14.9916 9.01037 13.6545 9 12.002C9.00048 11.5547 9.10309 11.1135 9.3 10.712L7.036 8.45095ZM19.852 15.612L18.46 14.221C19.0456 13.5589 19.5256 12.8104 19.883 12.002C18.5304 8.87553 15.4047 6.89303 12 7.00195C11.753 7.00195 11.505 7.01095 11.265 7.02795L9.5 5.26095C10.3216 5.08519 11.1598 4.99835 12 5.00195C13.6401 4.9816 15.2633 5.33557 16.746 6.03695C17.8953 6.59769 18.9274 7.37215 19.787 8.31895C20.6991 9.29592 21.4163 10.438 21.9 11.684L22 12.002L21.895 12.318C21.4268 13.536 20.7342 14.6554 19.853 15.618L19.852 15.612Z" fill="#91919F"/> 
                                        </svg> 
                                    </span> 
                                </span> 
                            </button> 
                            <template v-if="errors.confirmpassword"> 
                                <div class="invalid-feedback validation-msg" style="position: absolute;bottom: -25px;">{{ errors.confirmpassword }}</div> 
                            </template> 
                        </div> 
                        <a href="javascript:void(0)" class="mt-5 btn-solid" :class="(email_filed || password =='')?'disabled_button':''" @click="submitResetPassword()" :disabled="email_filed || password ==''"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></a> 
                    </div> 
                    </form> 
                    <p class="text-center back"> 
                        <a href="/sign-in" vd-node="link" class="callByAjax"> 
                            <span class="mr-10"> <img :src="getRootUrl() +'img/icon-arrow-left.png'" al="left"> </span> 
                            <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param> 
                        </a> 
                    </p> <!--From Section End Here--> 
            </div> 
            </section>
    </vd-component>
     `,
};

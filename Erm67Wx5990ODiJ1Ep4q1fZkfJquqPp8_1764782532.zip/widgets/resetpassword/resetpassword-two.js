let {
    resetPassword,
    // getVdConfig,
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {i18n} = await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
const { mapState} = Vuex;
export default {
    name: "resetpassword_two",
    data() {
        return {
            newpassword: "",
            confirmpassword: "",
            passkey: "",
            isFormValid: false,
            showPassword: false,
            showConfPassword: false,
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            errors: {},
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            rootUrl: getRootUrl(),
        };
    },
    mounted() {
        this.passkey = new URLSearchParams(window.location.search).get(
            "pass_key"
        );
        setTimeout(() => {
            JsLoadingOverlay.hide();
        }, 1000);
        //logo starts here
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });

        //logo ends here
    },
    computed: {
        newpassword() {
            return this.newpassword;
        },
        confirmpassword() {
            return this.confirmpassword;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
          })
    },
    watch: {
        newpassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.newpassword = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
            } else if (value.length < 8) {
                this.errors.valid = false;

                this.isFormValid = false;
                this.errors.newpassword =
                i18n("Password should be more than 8 characters long.");
                this.passwordFieldNotValidate = true;
            } else if (value === this.confirmpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = null;
                this.passwordFieldNotValidate = true;
                this.errors.confirmpassword = null;
                this.errors.newpassword = null;
            } else {
                this.errors.newpassword = null;
                this.passwordFieldNotValidate = false;
                if (value !== this.confirmpassword) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.confirmpassword = i18n("Password do not match");
                    this.confirmPwdFieldNotValidate = true;
                }
                if (
                    this.errors.newpassword !== undefined &&
                    this.errors.newpassword == null &&
                    this.errors.confirmpassword !== undefined &&
                    this.errors.confirmpassword == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        confirmpassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword =
                i18n("Confirm Password field is required");
                this.confirmPwdFieldNotValidate = true;
            } else if (value !== this.newpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword = i18n("Passwords do not match");
                this.confirmPwdFieldNotValidate = true;
            } else {
                this.errors.confirmpassword = null;
                this.confirmPwdFieldNotValidate = false;

                if (
                    this.errors.newpassword !== undefined &&
                    this.errors.newpassword == null &&
                    this.errors.confirmpassword !== undefined &&
                    this.errors.confirmpassword == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
    },

    methods: {
        getRootUrl,
        i18n,
        submitResetPassword() {
            if (!this.newpassword.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.newpassword = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
                return;
            } else {
                this.errors.newpassword = null;
                this.passwordFieldNotValidate = false;
            }

            if (this.newpassword != this.confirmpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword =
                i18n("Confirm password field not matched");
                this.confirmPwdFieldNotValidate = true;
                return;
            }

            this.errors.valid = true;
            this.isFormValid = true;

            let passwordData = {
                password_key: this.passkey,
                new_password: this.newpassword,
                confirm_password: this.confirmpassword,
            };
            resetPassword(passwordData)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        Toast.fire({
                            icon: "success",
                            text: res.data.message,
                        });

                        window.location.href = "/sign-in";
                        // setTimeout(() => {
                        //     window.location.href = "/login";
                        // }, 1000);
                    } else {
                        Toast.fire({
                            icon: "error",
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    console.log("error", err);
                });
        },
    },
    template: `
    <vd-component class="vd resetpassword-two" type="resetpassword-two">
    <!--Header Section Start Here-->
    <section class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a v-if="logo_details['logo']" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']" :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="rootUrl+'img/logo.png'" alt="Raiden" /></a>
            </nav>
          </div>
        </div>
      </div>
    </section>
    <!--Header Section End Here-->
    <!--Sign Up From Start Here-->
    <section class="sign-process">
      <div class="content">
        <!--From Section Start Here-->
        <div class="sign-form-layout">
          <h2><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2>
          <p><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
          <form action="" method="" class="" id="">
            <div class="form-group ">
              <div class="show-password form-label _required">
              <input @keyup.enter="submitResetPassword" v-bind:type="[showPassword ? 'text' : 'password']" v-model="newpassword" class="form-control mb-16 pr-42 vd-component-attr" vd-component-attr-placeholder="label5" :placeholder=i18n($attrs['label5']) 
              vd-component-attr-title="label7" :title=i18n($attrs['label7']) autocomplete="off" :class="passwordFieldNotValidate ? 'is-invalid' : ''">
                <button type="button"  @click="showPassword = !showPassword">
                  <i :class="[showPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                <template v-if="errors.newpassword">
                  <div class="invalid-feedback validation-msg">{{ errors.newpassword }}</div>
                </template>
              </div>
              <div class="show-password form-label _required">
              <input @keyup.enter="submitResetPassword" v-bind:type="[showConfPassword ? 'text' : 'password']" v-model="confirmpassword" class="form-control mb-16 pr-42 vd-component-attr"  vd-component-attr-placeholder="label6" :placeholder=i18n($attrs['label6']) 
              vd-component-attr-title="label8" :title=i18n($attrs['label8']) @copy.prevent @paste.prevent @cut.prevent autocomplete="off" :class="confirmPwdFieldNotValidate ? 'is-invalid' : ''">
                <button type="button"  @click="showConfPassword = !showConfPassword">
                  <i :class="[showConfPassword ? 'far fa-eye' : 'far fa-eye-slash']"></i></button>
                <template v-if="errors.confirmpassword">
                  <div class="invalid-feedback validation-msg">{{ errors.confirmpassword }}</div>
                </template>
              </div>
            </div>
            <div class="form-group mb-40">
              <button type="button" @click="submitResetPassword()" class="primary-button"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></button>
            </div>
          </form>
          <p class="text-center back">
            <a href="/sign-in" vd-node="link" class="callByAjax">
              <span class="mr-10">
                <img :src="getRootUrl() +'img/icon-arrow-left.png'" al="left">
              </span>
              <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
            </a>
          </p>
          <!--From Section End Here-->
        </div>
    </section>
</vd-component>
    `,
};

let {
	fetchPartnerDetails,
	fetchPartnerContentDetails,
	fetchEndUserContentDetails,
	fetchEndUserDetails
} = await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { owlCarousal } =await import(window.importAssetJs('js/customcarousel.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { defineAsyncComponent } = Vue;
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
const { mapState, mapActions } = Vuex;
export default {
	name: "user_contents_two",
	components: {
		content_hover_six,
		content_title_one,
		audio_player_one,
		content_purchase_five: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-five.js'))),
	},
	data() {
		return {
			isLogedIn: localStorage.getItem('isloggedin'),
			contentUuidAudio: '',
			resetAudioPlayer: Math.floor(Math.random() * 10000000),
			isAudioPlay: false,
			reloadOnUpdateLifeCycle: true,

			rootUrl: getRootUrl(),
			userUuid: permalink,
			userType: user_type,
			userDetails: {},
			currentTab: "all",

			allContentList: [],
			allTabPage: 1,
			allTabPerPage: 12,
			isAllTabNextPageCallReqd: true,

			videoContentList: [],
			videoTabPage: 1,
			videoTabPerPage: 12,
			isVideoTabNextPageCallReqd: true,

			audioContentList: [],
			audioTabPage: 1,
			audioTabPerPage: 12,
			isAudioTabNextPageCallReqd: true,

			playlistContentList: [],
			playlistTabPage: 1,
			playlistTabPerPage: 12,
			isPlaylistTabNextPageCallReqd: true,
			ugcContentList: [],
			ugcTabPage: 1,
			ugcTabPerPage: 12,
			isUgcTabNextPageCallReqd: true,
			miniContentList: [],
			miniTabPage: 1,
			miniTabPerPage: 12,
			isMiniTabNextPageCallReqd: true,

		};
	},
	created() {

	},
	updated() {
		if (!this.reloadOnUpdateLifeCycle) {
			this.reloadOnUpdateLifeCycle = true;
		} else {
			owlCarousal();
		}
	},
	props: {

	},

	mounted() {
		scrollLoad = true; //@ER: 74207
		this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
		this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
		this.$store.dispatch(GET_MATURITY_RATINGS);
		this.baseURL = getBaseUrl();
		if (this.userType == 'partner') {
			this.fetchPartnerDetails();
			this.fetchPartnerAllTabContentDetails(false);
			// this.fetchPartnerVideoTabContentDetails(false);
			this.fetchPartnerAudioTabContentDetails(false);
			this.fetchPartnerPlaylistTabContentDetails(false);
			//this.loadMore();

		} else {
			this.fetchUserDetails();
			this.fetchUserUGCTabContentDetails(false);
			this.fetchUserMinisTabContentDetails(false);
			this.currentTab = 'ugc';
		}
		this.loadMore();
	},
	methods: {
		getBaseUrl,
		getRootUrl,
		i18n,
		fetchPartnerDetails() {
			fetchPartnerDetails(this.userUuid).then((res) => {
				if (res.data.code == 200 && res.data.data.getUserDetails && res.data.data.getUserDetails.length > 0) {
					this.userDetails = res.data.data.getUserDetails[0];
					this.updateCreatedDate();
				}
			});
		},
		updateCreatedDate(){
			if(this.userDetails.created_date != undefined && this.userDetails.created_date != "" && this.userDetails.created_date){
				let dateVal =  this.userDetails.created_date?.split(" ")[0].split("-");
				this.userDetails.created_date = moment(new Date(dateVal[1]+"-"+dateVal[0]+"-"+dateVal[2])).format('DD MMMM YYYY');
				}
		},
		fetchUserDetails() { 
			fetchEndUserDetails(this.userUuid).then((res) => {
				if (res.data.code == 200 && res.data.data.getAllTypeUser && res.data.data.getAllTypeUser.users_list.length>0) {
						this.userDetails = res.data.data.getAllTypeUser.users_list[0];
						this.updateCreatedDate();
							}
			});
		},

		fetchPartnerAllTabContentDetails(onScroll) {
			if (this.isAllTabNextPageCallReqd) {
				this.isAllTabNextPageCallReqd = false;
				fetchPartnerContentDetails(this.userUuid, "2", 2, this.allTabPage, this.allTabPerPage).then((res) => {
					if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.allContentList = res.data.data.contentList.content_list;
					} else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.allContentList.push(...res.data.data.contentList.content_list);
					}

					if (res.data.code == 200 &&
						this.allContentList?.length < res.data.data.contentList.page_info.total_count
					) {
						this.isAllTabNextPageCallReqd = true;
					}

				});
			}
		},

		fetchPartnerVideoTabContentDetails(onScroll) {
			if (this.isVideoTabNextPageCallReqd) {
				this.isVideoTabNextPageCallReqd = false;
				fetchPartnerContentDetails(this.userUuid, "2", 0, this.videoTabPage, this.videoTabPerPage).then((res) => {
					if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.videoContentList = res.data.data.contentList.content_list;
					} else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.videoContentList.push(...res.data.data.contentList.content_list);
					}

					if (res.data.code == 200 &&
						this.videoContentList?.length < res.data.data.contentList.page_info.total_count
					) {
						this.isVideoTabNextPageCallReqd = true;
					}

				});
			}
		},

		fetchPartnerAudioTabContentDetails(onScroll) {
			if (this.isAudioTabNextPageCallReqd) {
				this.isAudioTabNextPageCallReqd = false;
				fetchPartnerContentDetails(this.userUuid, "2", 0, this.audioTabPage, this.audioTabPerPage).then((res) => {
					if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.audioContentList = res.data.data.contentList.content_list;
					} else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.audioContentList.push(...res.data.data.contentList.content_list);
					}

					if (res.data.code == 200 &&
						this.audioContentList?.length < res.data.data.contentList.page_info.total_count
					) {
						this.isAudioTabNextPageCallReqd = true;
					}

				});
			}
		},

		fetchPartnerPlaylistTabContentDetails(onScroll) {
			if (this.isPlaylistTabNextPageCallReqd) {
				this.isPlaylistTabNextPageCallReqd = false;
				fetchPartnerContentDetails(this.userUuid, "2", 1, this.playlistTabPage, this.playlistTabPerPage).then((res) => {
					if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.playlistContentList = res.data.data.contentList.content_list;
					} else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.playlistContentList.push(...res.data.data.contentList.content_list);
					}

					if (res.data.code == 200 &&
						this.playlistContentList?.length < res.data.data.contentList.page_info.total_count
					) {
						this.isPlaylistTabNextPageCallReqd = true;
					}

				});
			}
		},

		loadMore() {
			window.onscroll = () => {
				let bottomOfWindow =
					document.documentElement.scrollTop +
					document.documentElement.clientHeight +
					20 >=
					document.documentElement.scrollHeight;
				console.log("scroll check", bottomOfWindow);
				if (bottomOfWindow && this.isAllTabNextPageCallReqd && this.currentTab == 'all' && scrollLoad) {
					this.allTabPage++;
					console.log("scroll check page", this.allTabPage);
					this.fetchPartnerAllTabContentDetails(true);
				}
				if (bottomOfWindow && this.isPlaylistTabNextPageCallReqd && this.currentTab == 'playlist' && scrollLoad) {
					this.playlistTabPage++;
					this.fetchPartnerPlaylistTabContentDetails(true);
				}
				if (bottomOfWindow && this.isVideoTabNextPageCallReqd && this.currentTab == 'video' && scrollLoad) {

					this.videoTabPage++;
					this.fetchPartnerVideoTabContentDetails(true);
				}
				if (bottomOfWindow && this.isAudioTabNextPageCallReqd && this.currentTab == 'audio' && scrollLoad) {
					this.audioTabPage++;
					this.fetchPartnerAudioTabContentDetails(true);
				}
				if (bottomOfWindow && this.isUgcTabNextPageCallReqd && this.currentTab == 'ugc' && scrollLoad) {
					this.ugcTabPage++;
					this.fetchUserUGCTabContentDetails(true);
				}
				if (bottomOfWindow && this.isMiniTabNextPageCallReqd && this.currentTab == 'mini' && scrollLoad) {
					this.miniTabPage++;
					this.fetchUserMiniTabContentDetails(true);
				}
			};
		},
		playAudioContent(contentUuid) {
			this.reloadOnUpdateLifeCycle = false;
			this.contentUuidAudio = contentUuid;
			this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
			this.isAudioPlay = true;
		},
		fetchUserUGCTabContentDetails(onScroll) {
			if (this.isUgcTabNextPageCallReqd) {
				this.isUgcTabNextPageCallReqd = false;
				fetchEndUserContentDetails(this.userUuid, 2, this.ugcTabPage, this.ugcTabPerPage).then((res) => {
					if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.ugcContentList = res.data.data.contentList.content_list;
					} else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.ugcContentList.push(...res.data.data.contentList.content_list);
					}
					if (res.data.code == 200 &&
						this.ugcContentList?.length < res.data.data.contentList.page_info.total_count
					) {
						this.isUgcTabNextPageCallReqd = true;
					}
				});
			}
		},
		fetchUserMinisTabContentDetails(onScroll) {
			if (this.isMiniTabNextPageCallReqd) {
				this.isMiniTabNextPageCallReqd = false;
				fetchEndUserContentDetails(this.userUuid, 2, this.miniTabPage, this.miniTabPerPage).then((res) => {
					if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.miniContentList = res.data.data.contentList.content_list;
					} else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
						this.miniContentList.push(...res.data.data.contentList.content_list);
					}
					if (res.data.code == 200 &&
						this.miniContentList?.length < res.data.data.contentList.page_info.total_count
					) {
						this.isMiniTabNextPageCallReqd = true;
					}
				});
			}
		},

	},
	computed: {
		...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }), 
		isPartnerProfile() {
			return (this.userType === 'partner');
		},
		isEndUserProfile() {
			return (this.userType === 'user');
		}

	},
	watch: {
		currentTab(currentTab) {
			if (currentTab !== 'all') {
				$('#allTabLi').removeClass("active show");
			}
			if (currentTab !== 'ugc') {
				$('#ugcTabLi').removeClass("active show");
			}
		}
	},
	template: `
<vd-component class="vd user-contents-two" type="user-contents-two">
<content_purchase_five  :id="$attrs['id'] +'_content_purchase_five_5'" />
	<section class="season-content product-listing pt-0">
		<div class="container-fluid plr-80">
			<div class="row">
				<!-- Tabs Area Start-->
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<ul class="profile-tab-options nav nav-tabs">
						<li v-if="isPartnerProfile && !isEndUserProfile && allContentList?.length>0" class="nav-item active show" id="allTabLi">
							<a class="nav-link" id="all-tab" @click="currentTab='all'" data-toggle="tab" href="#all" role="tab" aria-controls="home" aria-selected="false">
								<vd-component-param type="label1" v-html="i18n($attrs['label1'])"/>
							</a>
						</li>
						<li class="nav-item" v-if="isPartnerProfile && !isEndUserProfile && audioContentList?.length>0">
							<a class="nav-link" @click="currentTab='audio'" id="audio-tab" data-toggle="tab" href="#audio" role="tab" aria-controls="home" aria-selected="true">
								<vd-component-param type="label3" v-html="i18n($attrs['label3'])"/>
							</a>
						</li>
						<li class="nav-item" v-if="isPartnerProfile && !isEndUserProfile && playlistContentList?.length>0">
							<a class="nav-link" @click="currentTab='playlist'" id="playlist-tab" data-toggle="tab" href="#playlist" role="tab" aria-controls="home" aria-selected="true">
								<vd-component-param type="label4" v-html="i18n($attrs['label4'])"/>
							</a>
						</li>
						<li class="nav-item" v-if="isPartnerProfile || isEndUserProfile"
						 :class="((isPartnerProfile && allContentList?.length==0 && videoContentList?.length==0 && 
						 audioContentList?.length==0 && playlistContentList?.length==0) || (isEndUserProfile && ugcContentList?.length==0 && miniContentList?.length==0))?'show active' : ''">
							<a class="nav-link" @click="currentTab='about'" id="about-tab" data-toggle="tab" href="#about" role="tab" aria-controls="home" aria-selected="true">
								<vd-component-param type="label5" v-html="i18n($attrs['label5'])"/>
							</a>
						</li>
					</ul>
				</div>
				<!-- Tabs Area end-->
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="tab-content profile-tab-contents" id="myTabContent">
						<!-- Tab all start -->
						<div v-show="isPartnerProfile && !isEndUserProfile && allContentList?.length>0 && currentTab=='all'" class="tab-pane fade  active show" id="all" role="tabpanel" aria-labelledby="all-tab">
							<section class="product-listing ugc-section">
								<div class="container-fluid p-0">
									<div class="row m-0">
										<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
											<div class="contect-listing">
												<ul class="tiles-ul" v-if="allContentList?.length>0">
													<li class="tiles-li w-308" v-for="data in allContentList">
														<div class="tiles grid-hover">
															<div class="picture h-176">
																<div class="freeContent-tag" v-if="data?.is_free_content">
																	<span><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></span>
															   	</div>
																<div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
																	<span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
																</div>
																<div :class="(data.content_asset_type == 2 && data.is_playlist!=1)?'icons-apply-audio':'icons-apply'">
																	<img v-if="data.is_playlist==0 && data.content_asset_type == 1" :src="rootUrl + 'img/video-icons.png'"/>
																	<img v-if="data.is_playlist==0 && data.content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'"/>
																	<img v-if="data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
																</div>
																<img class="w-100" loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url"/>
																<img class="w-100" loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="no image"/>
																<!--Button Show on Hover start Here-->
																<content_hover_one :id="$attrs['id'] +'_content_hover_one_1'" :content="data" :playNowBtnTxt="$attrs['label9']" :viewTrailerBtnTxt="$attrs['label10']" :playAllBtnTxt="$attrs['label11']" :watchNowBtnTxt="$attrs['label9']" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"/>
															</div>
															<content_title_one :id="$attrs['id'] +'_content_title_one_1'" :content="data"/>
														</div>
													</li>
												</ul>
												<div v-else class="w-100 text-center white-color">
													<h6>
														<vd-component-param type="label12" v-html="i18n($attrs['label12'])"/>
													</h6>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>
						<!-- Tab all end -->
						<!-- Tab Audio start -->
						<div v-show="isPartnerProfile && !isEndUserProfile && audioContentList?.length>0 && currentTab=='audio'" class="tab-pane fade" id="audio" role="tabpanel" aria-labelledby="all-tab">
							<section class="product-listing audio-section">
								<div class="container-fluid p-0">
									<div class="row m-0">
										<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
											<div class="contect-listing">
												<ul class="tiles-ul" v-if="audioContentList?.length>0">
													<li class="tiles-li w-200" v-for="data in audioContentList">
														<div class="tiles grid-hover">
															<div class="picture h-200">
																<div class="freeContent-tag" v-if="data?.is_free_content">
																	<span><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></span>
															   	</div>
																<div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
																	<span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
																</div>
																<img class="w-100" loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url"/>
																<img class="w-100" loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="no image"/>
																<!--Button Show on Hover start Here-->
																<content_hover_one :id="$attrs['id'] +'_content_hover_one_1'" :content="data" :playNowBtnTxt="$attrs['label9']" :viewTrailerBtnTxt="$attrs['label10']" :playAllBtnTxt="$attrs['label11']" :watchNowBtnTxt="$attrs['label9']" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"/>
															</div>
															<content_title_one :id="$attrs['id'] +'_content_title_one_1'" :content="data"/>
														</div>
													</li>
												</ul>
												<div v-else class="w-100 text-center white-color">
													<h6>
														<vd-component-param type="label12" v-html="i18n($attrs['label12'])"/>
													</h6>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>
						<!-- Tab Audio end-->
						<!-- Tab Playlist start -->
						<div v-show="isPartnerProfile && !isEndUserProfile && playlistContentList?.length>0 && currentTab=='playlist'" class="tab-pane fade" id="playlist" role="tabpanel" aria-labelledby="all-tab">
							<section class="product-listing ugc-section">
								<div class="container-fluid p-0">
									<div class="row m-0">
										<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
											<div class="contect-listing">
												<ul class="tiles-ul" v-if="playlistContentList?.length>0">
													<li class="tiles-li w-308" v-for="data in playlistContentList">
														<div class="tiles grid-hover">
															<div class="picture h-176">
																<div class="freeContent-tag" v-if="data?.is_free_content">
																	<span><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></span>
															   	</div>
																<div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
																	<span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
																</div>
																<img class="w-100" loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url"/>
																<img class="w-100" loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="no image"/>
																<!--Button Show on Hover start Here-->
																<content_hover_one :id="$attrs['id'] +'_content_hover_one_1'" :content="data" :playNowBtnTxt="$attrs['label9']" :viewTrailerBtnTxt="$attrs['label10']" :playAllBtnTxt="$attrs['label11']" :watchNowBtnTxt="$attrs['label9']" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"/>
															</div>
															<content_title_one :id="$attrs['id'] +'_content_title_one_1'" :content="data"/>
														</div>
													</li>
												</ul>
												<div v-else class="w-100 text-center white-color">
													<h6>
														<vd-component-param type="label12" v-html="i18n($attrs['label12'])"/>
													</h6>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>
						<!-- Tab Playlist end-->
						<!-- Tab About start-->
						<div :class="((isPartnerProfile && allContentList?.length==0 && videoContentList?.length==0 && 
							audioContentList?.length==0 && playlistContentList?.length==0) || (isEndUserProfile && ugcContentList?.length==0 && miniContentList?.length==0) )?'show active' : ''" v-show="isPartnerProfile || isEndUserProfile" class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="all-tab">
							<section class="product-listing ugc-section">
								<div class="container-fluid p-0">
									<div class="row m-0">
										<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
											<div class="about-cp">
												<div class="div-stats">
													<span><vd-component-param type="label13" v-html="i18n($attrs['label13'])"/></span>
													<p v-if="userDetails?.created_date"><vd-component-param type="label14" v-html="i18n($attrs['label14'])"/> {{userDetails.created_date}}</p>
												</div>
												<div class="div-description">
													<span><vd-component-param type="label15" v-html="i18n($attrs['label15'])"/></span>
													<p>{{userDetails?.about}}</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>
						<!-- Tab About end-->
					</div>
				</div>
			</div>
		</div>
	</section>
</vd-component>
`,

};


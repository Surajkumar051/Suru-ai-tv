let {
    validateToken,
    getReviewRating,
    SaveContentReview,
    categorizedPermalink,
    getContentReviewRatingSettingsDetails,
    getEndUserRegdLoginSetting
  } = await import(window.importAssetJs('js/webservices.js'));
  let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
  let {i18n}=await import(window.importAssetJs('js/i18n.js'));
  export default {
    name: 'reviewrating_three',
    
     data() {
          return {
              contentUuid: permalink,//window.location.pathname.toString().split("/")[2],
              contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
              reviewedData: [],
              enablePostButton: true,
              user: JSON.parse(localStorage.getItem('user')),
              isLogedIn: localStorage.getItem('isloggedin'),
              loadMoreSize: 0,
              totalSize: 2,
              rateValue: 0,
              comment: '',
              contentObj:{},
              showReviewSection:false,
              reviewRatingSettings:{
                  is_rating_enabled:false,
                  is_comment_enabled:false,
              },
              isNextPageCallReqd:true,
              page:1,
              multiProfileIsEnable:false,
              endUserProfile: JSON.parse(localStorage.getItem('multiprofileIdClicked'))
  
  
          }
      },
      created() {
          // console.log("created in player page .................");
          // this.eventBus.on('emitOnlyId', (data) => {
          //     this.newId = data
          //     console.log(this.newId)
          // })
  
      },
      beforeMount() {
          validateToken().then((data) => {
              if ((data.data['ip'].indexOf(',') > -1)) {
                  let strIp = data.data['ip'].split(',');
                  this.ip = strIp[0];
              } else {
                  this.ip = data.data['ip'];
              }
              this.email = data.data['email'];
          })
  
      },
      
      mounted() {
          this.isMultiProfileEnabled();
          scrollLoad = true; //@ER: 74207
          this.getContentReviewRatingSettingsDetails();
          this.loadMore();
  
          if (this.contentPermalink) {
              categorizedPermalink(this.contentPermalink).then(res => {
                  if (res.data.code == 200) {
                   JsLoadingOverlay.hide();
  
                      let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                          //console.log("Pithan-----",content);
                          if ((content.permalink_type == "content" || content.is_playlist==1 )&& content.content_permalink == this.contentPermalink) return true;
                          else return false;
                      })
                      if (findContentParentIndex > -1) {
                          this.contentObj = res.data.data.contentList.content_list[findContentParentIndex]
                          this.contentUuid = this.contentObj.content_uuid;
                         // console.log("ssssssssssss---"+this.contentUuid);
                         // if(this.contentObj.is_playlist==1 || window.location.pathname.toString().split("/")[1]=='player'){
                              this.getReviewRating(this.contentUuid,this.page,false);
                              this.showReviewSection = true;
                         // }
                      }
                  }else{
                      this.getReviewRating(this.contentUuid,this.page,false);
                      this.showReviewSection = true;
                  }
              });
             
          }
  
      },
  
      methods: {
          i18n,
          getReviewRating(contentUuid,page,onScroll){
              // console.log(this.isNextPageCallReqd+"page--------------------------"+this.page);
              if(this.isNextPageCallReqd){
                  this.isNextPageCallReqd = false,
                  // JsLoadingOverlay.show();
              getReviewRating(contentUuid,page).then((res) => {
                   JsLoadingOverlay.hide();
                  if (res.data.code === 200 && res.data.status === "SUCCESS") {
                      
                      if (!onScroll && res.data.code == 200 && res.data.data.contentReviewsList.content_reviews_list) {
                          this.reviewedData = res.data.data.contentReviewsList.content_reviews_list;
                      } else if (onScroll && res.data.code == 200 && res.data.data.contentReviewsList.content_reviews_list) {
                          this.reviewedData.push(...res.data.data.contentReviewsList.content_reviews_list);
                          
                      }  
  
                      if(res.data.code == 200 && this.reviewedData?.length < res.data.data.contentReviewsList.page_info.total_count){
                          this.isNextPageCallReqd = true;
                      }
  
                      this.reviewedData.forEach(element => {
  
                          //console.log(element.end_user_uuid+"-----------------------user uuid------------------------------"+this.user.data.user_uuid);
                          if (this.user== null){
                              this.enablePostButton = true;
                          }
  
                          // console.log("review element----",element);
                          if ((!this.multiProfileIsEnable && this.user != null && element.end_user_uuid === this.user?.user_uuid && this.contentUuid == element.content_uuid) || (this.multiProfileIsEnable && this.endUserProfile != null && element.profile_uuid === this.endUserProfile?.enduser_profile_uuid && this.contentUuid == element.content_uuid)) {
                              // console.log("enable false---------"+this.contentUuid);
                              this.enablePostButton = false;
                              
                          }
  
                      });
  
                  }
              }).catch((err) => {
                  console.log(err);
              });
          }
          },
  
          Reviewating: function() {
              getReviewRating(this.contentUuid,this.page).then((res) => {
  
                  if (res.data.code === 200) {
                      this.reviewedData = res.data.data.contentReviewsList.content_reviews_list;
  
                  }
              }).catch((err) => {
                  console.log(err);
              });
          },
          ratingvalue: function(event) {
              this.rateValue = event.target.value;
          },
          commentvalue: function(event) {
              this.comment = event.target.value;
          },
          addReview() {
              if(this.isLogedIn && 
                  (
                  (this.reviewRatingSettings.is_comment_enabled && this.reviewRatingSettings.is_rating_enabled && (this.rateValue || this.comment)) ||
                  (this.reviewRatingSettings.is_comment_enabled && !this.reviewRatingSettings.is_rating_enabled && !this.rateValue && this.comment) ||
                  (!this.reviewRatingSettings.is_comment_enabled && this.reviewRatingSettings.is_rating_enabled && this.rateValue && !this.comment)
                  )
              ){
                  // if(this.isLogedIn && 
                  //         (
                  //         (this.rateValue && this.comment)
                  //         )
                  //     ){
                  let rating_data = this.rateValue;
                  let comment_data = this.comment;
  
                  const param = {
                      "app_token": ":app_token",
                      "product_key": ":product_key",
                      "store_key": ":store_key",
                      "end_user_uuid": ":me",
                      "content_uuid": this.contentUuid,
                      "rating": rating_data,
                      "comment": comment_data,
                      "profile_uuid":":profile_uuid"
                  }
                  SaveContentReview(param).then(res => {
                      if (res.data.code == 200 && res.data.status == "SUCCESS") {
                          Toast.fire({
                              icon: 'success',
                              text: i18n(res.data.message),
                          })
                          window.location.reload();
                          this.Reviewating();
                          this.rateValue = 0;
                          this.comment = '';
  
                      } else {
                          if(typeof res.data.message === 'object'){
                              res.data.message = res.data.message[0];
                          }
                          Toast.fire({
                              icon: 'error',
                              text: i18n(res.data.message),
                          })
                      }
                  });
              }else if(!this.isLogedIn){
                  window.location.href = "/sign-up";
              }
          },
          getContentReviewRatingSettingsDetails(){
              getContentReviewRatingSettingsDetails().then(res => {
                  if (res.data.code == 200 && res.data.status == "SUCCESS") {
                      if(res.data.data.contentSettings.content_like_and_review_settings != null){
                          this.reviewRatingSettings = res.data.data.contentSettings.content_like_and_review_settings;
                      }
                  }
              });
          },
          loadMore() {
              window.onscroll = () => {
                  let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight+20 >= document.documentElement.scrollHeight;
                  //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                              
                  if(bottomOfWindow && this.isNextPageCallReqd && this.showReviewSection && scrollLoad){
                      this.page++;
                      this.getReviewRating(this.contentUuid,this.page,true);
                  }
              }
            },
  
            async isMultiProfileEnabled(){
              const res = await getEndUserRegdLoginSetting();
             // console.log("getEndUserRegdLoginSetting",res)
              if (res.data.code == 200 && res.data.data !== null) {
                  if(res.data.data.sections[0].groups[0].nodes[2].node_value == 1){
                      this.multiProfileIsEnable = true;
                      //console.log("this.multiProfileIsEnable",this.multiProfileIsEnable)
                  }
              }
            }  
  
      
    },
    template: /*html*/ `
  <vd-component class="vd reviewrating-three mt-94" type="reviewrating-three">
    <section class="rating-review" v-if="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled">
  <div class="container-fluid plr-65">
    <div class="row">
      <div :style="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled ? '' : 'padding:100px;'" :class="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled  ? 'col-xs-12 col-sm-12 col-md-7 col-lg-7 colBorder-right' : 'col-xs-12 col-sm-12 col-md-12 col-lg-12'">
        <div class="review" v-if="reviewedData.length">
          <div class="reviewRatingHead-div">
          <h3 class="sub-heading white-color"  v-if="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled">
           <h3 vd-readonly="true" v-else-if="reviewRatingSettings.is_rating_enabled" class="sub-heading white-color">
              <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h3>
              <!--<h3 vd-readonly="true" v-else-if="reviewRatingSettings.is_comment_enabled"
                class="sub-heading white-color" vd-readonly="true"><vd-component-param type="label7"
                  v-html="i18n($attrs['label7'])"></vd-component-param></h3>-->
          <!--<span class="seeAllReview-span">
            <a class="seeAllReview" href="#">
              See all Reviews
              <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.66536 9.30184L10.7787 9.30184L7.05203 13.0285L7.9987 13.9685L13.332 8.63517L7.9987 3.30184L7.0587 4.24184L10.7787 7.96851L2.66536 7.9685L2.66536 9.30184Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"></path>
                </svg>                
            </a>
          </span>-->
        </div>
          <!--Loop Div Here-->
          <template v-for="data in reviewedData">
          <div class="review-box reviewBorder-bottom pb-4" v-if="!(!reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled && data.rating<=0) && (!(reviewRatingSettings.is_comment_enabled && !reviewRatingSettings.is_rating_enabled && data.comment=='')) && !data.is_disabled">
            <!--<div class="profile-pic">
              <img src="img/reviewImg1.png" alt="profile picture">
            </div>-->
            <div class="comment-data" v-if="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled">
              <h4 v-if="!(!reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled && data.rating<=0) && (!(reviewRatingSettings.is_comment_enabled && !reviewRatingSettings.is_rating_enabled && data.comment==''))">{{data.end_user_name}}</h4>
              <ul v-if="reviewRatingSettings.is_rating_enabled && data.rating>0">
                <li >
                  <svg v-for="(isdata,index) in data.rating" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <g clip-path="url(.clip0_1989_12194)">
                      <path d="M14 5.34713H8.65237L6.99962 0L5.35938 7.07263L6.99962 10.6951L11.327 14L9.6743 8.65288L14 5.34713Z" fill="#F19F00"></path>
                      <path d="M5.34768 5.34713H0L4.32741 8.652L2.67384 14L7.00125 10.6951V0L5.34768 5.34713Z" fill="#F19F00"></path>
                    </g>
                    <defs>
                      <clipPath class="clip0_1989_12194">
                        <rect width="14" height="14" rx="2" fill="white"></rect>
                      </clipPath>
                    </defs>
                  </svg>
                </li>
    
              </ul>              
              
              <p v-if="reviewRatingSettings.is_comment_enabled">{{data.comment}}</p>
            </div>
          </div>
        </template>
        </div>
        <!-- else block starts-->
        <div class="no-review"  v-else-if="!reviewedData.length && reviewRatingSettings.is_rating_enabled">
          <div class="nr-div" id="noReview">
            <div class="nrd-icon">
              <svg xmlns="http://www.w3.org/2000/svg" width="91" height="90" viewBox="0 0 91 90" fill="none">
                <path d="M43.6901 27.2875C44.4104 25.7554 46.5897 25.7554 47.31 27.2875L49.4727 31.8878C49.7555 32.4894 50.3188 32.9112 50.9757 33.0132L55.9813 33.7906C57.5894 34.0403 58.242 36.0037 57.1032 37.1664L53.37 40.9777C52.9252 41.4319 52.7227 42.0704 52.8247 42.6979L53.6887 48.0164C53.9566 49.6653 52.2045 50.8965 50.7439 50.0858L46.4707 47.7138C45.867 47.3787 45.1331 47.3787 44.5294 47.7138L40.2562 50.0858C38.7956 50.8965 37.0435 49.6653 37.3114 48.0164L38.1754 42.6979C38.2774 42.0704 38.0749 41.4319 37.6301 40.9777L33.8969 37.1664C32.7581 36.0037 33.4106 34.0403 35.0188 33.7906L40.0244 33.0132C40.6813 32.9112 41.2446 32.4894 41.5274 31.8878L43.6901 27.2875Z" fill="#D5E7FE"></path>
                <path opacity="0.5" d="M70.55 5.55005H20.45C16.6508 5.55005 13.0072 7.05929 10.3207 9.74574C7.63424 12.4322 6.125 16.0758 6.125 19.8751V55.6501C6.125 59.4493 7.63424 63.0929 10.3207 65.7794C13.0072 68.4658 16.6508 69.9751 20.45 69.9751H34.775L45.5 80.7001L56.225 69.9751H70.55C74.3492 69.9751 77.9928 68.4658 80.6793 65.7794C83.3658 63.0929 84.875 59.4493 84.875 55.6501V19.8751C84.875 16.0758 83.3658 12.4322 80.6793 9.74574C77.9928 7.05929 74.3492 5.55005 70.55 5.55005Z" stroke="#E8F0FE" stroke-width="4" stroke-miterlimit="10"></path>
              </svg>
            </div>
            <div class="nrd-txt">
              <span vd-node="text" vd-readonly="true" class="nrdt-big"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></span>
              <span vd-node="text" vd-readonly="true" class="nrdt-small"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></span>
            </div>
          </div>
        </div>
        <!-- else block end-->
      </div>
      <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
        <div class="sign-form-layout rating-box" v-if="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled">
          <h3 class="sub-heading white-color mb-4"><vd-component-param type="label2"
            v-html="i18n($attrs['label2'])"></vd-component-param></h3>          
          <form action="" method="" class="comment-form" id="" v-if="reviewRatingSettings.is_rating_enabled">
            <div class="form-group mb-4">
              <label><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></label>
              <div class="ratingrange-div mt-2">
              <div class="rating">
                <input id="rating-5" @change="ratingvalue($event)" type="radio" name="rating" value="5" ><label
                for="rating-5"><label for="rating-5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M9.99996 1.66675L12.575 6.88341L18.3333 7.72508L14.1666 11.7834L15.15 17.5167L9.99996 14.8084L4.84996 17.5167L5.83329 11.7834L1.66663 7.72508L7.42496 6.88341L9.99996 1.66675Z" stroke="#C6C6C6" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                </label>
                <input id="rating-4" @change="ratingvalue($event)" type="radio" name="rating" value="4" ><label for="rating-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M9.99996 1.66675L12.575 6.88341L18.3333 7.72508L14.1666 11.7834L15.15 17.5167L9.99996 14.8084L4.84996 17.5167L5.83329 11.7834L1.66663 7.72508L7.42496 6.88341L9.99996 1.66675Z" stroke="#C6C6C6" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                </label>
                <input id="rating-3" @change="ratingvalue($event)" type="radio" name="rating" value="3"><label for="rating-3">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M9.99996 1.66675L12.575 6.88341L18.3333 7.72508L14.1666 11.7834L15.15 17.5167L9.99996 14.8084L4.84996 17.5167L5.83329 11.7834L1.66663 7.72508L7.42496 6.88341L9.99996 1.66675Z" stroke="#C6C6C6" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                </label>
                <input id="rating-2" @change="ratingvalue($event)" type="radio" name="rating" value="2" ><label for="rating-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M9.99996 1.66675L12.575 6.88341L18.3333 7.72508L14.1666 11.7834L15.15 17.5167L9.99996 14.8084L4.84996 17.5167L5.83329 11.7834L1.66663 7.72508L7.42496 6.88341L9.99996 1.66675Z" stroke="#C6C6C6" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                </label>
                <input id="rating-1" @change="ratingvalue($event)" type="radio" name="rating" value="1"><label for="rating-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M9.99996 1.66675L12.575 6.88341L18.3333 7.72508L14.1666 11.7834L15.15 17.5167L9.99996 14.8084L4.84996 17.5167L5.83329 11.7834L1.66663 7.72508L7.42496 6.88341L9.99996 1.66675Z" stroke="#C6C6C6" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                  </svg>
                </label>
              </div>
              <span class="ratingRange">{{rateValue}}</span>
            </div>
            </div> 
            <div class="form-group" v-if="reviewRatingSettings.is_comment_enabled">
              <label vd-node="text" vd-readonly="true" class="mb-2"><vd-component-param type="label4"
                v-html="i18n($attrs['label4'])"></vd-component-param></label>
                <textarea rows="4" v-model="comment" @keyup="commentvalue($event)" class="form-control"></textarea>             
            </div>  
            <div class="form-group">
             
              <button type="button" v-if="enablePostButton && (comment !='' || rateValue != 0)" @click="addReview()"
              class="primary-button" id="addReview"><vd-component-param type="label5"
                v-html="i18n($attrs['label5'])"></vd-component-param></button>
            <button type="button" disabled
              v-if="(enablePostButton && (comment =='' && rateValue == 0)) || (!enablePostButton && (comment =='' && rateValue == 0)) || (!enablePostButton && (comment !='' || rateValue != 0))"
              class="primary-button disabled-button">
              <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param> </button>       
            </div>          
            
          </form>
        </div>
        </div>
      </div>
    </div>
  
</section>
  </vd-component>
  `,
  };
  
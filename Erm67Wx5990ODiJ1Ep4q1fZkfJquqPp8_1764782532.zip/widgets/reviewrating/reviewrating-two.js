let {
    validateToken,
    getReviewRating,
    SaveContentReview,
    categorizedPermalink,
    getContentReviewRatingSettingsDetails,
    getEndUserRegdLoginSetting
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
// let { getLocale } = await import(window.importAssetJs('js/web-service-url.js'));
export default {
    name: 'reviewrating_two',

    data() {
        return {
            contentUuid: permalink,//window.location.pathname.toString().split("/")[2],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            reviewedData: [],
            enablePostButton: true,
            user: JSON.parse(localStorage.getItem('user')),
            isLogedIn: localStorage.getItem('isloggedin'),
            loadMoreSize: 0,
            totalSize: 2,
            rateValue: 0,
            comment: '',
            contentObj: {},
            showReviewSection: false,
            reviewRatingSettings: {
                is_rating_enabled: false,
                is_comment_enabled: false,
            },
            isNextPageCallReqd: true,
            page: 1,
            // languageCode: getLocale(),
            multiProfileIsEnable: false,
            endUserProfile: JSON.parse(localStorage.getItem('multiprofileIdClicked'))
            // languageCode:getLocale()


        };
    },
    created() {
        // console.log("created in player page .................");
        // this.eventBus.on('emitOnlyId', (data) => {
        //     this.newId = data
        //     console.log(this.newId)
        // })

    },
    beforeMount() {
        validateToken().then((data) => {
            if ((data.data['ip'].indexOf(',') > -1)) {
                let strIp = data.data['ip'].split(',');
                this.ip = strIp[0];
            } else {
                this.ip = data.data['ip'];
            }
            this.email = data.data['email'];
        });

    },

    mounted() {
        this.isMultiProfileEnabled();
        scrollLoad = true; //@ER: 74207
        this.getContentReviewRatingSettingsDetails();
        this.loadMore();

        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    JsLoadingOverlay.hide();

                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        console.log("Pithan-----", content);
                        if ((content.permalink_type == "content" || content.is_playlist == 1) && content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    });
                    if (findContentParentIndex > -1) {
                        this.contentObj = res.data.data.contentList.content_list[findContentParentIndex];
                        this.contentUuid = this.contentObj.content_uuid;
                        console.log("ssssssssssss---" + this.contentUuid);
                        // if(this.contentObj.is_playlist==1 || window.location.pathname.toString().split("/")[1]=='player'){
                        this.getReviewRating(this.contentUuid, this.page, false);
                        this.showReviewSection = true;
                        // }
                    }
                } else {
                    this.getReviewRating(this.contentUuid, this.page, false);
                    this.showReviewSection = true;
                }
            });

        }

    },

    methods: {
        i18n,
        getReviewRating(contentUuid, page, onScroll) {
            // console.log(this.isNextPageCallReqd+"page--------------------------"+this.page);
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                    // JsLoadingOverlay.show();
                    getReviewRating(contentUuid, page).then((res) => {
                        JsLoadingOverlay.hide();
                        if (res.data.code === 200 && res.data.status === "SUCCESS") {

                            if (!onScroll && res.data.code == 200 && res.data.data.contentReviewsList.content_reviews_list) {
                                this.reviewedData = res.data.data.contentReviewsList.content_reviews_list;
                            } else if (onScroll && res.data.code == 200 && res.data.data.contentReviewsList.content_reviews_list) {
                                this.reviewedData.push(...res.data.data.contentReviewsList.content_reviews_list);

                            }

                            if (res.data.code == 200 && this.reviewedData?.length < res.data.data.contentReviewsList.page_info.total_count) {
                                this.isNextPageCallReqd = true;
                            }

                            this.reviewedData.forEach(element => {

                                //console.log(element.end_user_uuid+"-----------------------user uuid------------------------------"+this.user.data.user_uuid);
                                if (this.user == null) {
                                    this.enablePostButton = true;
                                }

                                // console.log("review element----",element);
                                if ((!this.multiProfileIsEnable && this.user != null && element.end_user_uuid === this.user?.user_uuid && this.contentUuid == element.content_uuid) || (this.multiProfileIsEnable && this.endUserProfile != null && element.profile_uuid === this.endUserProfile?.enduser_profile_uuid && this.contentUuid == element.content_uuid)) {
                                    // console.log("enable false---------"+this.contentUuid);
                                    this.enablePostButton = false;

                                }

                            });

                        }
                    }).catch((err) => {
                        console.log(err);
                    });
            }
        },

        Reviewating: function () {
            getReviewRating(this.contentUuid, this.page).then((res) => {

                if (res.data.code === 200) {
                    this.reviewedData = res.data.data.contentReviewsList.content_reviews_list;

                }
            }).catch((err) => {
                console.log(err);
            });
        },
        ratingvalue: function (event) {
            this.rateValue = event.target.value;
        },
        commentvalue: function (event) {
            this.comment = event.target.value;
        },
        addReview() {
            if (this.isLogedIn &&
                (
                    (this.reviewRatingSettings.is_comment_enabled && this.reviewRatingSettings.is_rating_enabled && (this.rateValue || this.comment)) ||
                    (this.reviewRatingSettings.is_comment_enabled && !this.reviewRatingSettings.is_rating_enabled && !this.rateValue && this.comment) ||
                    (!this.reviewRatingSettings.is_comment_enabled && this.reviewRatingSettings.is_rating_enabled && this.rateValue && !this.comment)
                )
            ) {
                // if(this.isLogedIn && 
                //         (
                //         (this.rateValue && this.comment)
                //         )
                //     ){
                let rating_data = this.rateValue;
                let comment_data = this.comment;

                const param = {
                    "app_token": ":app_token",
                    "product_key": ":product_key",
                    "store_key": ":store_key",
                    "end_user_uuid": ":me",
                    "content_uuid": this.contentUuid,
                    "rating": rating_data,
                    "comment": comment_data,
                    "profile_uuid": ":profile_uuid"
                };
                SaveContentReview(param).then(res => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        Toast.fire({
                            icon: 'success',
                            text: i18n(res.data.message),
                        });
                        window.location.reload();
                        this.Reviewating();
                        this.rateValue = 0;
                        this.comment = '';

                    } else {
                        Toast.fire({
                            icon: 'error',
                            text: i18n(res.data.message),
                        });
                    }
                });
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-up";
            }
        },
        getContentReviewRatingSettingsDetails() {
            getContentReviewRatingSettingsDetails().then(res => {
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    if (res.data.data.contentSettings.content_like_and_review_settings != null) {
                        this.reviewRatingSettings = res.data.data.contentSettings.content_like_and_review_settings;
                    }
                }
            });
        },
        loadMore() {
            window.onscroll = () => {
                let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight + 20 >= document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);

                if (bottomOfWindow && this.isNextPageCallReqd && this.showReviewSection && scrollLoad) {
                    this.page++;
                    this.getReviewRating(this.contentUuid, this.page, true);
                }
            };
        },
        async isMultiProfileEnabled() {
            const res = await getEndUserRegdLoginSetting();
            console.log("getEndUserRegdLoginSetting", res);
            if (res.data.code == 200 && res.data.data !== null) {
                if (res.data.data.sections[0].groups[0].nodes[2].node_value == 1) {
                    this.multiProfileIsEnable = true;
                    console.log("this.multiProfileIsEnable", this.multiProfileIsEnable);
                }
            }
        }

    },
    template: `
    <vd-component class="vd reviewrating-two" type="reviewrating-two">
        <!--Ratings & Review Start Here-->
        <section class="product-listing custom-prevNext-btn recommended-music" v-if="showReviewSection" >
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 plr-88">
                        <div class="review">
                            <h3 vd-readonly="true" v-if="reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled" class="sub-heading white-color mb-0 rating-heading"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h3>
                            <h3 vd-readonly="true" v-else-if="reviewRatingSettings.is_rating_enabled" class="sub-heading white-color mb-0 rating-heading"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></h3>
                            <h3 vd-readonly="true" v-else-if="reviewRatingSettings.is_comment_enabled" class="sub-heading white-color mb-0 rating-heading"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h3>
                            <!--Loop Div Here  v-for="data in reviewedData"-->
                            <template  v-for="data in reviewedData">
                                <div class="review-box" v-if="!(!reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled && data.rating<=0) && (!(reviewRatingSettings.is_comment_enabled && !reviewRatingSettings.is_rating_enabled && data.comment=='')) && !data.is_disabled">
                                    <div class="comment-data">
                                        <ul v-if="reviewRatingSettings.is_rating_enabled && data.rating>0">
                                            <li><i class="fa fa-star" v-for="(isdata,index) in data.rating"></i></li>
                                        </ul>
                                        <h4 v-if="!(!reviewRatingSettings.is_comment_enabled && reviewRatingSettings.is_rating_enabled && data.rating<=0) && (!(reviewRatingSettings.is_comment_enabled && !reviewRatingSettings.is_rating_enabled && data.comment==''))">{{multiProfileIsEnable? data.profile_name :data.end_user_name}}</h4>
                                        <p v-if="reviewRatingSettings.is_comment_enabled">{{data.comment}}</p>
                                    </div>
                                </div>
                            </template>
                            <!--Loop Div End Here-->
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 plr-88" v-if="reviewRatingSettings.is_comment_enabled || reviewRatingSettings.is_rating_enabled">
                        <div class="sign-form-layout rating-box ml-0">
                            <h3 v-if="reviewRatingSettings.is_comment_enabled" class="sub-heading white-color comment-box-heading"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h3>
                            <form action="" method="" class="" id="">
                                <div class="form-group mb-1" v-if="reviewRatingSettings.is_rating_enabled">
                                    <label vd-node="text" vd-readonly="true" ><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></label>
                                    <div class="rating" >
                                        <input id="rating-5" @change="ratingvalue($event)" type="radio" name="rating" value="5" /><label for="rating-5"><i class="fa fa-star"></i></label>
                                        <input id="rating-4" @change="ratingvalue($event)" type="radio" name="rating" value="4" /><label for="rating-4"><i class="fa fa-star"></i></label>
                                        <input id="rating-3" @change="ratingvalue($event)" type="radio" name="rating" value="3" /><label for="rating-3"><i class="fa fa-star"></i></label>
                                        <input id="rating-2" @change="ratingvalue($event)" type="radio" name="rating" value="2" /><label for="rating-2"><i class="fa fa-star"></i></label>
                                        <input id="rating-1" @change="ratingvalue($event)" type="radio" name="rating" value="1" /><label for="rating-1"><i class="fa fa-star"></i></label>
                                    </div>
                                </div>
                                <div class="form-group" v-if="reviewRatingSettings.is_comment_enabled">
                                    <label vd-node="text" vd-readonly="true" ><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></label>
                                    <textarea rows="4" v-model="comment" @keyup="commentvalue($event)" class="form-control"></textarea>
                                </div>
                                <div class="form-group" > 
                                    <button type="button" v-if="enablePostButton && (comment !='' || rateValue != 0)" @click="addReview()" class="primary-button btn-solid"  ><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></button>
                                    <button type="button" disabled v-if="(enablePostButton && (comment =='' && rateValue == 0)) || (!enablePostButton && (comment =='' && rateValue == 0)) || (!enablePostButton && (comment !='' || rateValue != 0))" class="primary-button btn-solid disabled-button"> <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param> </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </vd-component>
    `
};

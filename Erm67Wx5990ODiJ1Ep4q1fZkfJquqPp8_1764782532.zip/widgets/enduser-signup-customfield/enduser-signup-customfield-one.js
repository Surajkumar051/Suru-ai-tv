//Sai
let {
    getFormSchema,
    getEndUserRegdLoginSetting
} = await import(window.importAssetJs('js/webservices.js'));

export default {
    name: "enduser_signup_customfield_one",

    data() {
        return {
            input: {
                customField:""
            },
            customFieldPayload:{
                "form_name":""
            },
            isCustomisedFormEnabled: false
        };
    },

    async mounted() {
        this.fetchFormSchema();

        setTimeout(() => {
            $(".selectpicker").selectpicker();
            $(".selectpicker").selectpicker("refresh");
        }, 2000);
        let regLogRes = await getEndUserRegdLoginSetting();
        if (regLogRes.data.code === 200 && regLogRes.data.data !== null) {
          const customisedForm = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[4].node_value);
          if (customisedForm == 1) {
            this.isCustomisedFormEnabled = true;
          }
        }
    },

    updated(){
        $(".selectpicker").selectpicker("refresh");
    },
    
    methods: {
        fetchFormSchema(){
            this.customFieldPayload.form_name = "registration";
            getFormSchema(this.customFieldPayload).then(res=>{
                if (res.data.status === "SUCCESS") {
                    this.formSchema = res.data.data;
                    this.createCustomForm();
                }else{
                    this.formSchema = [];
                }
            });
        },
        createCustomForm() {
            this.formSchema.forEach(schemaElement => {
              var isRequired = this.checkIsRequired(schemaElement);
              var options = this.getOptionValue(schemaElement);
                switch(schemaElement.field) {
                    case 'Text Field':
                        $('#customField').append('<div class="form-group vd-form"><label class="form-label">'+schemaElement.name+'</label><input type="text" class="form-control" id="'+schemaElement.input+'" placeholder="'+schemaElement.placeholder+'"></div>');
                      break;
                    case 'Text Area':
                        $('#customField').append('<div class="form-group vd-form"><label class="form-label">'+schemaElement.name+'</label><input type="text" class="form-control" id="'+schemaElement.input+'" placeholder="'+schemaElement.placeholder+'"></div>');
                      break;
                    case 'Checkbox':
                        $('#customField').append('<div class="form-group vd-form"><label class="form-label">'+schemaElement.name+'</label><div class="cf-checkboxes" id="'+schemaElement.input+'"></div></div>');
                        options.forEach(optionElement => {
                            $('#'+schemaElement.input).append('<div class="d-flex align-items-center"><div class="checkbox-button mr-2"><input type="checkbox" name='+schemaElement.name+' value="'+optionElement.option_value+'" id="'+optionElement.option_value+'"><label for="'+optionElement.option_value+'" class="checkbox-label blue"></label></div><label class="cf-checkLabel" for="'+optionElement.option_value+'">'+optionElement.option_label+'</label></div>');
                        });
                    break;
                    case 'Radio':
                        $('#customField').append('<div class="form-group vd-form" id="'+schemaElement.input+'"><label class="form-label">'+schemaElement.name+'</label><ul class="cf-ul w-100"></ul><div>');
                        options.forEach(optionElement => {
                            $('#'+schemaElement.input).append('<ul class="cf-ul w-100"><li class="radio-1"><input type="radio" id="'+optionElement.option_value+'" value="'+optionElement.option_value+'" name="'+schemaElement.name+'"><label for="'+optionElement.option_value+'">'+optionElement.option_label+'</label></li></ul>');
                        });
                    break;
                    case 'Dropdown':
                        $('#customField').append('<div class="form-group vd-form"><label class="form-label">'+schemaElement.name+'</label><select class="selectpicker form-control cf-select" id="'+schemaElement.input+'" placeholder="Choose"></select><div>');
                        options.forEach(optionElement => {
                            $('#'+schemaElement.input).append('<option value="0">'+optionElement.option_label+'</option>');
                        });
                    break;
                    case 'Date Picker':
                      break;
                    default:
                      // code block
                }
            });
        },
        checkIsRequired(fieldSchema) {
            return fieldSchema.is_required == 1 ? '_required' : '';
        },
        getOptionValue(fieldSchema) {
            return fieldSchema.option_schemas;
        },

        getCustomFieldData() {
            let jsonObject = {}; 
            this.formSchema.forEach(schemaElement => {
              if(schemaElement.field == 'Text Field' && $('#'+schemaElement.input).val() != '') {
                jsonObject[schemaElement.input] = $('#'+schemaElement.input).val();
              } else if (schemaElement.field == 'Text Area' && $('#'+schemaElement.input).val() != ''){
                jsonObject[schemaElement.input] = $('#'+schemaElement.input).val();
              } else if(schemaElement.field == 'Dropdown' && $('#'+schemaElement.input+' :selected').text() != ''){
                jsonObject[schemaElement.input] = $('#'+schemaElement.input+' :selected').text();
              } else if(schemaElement.field == 'Radio' && $("input[name='"+schemaElement.name+"']:checked").val() != '') {
                jsonObject[schemaElement.input] = $("input[name='"+schemaElement.name+"']:checked").val();
              } else if (schemaElement.field == 'Checkbox') {
                var selectedOptions = [];
                $("input[name='"+schemaElement.name+"']:checked").each(function() { 
                  selectedOptions.push(this.value);
                });
                jsonObject[schemaElement.input] = selectedOptions;
              } else {
                // For date picker
              }
            });
            return JSON.stringify(jsonObject);
          },
    },
    template: `
        <div id="customField" v-if="isCustomisedFormEnabled"/>
        `,
};

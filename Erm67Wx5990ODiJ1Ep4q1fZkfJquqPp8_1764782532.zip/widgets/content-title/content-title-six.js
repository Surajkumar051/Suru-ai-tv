let { getRootUrl,getLocale } = await import(window.importAssetJs('js/web-service-url.js'));
let { default: content_views_one } = await import(window.importLocalJs('widgets/content-views/content-views-one.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING, SET_PARTNER_AND_USER_PROFILE_SETTING } = await import(window.importAssetJs('js/configurations/actions.js'));

const { mapState, mapActions } = Vuex;
export default {
  name: "content_title_six",
  data() {
    return {
      rootUrl: getRootUrl(),
      contentViews: '',
      isShow: true,
      userDetails: {},
      docdetailsPageDisabledSettingsSet:false,
      docdetailsPageDisabledSettings:false,
    };
  },
  components: {
    content_views_one
  },
  async mounted() {
    var urlParams = new URLSearchParams(window.location.search);

          /*disable for VD*/
          if (urlParams.get('is_vd')) {
            $('.data').addClass("vdDisable");                    
        }
        else{
            $('.data').removeClass("vdDisable");
        }
    /*disable for VD*/
  },
  emits: [],
  props: {
    content: Object,
    userList: Array,
    // assignedArray:Array,
    isFavouriteContent: Boolean
  },
  updated() {
  },
  computed: {
    ...mapState({
      partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
    }),
  },
  watch: {
    "userList.length"(length) {
      // console.log(this.content,"watch called",this.userList)
      if (this.userList && this.userList.length > 0) {
        let indexVal = this.userList?.map(item => item.user_uuid).indexOf(this.content.content_created_by);
        if (indexVal > -1) {
          this.userDetails = this.userList[indexVal];
          console.log("this.userDetails=======", this.userDetails);
        } else {
          this.userDetails = {};
        }
      }
    },
  },
  methods: {
    timeFormating(duration) {
      if (duration !== null && duration !== undefined) {
        const cDuration = duration.replace(/^0(?:0:0?)?/, '');
        if (cDuration.length <= 5) {
          var contDuration = cDuration.replace(':', ' m ').concat(' sec');
        }
        else {
          var contDuration = cDuration.replace(':', ' h ').replace(':', ' min ').concat(' sec');
        }
        return contDuration;
      }
    },
  },
  template: `
  <vd-component type="content-title-six" class="vd content-title-six">
  <div class="data content-a">

  <div class="content-pic-div" 
        v-if="content?.user_type=='ROLE_PARTNER' && userList &&  
        partner_and_enduser_profile_settings?.partnerSettings.sections[0]?.groups[0]?.nodes[1]?.node_value" >
    <a :href="'/partner/'+content?.content_created_by" class="callByAjax">
      <img class="content-pic" :src="userDetails?.profile_image_url" alt="profile picture">
    </a>
  </div>

  <div class="content-pic-div" 
        v-else-if="content?.user_type=='ROLE_ENDUSER' && userList && 
        partner_and_enduser_profile_settings?.ugcSettings.sections[0]?.groups[1]?.nodes[4]?.node_value" >
   
    <a :href="'/user/'+content?.content_created_by" class="callByAjax">
      <img class="content-pic" :src="userDetails?.profile_image_url" alt="profile picture">
    </a>
  </div>

  <div class="content-name-div">
  <h2 vd-disable="true">
  <a v-if="content?.is_playlist==0 && (content.content_asset_type !=6 || content.is_parent==1 ||
      (content.content_asset_type == 6 && content.is_parent == 0  && !partner_and_enduser_profile_settings?.docDetailsPageDisabledSettings)) " :href="'/content/'+content.content_permalink" class="callByAjax" >
            <span vd-disable="true" v-if="content?.content_name" >{{content.content_name}} </span>
    <!-- <div class="popupMetaDetails">
                <template v-for="Details in assignedArray">
                <span vd-disable="true" v-if="content[Details.field_name]">{{content[Details.field_name]}}</span>   
                <template   v-for="customData in content.custom_field_data">
                <span vd-disable="true" v-if="Details.field_name == customData.custom_field_name">{{customData.custom_field_value}}</span>
                </template>                                 
                </template>
      </div> -->
    </a>
    <a v-else-if="content.content_asset_type == 6 && content.is_parent == 0  && partner_and_enduser_profile_settings?.docDetailsPageDisabledSettings" class="callByAjax disabled-content" >
            <span vd-disable="true" v-if="content?.content_name" >{{content.content_name}} </span>
    <!-- <div class="popupMetaDetails">
                <template v-for="Details in assignedArray">
                <span vd-disable="true" v-if="content[Details.field_name]">{{content[Details.field_name]}}</span>   
                <template   v-for="customData in content.custom_field_data">
                <span vd-disable="true" v-if="Details.field_name == customData.custom_field_name">{{customData.custom_field_value}}</span>
                </template>                                 
                </template>
      </div> -->
    </a>
    <a v-else-if="content?.is_playlist==1" :href="'/playlist/'+content.content_permalink" class="callByAjax" >
            <span vd-disable="true" v-if="content?.content_name" >{{content.content_name}}</span>
    <!-- <div class="popupMetaDetails">
                <template v-for="Details in assignedArray">
                <span vd-disable="true" v-if="content[Details.field_name]">{{content[Details.field_name]}}</span>   
                <template  v-for="customData in content.custom_field_data">
                <span vd-disable="true" v-if="Details.field_name == customData.custom_field_name">{{customData.custom_field_value}}</span>
                </template>                                 
                </template>
      </div> -->
    </a>
    
    
    <template v-else>
            <span vd-disable="true" style="cursor:pointer" v-if="content?.content_name" >{{content.content_name}}</span>
    <!-- <div class="popupMetaDetails">
            <template v-for="Details in assignedArray">
                                            <span vd-disable="true" v-if="content[Details.field_name]">{{content[Details.field_name]}}</span>   
                                            <template  v-for="customData in content.custom_field_data">
                                            <span vd-disable="true" v-if="Details.field_name == customData.custom_field_name">{{customData.custom_field_value}}</span>
                                            </template>                                 
                                            </template>
                    </div> -->
    </template>

    <div class="addto-favorites" v-if="isFavouriteContent">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" 
            @click="$emit('favourite',content)" >
                    <path d="M13.4219 3.43126C13.2124 2.94632 12.9104 2.50687 12.5328 2.13751C12.1549 1.76705 11.7093 1.47265 11.2203 1.27032C10.7132 1.05969 10.1694 0.951872 9.62031 0.953136C8.85 0.953136 8.09844 1.16407 7.44531 1.56251C7.28906 1.65782 7.14062 1.76251 7 1.87657C6.85938 1.76251 6.71094 1.65782 6.55469 1.56251C5.90156 1.16407 5.15 0.953136 4.37969 0.953136C3.825 0.953136 3.2875 1.05939 2.77969 1.27032C2.28906 1.47345 1.84687 1.76564 1.46719 2.13751C1.08906 2.50645 0.786997 2.94601 0.578125 3.43126C0.360938 3.93595 0.25 4.47189 0.25 5.02345C0.25 5.54376 0.35625 6.08595 0.567188 6.63751C0.74375 7.09845 0.996875 7.57657 1.32031 8.05939C1.83281 8.82345 2.5375 9.62032 3.4125 10.4281C4.8625 11.7672 6.29844 12.6922 6.35938 12.7297L6.72969 12.9672C6.89375 13.0719 7.10469 13.0719 7.26875 12.9672L7.63906 12.7297C7.7 12.6906 9.13437 11.7672 10.5859 10.4281C11.4609 9.62032 12.1656 8.82345 12.6781 8.05939C13.0016 7.57657 13.2562 7.09845 13.4312 6.63751C13.6422 6.08595 13.7484 5.54376 13.7484 5.02345C13.75 4.47189 13.6391 3.93595 13.4219 3.43126Z" fill="white"/>
            </svg>
    </div>
    </h2>

    <template v-if="userDetails?.name !== undefined">
        <a class="callByAjax" v-if="content?.user_type=='ROLE_PARTNER' && 
        partner_and_enduser_profile_settings?.partnerSettings.sections[0]?.groups[0]?.nodes[1]?.node_value" :href="'/partner/'+content?.content_created_by">
          <p vd-disable="true" class="truncate-text lc-one" >{{userDetails?.name}}</p>
        </a>
        <a class="callByAjax" v-else-if="content?.user_type=='ROLE_ENDUSER' &&
        partner_and_enduser_profile_settings?.ugcSettings.sections[0]?.groups[1]?.nodes[4]?.node_value ">
        <p vd-disable="true" class="truncate-text lc-one" >{{userDetails?.name}}</p>
        </a>
        <p vd-disable="true" v-else>&nbsp;</p>
    </template>
    
    
    <p vd-disable="true" v-if="content?.user_type==undefined || content?.user_type=='ROLE_ADMIN'">&nbsp;</p>
    
    
    <content_views_one :id="$attrs['id'] +'_content_views_one_1'" :content_uuid="content?.content_uuid" 
            :isPTagDesignRequired="isShow" v-if="content?.user_type=='ROLE_PARTNER' && 
            partner_and_enduser_profile_settings?.partnerSettings.sections[0]?.groups[0]?.nodes[1]?.node_value" />
    
    <content_views_one :id="$attrs['id'] +'_content_views_one_1'" :content_uuid="content?.content_uuid" 
            :isPTagDesignRequired="isShow" v-else-if="content?.user_type=='ROLE_ENDUSER' && 
            partner_and_enduser_profile_settings?.ugcSettings.sections[0]?.groups[1]?.nodes[4]?.node_value " />
    
    <p vd-disable="true" v-else>&nbsp;</p>
  </div>


</div>

</vd-component>
`,
};

let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_views_one}=await import(window.importLocalJs('widgets/content-views/content-views-one.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING, SET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS} = await import(window.importAssetJs('js/configurations/actions.js'));

const { mapState, mapActions } = Vuex;
export default {
    name: "content_title_eight",
    data() {
      return {
          rootUrl: getRootUrl(),
          contentViews: '',
          isShow:true,
          userDetails:{},
          docdetailsPageDisabledSettingsSet:false,
          docdetailsPageDisabledSettings:false,
          owlsld : $(".owl-carousel")
      }
  },
  components: {
      content_views_one
  },
  async mounted() {
        let hasMaturityRatings = false;
        if (hasMaturityRatings) {
            this.$store.dispatch(GET_MATURITY_RATINGS);
            hasMaturityRatings = true;
        }
    /*disable for VD*/
    var urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('is_vd')) {
          $('.data').addClass("vdDisable");                    
      }
      else{
          $('.data').removeClass("vdDisable");
      }
  /*disable for VD*/
     // this.$store.dispatch(GET_MATURITY_RATINGS);
      $(function () {
    

    //   Script for owl item hover effect start
      var owlsld = $(".owl-carousel");
  function owlsldClasses() {
    owlsld.each(function () {
      var total = $(this).find(".owl-item.active").length;
      $(this).find(".owl-item").removeClass("firstactiveitem");
      $(this).find(".owl-item").removeClass("lastactiveitem");
      if(!$(this).children('.owl-nav').hasClass('disabled')){
      $(this)
        .find(".owl-item.active")
        .each(function (index) {
          if (index === 0) {
            $(this).addClass("firstactiveitem");
          }
          if (index === total - 1 && total > 1) {
            $(this).addClass("lastactiveitem");
          }
        });
    }
    });
  }
  // owlsldClasses();
  owlsld.on('translated.on.carousel changed.owl.carousel initialized.owl.carousel', function (event) {
    owlsldClasses();
  });
  
  $(document).on('mouseenter mouseleave', '.owl-item', function(event) {
      
    owlsldClasses();
    const action = event.type === 'mouseenter' ? 'addClass' : 'removeClass';
    $(this).closest('.owl-carousel').find('.owl-nav button')[action]('noOverlay');
});
      //   Script for owl item hover effect End
  });

  },
  
  emits: [],
  props: {
    content: Object,
    userList:Array,
    isFavouriteContent:Boolean
    },
     
          updated(){
        $('[data-toggle="tooltip"]').tooltip({
            trigger : 'hover'
            });

         
      
  },
 

  computed: {
    ...mapState({
      partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
    maturity_rating: (state) => state.maturity_rating
    }),

    
},
  watch: {
      "userList.length"(length){
         // console.log(this.content,"watch called",this.userList)
          if(this.userList && this.userList.length>0 ){
              let indexVal =  this.userList?.map(item => item.user_uuid).indexOf(this.content.content_created_by);
              if(indexVal >-1){
                this.userDetails =  this.userList[indexVal];
              }else{
                this.userDetails = {};
              }
          }
      },
      
  },
  methods: {

  },

    template: `
   <vd-component type="content-title-eight" class="vd content-title-eight">
    
<a v-if="content?.is_playlist==0 && (content.content_asset_type !=6 || content.is_parent==1 || (content.content_asset_type == 6 && content.is_parent == 0  && !partner_and_enduser_profile_settings?.docDetailsPageDisabledSettings)) " :href="'/content/'+content.content_permalink" class="dataContents callByAjax" >
                
                <span vd-disable="true" v-if="content?.content_name " class="dataHeading">{{content.content_name}}</span>
             <div class="popupMetaDetails ">
                    <!--<span class="duration">2023</span>
                 <span class="genre1">1 season</span>
                 <span class="genre2">2h 29m</span>-->
                 <span class="mr-badge" v-if="(content?.maturity_rating && maturity_rating?.maturity_rating_list != null) && (content.is_parent==1)">{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
               </div> 
               <div v-if="content?.content_desc" class="somePara" vd-disable="true">
                {{content.content_desc}}
               </div>             
               </a>

               <a v-else-if="content?.is_playlist==1" :href="'/playlist/'+content.content_permalink"  class="dataContents callByAjax" >
                
                <span vd-disable="true" v-if="content?.content_name " class="dataHeading">{{content.content_name}}</span>
                <div class="popupMetaDetails ">
                 <!--<span class="duration">2023</span>
                 <span class="genre1">1 season</span>
                 <span class="genre2">2h 29m</span> -->
                <span class="mr-badge" v-if="(content?.maturity_rating && maturity_rating?.maturity_rating_list != null) && (content.is_parent==1)">{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
               </div>
               <div v-if="content?.content_desc && content.is_parent==1" class="somePara" vd-disable="true">
                {{content.content_desc}}
               </div>             
               </a>

                <a v-else :href="'/content/'+content.content_permalink"  class="dataContents callByAjax" >

                <span vd-disable="true" v-if="content?.content_name " class="dataHeading">{{content.content_name}}</span>
                <div class="popupMetaDetails ">
                 <!--<span class="duration">2023</span>
                 <span class="genre1">1 season</span>
                 <span class="genre2">2h 29m</span> -->
                <span class="mr-badge" v-if="(content?.maturity_rating && maturity_rating?.maturity_rating_list != null) && (content.is_parent==1)">{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
               </div>
               <div v-if="content?.content_desc && content.is_parent!=0" class="somePara" vd-disable="true">
                {{content.content_desc}}
               </div>
               </a>

    </vd-component>
    `,
};

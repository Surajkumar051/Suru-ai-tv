let {
    getContentSettingsDetails,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
    getEnduserPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_STORE_CONTENT_TYPE, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
const { mapState, mapGetters } = Vuex;

export default {
    name: "like_favourite_share_content_six",
    props: {
        contentData: Object,
        likeReviewRatingsSettingsData: Object,
        isFavouriteSettings: Boolean,
        contentUuid: "",
        isPlayList: Number,
        shareVideoText: String,
        linkText: String,
        socialText: String,
    },
    components: {
        playlist_enduser_one
    },
    data() {
        return {
            contentDetails: Object,
            likeReviewRatingsSettings: Object,
            isFavouriteEnabled: Boolean,
            isHidden: false,
            copiedText: false,
            isFavourite: 0,
            //contentUuid:"",
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            enduserPlaylist: [],
            pageNo: 1
        };
    },
    watch: {
        contentUuid(contentUuid) {
            // console.log("pithan contentUuid--------" + contentUuid);
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getContentFavouriteAction(contentUuid);
            this.getContentSettingsDetails("");
        },
        contentData(contentData) {
            // console.log("pithan contentData--------", contentData);
            this.contentDetails = contentData;
            this.getContentFavouriteAction(contentData.content_uuid);
        },
        likeReviewRatingsSettingsData(likeReviewRatingsSettingsData) {
            // console.log(
            //     "pithan likeReviewRatingsSettingsData--------",
            //     likeReviewRatingsSettingsData
            // );
            this.likeReviewRatingsSettings = likeReviewRatingsSettingsData;
        },
        show_enduser_playlist_modal(cv) {
            // console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                    // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                    // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
    },
    computed: {
        ...mapState({
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal,
            partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
        })
    },
    mounted() {},
    methods: {
		i18n,
        threeDotClick() {
            $(".playlist-modal").toggle();
        },
        closePopup() {
            this.isHidden = false;
            this.copiedText = false;
        },
        openSocialSharing() {
            this.isHidden = true;
            this.pageLink = window.location.href;
        },

        copyURL() {
            const el = document.createElement("textarea");
            el.value = window.location.href;
            el.setAttribute("readonly", "");
            el.style.position = "absolute";
            el.style.left = "-9999px";
            document.body.appendChild(el);
            const selected =
                document.getSelection().rangeCount > 0
                    ? document.getSelection().getRangeAt(0)
                    : false;
            el.select();
            document.execCommand("copy");
            document.body.removeChild(el);
            if (selected) {
                document.getSelection().removeAllRanges();
                document.getSelection().addRange(selected);
            }
            this.copiedText = true;
        },
        openSocialShare(type) {
            let sharing_link = window.location.href;
            if (type === "facebook") {
                window.open(
                    `https://www.facebook.com/sharer/sharer.php?u=${sharing_link}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "twitter") {
                window.open(
                    `https://twitter.com/share?text=${this.contentDetails.content_name}&url=${window.location.href}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "linkedin") {
                window.open(`
                    https://www.linkedin.com/shareArticle?mini=true&url=${sharing_link}&title=${this.contentDetails.content_name}&source={LinkedIn}`);
            } else if (type === "pinterest") {
                window.open(
                    `http://pinterest.com/pin/create/button/?url=${sharing_link}&description=${this.contentDetails.content_desc}`
                );
            } else if (type === "tumblr") {
                window.open(
                    `http://www.tumblr.com/share/link?url=${sharing_link}`
                );
            }
            // else if (type === 'link') {
            //     this.copyMessage(window.location.href);
            //     // this.toastr.info('Link copied to clipboard');
            // }
        },

        likeEvent(event, likeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: likeStatus,
                    profile_uuid: ":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );
                        // this.contentDetails.like_status = 1;
                        //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                    }
                });
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-up";
            }
        },
        dislikeEvent(event, dislikeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: dislikeStatus,
                    profile_uuid: ":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );

                        // this.contentDetails.total_dislikes_count++;
                        // if(this.contentDetails.like_status == 1){
                        //     this.contentDetails.total_likes_count--;
                        // }
                        // this.contentDetails.like_status = 0;
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        favouriteEvent(contentDetails) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: contentDetails.content_uuid,
                    is_favourite: this.isFavourite == 0 ? 1 : 0,
                    profile_uuid: ":profile_uuid",
                };
                makeContentFavorite(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentFavouriteAction(
                            contentDetails.content_uuid
                        );
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite =
                        res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },

        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                }
            });
        },
        async playlistEvent(contentDetails) {
            // console.log('contentDetails', contentDetails);
            if (this.isLogedIn) {
                JsLoader.show();
                try {
                    await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                    this.contentDetails.page = this.pageNo;
                    await this.$store.dispatch(GET_ENDUSER_PLAYLIST, contentDetails);
                    await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                } catch (error) {
                    console.error("Something went wrong!", error.message);
                    Toast.fire({
                        icon: "info",
                        title: 'Something went wrong!',
                        text: error.message,
                    });
                }
                JsLoader.hide();
            } else {
                window.location.href = "/sign-in";
            }
        },
        getNodeValueByCode(config_data, code) {
            const node = config_data?.sections
                .flatMap(section => section.groups.flatMap(group => group.nodes))
                .find(node => node.node_code === code);
            return node && parseInt(node.node_value) ? (node.node_value) : null;
        }
    },
    template: `




<vd-component class="vd like-favourite-share-content-six" type="like-favourite-share-content-six">
<ul class="social-share">
<li v-if="likeReviewRatingsSettings?.is_like_enabled">
        <a vd-readonly="true" vd-node="dynButton" class="callByAjax social-share-li" :class="contentDetails.like_status==1?'liked callByAjax':'callByAjax'" href="javascript:void(0);" @click="likeEvent($event,contentDetails.like_status==1?0:1,contentDetails.content_uuid)" data-toggle="tooltip" data-placement="top" :title="i18n('Like')">
                <i class="fa-thumbs-up far"/>
        </a>
        <span vd-readonly="true" v-if="likeReviewRatingsSettings?.is_like_count_enabled">{{contentDetails.total_likes_count}}</span>
</li>
<li v-if="likeReviewRatingsSettings?.is_dislike_enabled">
        <a vd-readonly="true" vd-node="dynButton" class="callByAjax social-share-li" :class="contentDetails.like_status==2?'liked callByAjax':'callByAjax'" href="javascript:void(0);" @click="dislikeEvent($event,contentDetails.like_status==2?0:2,contentDetails.content_uuid)" data-toggle="tooltip" data-placement="top" :title="i18n('Dislike')">
                <i class="fa-thumbs-down far" />
        </a>
        <span vd-readonly="true" v-if="likeReviewRatingsSettings?.is_dislike_count_enabled">{{contentDetails.total_dislikes_count}}</span>
</li>
<li   v-if="isFavouriteSettings">
        <a vd-readonly="true" vd-node="dynButton" class="callByAjax social-share-li" :class="isFavourite==1?'liked callByAjax':'callByAjax'" href="javascript:void(0);" @click="favouriteEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Favorite')" :data-original-title="i18n('Add to Favorites')">
                <i class="fa-heart far" />
        </a>
</li>
<li v-if ="contentDetails.content_name != null && contentDetails.content_name != ''" class="social-share-all">
        <a vd-readonly="true" vd-node="dynButton" class="callByAjax social-share-li" id="social-share-popup" href="javascript:void(0);" data-toggle="tooltip" data-placement="top" :title="i18n('Share')"  @click="openSocialSharing()">
                <i class="fa fa-share-alt"/>
        </a>
        <div class="share-video share_content" v-if="isHidden">
                <div class="heading">
                        <h4>
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.9561 0.662598C13.9332 0.712545 13.9016 0.758044 13.8628 0.796998L5.03906 9.61886L7.53106 13.7731C7.57521 13.847 7.63893 13.9072 7.71517 13.9472C7.79142 13.9871 7.87722 14.0052 7.96309 13.9994C8.04896 13.9936 8.13156 13.9641 8.20174 13.9143C8.27193 13.8645 8.32698 13.7963 8.3608 13.7171L13.9561 0.662598Z" fill="white"/>
                                <path d="M4.38059 8.95999L0.226323 6.46613C0.152441 6.42198 0.0922065 6.35826 0.0522792 6.28202C0.0123518 6.20577 -0.00571274 6.11997 8.28447e-05 6.0341C0.00587843 5.94823 0.0353084 5.86563 0.0851187 5.79544C0.134929 5.72526 0.203179 5.67021 0.282323 5.63639L13.3397 0.0419922C13.289 0.0650345 13.2428 0.0969598 13.2034 0.136259L4.38059 8.95999Z" fill="white"/>
                            </svg>
                            <vd-component-param type="label7">{{ i18n(shareVideoText) }}</vd-component-param>
                        </h4>
                        <span>
                            <a href="javascript:void(0);" @click="closePopup()" class="close callByAjax" id="close-share">
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0.696802 0.873186L0.778927 0.778686C0.921789 0.635791 1.11119 0.548909 1.31269 0.533838C1.51418 0.518767 1.7144 0.576508 1.87693 0.696561L1.97143 0.778686L7.00018 5.80631L12.0289 0.777561C12.1068 0.697012 12.1999 0.632778 12.3029 0.588607C12.4059 0.544436 12.5166 0.521212 12.6286 0.520292C12.7406 0.519372 12.8517 0.540773 12.9554 0.583246C13.0591 0.625719 13.1533 0.688415 13.2324 0.767674C13.3116 0.846933 13.3742 0.941168 13.4166 1.04488C13.459 1.14859 13.4803 1.25971 13.4793 1.37174C13.4782 1.48377 13.4549 1.59448 13.4106 1.6974C13.3664 1.80032 13.302 1.89339 13.2214 1.97119L8.1938 6.99994L13.2226 12.0287C13.3653 12.1717 13.452 12.3612 13.4668 12.5627C13.4817 12.7641 13.4237 12.9643 13.3036 13.1267L13.2214 13.2212C13.0786 13.3641 12.8892 13.451 12.6877 13.466C12.4862 13.4811 12.286 13.4234 12.1234 13.3033L12.0289 13.2212L7.00018 8.19356L1.97143 13.2223C1.81222 13.3759 1.59905 13.4609 1.37782 13.4589C1.15659 13.4568 0.945009 13.368 0.788644 13.2115C0.632279 13.055 0.543642 12.8433 0.541825 12.6221C0.540007 12.4008 0.625155 12.1877 0.778927 12.0287L5.80655 6.99994L0.777802 1.97119C0.635076 1.82818 0.548402 1.63871 0.533538 1.43722C0.518673 1.23572 0.576606 1.03558 0.696802 0.873186L0.778927 0.778686L0.696802 0.873186Z" fill="white"/>
                                </svg>
                            </a>
                        </span>
                </div>
                <div class="content">
                        <p>
                            <vd-component-param type="label8">{{ i18n(linkText) }}</vd-component-param>
                        </p>
                        <input type="text" class="form-control" v-model="pageLink" ref="mylink" readonlyid=""/>
                        <span class="player_shareicon" v-if="!copiedText">
                            <i class="fas fa-link" @click="copyURL()"/>
                        </span>
                        <span v-if="copiedText">
                                <i class="fas fa-check"/>
                        </span>
                </div>
                <div class="bottom">
                    <h6>
                        <vd-component-param type="label9">{{ i18n(socialText) }}</vd-component-param>
                    </h6>
                    <ul>
                            <li class="share_icon">
                                    <a href="Javascript:void(0);" class="callByAjax">
                                            <svg width="11" height="21" @click="openSocialShare('facebook')" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5858 0.0043694L7.94737 0C4.98322 0 3.06766 2.02849 3.06766 5.16813V7.55098H0.414863C0.18563 7.55098 0 7.7428 0 7.9794V11.4319C0 11.6685 0.185842 11.8601 0.414863 11.8601H3.06766V20.5718C3.06766 20.8084 3.25329 21 3.48252 21H6.94366C7.17289 21 7.35852 20.8082 7.35852 20.5718V11.8601H10.4603C10.6895 11.8601 10.8751 11.6685 10.8751 11.4319L10.8764 7.9794C10.8764 7.8658 10.8326 7.757 10.7549 7.6766C10.6772 7.5962 10.5714 7.55098 10.4613 7.55098H7.35852V5.53101C7.35852 4.56013 7.58267 4.06726 8.808 4.06726L10.5853 4.0666C10.8144 4.0666 11 3.87479 11 3.6384V0.432571C11 0.196405 10.8146 0.00480634 10.5858 0.0043694Z" fill="white"/>
                                            </svg>
                                    </a>
                            </li>
                            <li class="share_icon">
                                    <a href="Javascript:void(0);" class="callByAjax">
                                            <svg width="24" height="24" @click="openSocialShare('twitter')" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M23 7.11613C22.1819 7.475 21.3101 7.71288 20.4013 7.82838C21.3363 7.27013 22.0499 6.39287 22.3854 5.3355C21.5136 5.85525 20.5511 6.22238 19.5254 6.42725C18.6976 5.54588 17.5179 5 16.2309 5C13.7339 5 11.7236 7.02675 11.7236 9.51137C11.7236 9.86887 11.7539 10.2126 11.8281 10.5399C8.0785 10.357 4.76062 8.55987 2.53175 5.82225C2.14262 6.49738 1.91438 7.27012 1.91438 8.102C1.91438 9.664 2.71875 11.0486 3.91775 11.8502C3.19312 11.8365 2.48225 11.6261 1.88 11.2948C1.88 11.3085 1.88 11.3264 1.88 11.3443C1.88 13.536 3.44338 15.3565 5.4935 15.7759C5.12638 15.8763 4.72625 15.9244 4.311 15.9244C4.02225 15.9244 3.73075 15.9079 3.45712 15.8474C4.0415 17.6335 5.69975 18.9466 7.6715 18.9893C6.137 20.1896 4.18863 20.9129 2.07938 20.9129C1.7095 20.9129 1.35475 20.8964 1 20.851C2.99787 22.1394 5.36563 22.875 7.919 22.875C16.2185 22.875 20.756 16 20.756 10.0408C20.756 9.84138 20.7491 9.64887 20.7395 9.45775C21.6346 8.8225 22.3867 8.02913 23 7.11613Z" fill="white"/>
                                            </svg>
                                    </a>
                            </li>
                          
                            <li class="share_icon">
                                    <a href="Javascript:void(0);" class="callByAjax">
                                            <svg width="18" height="18" @click="openSocialShare('tumblr')" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M3.47231 0C1.54859 0 0 1.54859 0 3.47231V14.5277C0 16.4514 1.54859 18 3.47231 18H14.5277C16.4514 18 18 16.4514 18 14.5277V3.47231C18 1.54859 16.4514 0 14.5277 0H3.47231ZM7.82887 2.54531H9.61312V5.71669H12.591V7.68658H9.61312V10.9041C9.61312 11.6313 9.65174 12.0985 9.729 12.3053C9.80581 12.5116 9.94946 12.6764 10.1587 12.7997C10.4364 12.9661 10.7535 13.0495 11.1111 13.0495C11.7461 13.0495 12.3781 12.8427 13.0067 12.4296V14.4085C12.4703 14.661 11.9853 14.839 11.5509 14.9406C11.1161 15.0422 10.646 15.093 10.1407 15.093C9.56741 15.093 9.05998 15.02 8.61919 14.8753C8.17843 14.7303 7.80275 14.5236 7.49138 14.256C7.18 13.9876 6.96404 13.7026 6.84394 13.4005C6.7237 13.0987 6.66394 12.6609 6.66394 12.0876V7.68659H5.27681V5.91079C5.76961 5.7506 6.19247 5.52155 6.54356 5.22229C6.89519 4.92347 7.17701 4.56437 7.38956 4.14509C7.60241 3.7262 7.74889 3.19252 7.82887 2.54534V2.54531Z" fill="white"/>
                                            </svg>
                                    </a>
                            </li>
                            <li class="share_icon">
                                    <a href="Javascript:void(0);" class="callByAjax">
                                            <svg width="20" height="20" @click="openSocialShare('linkedin')" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0.833008 2.36492C0.833008 1.9587 0.99438 1.56911 1.28162 1.28187C1.56887 0.994626 1.95845 0.833254 2.36467 0.833254H17.633C17.8343 0.832925 18.0337 0.872306 18.2198 0.949143C18.4059 1.02598 18.575 1.13876 18.7174 1.28103C18.8598 1.42331 18.9728 1.59227 19.0498 1.77826C19.1269 1.96425 19.1665 2.16361 19.1663 2.36492V17.6333C19.1666 17.8346 19.1271 18.034 19.0501 18.2201C18.9732 18.4062 18.8604 18.5753 18.718 18.7177C18.5757 18.8601 18.4067 18.973 18.2206 19.0501C18.0346 19.1271 17.8352 19.1667 17.6338 19.1666H2.36467C2.16346 19.1666 1.96422 19.1269 1.77834 19.0499C1.59245 18.9729 1.42357 18.86 1.28133 18.7177C1.13909 18.5754 1.02628 18.4064 0.94936 18.2205C0.872436 18.0346 0.832899 17.8353 0.833008 17.6341V2.36492ZM8.08967 7.82325H10.5722V9.06992C10.9305 8.35325 11.8472 7.70825 13.2247 7.70825C15.8655 7.70825 16.4913 9.13575 16.4913 11.7549V16.6066H13.8188V12.3516C13.8188 10.8599 13.4605 10.0183 12.5505 10.0183C11.288 10.0183 10.763 10.9258 10.763 12.3516V16.6066H8.08967V7.82325ZM3.50634 16.4924H6.17967V7.70825H3.50634V16.4916V16.4924ZM6.56217 4.84325C6.56721 5.07215 6.52648 5.29974 6.44237 5.51268C6.35826 5.72562 6.23247 5.91962 6.07237 6.08328C5.91227 6.24694 5.72109 6.37698 5.51005 6.46576C5.29902 6.55454 5.07237 6.60027 4.84342 6.60027C4.61448 6.60027 4.38783 6.55454 4.1768 6.46576C3.96576 6.37698 3.77458 6.24694 3.61448 6.08328C3.45438 5.91962 3.32859 5.72562 3.24447 5.51268C3.16036 5.29974 3.11963 5.07215 3.12467 4.84325C3.13457 4.39397 3.32 3.96641 3.64125 3.65216C3.9625 3.3379 4.39403 3.16194 4.84342 3.16194C5.29282 3.16194 5.72435 3.3379 6.0456 3.65216C6.36685 3.96641 6.55228 4.39397 6.56217 4.84325Z" fill="white"/>
                                            </svg>
                                    </a>
                            </li>
                            <li v-if="contentDetails.content_asset_type == 2 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null  && contentDetails.content_asset_uuid != '' &&
                            contentDetails.audio_details != null && 
                            (contentDetails.audio_details.encoding_status =='completed' || contentDetails.audio_details.encoding_status == null))">
                                <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
                                    <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
                                </svg>
                                </a>
                            </li>
                            <li v-if="contentDetails.content_asset_type == 1 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null && contentDetails.content_asset_uuid != '' &&
                            contentDetails.video_details != null && 
                            ((!contentDetails.video_details.is_feed && (contentDetails.video_details.encoding_status =='completed' || contentDetails.video_details.encoding_status == null)) || contentDetails.video_details.is_feed))">
                                <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
                                    <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
                                </svg>
                                </a>
                            </li>
                    </ul>
                </div>
        </div>
</li>

</ul>
<playlist_enduser_one :id="$attrs['id'] +'_playlist_enduser_one_1'" v-if="show_enduser_playlist_modal" :contentDetails="contentDetails" />
</vd-component>

`,
};

let { getContentSettingsDetails, getContentDetails, getChildDetails, isAuthorizedContent, getLocation, categorizedPermalink, likeDislike, makeContentFavorite, getContentFavoriteStatus, getEnduserPlaylist, } = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_views_one}=await import(window.importLocalJs('widgets/content-views/content-views-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_STORE_CONTENT_TYPE, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
const { mapState, mapGetters } = Vuex;

export default {
        name: 'like_favourite_share_content_two',
        props: {
                contentData: Object,
                likeReviewRatingsSettingsData: Object,
                likeReviewRatingsSettingsDataAvailable: Boolean,
                isFavouriteSettings: Boolean,
                contentUuid: "",
                isPlayList: 0,
                shareVideoText: String,
                linkText: String,
                socialText: String,
        },
        components: {
                content_views_one,
                playlist_enduser_one
        },
        data() {
                return {
                        contentDetails: Object,
                        likeReviewRatingsSettings: Object,
                        isFavouriteEnabled: Boolean,
                        isHidden: false,
                        copiedText: false,
                        isFavourite: 0,
                        //contentUuid:"",
                        isLogedIn: JSON.parse(localStorage.getItem('isloggedin')),
                        showViews: false,
                        enduserPlaylist: [],
                        pageNo: 1
                }
        },
        watch: {


                contentUuid(contentUuid) {
                        // console.log("pithan contentUuid--------" + contentUuid);
                        this.getContentDetailsData(contentUuid, this.isPlayList);
                        this.getContentFavouriteAction(contentUuid);
                        this.getContentSettingsDetails("");

                },
                contentData(contentData) {
                        // console.log("pithan contentData--------" + contentData);
                        this.contentDetails = contentData;
                        this.showViews = true;
                        this.getContentFavouriteAction(contentData.content_uuid);
                },
                likeReviewRatingsSettingsData(likeReviewRatingsSettingsData) {
                        // console.log("pithan likeReviewRatingsSettingsData--------" + likeReviewRatingsSettingsData);
                        this.likeReviewRatingsSettings = likeReviewRatingsSettingsData;
                },
                isFavouriteSettings(isFavouriteSettings) {
                        this.isFavouriteEnabled = isFavouriteSettings;
                },
                likeReviewRatingsSettingsDataAvailable(likeReviewRatingsSettingsDataAvailable) {
                        if (likeReviewRatingsSettingsDataAvailable) {
                                this.getContentSettingsDetails("");
                        }
                },
                show_enduser_playlist_modal(cv) {
                        // console.log('cv', cv);
                        if (cv) {
                            setTimeout(() => {
                                $('#addPlaylist').modal('show');
                                $('.modal-backdrop').css('z-index', 'initial');
                                // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                                // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                            }, 100);
                        } else {
                            $('#addPlaylist').modal('hide');
                        }
                    },
                },
        computed: {
                ...mapState({
                show_enduser_playlist_modal: state => state.show_enduser_playlist_modal,
                partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
                })
        },
        mounted() {

        },
        methods: {
                i18n,
                closePopup() {
                        this.isHidden = false;
                        this.copiedText = false;
                },
                openSocialSharing() {
                        this.isHidden = true;
                        this.pageLink = window.location.href;
                },

                copyURL() {
                        const el = document.createElement('textarea');
                        el.value = window.location.href;
                        el.setAttribute('readonly', '');
                        el.style.position = 'absolute';
                        el.style.left = '-9999px';
                        document.body.appendChild(el);
                        const selected = document.getSelection().rangeCount > 0 ? document.getSelection().getRangeAt(0) : false;
                        el.select();
                        document.execCommand('copy');
                        document.body.removeChild(el);
                        if (selected) {
                                document.getSelection().removeAllRanges();
                                document.getSelection().addRange(selected);
                        }
                        this.copiedText = true;
                },
                openSocialShare(type) {
                        let sharing_link = window.location.href;
                        if (type === 'facebook') {
                                window.open(`https://www.facebook.com/sharer/sharer.php?u=${sharing_link}`,
                                        '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
                        } else if (type === 'twitter') {
                                window.open(`https://twitter.com/share?text=${this.contentDetails.content_name}&url=${window.location.href}`, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
                        } else if (type === 'linkedin') {
                                window.open(`
                    https://www.linkedin.com/shareArticle?mini=true&url=${sharing_link}&title=${this.contentDetails.content_name}&source={LinkedIn}`);
                        } else if (type === 'pinterest') {
                                window.open(`http://pinterest.com/pin/create/button/?url=${sharing_link}&description=${this.contentDetails.content_desc}`);
                        } else if (type === 'tumblr') {
                                window.open(`http://www.tumblr.com/share/link?url=${sharing_link}`);
                        }
                        // else if (type === 'link') {
                        //     this.copyMessage(window.location.href);
                        //     // this.toastr.info('Link copied to clipboard');
                        // }
                },

                likeEvent(event, likeStatus, content_uuid) {
                        if (this.isLogedIn) {

                                const param = {
                                        "app_token": ":app_token",
                                        "product_key": ":product_key",
                                        "store_key": ":store_key",
                                        "end_user_uuid": ":me",
                                        "content_uuid": content_uuid,
                                        "like_status": likeStatus,
                                        profile_uuid: ":profile_uuid",
                                };
                                likeDislike(param).then((res) => {
                                        if (res.data.code == 200 && res.data.status == "SUCCESS") {
                                                this.getContentDetailsData(param.content_uuid, this.contentDetails.is_playlist);
                                                // this.contentDetails.like_status = 1;
                                                //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                                        }
                                });
                        } else if (!this.isLogedIn) {
                                window.location.href = "/sign-up";
                        }
                },
                dislikeEvent(event, dislikeStatus, content_uuid) {
                        if (this.isLogedIn) {
                                const param = {
                                        "app_token": ":app_token",
                                        "product_key": ":product_key",
                                        "store_key": ":store_key",
                                        "end_user_uuid": ":me",
                                        "content_uuid": content_uuid,
                                        "like_status": dislikeStatus,
                                        profile_uuid: ":profile_uuid",
                                };
                                likeDislike(param).then((res) => {
                                        if (res.data.code == 200 && res.data.status == "SUCCESS") {
                                                this.getContentDetailsData(param.content_uuid, this.contentDetails.is_playlist);

                                                // this.contentDetails.total_dislikes_count++; 
                                                // if(this.contentDetails.like_status == 1){
                                                //     this.contentDetails.total_likes_count--;
                                                // }
                                                // this.contentDetails.like_status = 0;
                                        }
                                });
                        } else {
                                window.location.href = "/sign-up";
                        }
                },
                favouriteEvent(contentDetails) {
                        if (this.isLogedIn) {
                                const param = {
                                        "app_token": ":app_token",
                                        "product_key": ":product_key",
                                        "store_key": ":store_key",
                                        "end_user_uuid": ":me",
                                        "content_uuid": contentDetails.content_uuid,
                                        "is_favourite": this.isFavourite == 0 ? 1 : 0,
                                        profile_uuid: ":profile_uuid",
                                };
                                makeContentFavorite(param).then((res) => {
                                        if (res.data.code == 200 && res.data.status == "SUCCESS") {
                                                this.getContentFavouriteAction(contentDetails.content_uuid);
                                        }
                                });
                        } else {
                                window.location.href = "/sign-up";
                        }
                },
                getContentFavouriteAction(contentUuid) {
                        getContentFavoriteStatus(contentUuid).then((res) => {
                                if (res.data.code == 200 && res.data.data !== null) {
                                        this.isFavourite = res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                                } else {
                                        this.isFavourite = 0;
                                }
                        });
                },

                getContentDetailsData(content_uuid, isPlaylist) {
                        getContentDetails(content_uuid, isPlaylist).then((res) => {
                                if (res.data.code == 200 && res.data.data !== null) {
                                        this.contentDetails = res.data.data.contentList.content_list[0];
                                }
                        });
                },

                getContentSettingsDetails(structureUuid) {
                        getContentSettingsDetails(structureUuid).then((res) => {
                                if (res.data.code == 200) {

                                        this.isFavouriteEnabled = (res.data.data.contentSettings.content_favourite_settings != null) ? res.data.data.contentSettings.content_favourite_settings?.is_enabled : false;
                                        if (res.data.data.contentSettings.content_like_and_review_settings != null) {
                                                this.likeReviewRatingsSettings = res.data.data.contentSettings.content_like_and_review_settings;
                                        }

                                }
                        });
                },
                async playlistEvent(contentDetails) {
                        // console.log('contentDetails', contentDetails);
                        if (this.isLogedIn) {
                            JsLoader.show();
                            try {
                                await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                                this.contentDetails.page = this.pageNo;
                                await this.$store.dispatch(GET_ENDUSER_PLAYLIST, contentDetails);
                                await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                            } catch (error) {
                                console.error("Something went wrong!", error.message);
                                Toast.fire({
                                    icon: "info",
                                    title: 'Something went wrong!',
                                    text: error.message,
                                });
                            }
                            JsLoader.hide();
                        } else {
                            window.location.href = "/sign-in";
                        }
                    },
                    getNodeValueByCode(config_data, code) {
                        const node = config_data?.sections
                            .flatMap(section => section.groups.flatMap(group => group.nodes))
                            .find(node => node.node_code === code);
                        return node && parseInt(node.node_value) ? (node.node_value) : null;
                    }
        },
        template: `
        <vd-component class="vd like-favourite-share-content-two" type="like-favourite-share-content-two">
                        <ul class="like-it">
                                <li><content_views_one :id="$attrs['id'] +'_content_views_one_1'" :content_uuid="contentDetails.content_uuid" v-if="showViews" /></li>
                                <li v-if="likeReviewRatingsSettings?.is_like_enabled">
                                        <a vd-readonly="true" vd-node="dynButton" href="javascript:void(0);" class="callByAjax"
                                                @click="likeEvent($event,contentDetails.like_status==1?0:1,contentDetails.content_uuid)"
                                                data-toggle="tooltip" data-placement="top" title="Like">
                                                <i class="fa-thumbs-up" :class="contentDetails.like_status==1?'fas':'far'" />
                                                <span
                                                        v-if="likeReviewRatingsSettings?.is_like_count_enabled">{{contentDetails.total_likes_count}}</span>
                                        </a>

                                </li>
                                <li v-if="likeReviewRatingsSettings?.is_dislike_enabled">
                                        <a vd-readonly="true" vd-node="dynButton" href="javascript:void(0);" class="callByAjax"
                                                @click="dislikeEvent($event,contentDetails.like_status==2?0:2,contentDetails.content_uuid)"
                                                data-toggle="tooltip" data-placement="top" title="Dislike">
                                                <i class="fa-thumbs-down" :class="contentDetails.like_status==2?'fas':'far'" />
                                                <span
                                                        v-if="likeReviewRatingsSettings?.is_dislike_count_enabled">{{contentDetails.total_dislikes_count}}</span>
                                        </a>

                                </li>
                                <li v-if="isFavouriteEnabled">
                                        <a vd-readonly="true" vd-node="dynButton" class="callByAjax" href="javascript:void(0);" @click="favouriteEvent(contentDetails)" data-toggle="tooltip"
                                                data-placement="top" title="Add To Favorite" data-original-title="Add to Favorites ">
                                                <i class="fa-heart" :class="isFavourite==1?'fas':'far'" />
                                        </a>
                                </li>
                        </ul>
                        <ul class="share-list">
                                <li>
                                        <a vd-readonly="true" vd-node="dynButton" class="callByAjax" id="social-share-popup" href="javascript:void(0);" data-toggle="tooltip" data-placement="top"
                                                :title="i18n('Share')" @click="openSocialSharing()">
                                                <i class="fas fa-share-alt" /><span>{{i18n('Share')}}</span>
                                        </a>
                                        <div class="share-video" v-if="isHidden">
                                                <div class="heading">
                                                        <h4>
                                                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M13.9561 0.662598C13.9332 0.712545 13.9016 0.758044 13.8628 0.796998L5.03906 9.61886L7.53106 13.7731C7.57521 13.847 7.63893 13.9072 7.71517 13.9472C7.79142 13.9871 7.87722 14.0052 7.96309 13.9994C8.04896 13.9936 8.13156 13.9641 8.20174 13.9143C8.27193 13.8645 8.32698 13.7963 8.3608 13.7171L13.9561 0.662598Z"
                                                                                fill="white" />
                                                                        <path d="M4.38059 8.95999L0.226323 6.46613C0.152441 6.42198 0.0922065 6.35826 0.0522792 6.28202C0.0123518 6.20577 -0.00571274 6.11997 8.28447e-05 6.0341C0.00587843 5.94823 0.0353084 5.86563 0.0851187 5.79544C0.134929 5.72526 0.203179 5.67021 0.282323 5.63639L13.3397 0.0419922C13.289 0.0650345 13.2428 0.0969598 13.2034 0.136259L4.38059 8.95999Z"
                                                                                fill="white" />
                                                                </svg>
                                                                <vd-component-param type="label7">{{ i18n(shareVideoText) }}
                                                                </vd-component-param>
                                                        </h4>
                                                        <span>
                                                                <a href="javascript:void(0);" @click="closePopup()" class="close callByAjax"
                                                                        id="close-share">
                                                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                                                xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M0.696802 0.873186L0.778927 0.778686C0.921789 0.635791 1.11119 0.548909 1.31269 0.533838C1.51418 0.518767 1.7144 0.576508 1.87693 0.696561L1.97143 0.778686L7.00018 5.80631L12.0289 0.777561C12.1068 0.697012 12.1999 0.632778 12.3029 0.588607C12.4059 0.544436 12.5166 0.521212 12.6286 0.520292C12.7406 0.519372 12.8517 0.540773 12.9554 0.583246C13.0591 0.625719 13.1533 0.688415 13.2324 0.767674C13.3116 0.846933 13.3742 0.941168 13.4166 1.04488C13.459 1.14859 13.4803 1.25971 13.4793 1.37174C13.4782 1.48377 13.4549 1.59448 13.4106 1.6974C13.3664 1.80032 13.302 1.89339 13.2214 1.97119L8.1938 6.99994L13.2226 12.0287C13.3653 12.1717 13.452 12.3612 13.4668 12.5627C13.4817 12.7641 13.4237 12.9643 13.3036 13.1267L13.2214 13.2212C13.0786 13.3641 12.8892 13.451 12.6877 13.466C12.4862 13.4811 12.286 13.4234 12.1234 13.3033L12.0289 13.2212L7.00018 8.19356L1.97143 13.2223C1.81222 13.3759 1.59905 13.4609 1.37782 13.4589C1.15659 13.4568 0.945009 13.368 0.788644 13.2115C0.632279 13.055 0.543642 12.8433 0.541825 12.6221C0.540007 12.4008 0.625155 12.1877 0.778927 12.0287L5.80655 6.99994L0.777802 1.97119C0.635076 1.82818 0.548402 1.63871 0.533538 1.43722C0.518673 1.23572 0.576606 1.03558 0.696802 0.873186L0.778927 0.778686L0.696802 0.873186Z"
                                                                                        fill="white" />
                                                                        </svg>
                                                                </a>
                                                        </span>
                                                </div>
                                                <div class="content">
                                                        <p>
                                                                <vd-component-param type="label8">{{ i18n(linkText) }}
                                                                </vd-component-param>
                                                        </p>
                                                        <input type="text" class="form-control" v-model="pageLink" ref="mylink"
                                                                readonlyid="" />
                                                        <span class="link-icon" v-if="!copiedText">
                                                        <svg  @click="copyURL()"  width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M8.02953 5.97064C7.48346 5.4248 6.74297 5.11816 5.97087 5.11816C5.19877 5.11816 4.45827 5.4248 3.9122 5.97064L1.85287 8.02931C1.30678 8.57539 1 9.31603 1 10.0883C1 10.8606 1.30678 11.6012 1.85287 12.1473C2.39895 12.6934 3.13959 13.0002 3.91187 13.0002C4.68414 13.0002 5.42478 12.6934 5.97087 12.1473L7.0002 11.118" stroke="white" stroke-width="1.16667" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M5.9707 8.02929C6.51677 8.57513 7.25727 8.88177 8.02937 8.88177C8.80147 8.88177 9.54196 8.57513 10.088 8.02929L12.1474 5.97062C12.6935 5.42454 13.0002 4.6839 13.0002 3.91162C13.0002 3.13935 12.6935 2.3987 12.1474 1.85262C11.6013 1.30654 10.8606 0.999756 10.0884 0.999756C9.31609 0.999756 8.57545 1.30654 8.02937 1.85262L7.00004 2.88195" stroke="white" stroke-width="1.16667" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        </svg>
                                                               
                                                        </span>
                                                        <span class="link-icon" v-if="copiedText">
                                                                <svg xmlns="http://www.w3.org/2000/svg" id="Icon" width="20" height="20" viewBox="0 0 20 20">                                                                    <rect id="Area" width="20" height="20" fill="#fcfcfc" opacity="0"></rect>                                                                    <g id="Icon-2" data-name="Icon" transform="translate(1.29 2.499)">                                                                        <path id="Path" d="M16.667,5,7.5,14.167,3.333,10" transform="translate(-1.29 -2.499)" fill="none" stroke="#fff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.667"></path>                                                                    </g>                                                                </svg>
                                                        </span>
                                                </div>
                                                <div class="bottom">
                                                        <h6>
                                                                <vd-component-param type="label9">{{ i18n(socialText) }}
                                                                </vd-component-param>
                                                        </h6>
                                                        <ul>
                                                                <li class="share_icon">
                                                                        <a class="callByAjax" href="Javascript:void(0);">
                                                                                <svg width="11" height="21"
                                                                                        @click="openSocialShare('facebook')"
                                                                                        viewBox="0 0 11 21" fill="none"
                                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                                                                d="M10.5858 0.0043694L7.94737 0C4.98322 0 3.06766 2.02849 3.06766 5.16813V7.55098H0.414863C0.18563 7.55098 0 7.7428 0 7.9794V11.4319C0 11.6685 0.185842 11.8601 0.414863 11.8601H3.06766V20.5718C3.06766 20.8084 3.25329 21 3.48252 21H6.94366C7.17289 21 7.35852 20.8082 7.35852 20.5718V11.8601H10.4603C10.6895 11.8601 10.8751 11.6685 10.8751 11.4319L10.8764 7.9794C10.8764 7.8658 10.8326 7.757 10.7549 7.6766C10.6772 7.5962 10.5714 7.55098 10.4613 7.55098H7.35852V5.53101C7.35852 4.56013 7.58267 4.06726 8.808 4.06726L10.5853 4.0666C10.8144 4.0666 11 3.87479 11 3.6384V0.432571C11 0.196405 10.8146 0.00480634 10.5858 0.0043694Z"
                                                                                                fill="white" />
                                                                                </svg>
                                                                        </a>
                                                                </li>
                                                                <li class="share_icon">
                                                                        <a class="callByAjax" href="Javascript:void(0);">
                                                                                <svg width="24" height="24"
                                                                                        @click="openSocialShare('twitter')"
                                                                                        viewBox="0 0 24 24" fill="none"
                                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                                                                d="M23 7.11613C22.1819 7.475 21.3101 7.71288 20.4013 7.82838C21.3363 7.27013 22.0499 6.39287 22.3854 5.3355C21.5136 5.85525 20.5511 6.22238 19.5254 6.42725C18.6976 5.54588 17.5179 5 16.2309 5C13.7339 5 11.7236 7.02675 11.7236 9.51137C11.7236 9.86887 11.7539 10.2126 11.8281 10.5399C8.0785 10.357 4.76062 8.55987 2.53175 5.82225C2.14262 6.49738 1.91438 7.27012 1.91438 8.102C1.91438 9.664 2.71875 11.0486 3.91775 11.8502C3.19312 11.8365 2.48225 11.6261 1.88 11.2948C1.88 11.3085 1.88 11.3264 1.88 11.3443C1.88 13.536 3.44338 15.3565 5.4935 15.7759C5.12638 15.8763 4.72625 15.9244 4.311 15.9244C4.02225 15.9244 3.73075 15.9079 3.45712 15.8474C4.0415 17.6335 5.69975 18.9466 7.6715 18.9893C6.137 20.1896 4.18863 20.9129 2.07938 20.9129C1.7095 20.9129 1.35475 20.8964 1 20.851C2.99787 22.1394 5.36563 22.875 7.919 22.875C16.2185 22.875 20.756 16 20.756 10.0408C20.756 9.84138 20.7491 9.64887 20.7395 9.45775C21.6346 8.8225 22.3867 8.02913 23 7.11613Z"
                                                                                                fill="white" />
                                                                                </svg>
                                                                        </a>
                                                                </li>
                                                                <!--<li class="share_icon">
                                                                        <a class="callByAjax" href="Javascript:void(0);">
                                                                                <svg width="18" height="18"
                                                                                        @click="openSocialShare('pinterest')"
                                                                                        viewBox="0 0 18 18" fill="none"
                                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M0 9C0 12.8422 2.40825 16.1228 5.7975 17.4135C5.715 16.7108 5.62725 15.552 5.81625 14.739C5.979 14.04 6.867 10.2855 6.867 10.2855C6.867 10.2855 6.59925 9.74925 6.59925 8.955C6.59925 7.71 7.32075 6.78 8.22 6.78C8.985 6.78 9.354 7.35375 9.354 8.0415C9.354 8.81025 8.86425 9.95925 8.6115 11.025C8.40075 11.9167 9.05925 12.6442 9.93825 12.6442C11.5305 12.6442 12.7552 10.965 12.7552 8.541C12.7552 6.39525 11.2133 4.896 9.012 4.896C6.4635 4.896 4.96725 6.80775 4.96725 8.784C4.96725 9.55425 5.2635 10.3792 5.634 10.8285C5.66559 10.8624 5.68791 10.9039 5.69881 10.949C5.70971 10.994 5.70883 11.0411 5.69625 11.0858C5.628 11.3693 5.4765 11.9775 5.44725 12.102C5.4075 12.2655 5.3175 12.3007 5.14725 12.2213C4.02825 11.7008 3.32925 10.065 3.32925 8.751C3.32925 5.92425 5.382 3.32925 9.24825 3.32925C12.3563 3.32925 14.772 5.544 14.772 8.5035C14.772 11.5913 12.8258 14.0767 10.1227 14.0767C9.2145 14.0767 8.36175 13.6042 8.06925 13.047C8.06925 13.047 7.62 14.7585 7.51125 15.177C7.29975 15.99 6.71325 17.019 6.3495 17.6033C7.188 17.8612 8.0775 18 9 18C13.9703 18 18 13.9703 18 9C18 4.02975 13.9703 0 9 0C4.02975 0 0 4.02975 0 9Z"
                                                                                                fill="white" />
                                                                                </svg>
                                                                        </a>
                                                                </li>-->
                                                                <li class="share_icon">
                                                                        <a class="callByAjax" href="Javascript:void(0);">
                                                                                <svg width="18" height="18"
                                                                                        @click="openSocialShare('tumblr')"
                                                                                        viewBox="0 0 18 18" fill="none"
                                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M3.47231 0C1.54859 0 0 1.54859 0 3.47231V14.5277C0 16.4514 1.54859 18 3.47231 18H14.5277C16.4514 18 18 16.4514 18 14.5277V3.47231C18 1.54859 16.4514 0 14.5277 0H3.47231ZM7.82887 2.54531H9.61312V5.71669H12.591V7.68658H9.61312V10.9041C9.61312 11.6313 9.65174 12.0985 9.729 12.3053C9.80581 12.5116 9.94946 12.6764 10.1587 12.7997C10.4364 12.9661 10.7535 13.0495 11.1111 13.0495C11.7461 13.0495 12.3781 12.8427 13.0067 12.4296V14.4085C12.4703 14.661 11.9853 14.839 11.5509 14.9406C11.1161 15.0422 10.646 15.093 10.1407 15.093C9.56741 15.093 9.05998 15.02 8.61919 14.8753C8.17843 14.7303 7.80275 14.5236 7.49138 14.256C7.18 13.9876 6.96404 13.7026 6.84394 13.4005C6.7237 13.0987 6.66394 12.6609 6.66394 12.0876V7.68659H5.27681V5.91079C5.76961 5.7506 6.19247 5.52155 6.54356 5.22229C6.89519 4.92347 7.17701 4.56437 7.38956 4.14509C7.60241 3.7262 7.74889 3.19252 7.82887 2.54534V2.54531Z"
                                                                                                fill="white" />
                                                                                </svg>
                                                                        </a>
                                                                </li>
                                                                <li class="share_icon">
                                                                        <a class="callByAjax" href="Javascript:void(0);">
                                                                                <svg width="20" height="20"
                                                                                        @click="openSocialShare('linkedin')"
                                                                                        viewBox="0 0 20 20" fill="none"
                                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                                                                d="M0.833008 2.36492C0.833008 1.9587 0.99438 1.56911 1.28162 1.28187C1.56887 0.994626 1.95845 0.833254 2.36467 0.833254H17.633C17.8343 0.832925 18.0337 0.872306 18.2198 0.949143C18.4059 1.02598 18.575 1.13876 18.7174 1.28103C18.8598 1.42331 18.9728 1.59227 19.0498 1.77826C19.1269 1.96425 19.1665 2.16361 19.1663 2.36492V17.6333C19.1666 17.8346 19.1271 18.034 19.0501 18.2201C18.9732 18.4062 18.8604 18.5753 18.718 18.7177C18.5757 18.8601 18.4067 18.973 18.2206 19.0501C18.0346 19.1271 17.8352 19.1667 17.6338 19.1666H2.36467C2.16346 19.1666 1.96422 19.1269 1.77834 19.0499C1.59245 18.9729 1.42357 18.86 1.28133 18.7177C1.13909 18.5754 1.02628 18.4064 0.94936 18.2205C0.872436 18.0346 0.832899 17.8353 0.833008 17.6341V2.36492ZM8.08967 7.82325H10.5722V9.06992C10.9305 8.35325 11.8472 7.70825 13.2247 7.70825C15.8655 7.70825 16.4913 9.13575 16.4913 11.7549V16.6066H13.8188V12.3516C13.8188 10.8599 13.4605 10.0183 12.5505 10.0183C11.288 10.0183 10.763 10.9258 10.763 12.3516V16.6066H8.08967V7.82325ZM3.50634 16.4924H6.17967V7.70825H3.50634V16.4916V16.4924ZM6.56217 4.84325C6.56721 5.07215 6.52648 5.29974 6.44237 5.51268C6.35826 5.72562 6.23247 5.91962 6.07237 6.08328C5.91227 6.24694 5.72109 6.37698 5.51005 6.46576C5.29902 6.55454 5.07237 6.60027 4.84342 6.60027C4.61448 6.60027 4.38783 6.55454 4.1768 6.46576C3.96576 6.37698 3.77458 6.24694 3.61448 6.08328C3.45438 5.91962 3.32859 5.72562 3.24447 5.51268C3.16036 5.29974 3.11963 5.07215 3.12467 4.84325C3.13457 4.39397 3.32 3.96641 3.64125 3.65216C3.9625 3.3379 4.39403 3.16194 4.84342 3.16194C5.29282 3.16194 5.72435 3.3379 6.0456 3.65216C6.36685 3.96641 6.55228 4.39397 6.56217 4.84325Z"
                                                                                                fill="white" />
                                                                                </svg>
                                                                        </a>
                                                                </li>
                                                                <!--<li class="share_icon">
                                                                        <a class="callByAjax" href="Javascript:void(0);">
                                                                                <svg width="18" height="18" viewBox="0 0 18 18"
                                                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M6.93766 9C6.6901 9.0003 6.45277 9.09877 6.27772 9.27382C6.10268 9.44887 6.0042 9.6862 6.00391 9.93375C6.00391 10.4501 6.42241 10.8788 6.93766 10.8686C7.17984 10.8602 7.4093 10.7581 7.57765 10.5838C7.74601 10.4095 7.84011 10.1766 7.84011 9.93431C7.84011 9.69198 7.74601 9.45912 7.57765 9.28482C7.4093 9.11052 7.17984 9.00841 6.93766 9ZM9.01103 13.1029C9.36541 13.1029 10.5894 13.0601 11.234 12.4155C11.2758 12.3679 11.2988 12.3067 11.2988 12.2434C11.2988 12.18 11.2758 12.1189 11.234 12.0713C11.2117 12.0482 11.1849 12.0298 11.1554 12.0173C11.1258 12.0048 11.094 11.9983 11.0619 11.9983C11.0298 11.9983 10.998 12.0048 10.9684 12.0173C10.9389 12.0298 10.9121 12.0482 10.8898 12.0713C10.4927 12.4796 9.62303 12.6191 9.01103 12.6191C8.39791 12.6191 7.53953 12.4796 7.13116 12.0713C7.10882 12.0482 7.08207 12.0298 7.0525 12.0173C7.02293 12.0048 6.99114 11.9983 6.95903 11.9983C6.92692 11.9983 6.89513 12.0048 6.86557 12.0173C6.836 12.0298 6.80925 12.0482 6.78691 12.0713C6.76384 12.0936 6.7455 12.1203 6.73297 12.1499C6.72045 12.1795 6.71399 12.2113 6.71399 12.2434C6.71399 12.2755 6.72045 12.3073 6.73297 12.3368C6.7455 12.3664 6.76384 12.3932 6.78691 12.4155C7.42141 13.0489 8.64541 13.1018 9.01103 13.1018V13.1029ZM10.127 9.945C10.127 10.4603 10.5467 10.8788 11.0619 10.8788C11.5772 10.8788 11.9957 10.4501 11.9957 9.945C11.9839 9.70528 11.8804 9.47927 11.7066 9.31378C11.5327 9.14828 11.3019 9.05597 11.0619 9.05597C10.8219 9.05597 10.5911 9.14828 10.4173 9.31378C10.2434 9.47927 10.1399 9.70528 10.1282 9.945H10.127Z"
                                                                                                fill="white" />
                                                                                        <path d="M18 9C18 11.3869 17.0518 13.6761 15.364 15.364C13.6761 17.0518 11.3869 18 9 18C6.61305 18 4.32387 17.0518 2.63604 15.364C0.948212 13.6761 0 11.3869 0 9C0 6.61305 0.948212 4.32387 2.63604 2.63604C4.32387 0.948212 6.61305 0 9 0C11.3869 0 13.6761 0.948212 15.364 2.63604C17.0518 4.32387 18 6.61305 18 9ZM13.6935 7.68937C13.3391 7.68937 13.0162 7.82887 12.78 8.055C11.8789 7.41037 10.6425 6.99187 9.26888 6.93787L9.86963 4.12425L11.8249 4.54275C11.8335 4.72531 11.8954 4.90134 12.0031 5.04902C12.1108 5.19669 12.2595 5.30952 12.4307 5.37352C12.6018 5.43751 12.7881 5.44986 12.9662 5.40902C13.1444 5.36819 13.3066 5.27598 13.4328 5.14381C13.5591 5.01164 13.6437 4.84534 13.6764 4.6655C13.709 4.48567 13.6881 4.30022 13.6163 4.13214C13.5445 3.96406 13.425 3.82074 13.2725 3.71995C13.1201 3.61916 12.9414 3.56533 12.7586 3.56512C12.5838 3.56574 12.4127 3.61541 12.2647 3.70849C12.1167 3.80157 11.9979 3.93431 11.9216 4.09163L9.74137 3.63037C9.71202 3.62405 9.68171 3.62358 9.65218 3.62899C9.62264 3.63439 9.59446 3.64557 9.56925 3.66188C9.54297 3.67827 9.52066 3.7003 9.50393 3.72637C9.4872 3.75244 9.47646 3.7819 9.4725 3.81262L8.8065 6.94913C7.4115 6.99188 6.15375 7.41038 5.24025 8.06513C5.004 7.84013 4.68225 7.70062 4.329 7.70062C4.02942 7.70018 3.73876 7.80256 3.50559 7.99066C3.27241 8.17876 3.11086 8.44118 3.0479 8.73407C2.98495 9.02696 3.02442 9.33259 3.15972 9.59988C3.29502 9.86717 3.51794 10.0799 3.79125 10.2026C3.76875 10.332 3.75863 10.4614 3.75863 10.5997C3.75863 12.6191 6.111 14.2628 9.01125 14.2628C11.9104 14.2628 14.2628 12.6304 14.2628 10.5997C14.2628 10.4715 14.2515 10.332 14.2301 10.2026C14.6813 9.999 15.0041 9.53662 15.0041 9C15.0041 8.26875 14.4135 7.68937 13.6935 7.68937Z"
                                                                                                fill="white" />
                                                                                </svg>
                                                                        </a>
                                                                </li>-->
                                                        </ul>
                                                </div>
                                        </div>
                                </li>
                                <li v-if="contentDetails.content_asset_type == 2 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null  && contentDetails.content_asset_uuid != '' &&
                                contentDetails.audio_details != null && 
                                (contentDetails.audio_details.encoding_status =='completed' || contentDetails.audio_details.encoding_status == null))">
                                        <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
                                                <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
                                        </svg>
                                        </a>
                                </li>
                                <li v-if="contentDetails.content_asset_type == 1 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null && contentDetails.content_asset_uuid != '' &&
                                contentDetails.video_details != null && 
                                ((!contentDetails.video_details.is_feed && (contentDetails.video_details.encoding_status =='completed' || contentDetails.video_details.encoding_status == null)) || contentDetails.video_details.is_feed))">
                                        <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
                                                <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
                                        </svg>
                                        </a>
                                </li>
                        </ul>
                        <playlist_enduser_one :id="$attrs['id'] +'_playlist_enduser_one_1'" v-if="show_enduser_playlist_modal" :contentDetails="contentDetails" />
                </vd-component>`
}

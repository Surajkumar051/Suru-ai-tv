let {
    getContentSettingsDetails,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
    getEnduserPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_STORE_CONTENT_TYPE, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
const { mapState, mapGetters } = Vuex;

export default {
    name: "like_favourite_share_content_five",
    props: {
        contentData: Object,
        likeReviewRatingsSettingsData: Object,
        isFavouriteSettings: Boolean,
        contentUuid: "",
        isPlayList: Number,
        shareVideoText: String,
        linkText: String,
        socialText: String,
    },
    components: {
        playlist_enduser_one
    },
    data() {
        return {
            contentDetails: Object,
            likeReviewRatingsSettings: Object,
            isFavouriteEnabled: Boolean,
            isHidden: false,
            copiedText: false,
            isFavourite: 0,
            //contentUuid:"",
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            enduserPlaylist: [],
            pageNo: 1
        };
    },
    watch: {
        contentUuid(contentUuid) {
            // console.log("pithan contentUuid--------" + contentUuid);
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getContentFavouriteAction(contentUuid);
            this.getContentSettingsDetails("");
        },
        contentData(contentData) {
            // console.log("pithan contentData--------", contentData);
            this.contentDetails = contentData;
            this.getContentFavouriteAction(contentData.content_uuid);
        },
        likeReviewRatingsSettingsData(likeReviewRatingsSettingsData) {
            // console.log(
            //     "pithan likeReviewRatingsSettingsData--------",
            //     likeReviewRatingsSettingsData
            // );
            this.likeReviewRatingsSettings = likeReviewRatingsSettingsData;
        },
        show_enduser_playlist_modal(cv) {
            // console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                    // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                    // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
    },
    computed: {
        ...mapState({
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal,
            partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
        })
    },
    mounted() {},
    methods: {
        i18n,
        threeDotClick() {
            $(".playlist-modal").toggle();
        },
        closePopup() {
            this.isHidden = false;
            this.copiedText = false;
        },
        openSocialSharing() {
            this.isHidden = true;
            this.pageLink = window.location.href;
        },

        copyURL() {
            const el = document.createElement("textarea");
            el.value = window.location.href;
            el.setAttribute("readonly", "");
            el.style.position = "absolute";
            el.style.left = "-9999px";
            document.body.appendChild(el);
            const selected =
                document.getSelection().rangeCount > 0
                    ? document.getSelection().getRangeAt(0)
                    : false;
            el.select();
            document.execCommand("copy");
            document.body.removeChild(el);
            if (selected) {
                document.getSelection().removeAllRanges();
                document.getSelection().addRange(selected);
            }
            this.copiedText = true;
        },
        openSocialShare(type) {
            let sharing_link = window.location.href;
            if (type === "facebook") {
                window.open(
                    `https://www.facebook.com/sharer/sharer.php?u=${sharing_link}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "twitter") {
                window.open(
                    `https://twitter.com/share?text=${this.contentDetails.content_name}&url=${window.location.href}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "linkedin") {
                window.open(`
                    https://www.linkedin.com/shareArticle?mini=true&url=${sharing_link}&title=${this.contentDetails.content_name}&source={LinkedIn}`);
            } else if (type === "pinterest") {
                window.open(
                    `http://pinterest.com/pin/create/button/?url=${sharing_link}&description=${this.contentDetails.content_desc}`
                );
            } else if (type === "tumblr") {
                window.open(
                    `http://www.tumblr.com/share/link?url=${sharing_link}`
                );
            }
            // else if (type === 'link') {
            //     this.copyMessage(window.location.href);
            //     // this.toastr.info('Link copied to clipboard');
            // }
        },

        likeEvent(event, likeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: likeStatus,
                    profile_uuid: ":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );
                        // this.contentDetails.like_status = 1;
                        //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                    }
                });
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-in";
            }
        },
        dislikeEvent(event, dislikeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: dislikeStatus,
                    profile_uuid: ":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );

                        // this.contentDetails.total_dislikes_count++;
                        // if(this.contentDetails.like_status == 1){
                        //     this.contentDetails.total_likes_count--;
                        // }
                        // this.contentDetails.like_status = 0;
                    }
                });
            } else {
                window.location.href = "/sign-in";
            }
        },
        favouriteEvent(contentDetails) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: contentDetails.content_uuid,
                    is_favourite: this.isFavourite == 0 ? 1 : 0,
                    profile_uuid: ":profile_uuid",
                };
                makeContentFavorite(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentFavouriteAction(
                            contentDetails.content_uuid
                        );
                    }
                });
            } else {
                window.location.href = "/sign-in";
            }
        },
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite =
                        res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },

        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                }
            });
        },
        async playlistEvent(contentDetails) {
            // console.log('contentDetails', contentDetails);
            if (this.isLogedIn) {
                JsLoader.show();
                try {
                    await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                    this.contentDetails.page = this.pageNo;
                    await this.$store.dispatch(GET_ENDUSER_PLAYLIST, contentDetails);
                    await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                } catch (error) {
                    console.error("Something went wrong!", error.message);
                    Toast.fire({
                        icon: "info",
                        title: 'Something went wrong!',
                        text: error.message,
                    });
                }
                JsLoader.hide();
            } else {
                window.location.href = "/sign-in";
            }
        },
        getNodeValueByCode(config_data, code) {
            const node = config_data?.sections
                .flatMap(section => section.groups.flatMap(group => group.nodes))
                .find(node => node.node_code === code);
            return node && parseInt(node.node_value) ? (node.node_value) : null;
        }
    },
    template: `


 

<vd-component class="vd row gx-2 like-favourite-share-content-five" type="like-favourite-share-content-five">
<div class="col-auto d-none" v-if="likeReviewRatingsSettings?.is_like_enabled">
<a vd-readonly="true" vd-node="dynButton" class="callByAjax" :class="contentDetails.like_status==1?'liked':''" href="javascript:void(0);" @click="likeEvent($event,contentDetails.like_status==1?0:1,contentDetails.content_uuid)" data-toggle="tooltip" data-placement="top" title="Like">
    <div class="svg"> 
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14.0007 24.5001C13.2482 23.8328 12.3977 23.1386 11.4982 22.4001H11.4865C8.31901 19.8101 4.72918 16.8794 3.14368 13.3678C2.62278 12.2498 2.34673 11.0334 2.334 9.80009C2.33052 8.10782 3.00924 6.48557 4.21679 5.29999C5.42433 4.1144 7.05876 3.46555 8.75068 3.50009C10.1281 3.50227 11.4758 3.90035 12.6333 4.64692C13.142 4.97705 13.6022 5.37639 14.0007 5.83342C14.4014 5.37818 14.8617 4.97908 15.3692 4.64692C16.5262 3.9002 17.8736 3.5021 19.2507 3.50009C20.9426 3.46555 22.577 4.1144 23.7846 5.29999C24.9921 6.48557 25.6708 8.10782 25.6674 9.80009C25.6555 11.0354 25.3794 12.2538 24.8577 13.3736C23.2722 16.8853 19.6835 19.8148 16.516 22.4001L16.5043 22.4094C15.6037 23.1433 14.7543 23.8374 14.0018 24.5094L14.0007 24.5001ZM8.75068 5.83342C7.66394 5.81982 6.61576 6.23574 5.83401 6.99076C5.08079 7.73062 4.65982 8.74431 4.66725 9.80009C4.68056 10.699 4.88414 11.5849 5.26468 12.3994C6.01311 13.9146 7.02297 15.2858 8.24784 16.4501C9.40401 17.6168 10.734 18.7461 11.8843 19.6958C12.2028 19.9583 12.5272 20.2231 12.8515 20.4879L13.0557 20.6548C13.3672 20.9091 13.6892 21.1728 14.0007 21.4318L14.0158 21.4178L14.0228 21.4119H14.0298L14.0403 21.4038H14.0462H14.052L14.073 21.3863L14.1208 21.3478L14.129 21.3408L14.1418 21.3314H14.1488L14.1593 21.3221L14.934 20.6863L15.137 20.5194C15.4648 20.2523 15.7892 19.9874 16.1077 19.7249C17.258 18.7753 18.5892 17.6471 19.7453 16.4746C20.9704 15.3109 21.9803 13.94 22.7285 12.4251C23.1159 11.6035 23.3224 10.7083 23.3341 9.80009C23.3389 8.74757 22.9181 7.73777 22.1673 7.00009C21.3871 6.24166 20.3387 5.82232 19.2507 5.83342C17.9229 5.82214 16.6536 6.37869 15.7623 7.36292L14.0007 9.39292L12.239 7.36292C11.3478 6.37869 10.0784 5.82214 8.75068 5.83342Z" fill="url(#paint0_linear_366_3406)"/>
            <defs>
            <linearGradient id="paint0_linear_366_3406" x1="2.33398" y1="3.49878" x2="29.4094" y2="17.0115" gradientUnits="userSpaceOnUse">
            <stop stop-color="#09C6F9"/>
            <stop offset="1" stop-color="#045DE9"/>
            </linearGradient>
            </defs>
        </svg>                                      
    </div>
    <span v-if="likeReviewRatingsSettings?.is_like_count_enabled && contentDetails.total_likes_count >0">{{contentDetails.total_likes_count}}</span>
</a>
</div>

<div class="col-auto" v-if="isFavouriteSettings">
<a  vd-readonly="true" vd-node="dynButton" class="btn-border with-icon icon-only " :class="isFavourite==1?'liked callByAjax':'like-favourite-share-content-five callByAjax'" href="javascript:void(0);" @click="favouriteEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="isFavourite==1 ? 'Remove From Favorites': 'Add To Favorite'" :data-original-title="isFavourite==1 ? 'Remove From Favorites': 'Add To Favorite'">
    <div class="svg">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14.0007 24.5001C13.2482 23.8328 12.3977 23.1386 11.4982 22.4001H11.4865C8.31901 19.8101 4.72918 16.8794 3.14368 13.3678C2.62278 12.2498 2.34673 11.0334 2.334 9.80009C2.33052 8.10782 3.00924 6.48557 4.21679 5.29999C5.42433 4.1144 7.05876 3.46555 8.75068 3.50009C10.1281 3.50227 11.4758 3.90035 12.6333 4.64692C13.142 4.97705 13.6022 5.37639 14.0007 5.83342C14.4014 5.37818 14.8617 4.97908 15.3692 4.64692C16.5262 3.9002 17.8736 3.5021 19.2507 3.50009C20.9426 3.46555 22.577 4.1144 23.7846 5.29999C24.9921 6.48557 25.6708 8.10782 25.6674 9.80009C25.6555 11.0354 25.3794 12.2538 24.8577 13.3736C23.2722 16.8853 19.6835 19.8148 16.516 22.4001L16.5043 22.4094C15.6037 23.1433 14.7543 23.8374 14.0018 24.5094L14.0007 24.5001ZM8.75068 5.83342C7.66394 5.81982 6.61576 6.23574 5.83401 6.99076C5.08079 7.73062 4.65982 8.74431 4.66725 9.80009C4.68056 10.699 4.88414 11.5849 5.26468 12.3994C6.01311 13.9146 7.02297 15.2858 8.24784 16.4501C9.40401 17.6168 10.734 18.7461 11.8843 19.6958C12.2028 19.9583 12.5272 20.2231 12.8515 20.4879L13.0557 20.6548C13.3672 20.9091 13.6892 21.1728 14.0007 21.4318L14.0158 21.4178L14.0228 21.4119H14.0298L14.0403 21.4038H14.0462H14.052L14.073 21.3863L14.1208 21.3478L14.129 21.3408L14.1418 21.3314H14.1488L14.1593 21.3221L14.934 20.6863L15.137 20.5194C15.4648 20.2523 15.7892 19.9874 16.1077 19.7249C17.258 18.7753 18.5892 17.6471 19.7453 16.4746C20.9704 15.3109 21.9803 13.94 22.7285 12.4251C23.1159 11.6035 23.3224 10.7083 23.3341 9.80009C23.3389 8.74757 22.9181 7.73777 22.1673 7.00009C21.3871 6.24166 20.3387 5.82232 19.2507 5.83342C17.9229 5.82214 16.6536 6.37869 15.7623 7.36292L14.0007 9.39292L12.239 7.36292C11.3478 6.37869 10.0784 5.82214 8.75068 5.83342Z" fill="url(#paint0_linear_366_3406)"/>
            <defs>
            <linearGradient id="paint0_linear_366_3406" x1="2.33398" y1="3.49878" x2="29.4094" y2="17.0115" gradientUnits="userSpaceOnUse">
            <stop stop-color="#09C6F9"/>
            <stop offset="1" stop-color="#045DE9"/>
            </linearGradient>
            </defs>
        </svg>                                      
    </div>
</a>
</div>

<div class="col-auto position-relative" v-if ="contentDetails.content_name != null && contentDetails.content_name != ''">
<a id="social-share-popup" href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Share" @click="openSocialSharing()" class="btn-border with-icon icon-only">
    <div class="svg">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20.4162 25.6667C19.1539 25.6813 17.9573 25.1044 17.1825 24.1077C16.4077 23.111 16.1439 21.8091 16.4694 20.5893L9.16608 16.415C7.90408 17.5712 6.05421 17.8159 4.53498 17.0276C3.01575 16.2393 2.15076 14.5859 2.36951 12.8884C2.58825 11.1909 3.84413 9.81079 5.51357 9.43338C7.18301 9.05598 8.91041 9.76165 9.83808 11.2L16.4682 7.40951C16.3825 7.0854 16.337 6.75193 16.3329 6.41668C16.3162 4.46451 17.672 2.76868 19.58 2.35531C21.488 1.94193 23.4241 2.92455 24.2168 4.70858C25.0096 6.49262 24.4412 8.58811 22.8557 9.7271C21.2702 10.8661 19.1029 10.7358 17.6652 9.41501L10.4891 13.5158C10.482 13.8184 10.4397 14.1191 10.3631 14.4118L17.6652 18.585C19.0096 17.3513 21.0098 17.1609 22.5628 18.1187C24.1157 19.0766 24.8433 20.9495 24.3442 22.7045C23.8451 24.4596 22.2408 25.6694 20.4162 25.6667ZM20.4162 19.8333C19.4497 19.8333 18.6662 20.6168 18.6662 21.5833C18.6662 22.5498 19.4497 23.3333 20.4162 23.3333C21.3827 23.3333 22.1662 22.5498 22.1662 21.5833C22.1662 20.6168 21.3827 19.8333 20.4162 19.8333ZM6.41624 11.6667C5.44975 11.6667 4.66624 12.4502 4.66624 13.4167C4.66624 14.3832 5.44975 15.1667 6.41624 15.1667C7.38274 15.1667 8.16624 14.3832 8.16624 13.4167C8.16624 12.4502 7.38274 11.6667 6.41624 11.6667ZM20.4162 4.66668C19.4497 4.66668 18.6662 5.45018 18.6662 6.41668C18.6662 7.38318 19.4497 8.16668 20.4162 8.16668C21.3827 8.16668 22.1662 7.38318 22.1662 6.41668C22.1662 5.45018 21.3827 4.66668 20.4162 4.66668Z" fill="url(#paint0_linear_366_3409)"/>
            <defs>
            <linearGradient id="paint0_linear_366_3409" x1="2.33594" y1="2.26147" x2="29.596" y2="13.9" gradientUnits="userSpaceOnUse">
            <stop stop-color="#09C6F9"/>
            <stop offset="1" stop-color="#045DE9"/>
            </linearGradient>
            </defs>
        </svg>                                                                            
    </div>
  
</li>
</a>
<div class="share-video share_content" v-if="isHidden">
                <div class="heading">
                        <h4>
                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path style="fill: white;" d="M13.9561 0.662598C13.9332 0.712545 13.9016 0.758044 13.8628 0.796998L5.03906 9.61886L7.53106 13.7731C7.57521 13.847 7.63893 13.9072 7.71517 13.9472C7.79142 13.9871 7.87722 14.0052 7.96309 13.9994C8.04896 13.9936 8.13156 13.9641 8.20174 13.9143C8.27193 13.8645 8.32698 13.7963 8.3608 13.7171L13.9561 0.662598Z" fill="white"/>
                                        <path style="fill: white;"  d="M4.38059 8.95999L0.226323 6.46613C0.152441 6.42198 0.0922065 6.35826 0.0522792 6.28202C0.0123518 6.20577 -0.00571274 6.11997 8.28447e-05 6.0341C0.00587843 5.94823 0.0353084 5.86563 0.0851187 5.79544C0.134929 5.72526 0.203179 5.67021 0.282323 5.63639L13.3397 0.0419922C13.289 0.0650345 13.2428 0.0969598 13.2034 0.136259L4.38059 8.95999Z" fill="white"/>
                                </svg>
                                <vd-component-param type="label7" v-html="i18n(shareVideoText)"></vd-component-param>
                        </h4>
                        <span>
                                <a href="javascript:void(0);" @click="closePopup()" class="close callByAjax" id="close-share">
                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path style="fill: white;" d="M0.696802 0.873186L0.778927 0.778686C0.921789 0.635791 1.11119 0.548909 1.31269 0.533838C1.51418 0.518767 1.7144 0.576508 1.87693 0.696561L1.97143 0.778686L7.00018 5.80631L12.0289 0.777561C12.1068 0.697012 12.1999 0.632778 12.3029 0.588607C12.4059 0.544436 12.5166 0.521212 12.6286 0.520292C12.7406 0.519372 12.8517 0.540773 12.9554 0.583246C13.0591 0.625719 13.1533 0.688415 13.2324 0.767674C13.3116 0.846933 13.3742 0.941168 13.4166 1.04488C13.459 1.14859 13.4803 1.25971 13.4793 1.37174C13.4782 1.48377 13.4549 1.59448 13.4106 1.6974C13.3664 1.80032 13.302 1.89339 13.2214 1.97119L8.1938 6.99994L13.2226 12.0287C13.3653 12.1717 13.452 12.3612 13.4668 12.5627C13.4817 12.7641 13.4237 12.9643 13.3036 13.1267L13.2214 13.2212C13.0786 13.3641 12.8892 13.451 12.6877 13.466C12.4862 13.4811 12.286 13.4234 12.1234 13.3033L12.0289 13.2212L7.00018 8.19356L1.97143 13.2223C1.81222 13.3759 1.59905 13.4609 1.37782 13.4589C1.15659 13.4568 0.945009 13.368 0.788644 13.2115C0.632279 13.055 0.543642 12.8433 0.541825 12.6221C0.540007 12.4008 0.625155 12.1877 0.778927 12.0287L5.80655 6.99994L0.777802 1.97119C0.635076 1.82818 0.548402 1.63871 0.533538 1.43722C0.518673 1.23572 0.576606 1.03558 0.696802 0.873186L0.778927 0.778686L0.696802 0.873186Z" fill="white"/>
                                        </svg>
                                </a>
                        </span>
                </div>
                <div class="content">
                        <p>
                        <vd-component-param type="label8" v-html="i18n(linkText)"></vd-component-param>
                        </p>
                        <input type="text" class="form-control" v-model="pageLink" ref="mylink" readonlyid=""/>
                        <span v-if="!copiedText">
                                <!-- <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" @click="copyURL()">
                    <path d="M8.02953 5.97064C7.48346 5.4248 6.74297 5.11816 5.97087 5.11816C5.19877 5.11816 4.45827 5.4248 3.9122 5.97064L1.85287 8.02931C1.30678 8.57539 1 9.31603 1 10.0883C1 10.8606 1.30678 11.6012 1.85287 12.1473C2.39895 12.6934 3.13959 13.0002 3.91187 13.0002C4.68414 13.0002 5.42478 12.6934 5.97087 12.1473L7.0002 11.118" stroke="white" stroke-width="1.16667" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M5.9707 8.02929C6.51677 8.57513 7.25727 8.88177 8.02937 8.88177C8.80147 8.88177 9.54196 8.57513 10.088 8.02929L12.1474 5.97062C12.6935 5.42454 13.0002 4.6839 13.0002 3.91162C13.0002 3.13935 12.6935 2.3987 12.1474 1.85262C11.6013 1.30654 10.8606 0.999756 10.0884 0.999756C9.31609 0.999756 8.57545 1.30654 8.02937 1.85262L7.00004 2.88195" stroke="white" stroke-width="1.16667" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg> -->
                                <!-- <i class="fa fa-check" aria-hidden="true"></i> -->
                                <i class="fas fa-link" @click="copyURL()"/>
                        </span>
                        <span v-if="copiedText">
                                <i class="fas fa-check"/>
                        </span>
                </div>
                <div class="bottom">
                        <h6>
                        <vd-component-param type="label9" v-html="i18n(socialText)"></vd-component-param>
                        </h6>
                        <ul>
                                <li class="share_icon">
                                        <a href="Javascript:void(0);" class="callByAjax">
                                                <svg width="11" height="21" @click="openSocialShare('facebook')" viewBox="0 0 11 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5858 0.0043694L7.94737 0C4.98322 0 3.06766 2.02849 3.06766 5.16813V7.55098H0.414863C0.18563 7.55098 0 7.7428 0 7.9794V11.4319C0 11.6685 0.185842 11.8601 0.414863 11.8601H3.06766V20.5718C3.06766 20.8084 3.25329 21 3.48252 21H6.94366C7.17289 21 7.35852 20.8082 7.35852 20.5718V11.8601H10.4603C10.6895 11.8601 10.8751 11.6685 10.8751 11.4319L10.8764 7.9794C10.8764 7.8658 10.8326 7.757 10.7549 7.6766C10.6772 7.5962 10.5714 7.55098 10.4613 7.55098H7.35852V5.53101C7.35852 4.56013 7.58267 4.06726 8.808 4.06726L10.5853 4.0666C10.8144 4.0666 11 3.87479 11 3.6384V0.432571C11 0.196405 10.8146 0.00480634 10.5858 0.0043694Z" fill="white"/>
                                                </svg>
                                        </a>
                                </li>
                                <li class="share_icon">
                                        <a href="Javascript:void(0);" class="callByAjax">
                                                <svg width="24" height="24" @click="openSocialShare('twitter')" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M23 7.11613C22.1819 7.475 21.3101 7.71288 20.4013 7.82838C21.3363 7.27013 22.0499 6.39287 22.3854 5.3355C21.5136 5.85525 20.5511 6.22238 19.5254 6.42725C18.6976 5.54588 17.5179 5 16.2309 5C13.7339 5 11.7236 7.02675 11.7236 9.51137C11.7236 9.86887 11.7539 10.2126 11.8281 10.5399C8.0785 10.357 4.76062 8.55987 2.53175 5.82225C2.14262 6.49738 1.91438 7.27012 1.91438 8.102C1.91438 9.664 2.71875 11.0486 3.91775 11.8502C3.19312 11.8365 2.48225 11.6261 1.88 11.2948C1.88 11.3085 1.88 11.3264 1.88 11.3443C1.88 13.536 3.44338 15.3565 5.4935 15.7759C5.12638 15.8763 4.72625 15.9244 4.311 15.9244C4.02225 15.9244 3.73075 15.9079 3.45712 15.8474C4.0415 17.6335 5.69975 18.9466 7.6715 18.9893C6.137 20.1896 4.18863 20.9129 2.07938 20.9129C1.7095 20.9129 1.35475 20.8964 1 20.851C2.99787 22.1394 5.36563 22.875 7.919 22.875C16.2185 22.875 20.756 16 20.756 10.0408C20.756 9.84138 20.7491 9.64887 20.7395 9.45775C21.6346 8.8225 22.3867 8.02913 23 7.11613Z" fill="white"/>
                                                </svg>
                                        </a>
                                </li>
                                <li class="share_icon">
                                        <a href="Javascript:void(0);" class="callByAjax">
                                                <svg width="18" height="18" @click="openSocialShare('pinterest')" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M0 9C0 12.8422 2.40825 16.1228 5.7975 17.4135C5.715 16.7108 5.62725 15.552 5.81625 14.739C5.979 14.04 6.867 10.2855 6.867 10.2855C6.867 10.2855 6.59925 9.74925 6.59925 8.955C6.59925 7.71 7.32075 6.78 8.22 6.78C8.985 6.78 9.354 7.35375 9.354 8.0415C9.354 8.81025 8.86425 9.95925 8.6115 11.025C8.40075 11.9167 9.05925 12.6442 9.93825 12.6442C11.5305 12.6442 12.7552 10.965 12.7552 8.541C12.7552 6.39525 11.2133 4.896 9.012 4.896C6.4635 4.896 4.96725 6.80775 4.96725 8.784C4.96725 9.55425 5.2635 10.3792 5.634 10.8285C5.66559 10.8624 5.68791 10.9039 5.69881 10.949C5.70971 10.994 5.70883 11.0411 5.69625 11.0858C5.628 11.3693 5.4765 11.9775 5.44725 12.102C5.4075 12.2655 5.3175 12.3007 5.14725 12.2213C4.02825 11.7008 3.32925 10.065 3.32925 8.751C3.32925 5.92425 5.382 3.32925 9.24825 3.32925C12.3563 3.32925 14.772 5.544 14.772 8.5035C14.772 11.5913 12.8258 14.0767 10.1227 14.0767C9.2145 14.0767 8.36175 13.6042 8.06925 13.047C8.06925 13.047 7.62 14.7585 7.51125 15.177C7.29975 15.99 6.71325 17.019 6.3495 17.6033C7.188 17.8612 8.0775 18 9 18C13.9703 18 18 13.9703 18 9C18 4.02975 13.9703 0 9 0C4.02975 0 0 4.02975 0 9Z" fill="white"/>
                                                </svg>
                                        </a>
                                </li>
                                <li class="share_icon">
                                        <a href="Javascript:void(0);" class="callByAjax">
                                                <svg width="18" height="18" @click="openSocialShare('tumblr')" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M3.47231 0C1.54859 0 0 1.54859 0 3.47231V14.5277C0 16.4514 1.54859 18 3.47231 18H14.5277C16.4514 18 18 16.4514 18 14.5277V3.47231C18 1.54859 16.4514 0 14.5277 0H3.47231ZM7.82887 2.54531H9.61312V5.71669H12.591V7.68658H9.61312V10.9041C9.61312 11.6313 9.65174 12.0985 9.729 12.3053C9.80581 12.5116 9.94946 12.6764 10.1587 12.7997C10.4364 12.9661 10.7535 13.0495 11.1111 13.0495C11.7461 13.0495 12.3781 12.8427 13.0067 12.4296V14.4085C12.4703 14.661 11.9853 14.839 11.5509 14.9406C11.1161 15.0422 10.646 15.093 10.1407 15.093C9.56741 15.093 9.05998 15.02 8.61919 14.8753C8.17843 14.7303 7.80275 14.5236 7.49138 14.256C7.18 13.9876 6.96404 13.7026 6.84394 13.4005C6.7237 13.0987 6.66394 12.6609 6.66394 12.0876V7.68659H5.27681V5.91079C5.76961 5.7506 6.19247 5.52155 6.54356 5.22229C6.89519 4.92347 7.17701 4.56437 7.38956 4.14509C7.60241 3.7262 7.74889 3.19252 7.82887 2.54534V2.54531Z" fill="white"/>
                                                </svg>
                                        </a>
                                </li>
                                <li class="share_icon">
                                        <a href="Javascript:void(0);" class="callByAjax">
                                                <svg width="20" height="20" @click="openSocialShare('linkedin')" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0.833008 2.36492C0.833008 1.9587 0.99438 1.56911 1.28162 1.28187C1.56887 0.994626 1.95845 0.833254 2.36467 0.833254H17.633C17.8343 0.832925 18.0337 0.872306 18.2198 0.949143C18.4059 1.02598 18.575 1.13876 18.7174 1.28103C18.8598 1.42331 18.9728 1.59227 19.0498 1.77826C19.1269 1.96425 19.1665 2.16361 19.1663 2.36492V17.6333C19.1666 17.8346 19.1271 18.034 19.0501 18.2201C18.9732 18.4062 18.8604 18.5753 18.718 18.7177C18.5757 18.8601 18.4067 18.973 18.2206 19.0501C18.0346 19.1271 17.8352 19.1667 17.6338 19.1666H2.36467C2.16346 19.1666 1.96422 19.1269 1.77834 19.0499C1.59245 18.9729 1.42357 18.86 1.28133 18.7177C1.13909 18.5754 1.02628 18.4064 0.94936 18.2205C0.872436 18.0346 0.832899 17.8353 0.833008 17.6341V2.36492ZM8.08967 7.82325H10.5722V9.06992C10.9305 8.35325 11.8472 7.70825 13.2247 7.70825C15.8655 7.70825 16.4913 9.13575 16.4913 11.7549V16.6066H13.8188V12.3516C13.8188 10.8599 13.4605 10.0183 12.5505 10.0183C11.288 10.0183 10.763 10.9258 10.763 12.3516V16.6066H8.08967V7.82325ZM3.50634 16.4924H6.17967V7.70825H3.50634V16.4916V16.4924ZM6.56217 4.84325C6.56721 5.07215 6.52648 5.29974 6.44237 5.51268C6.35826 5.72562 6.23247 5.91962 6.07237 6.08328C5.91227 6.24694 5.72109 6.37698 5.51005 6.46576C5.29902 6.55454 5.07237 6.60027 4.84342 6.60027C4.61448 6.60027 4.38783 6.55454 4.1768 6.46576C3.96576 6.37698 3.77458 6.24694 3.61448 6.08328C3.45438 5.91962 3.32859 5.72562 3.24447 5.51268C3.16036 5.29974 3.11963 5.07215 3.12467 4.84325C3.13457 4.39397 3.32 3.96641 3.64125 3.65216C3.9625 3.3379 4.39403 3.16194 4.84342 3.16194C5.29282 3.16194 5.72435 3.3379 6.0456 3.65216C6.36685 3.96641 6.55228 4.39397 6.56217 4.84325Z" fill="white"/>
                                                </svg>
                                        </a>
                                </li>
                             
                        </ul>
                </div>
        </div>
</div>
    <div class="col-auto">
        <template
            v-if="contentDetails.content_asset_type == 2 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null  && contentDetails.content_asset_uuid != '' &&
                                contentDetails.audio_details != null && 
                                (contentDetails.audio_details.encoding_status =='completed' || contentDetails.audio_details.encoding_status == null))"
        >
            <a
                class="btn-border with-icon icon-only"
                href="javascript:void(0);"
                @click="playlistEvent(contentDetails)"
                data-toggle="tooltip"
                data-placement="top"
                :title="i18n('Add To Playlist')"
                :data-original-title="i18n('Add To Playlist') "
            >
                <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z"
                        fill="white"
                    ></path>
                </svg>
            </a>
        </template>
        <template
            v-if="contentDetails.content_asset_type == 1 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null && contentDetails.content_asset_uuid != '' &&
                                contentDetails.video_details != null && 
                                ((!contentDetails.video_details.is_feed && (contentDetails.video_details.encoding_status =='completed' || contentDetails.video_details.encoding_status == null)) || contentDetails.video_details.is_feed))"
        >
            <a
                class="btn-border with-icon icon-only"
                href="javascript:void(0);"
                @click="playlistEvent(contentDetails)"
                data-toggle="tooltip"
                data-placement="top"
                :title="i18n('Add To Playlist')"
                :data-original-title="i18n('Add To Playlist') "
            >
                <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z"
                        fill="white"
                    ></path>
                </svg>
            </a>
        </template>
    </div>
    <playlist_enduser_one :id="$attrs['id'] +'_playlist_enduser_one_1'" v-if="show_enduser_playlist_modal" :contentDetails="contentDetails" />
</vd-component>


`,
};

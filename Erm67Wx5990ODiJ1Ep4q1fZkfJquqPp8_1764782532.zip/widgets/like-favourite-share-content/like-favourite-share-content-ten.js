let {
    getContentSettingsDetails,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getPlayerParentPermarlinkDetails,
    getVideoDetails,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
    getEnduserPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_STORE_CONTENT_TYPE, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
const { mapState, mapGetters } = Vuex;

export default {
    name: "like_favourite_share_content_ten",
    props: {
        contentData: Object,
        likeReviewRatingsSettingsData: Object,
        isFavouriteSettings: Boolean,
        contentUuid: "",
        isPlayList: Number,
        shareVideoText: String,
        linkText: String,
        socialText: String,
        permalinkDataEmitted: Object
    },
    components: {
        playlist_enduser_one
    },
    data() {
        return {
            contentDetails: Object,
            likeReviewRatingsSettings: Object,
            isFavouriteEnabled: Boolean,
            isHidden: false,
            copiedText: false,
            isFavourite: 0,
            //contentUuid:"",
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            enduserPlaylist: [],
            pageNo: 1
        };
    },
    watch: {
        contentUuid(contentUuid) {
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getContentFavouriteAction(contentUuid);
            this.getContentSettingsDetails("");
        },
        contentData(contentData) {
            this.contentDetails = contentData;
            this.getContentFavouriteAction(contentData.content_uuid);
        },
        likeReviewRatingsSettingsData(likeReviewRatingsSettingsData) {
           
            this.likeReviewRatingsSettings = likeReviewRatingsSettingsData;
        },
        show_enduser_playlist_modal(cv) {
            // console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                    // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                    // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
    },
    computed: {
        ...mapState({
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal,
            partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
        })
    },

    mounted() {},
    methods: {
		i18n,
        threeDotClick() {
            $(".playlist-modal").toggle();
        },
        openSocialSharing() {
            this.isHidden = true;
            this.pageLink = window.location.href;
        },

        copyURL() {
            const el = document.createElement("textarea");
            el.value = window.location.href;
            // console.log('bibek',el.value)
            el.setAttribute("readonly", "");
            el.style.position = "absolute";
            el.style.left = "-9999px";
            document.body.appendChild(el);
            const selected =
                document.getSelection().rangeCount > 0
                    ? document.getSelection().getRangeAt(0)
                    : false;
            el.select();
            document.execCommand("copy");
            document.body.removeChild(el);
            if (selected) {
                document.getSelection().removeAllRanges();
                document.getSelection().addRange(selected);
            }
            this.copiedText = true;
        },
        openSocialShare(type) {
           
            let sharing_link = window.location.href;
            if (type === "facebook") {
                window.open(
                    `https://www.facebook.com/sharer/sharer.php?u=${sharing_link}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "twitter") {
                window.open(
                    `https://x.com/share?text=${this.contentDetails.content_name}&url=${window.location.href}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "linkedin") {
                window.open(`
                    https://www.linkedin.com/shareArticle?mini=true&url=${sharing_link}&title=${this.contentDetails.content_name}&source={LinkedIn}`);
            } else if (type === "pinterest") {
                window.open(
                    `http://pinterest.com/pin/create/button/?url=${sharing_link}&description=${this.contentDetails.content_desc}`
                );
            } else if (type === "tumblr") {
                window.open(
                    `http://www.tumblr.com/share/link?url=${sharing_link}`
                );
            }
            else if (type === "instagram") {
                window.open(
                    `http://www.instagram.com/share/link?url=${sharing_link}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                    
                );
            }
            // else if (type === 'link') {instagram
            //     this.copyMessage(window.location.href);
            //     // this.toastr.info('Link copied to clipboard');
            // }
        },

        likeEvent(event, likeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: likeStatus,
                    profile_uuid:":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );
                        // this.contentDetails.like_status = 1;
                        //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                    }
                });
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-up";
            }
        },
        dislikeEvent(event, dislikeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: dislikeStatus,
                    profile_uuid:":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );

                        // this.contentDetails.total_dislikes_count++;
                        // if(this.contentDetails.like_status == 1){
                        //     this.contentDetails.total_likes_count--;
                        // }
                        // this.contentDetails.like_status = 0;
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        favouriteEvent(contentDetails) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: contentDetails.content_uuid,
                    is_favourite: this.isFavourite == 0 ? 1 : 0,
                    profile_uuid:":profile_uuid"
                };
                makeContentFavorite(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentFavouriteAction(
                            contentDetails.content_uuid
                        );
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite =
                        res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },

        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                }
            });
        },
        async playlistEvent(contentDetails) {
            // console.log('contentDetails', contentDetails);
            if (this.isLogedIn) {
                JsLoader.show();
                try {
                    await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                    this.contentDetails.page = this.pageNo;
                    await this.$store.dispatch(GET_ENDUSER_PLAYLIST, contentDetails);
                    await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                } catch (error) {
                    console.error("Something went wrong!", error.message);
                    Toast.fire({
                        icon: "info",
                        title: 'Something went wrong!',
                        text: error.message,
                    });
                }
                JsLoader.hide();
            } else {
                window.location.href = "/sign-in";
            }
        },
        getNodeValueByCode(config_data, code) {
            const node = config_data?.sections
                .flatMap(section => section.groups.flatMap(group => group.nodes))
                .find(node => node.node_code === code);
            return node && parseInt(node.node_value) ? (node.node_value) : null;
        }
    },
    template: `
    <vd-component class="vd like-favourite-share-content-ten" type="like-favourite-share-content-ten">
<!--- like favourite share component -->
                        
                        
						
                                  <a class="share-a " href="javascript:void(0);" id="social-share-popup" @click="openSocialSharing()">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M18 8C19.6569 8 21 6.65685 21 5C21 3.34315 19.6569 2 18 2C16.3431 2 15 3.34315 15 5C15 6.65685 16.3431 8 18 8Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                      <path d="M6 15C7.65685 15 9 13.6569 9 12C9 10.3431 7.65685 9 6 9C4.34315 9 3 10.3431 3 12C3 13.6569 4.34315 15 6 15Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                      <path d="M18 22C19.6569 22 21 20.6569 21 19C21 17.3431 19.6569 16 18 16C16.3431 16 15 17.3431 15 19C15 20.6569 16.3431 22 18 22Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                      <path d="M8.58984 13.5098L15.4198 17.4898" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                      <path d="M15.4098 6.50977L8.58984 10.4898" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                      </svg>                                        
                                  </a>
                                  <div class="showSharepopup" >
                                    <span class="share-top-arrow">
                                      <svg width="16" height="8" viewBox="0 0 16 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 8L16 8L8 -6.99382e-07L0 8Z" fill="white"/>
                                        </svg>                                                                        
                                    </span>
                                    <div class="shareSocialpopup"  >
                                     <div class="socialIcons" >
                                      <span class="si-span facebook" @click="openSocialShare('facebook')">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M13.5 1.5H11.25C10.2554 1.5 9.30161 1.89509 8.59835 2.59835C7.89509 3.30161 7.5 4.25544 7.5 5.25V7.5H5.25V10.5H7.5V16.5H10.5V10.5H12.75L13.5 7.5H10.5V5.25C10.5 5.05109 10.579 4.86032 10.7197 4.71967C10.8603 4.57902 11.0511 4.5 11.25 4.5H13.5V1.5Z" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                          </svg>                                            
                                      </span>
                                      <span class="si-span twitter" @click="openSocialShare('twitter')">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M13.6546 1.6875H16.1356L10.7154 7.8825L17.0919 16.3125H12.0984L8.18786 11.1997L3.71336 16.3125H1.23086L7.02836 9.68625L0.912109 1.6875H6.03086L9.56561 6.36075L13.6531 1.6875H13.6546ZM12.7839 14.8275H14.1586L5.28461 3.0945H3.80936L12.7839 14.8275Z" fill="#888888"/>
                                          </svg>                                                                                      
                                      </span>
                                      <span class="si-span instagram" @click="openSocialShare('instagram')">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <g clip-path="url(#clip0_214_10839)">
                                          <path d="M12.75 1.5H5.25C3.17893 1.5 1.5 3.17893 1.5 5.25V12.75C1.5 14.8211 3.17893 16.5 5.25 16.5H12.75C14.8211 16.5 16.5 14.8211 16.5 12.75V5.25C16.5 3.17893 14.8211 1.5 12.75 1.5Z" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M12.0008 8.52748C12.0933 9.15167 11.9867 9.78914 11.6961 10.3492C11.4055 10.9093 10.9456 11.3635 10.382 11.6472C9.81834 11.9309 9.17959 12.0297 8.5566 11.9294C7.9336 11.8292 7.35808 11.535 6.91189 11.0889C6.46569 10.6427 6.17156 10.0671 6.07131 9.44414C5.97106 8.82115 6.06981 8.1824 6.3535 7.61876C6.6372 7.05512 7.0914 6.59529 7.6515 6.30466C8.21159 6.01404 8.84907 5.90742 9.47326 5.99998C10.1099 6.0944 10.6994 6.39108 11.1545 6.84621C11.6097 7.30134 11.9063 7.89079 12.0008 8.52748Z" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M13.125 4.875H13.1317" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                          </g>
                                          <defs>
                                          <clipPath id="clip0_214_10839">
                                          <rect width="18" height="18" fill="white"/>
                                          </clipPath>
                                          </defs>
                                          </svg>                                                                                      
                                      </span>
                                      <span class="si-span copyLink"  v-model="pageLink" ref="mylink" @click="copyURL()" v-if="!copiedText">
                                      
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <g clip-path="url(#clip0_214_10910)">
                                          <path d="M7.5 9.74997C7.82209 10.1806 8.23302 10.5369 8.70491 10.7947C9.17681 11.0525 9.69863 11.2058 10.235 11.2442C10.7713 11.2826 11.3097 11.2052 11.8135 11.0173C12.3173 10.8294 12.7748 10.5353 13.155 10.155L15.405 7.90497C16.0881 7.19772 16.4661 6.25046 16.4575 5.26722C16.449 4.28398 16.0546 3.34343 15.3593 2.64815C14.664 1.95287 13.7235 1.55849 12.7403 1.54995C11.757 1.5414 10.8098 1.91938 10.1025 2.60247L8.8125 3.88497" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M10.5006 8.24992C10.1785 7.81933 9.76762 7.46304 9.29573 7.20522C8.82383 6.9474 8.30201 6.79409 7.76565 6.75567C7.22929 6.71726 6.69095 6.79465 6.18713 6.98259C5.68331 7.17053 5.2258 7.46462 4.84564 7.84492L2.59564 10.0949C1.91255 10.8022 1.53457 11.7494 1.54311 12.7327C1.55165 13.7159 1.94604 14.6565 2.64132 15.3517C3.3366 16.047 4.27715 16.4414 5.26038 16.45C6.24362 16.4585 7.19088 16.0805 7.89814 15.3974L9.18064 14.1149" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                                          </g>
                                          <defs>
                                          <clipPath id="clip0_214_10910">
                                          <rect width="18" height="18" fill="white"/>
                                          </clipPath>
                                          </defs>
                                          </svg>                                                                                      
                                      
                                      </span>
                                      <span class="si-span copyLink"  v-if="copiedText">
                                                                                                                           
                                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="#888888" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check">
                                      <polyline points="19 5 9 15 5 10"/>
                                      </svg>
                                      
                                      </span>
                                    
                                </vd-component>`,
};

let {
    getContentSettingsDetails,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
    getEnduserPlaylist,
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_views_two}=await import(window.importLocalJs('widgets/content-views/content-views-two.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_STORE_CONTENT_TYPE, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
const { mapState, mapGetters } = Vuex;
export default {
    name: "like_favourite-share_content_four",
    props: {
        contentData: Object,
        likeReviewRatingsSettingsData: Object,
        likeReviewRatingsSettingsDataAvailable: Boolean,
        isFavouriteSettings: Boolean,
        contentUuid: "",
        isPlayList: 0,
        shareVideoText: String,
        linkText: String,
        socialText: String,
    },
    components: {
        content_views_two,
    },
    data() {
        return {
            contentDetails: Object,
            likeReviewRatingsSettings: Object,
            isFavouriteEnabled: Boolean,
            isHidden: false,
            copiedText: false,
            isFavourite: 0,
            //contentUuid:"",
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            showViews: false,
            enduserPlaylist: [],
            pageNo: 1
        };
    },
    watch: {
        contentUuid(contentUuid) {
            // console.log("pithan contentUuid--------" + contentUuid);
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getContentFavouriteAction(contentUuid);
            this.getContentSettingsDetails("");
        },
        contentData(contentData) {
            // console.log("pithan contentData--------" + contentData);
            this.contentDetails = contentData;
            this.showViews = true;
            this.getContentFavouriteAction(contentData.content_uuid);
        },
        likeReviewRatingsSettingsData(likeReviewRatingsSettingsData) {
            // console.log(
            //     "pithan likeReviewRatingsSettingsData--------" +
            //         likeReviewRatingsSettingsData
            // );
            this.likeReviewRatingsSettings = likeReviewRatingsSettingsData;
        },
        show_enduser_playlist_modal(cv) {
            // console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                    // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                    // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
        isFavouriteSettings(isFavouriteSettings) {
            this.isFavouriteEnabled = isFavouriteSettings;
        },
        likeReviewRatingsSettingsDataAvailable(
            likeReviewRatingsSettingsDataAvailable
        ) {
            if (likeReviewRatingsSettingsDataAvailable) {
                this.getContentSettingsDetails("");
            }
        },
    },
    
    computed: {
        ...mapState({
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal,
            partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
        })
    },

    mounted() {},
    methods: {
        closePopup() {
            this.isHidden = false;
            this.copiedText = false;
        },
        openSocialSharing() {
            this.isHidden = true;
            this.pageLink = window.location.href;
        },

        copyURL() {
            const el = document.createElement("textarea");
            el.value = window.location.href;
            el.setAttribute("readonly", "");
            el.style.position = "absolute";
            el.style.left = "-9999px";
            document.body.appendChild(el);
            const selected =
                document.getSelection().rangeCount > 0
                    ? document.getSelection().getRangeAt(0)
                    : false;
            el.select();
            document.execCommand("copy");
            document.body.removeChild(el);
            if (selected) {
                document.getSelection().removeAllRanges();
                document.getSelection().addRange(selected);
            }
            this.copiedText = true;
        },
        openSocialShare(type) {
            let sharing_link = window.location.href;
            if (type === "facebook") {
                window.open(
                    `https://www.facebook.com/sharer/sharer.php?u=${sharing_link}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "twitter") {
                window.open(
                    `https://twitter.com/share?text=${this.contentDetails.content_name}&url=${window.location.href}`,
                    "",
                    "menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"
                );
            } else if (type === "linkedin") {
                window.open(`
                    https://www.linkedin.com/shareArticle?mini=true&url=${sharing_link}&title=${this.contentDetails.content_name}&source={LinkedIn}`);
            } else if (type === "pinterest") {
                window.open(
                    `http://pinterest.com/pin/create/button/?url=${sharing_link}&description=${this.contentDetails.content_desc}`
                );
            } else if (type === "tumblr") {
                window.open(
                    `http://www.tumblr.com/share/link?url=${sharing_link}`
                );
            }
            // else if (type === 'link') {
            //     this.copyMessage(window.location.href);
            //     // this.toastr.info('Link copied to clipboard');
            // }
        },

        likeEvent(event, likeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: likeStatus,
                    profile_uuid: ":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );
                        // this.contentDetails.like_status = 1;
                        //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                    }
                });
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-up";
            }
        },
        dislikeEvent(event, dislikeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: dislikeStatus,
                    profile_uuid: ":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );

                        // this.contentDetails.total_dislikes_count++;
                        // if(this.contentDetails.like_status == 1){
                        //     this.contentDetails.total_likes_count--;
                        // }
                        // this.contentDetails.like_status = 0;
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        favouriteEvent(contentDetails) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: contentDetails.content_uuid,
                    is_favourite: this.isFavourite == 0 ? 1 : 0,
                    profile_uuid: ":profile_uuid",
                };
                makeContentFavorite(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentFavouriteAction(
                            contentDetails.content_uuid
                        );
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite =
                        res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },

        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                }
            });
        },

        getContentSettingsDetails(structureUuid) {
            getContentSettingsDetails(structureUuid).then((res) => {
                if (res.data.code == 200) {
                    this.isFavouriteEnabled =
                        res.data.data.contentSettings
                            .content_favourite_settings != null
                            ? res.data.data.contentSettings
                                  .content_favourite_settings?.is_enabled
                            : false;
                    if (
                        res.data.data.contentSettings
                            .content_like_and_review_settings != null
                    ) {
                        this.likeReviewRatingsSettings =
                            res.data.data.contentSettings.content_like_and_review_settings;
                    }
                }
            });
        },
        async playlistEvent(contentDetails) {
            // console.log('contentDetails', contentDetails);
            if (this.isLogedIn) {
                JsLoader.show();
                try {
                    await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                    this.contentDetails.page = this.pageNo;
                    await this.$store.dispatch(GET_ENDUSER_PLAYLIST, contentDetails);
                    await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                } catch (error) {
                    console.error("Something went wrong!", error.message);
                    Toast.fire({
                        icon: "info",
                        title: 'Something went wrong!',
                        text: error.message,
                    });
                }
                JsLoader.hide();
            } else {
                window.location.href = "/sign-in";
            }
        },
        getNodeValueByCode(config_data, code) {
            const node = config_data?.sections
                .flatMap(section => section.groups.flatMap(group => group.nodes))
                .find(node => node.node_code === code);
            return node && parseInt(node.node_value) ? (node.node_value) : null;
        }
    },
    template: `<vd-component class="vd like-favourite-share-content-four" type="like-favourite-share-content-four">
        <div class="socail-share">
            <h4 vd-readonly="true" class="align-self-center">Social Share :</h4>
            <ul class="social-inner">
                <li><a class="callByAjax" href="Javascript:void(0);" @click="openSocialShare('facebook')" class="facebook"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li><a class="callByAjax" href="Javascript:void(0);" @click="openSocialShare('linkedin')" class="facebook"><i class="fab fa-linkedin"></i></a>
                </li>
                <li><a class="callByAjax" href="Javascript:void(0);" @click="openSocialShare('twitter')" class="facebook"><i class="fa-brands fa-x-twitter"></i></a></li>
                <li v-if="contentDetails.content_asset_type == 2 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null  && contentDetails.content_asset_uuid != '' &&
                contentDetails.audio_details != null && 
                (contentDetails.audio_details.encoding_status =='completed' || contentDetails.audio_details.encoding_status == null))">
                    <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
                        <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
                    </svg>
                    </a>
                </li>
                <li v-if="contentDetails.content_asset_type == 1 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null && contentDetails.content_asset_uuid != '' &&
                contentDetails.video_details != null && 
                ((!contentDetails.video_details.is_feed && (contentDetails.video_details.encoding_status =='completed' || contentDetails.video_details.encoding_status == null)) || contentDetails.video_details.is_feed))">
                    <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
                        <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
                    </svg>
                    </a>
                </li>
            </ul>
        </div>
        <playlist_enduser_one :id="$attrs['id'] +'_playlist_enduser_one_1'" v-if="show_enduser_playlist_modal" :contentDetails="contentDetails" />
    </vd-component>`,
};

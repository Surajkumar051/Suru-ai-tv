let {
    getContentSettingsDetails,
    getContentDetails,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
    getEnduserPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_STORE_CONTENT_TYPE, GET_ENDUSER_PLAYLIST } = await import(window.importAssetJs('js/configurations/actions.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
const { mapState, mapGetters } = Vuex;

export default {
    name: "like_favourite_share_content_seven",
    props: {
         contentData: Object,
        likeReviewRatingsSettingsData: Object,
        isFavouriteSettings: Boolean,
        contentUuid: "",
        isPlayList: Number,
        shareVideoText: String,
        linkText: String,
        socialText: String,
        permalinkDataEmitted: Object
    },
    components: {
        playlist_enduser_one
    },
    data() {
        return {
    contentDetails: Object,
            likeReviewRatingsSettings: Object,
            isFavouriteEnabled: Boolean,
            isHidden: false,
            copiedText: false,
            isFavourite: 0,
            //contentUuid:"",
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            enduserPlaylist: [],
            pageNo: 1
        };
    },
    watch: {
        contentUuid(contentUuid) {
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getContentFavouriteAction(contentUuid);
            this.getContentSettingsDetails("");
        },
        contentData(contentData) {
            this.contentDetails = contentData;
            this.getContentFavouriteAction(contentData.content_uuid);
        },
        likeReviewRatingsSettingsData(likeReviewRatingsSettingsData) {
            this.likeReviewRatingsSettings = likeReviewRatingsSettingsData;
        },
        show_enduser_playlist_modal(cv) {
            //console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                    // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                    // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
    },
    computed: {
        ...mapState({
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal,
            partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
        })
    },
    updated(){
        $('[data-toggle="tooltip"]').tooltip({
            trigger : 'hover'
            });
    },
    mounted() {   
            this.getContentDetailsData(this.contentData.content_uuid, this.isPlayList);
            this.getContentFavouriteAction(this.contentData.content_uuid);  
            this.contentDetails = this.contentData;
            this.getContentFavouriteAction(this.contentData.content_uuid);
            this.likeReviewRatingsSettings = this.likeReviewRatingsSettingsData;    
    },
    methods: {
        i18n,
        likeEvent(event, likeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: likeStatus,
                    profile_uuid:":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );
                        // this.contentDetails.like_status = 1;
                        //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                    }
                });
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-up";
            }
        },
        dislikeEvent(event, dislikeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: content_uuid,
                    like_status: dislikeStatus,
                    profile_uuid:":profile_uuid"
                };
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(
                            param.content_uuid,
                            this.contentDetails.is_playlist
                        );

                        // this.contentDetails.total_dislikes_count++;
                        // if(this.contentDetails.like_status == 1){
                        //     this.contentDetails.total_likes_count--;
                        // }
                        // this.contentDetails.like_status = 0;
                    }
                });
            } else {
                window.location.href = "/sign-in";
            }
        },
        favouriteEvent(contentDetails) {
            //console.log('contentDetails',this.isFavourite)
            if (this.isLogedIn) {
                const param = {
                    app_token: ":app_token",
                    product_key: ":product_key",
                    store_key: ":store_key",
                    end_user_uuid: ":me",
                    content_uuid: contentDetails.content_uuid,
                    is_favourite: this.isFavourite == 0 ? 1 : 0,
                    profile_uuid:":profile_uuid"
                };
                makeContentFavorite(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentFavouriteAction(
                            contentDetails.content_uuid
                        );
                    }
                });
            } else {
                window.location.href = "/sign-up";
            }
        },
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite =
                        res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },

        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                }
            });
        },
        async playlistEvent(contentDetails) {
            // console.log('contentDetails', contentDetails);
            if (this.isLogedIn) {
                JsLoader.show();
                try {
                    await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                    this.contentDetails.page = this.pageNo;
                    await this.$store.dispatch(GET_ENDUSER_PLAYLIST, contentDetails);
                    await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                } catch (error) {
                    console.error("Something went wrong!", error.message);
                    Toast.fire({
                        icon: "info",
                        title: 'Something went wrong!',
                        text: error.message,
                    });
                }
                JsLoader.hide();
            } else {
                window.location.href = "/sign-in";
            }
        },
        getNodeValueByCode(config_data, code) {
            const node = config_data?.sections
                .flatMap(section => section.groups.flatMap(group => group.nodes))
                .find(node => node.node_code === code);
            return node && parseInt(node.node_value) ? (node.node_value) : null;
        }
    },
    template: /*html*/ `<vd-component class="vd like-favourite-share-content-seven" type="like-favourite-share-content-seven">
    <ul class="social-share p-0">
    <li class="vd-no-navigation" id="showStartOver" v-if="permalinkDataEmitted?.show_play_btn && permalinkDataEmitted?.button_text === 'Resume'">
        <a title="Start Over" href="javascript:void(0);" class="callByAjax svg-fill startOver"
            data-toggle="tooltip" data-placement="top" data-original-title="Start Over" :title="i18n('Start Over')" style="" @click="$emit('callWatchNow')">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M2 3.99219V9.99219H8" stroke="#818181" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round"></path>
                <path
                    d="M4.51 14.9907C5.15839 16.831 6.38734 18.4109 8.01166 19.492C9.63598 20.5732 11.5677 21.0973 13.5157 20.9851C15.4637 20.873 17.3226 20.1308 18.8121 18.8704C20.3017 17.61 21.3413 15.8996 21.7742 13.997C22.2072 12.0944 22.0101 10.1026 21.2126 8.32177C20.4152 6.54091 19.0605 5.06747 17.3528 4.12344C15.6451 3.17941 13.6769 2.81593 11.7447 3.08779C9.81245 3.35964 8.02091 4.25209 6.64 5.63067L2 9.99067"
                    stroke="#818181" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        </a>
        <span class="count-box"></span>
    </li>
    <li class="vd-no-navigation" v-if="likeReviewRatingsSettings?.is_like_enabled" >
            <a :title="i18n('Like')" :style="contentDetails.like_status==1?'background: #fff;':''"
            @click="likeEvent($event,contentDetails.like_status==1?0:1,contentDetails.content_uuid)" href="javascript:void(0);" class="callByAjax svg-fill" data-toggle="tooltip" data-placement="top" title="Like">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path :style="contentDetails.like_status == 1?'stroke: #f4181c;':''" d="M20.5714 8.143H15.4286V3.00014C15.4279 2.31836 15.1568 1.66471 14.6747 1.18262C14.1926 0.700528 13.5389 0.429392 12.8571 0.428711H11.0289C10.6167 0.430461 10.2188 0.579908 9.90744 0.849934C9.59606 1.11996 9.39179 1.49267 9.33171 1.90043L8.60743 6.97214L5.54143 11.5716H0V23.5716H18C19.5907 23.5698 21.1158 22.937 22.2406 21.8122C23.3655 20.6874 23.9982 19.1623 24 17.5716V11.5716C23.9989 10.6626 23.6373 9.79119 22.9945 9.14845C22.3518 8.50572 21.4804 8.14413 20.5714 8.143ZM5.14286 21.8573H1.71429V13.2859H5.14286V21.8573ZM22.2857 17.5716C22.2844 18.7078 21.8324 19.7971 21.029 20.6005C20.2255 21.404 19.1362 21.8559 18 21.8573H6.85714V12.6884L10.2497 7.59957L11.0297 2.143H12.8571C13.0845 2.143 13.3025 2.2333 13.4632 2.39405C13.624 2.55479 13.7143 2.77281 13.7143 3.00014V9.85728H20.5714C21.0259 9.85774 21.4617 10.0385 21.7831 10.3599C22.1045 10.6813 22.2853 11.1171 22.2857 11.5716V17.5716Z" fill="#818181"/>
        </svg>                                        
    </a><span v-if="likeReviewRatingsSettings?.is_like_count_enabled" class="count-box">{{contentDetails.total_likes_count}}</span></li>
    <li class="vd-no-navigation" v-if="likeReviewRatingsSettings?.is_dislike_enabled">
            <a :style="contentDetails.like_status==2?'background: #fff;':''" href="javascript:void(0);" class="svg-fill" data-toggle="tooltip" data-placement="top"  :title="i18n('Dislike')"  @click="dislikeEvent($event,contentDetails.like_status==2?0:2,contentDetails.content_uuid)">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path :style="contentDetails.like_status == 2?'stroke: #f4181c;':''"  d="M3.42857 15.857L8.57143 15.857L8.57143 20.9999C8.57211 21.6816 8.84325 22.3353 9.32533 22.8174C9.80742 23.2995 10.4611 23.5706 11.1429 23.5713H12.9711C13.3833 23.5695 13.7812 23.4201 14.0926 23.1501C14.4039 22.88 14.6082 22.5073 14.6683 22.0996L15.3926 17.0279L18.4586 12.4284H24L24 0.428432L6 0.428432C4.40926 0.430246 2.88419 1.06297 1.75936 2.1878C0.634539 3.31262 0.00181389 4.83769 0 6.42843L0 12.4284C0.00113297 13.3374 0.362722 14.2088 1.00546 14.8515C1.64819 15.4943 2.51961 15.8559 3.42857 15.857ZM18.8571 2.14272H22.2857L22.2857 10.7141H18.8571L18.8571 2.14272ZM1.71428 6.42843C1.71565 5.29221 2.16761 4.20291 2.97104 3.39948C3.77448 2.59604 4.86378 2.14408 6 2.14272L17.1429 2.14272L17.1429 11.3116L13.7503 16.4004L12.9703 21.857H11.1429C10.9155 21.857 10.6975 21.7667 10.5368 21.606C10.376 21.4452 10.2857 21.2272 10.2857 20.9999L10.2857 14.1427H3.42857C2.97405 14.1423 2.53828 13.9615 2.21689 13.6401C1.8955 13.3187 1.71474 12.8829 1.71428 12.4284L1.71428 6.42843Z" fill="#818181"/>
        </svg>                                        
    </a><span v-if="likeReviewRatingsSettings?.is_dislike_count_enabled" class="count-box">{{contentDetails.total_dislikes_count}}</span></li>
    <li class="vd-no-navigation" v-if="isFavouriteSettings"><a href="javascript:void(0);" :style="isFavourite == 1?'background: #fff':''"
            :title="i18n('Favourite')" @click="favouriteEvent(contentDetails)" class="svg-stroke" data-toggle="tooltip" data-placement="top">
      <svg width="24" height="22" viewBox="0 0 24 22" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path :style="isFavourite == 1?'stroke: #f4181c;fill: #f4181c;':''" d="M20.8396 3.4961C20.3289 2.98511 19.7224 2.57975 19.055 2.30319C18.3875 2.02662 17.6721 1.88428 16.9496 1.88428C16.2271 1.88428 15.5117 2.02662 14.8443 2.30319C14.1768 2.57975 13.5704 2.98511 13.0596 3.4961L11.9996 4.5561L10.9396 3.4961C9.90794 2.46441 8.50866 1.88481 7.04963 1.88481C5.5906 1.88481 4.19132 2.46441 3.15963 3.4961C2.12794 4.5278 1.54834 5.92707 1.54834 7.3861C1.54834 8.84514 2.12794 10.2444 3.15963 11.2761L4.21963 12.3361L11.9996 20.1161L19.7796 12.3361L20.8396 11.2761C21.3506 10.7653 21.756 10.1589 22.0325 9.49146C22.3091 8.824 22.4515 8.10859 22.4515 7.3861C22.4515 6.66362 22.3091 5.94821 22.0325 5.28075C21.756 4.61329 21.3506 4.00686 20.8396 3.4961Z" stroke="#818181" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>                                        
    </a></li>
    <li v-if="contentDetails.content_asset_type == 2 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null  && contentDetails.content_asset_uuid != '' &&
    contentDetails.audio_details != null && 
    (contentDetails.audio_details.encoding_status =='completed' || contentDetails.audio_details.encoding_status == null))">
        <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
            <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
        </svg>
        </a>
    </li>
    <li v-if="contentDetails.content_asset_type == 1 && getNodeValueByCode(partner_and_enduser_profile_settings?.ugcSettings, 'is_enduser_playlist_enabled') && contentDetails.is_parent == 0 && (contentDetails.content_asset_uuid != null && contentDetails.content_asset_uuid != '' &&
    contentDetails.video_details != null && 
    ((!contentDetails.video_details.is_feed && (contentDetails.video_details.encoding_status =='completed' || contentDetails.video_details.encoding_status == null)) || contentDetails.video_details.is_feed))">
        <a href="javascript:void(0);" @click="playlistEvent(contentDetails)" data-toggle="tooltip" data-placement="top" :title="i18n('Add To Playlist')" :data-original-title="i18n('Add To Playlist') ">
            <svg width="24" height="18" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.2 5.40156H1.2C0.54 5.40156 0 5.94156 0 6.60156C0 7.26156 0.54 7.80156 1.2 7.80156H13.2C13.86 7.80156 14.4 7.26156 14.4 6.60156C14.4 5.94156 13.86 5.40156 13.2 5.40156ZM13.2 0.601562H1.2C0.54 0.601562 0 1.14156 0 1.80156C0 2.46156 0.54 3.00156 1.2 3.00156H13.2C13.86 3.00156 14.4 2.46156 14.4 1.80156C14.4 1.14156 13.86 0.601562 13.2 0.601562ZM19.2 10.2016V6.60156C19.2 5.94156 18.66 5.40156 18 5.40156C17.34 5.40156 16.8 5.94156 16.8 6.60156V10.2016H13.2C12.54 10.2016 12 10.7416 12 11.4016C12 12.0616 12.54 12.6016 13.2 12.6016H16.8V16.2016C16.8 16.8616 17.34 17.4016 18 17.4016C18.66 17.4016 19.2 16.8616 19.2 16.2016V12.6016H22.8C23.46 12.6016 24 12.0616 24 11.4016C24 10.7416 23.46 10.2016 22.8 10.2016H19.2ZM1.2 12.6016H8.4C9.06 12.6016 9.6 12.0616 9.6 11.4016C9.6 10.7416 9.06 10.2016 8.4 10.2016H1.2C0.54 10.2016 0 10.7416 0 11.4016C0 12.0616 0.54 12.6016 1.2 12.6016Z" fill="white"></path>
        </svg>
        </a>
    </li>
  </ul>
  <playlist_enduser_one :id="$attrs['id'] +'_playlist_enduser_one_1'" v-if="show_enduser_playlist_modal" :contentDetails="contentDetails" />
</vd-component>`,
};

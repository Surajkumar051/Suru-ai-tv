let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n }=await import(window.importAssetJs('js/i18n.js'));
let {isAuthorizedContent}=await import(window.importAssetJs('js/webservices.js'));
// let { getLocale } = await import(window.importAssetJs('js/web-service-url.js')); //ER-100207
let { TOGGLE_CONTENT_PURCHASE_MODAL, SET_CURRENT_CONTENT_SELECTION_DATA } = await import(window.importAssetJs('js/configurations/actions.js'));
let { content_purchase_one} = await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));

const { mapState, mapActions } = Vuex;
export default {
    name: "watch_preorder_two",
    props: ["playerRequiredObj"],
    template: `
    <vd-component class="vd watch-preorder-two vd-no-navigation cursor-pointer" type="watch-preorder-two">
        <a class="callByAjax playBut popup-youtube popup-vimeo popup-gmaps" @click="getContentDetails()">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="213.7px" height="213.7px" viewBox="0 0 213.7 213.7" enable-background="new 0 0 213.7 213.7" xml:space="preserve"><polygon class="triangle" id="XMLID_18_" fill="none" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
             73.5,62.5 148.5,105.8 73.5,149.1 "></polygon><circle class="circle" id="XMLID_17_" fill="none" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="106.8" cy="106.8" r="103.3"></circle></svg>
            <span>{{i18n(buttonText)}}</span>
        </a>
        <div class="toastCustom fade" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toastCustom-header">
                <strong class="mr-auto">{{i18n('You will be notified once the media is available for this content.')}}</strong>
                <button @click="closeToastMessage()" type="button" class="ml-2 mb-1 closeToast" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </vd-component>
    `,
    data() {
        return {
            isLoggedIn: JSON.parse(localStorage.getItem("isloggedin")),
            contentUuid: this.playerRequiredObj.contentUuid,
            buttonText: "Pre-order",
            isRegdLogin: 1,
            // languageCode: getLocale() //ER-100207
        };
    },
    computed: {
        ...mapState({
            end_user_regd_login_setting: (state) => state.end_user_regd_login_setting,
        }),
    },
    components: {

    },
    beforeCreate() {},
    async created() {
        JsLoadingOverlay.hide();
        let validate = await this.validatePlayerRequiredObj(
            this.playerRequiredObj
        );
        if (validate) {
            let parentUuid = this.playerRequiredObj.rootParentUuid ?? '';
            let childUuid = this.playerRequiredObj.contentUuid;
            if (this.playerRequiredObj.isParent == 0) {
                parentUuid = null;
            }
            if (parentUuid == childUuid) {
                childUuid = null;
            }
            if (this.playerRequiredObj.isPlayList == 1) {
                parentUuid = this.playerRequiredObj.contentUuid;
                childUuid = null;
            }
        } else {
            //Call contentList API
            console.log("else error");
        }
    },
    beforeMount() {
        
    },
    async mounted() {
        
    },
    methods: {
        i18n,
        async validatePlayerRequiredObj(playerRequiredObj = {}) {
            let isValid = true;
            if (
                typeof playerRequiredObj.contentUuid == "undefined" ||
                playerRequiredObj.contentUuid == null ||
                playerRequiredObj.contentUuid == ""
            ) {
                isValid = false;
            }
            if (
                typeof playerRequiredObj.contentAssetType == "undefined" ||
                playerRequiredObj.contentAssetType == null ||
                playerRequiredObj.contentAssetType == ""
            ) {
                isValid = false;
            }
            if (
                typeof playerRequiredObj.contentPermalink == "undefined" ||
                playerRequiredObj.contentPermalink == null ||
                playerRequiredObj.contentPermalink == ""
            ) {
                isValid = false;
            }
            if (
                typeof playerRequiredObj.isParent == "undefined" ||
                playerRequiredObj.isParent == null ||
                (playerRequiredObj.isParent == "" &&
                    !Number.isInteger(playerRequiredObj.isParent))
            ) {
                isValid = false;
            }
            if (
                typeof playerRequiredObj.isPlayList == "undefined" ||
                playerRequiredObj.isPlayList == null ||
                (playerRequiredObj.isPlayList == "" &&
                    !Number.isInteger(playerRequiredObj.isParent))
            ) {
                isValid = false;
            }
            return isValid;
        },
        /**
         * @purpose : SHOW CONTENT
         */
        async getContentDetails() {
            try {
                // JsLoadingOverlay.show();
                if (!this.isLoggedIn) {
                    let redirectAfterLogin = window.location.origin;
                    redirectAfterLogin = redirectAfterLogin + '/content/' + this.playerRequiredObj.contentPermalink;
                    window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                    window.location.href = "/sign-in";
                    return false;
                } else {
                    //Monetization Logic
                    const res = await isAuthorizedContent(this.contentUuid);
                    if (res.data.code == 200) {
                        if (res.data.data.isAuthorized.is_content_authorized) {
                            let unique_id = this.contentUuid;
                            let queue_config = {};
                            let queue_header = {
                                Authorization:
                                    "Bearer " + localStorage.getItem("access_token"),
                            };
                            let queue_body = {
                                unique_id: unique_id,
                                domain: this.enduserURL,
                            };
                            queue_config.add_to_queue_url =
                                getBaseUrl() + "player/add-to-queue";
                            queue_config.queue_header = queue_header;
                            queue_config.queue_body = queue_body;
                            window.audioQueueObj._loadIntoQueue(queue_config);
                        } else if(res.data.data.isAuthorized.is_content_purchased && !res.data.data.isAuthorized.is_content_authorized) {
                            document.getElementsByClassName('toastCustom')[0].classList.add('show');
                        } else {
                            this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                content_uuid: this.contentUuid,
                                monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                            });
                        }
                    }
                }
            } catch (error) {
                throw error;
            }
        },
        closeToastMessage() {
            document.getElementsByClassName('toastCustom')[0].classList.remove('show');
        },
        /**
         * @purpose : SHOW TOASTER MESSAGE
         * @param {*} icon
         * @param {*} text
         */
        showToastMessage: function (icon, text) {
            try {
                Toast.fire({ icon: icon, title: "Error", text: text });
            } catch (error) {
                throw error;
            }
        },
    },
};

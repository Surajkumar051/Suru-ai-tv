let { getMyPlan,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    generateSST,
    getEndUserRegdLoginSetting,
    getCardList,
    makeDefault,
    deleteCard,
    getCardForms,
    addCard,
    purchaseHistory,
    viewInvoiceDetails,
    checkGateway,
    //87419 Raj
    validatePromocode,
    getContentByContentUuid,
    getvalidateContentPattern,
    expireCanceledPlan,
    confirmCheckout } = await import(window.importAssetJs('js/webservices.js'));
let { TOGGLE_ACCOUNT_CANCELLATION_MODAL } = await import(window.importAssetJs('js/configurations/actions.js'));
let { getCookie,
    notLoggedinUser,
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies } = await import(window.importAssetJs('js/main.js'));
let { Toast,
    Alert } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));

const { defineAsyncComponent } = Vue;
const { useVuelidate } = Vuelidate;
const { helpers } = VuelidateValidators;
const { mapState, mapGetters } = Vuex;

const current = moment().format('MM / YY');

export default {
    name: 'billing_and_purchases_seven',
    template: `
    <vd-component class="vd billing-and-purchases-seven" type="billing-and-purchases-seven">
    <div class="dashboard-rightsection">
        <div class="page-nav page-nav2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <h2 class="mb-1">{{i18n("Billing & Purchase")}}</h2>
                    </div>
                </div>
            </div>
        </div>
        <section id="muvi-MyProfile1">
            <div id="accordion" class="accordion" v-if="show_device != 'showplan'">
                <div class="card mb-3">
                    <div class="card-header" id="headingOne">
                        <h5 class="mb-0">
                            <button class="btn btn-link small-text pl-5 text-left" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <i class="fa fa-circle-info"></i><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param>
                            </button>
                        </h5>
                    </div>
                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                        <div class="card-body form-div">
                            <div class="" v-if="(!is_subscribed && !is_cancelled && !is_renews_on_panding) && is_expired">
                                <p class="m-0 none" v-if="noPlanMsg">{{i18n(noPlanMsg)}}</p>
                                <p class="m-0 none" v-else>{{i18n("You have no active plans")}}</p>
                                <button type="button" v-if="isSelected" @click="showPlan();" class="primary-button acrd-btn plans chooseplan-btn">
                                    {{i18n("Choose Plan")}}
                                </button>
                            </div>
                            <div class="plan-divs hide mb-12" v-for="({ plan_name, next_billing_date, plan_status, is_specific_plan, subscription_uuid, plan_description, cancel_reason_type, cancel_message, cancel_additional_message, payment_mode, is_free_plan},i) in my_plans">
                                <div class="plan-d-span">
                                    <span class="text-uppercase w-200">
                                        <span class="plan-txt-main">{{plan_name}}</span>
                                        <span class="svg position-relative" v-if="plan_description">
                                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M7.0026 0.582031C3.45885 0.582031 0.585938 3.45495 0.585938 6.9987C0.585938 10.5424 3.45885 13.4154 7.0026 13.4154C10.5464 13.4154 13.4193 10.5424 13.4193 6.9987C13.4193 3.45495 10.5464 0.582031 7.0026 0.582031ZM6.71094 3.4987C6.55623 3.4987 6.40785 3.56016 6.29846 3.66955C6.18906 3.77895 6.1276 3.92732 6.1276 4.08203C6.1276 4.23674 6.18906 4.38511 6.29846 4.49451C6.40785 4.60391 6.55623 4.66536 6.71094 4.66536H7.0026C7.15731 4.66536 7.30569 4.60391 7.41508 4.49451C7.52448 4.38511 7.58594 4.23674 7.58594 4.08203C7.58594 3.92732 7.52448 3.77895 7.41508 3.66955C7.30569 3.56016 7.15731 3.4987 7.0026 3.4987H6.71094ZM5.83594 5.83203C5.68123 5.83203 5.53285 5.89349 5.42346 6.00289C5.31406 6.11228 5.2526 6.26065 5.2526 6.41536C5.2526 6.57007 5.31406 6.71845 5.42346 6.82784C5.53285 6.93724 5.68123 6.9987 5.83594 6.9987H6.41927V8.7487H5.83594C5.68123 8.7487 5.53285 8.81016 5.42346 8.91955C5.31406 9.02895 5.2526 9.17732 5.2526 9.33203C5.2526 9.48674 5.31406 9.63511 5.42346 9.74451C5.53285 9.85391 5.68123 9.91536 5.83594 9.91536H8.16927C8.32398 9.91536 8.47235 9.85391 8.58175 9.74451C8.69115 9.63511 8.7526 9.48674 8.7526 9.33203C8.7526 9.17732 8.69115 9.02895 8.58175 8.91955C8.47235 8.81016 8.32398 8.7487 8.16927 8.7487H7.58594V6.41536C7.58594 6.26065 7.52448 6.11228 7.41508 6.00289C7.30569 5.89349 7.15731 5.83203 7.0026 5.83203H5.83594Z"
                                                    fill="#BBBBBB" fill-opacity="0.6" />
                                            </svg>
                                            <div class="hover-tooltip">
                                                <div class="inner-tooltip position-relative">
                                                    <p class="info-para">
                                                        {{plan_description}}
                                                    </p>
                                                </div>
                                            </div>
                                        </span>
                                    </span>
                                    <!--<span class="plan-d-txt position-relative">Plan Details
                                        <div class="plan-d-list hover-tooltip">
                                            <div class="inner-tooltip position-relative">
                                                <ul>
                                                    <li v-for="(elements, inDx) in contentListMyPlan[i]" :class="[types.includes(elements) ? 'fw-bold' : '']">
                                                        <span class="mr-2">
                                                            <svg width="15" height="16" viewBox="0 0 15 16"
                                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M13.4862 3.27244C13.6697 3.09081 13.8807 3 14.1193 3C14.3578 3 14.5688 3.09081 14.7523 3.27244C14.9174 3.4359 15 3.64022 15 3.88542C15 4.13061 14.9174 4.33494 14.7523 4.4984L5.97248 13.2436C5.95413 13.2618 5.93578 13.2799 5.91743 13.2981C5.89908 13.3162 5.88073 13.3344 5.86238 13.3526C5.69725 13.5342 5.49083 13.625 5.24312 13.625C4.99541 13.625 4.78899 13.5342 4.62385 13.3526L0.247706 9.04808C0.082568 8.88461 0 8.68029 0 8.4351C0 8.1899 0.082568 7.98558 0.247706 7.82212C0.431194 7.64049 0.642201 7.54968 0.880734 7.54968C1.11927 7.54968 1.33027 7.64049 1.51376 7.82212L5.22936 11.5L13.4862 3.27244Z"
                                                                    fill="#4A8858" />
                                                            </svg>
                                                        </span>
                                                        {{elements.charAt(0).toUpperCase() + elements.slice(1)}}
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </span>-->
                                </div>
                                <span v-if="is_free_plan == 0 && plan_status != 0">
                                    <!--<span v-if="payment_mode === 'Card'">-->
                                        <span v-if="plan_status === 1">
                                            <span v-if="is_free_Trial(i)">
                                                {{i18n("Charging on")}}
                                            </span>
                                            <span v-else>
                                                {{i18n("Renews On")}}
                                            </span>
                                        </span>
                                        <span v-else-if="plan_status === 3">
                                        {{i18n("Renewal Pending since")}}
                                        </span>
                                        <span v-else>
                                            {{i18n("Valid Till")}}
                                        </span>&nbsp;
                                    <!-- </span>
                                    <span v-else-if="plan_status === 3">
                                        {{i18n("Renewal Pending since")}}
                                    </span>
                                    <span v-else>
                                        {{i18n("Valid Till")}}
                                    </span>-->
                                    {{next_billing_date}}
                                </span>
                                <span v-else></span>
                                <span class="span-green cancelspan" v-if="plan_status === 2">{{i18n("Cancelled")}}</span>
                                <span class="text-danger" v-if="plan_status === 0">{{i18n("Expired")}}</span>
                                <span class="span-green freespan" v-if="is_free_Trial(i)">{{i18n("On Free Trial")}}</span>
                                <span class="span-green activespan" v-if="plan_status === 1 && !is_free_Trial(i)">{{i18n("Active")}}</span>
                                <span class="span-green activespan" v-if="plan_status === 3">{{i18n("Renewal Pending")}}</span>
                                <!--<p class="plandate">Valid till {{next_billing_date}}</p>-->
                                <div class="btn-plns" v-if="(plan_status === 1 || plan_status === 3) && !is_third_party_gateway">
                                    <button type="button" class="primary-button acrd-btn cancelplan-btn"
                                        @click="openAccountCancellationModal(subscription_uuid)">
                                        {{i18n("Cancel Plan")}}
                                    </button>
                                    <!--<button type="button" class="primary-button changeplan-btn plans">Change Plan</button>-->
                                </div>
                                <div class="btn-plns w-200" v-else>
                                    <span v-if="plan_status === 2 && cancel_reason_type === 7" class="text-muted">
                                        <span class="text-danger">{{i18n('Note')}} : </span>
                                        {{i18n(cancel_additional_message)}}
                                    </span>
                                    <span v-else style="user-select: none;visibility: hidden;">{{i18n('Cancel Plan')}}</span>
                                </div>
                            </div>
                            <account_cancellation_modal :label9="$attrs['label9']" :label10="$attrs['label10']" :label11="$attrs['label11']" />
                        </div>
                    </div>
                </div>
                <template v-if="is_test_gateway || (is_non_hosted_gateway && !is_carrier_billing)">
                    <div class="card mb-3">
                        <div class="card-header" id="headingTwo">
                            <h5 class="mb-0">
                            <button class="btn btn-link small-text collapsed pl-5 text-left" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <i class="fa-regular fa-credit-card"></i><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param> <span><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></span>
                            </button>
                            </h5>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                            <div class="card-body form-div">
                                 <div class="card-info-child">
                                    <div class="blank-card-info" v-if="cards.length == 0">
                                        <p>
                                            <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param><br />
                                            <vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param>
                                        </p>
                                        <button class="primary-button acrd-btn" type="button" @click="openAddModal">
                                            <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                                        </button>
                                    </div>
                                    <!-- Blank Card End Here-->
                                    <!--card Information Start Here-->
                                    <div class="card-information" v-else>
                                    <!--Loop Section start Here-->
                                    <div class="box" v-for="card in cards">
                                        <div class="card-icon">
                                            <a href="javascript:void(0);" class="callByAjax" v-if="card.brand">
                                                <img :src="getRootUrl() + 'img/' + card.brand.toLowerCase().replace(/\\s/g, '-') + '.svg'" :alt="card.brand" class="mw-100" />
                                            </a>
                                        </div>
                                        <div class="card-number">
                                            <p class="pb-1">{{i18n('Card ending in')}} **** {{card.last4}}</p>
                                            <p class="pb-0">{{card.name}}</p>
                                            <span class="Primary" v-if='card.is_primary == 1'>
                                                <vd-component-param class="primary-cards primary-card-green" type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
                                            </span>
                                            <span>
                                                <p class="pb-0" style="color:white;" v-if='card.is_primary == 0'>
                                                    <a
                                                        class="callByAjax mw-100"
                                                        href="javascript:void(0);"
                                                        style="font-size:13px;color:#7B8794;text-decoration:none;"
                                                        @click="openConfirm(card.card_uuid, 'makedefault');"
                                                    >
                                                        <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
                                                    </a>
                                                    <a class="callByAjax" href="javascript:void(0);" @click="openConfirm(card.card_uuid, 'delete')">
                                                        <img :src="getRootUrl() + 'img/trash_full.png'" alt="about us" class="mw-100" />
                                                    </a>
                                                </p>
                                            </span>
                                        </div>
                                    </div>
                                    <!--Loop Section End Here-->
                                    <!--Button Start Here-->
                                    <div class="addnew-card anc-new">
                                        <button type="button" class="primary-button acrd-btn" @click="openAddModal">
                                            <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                                        </button>
                                    </div>
                                    <!--Button End Here-->
                                </div>
                                <!--card Information End Here-->
                            </div>
                            <!--Dashboard section End Here-->
                            <!--Delete Card Popup Start Here-->
                            <confirm-modal
                                :ref="setConfirmModal"
                                :title="modal_title"
                                :message="modal_message"
                                :modal_type="modal_type"
                                dismisstext="Dismiss"
                                proceedtext="Proceed"
                                @dismiss="dismissConfirm"
                                @proceed="proceedWith"
                                >
                            </confirm-modal>
                             <!--Delete Card Popup End Here-->
                            <!--Add New Card Popup Start Here-->
                            <div ref="add_modal_el" class="modal fade bd-example-modal-lg addnew-card-popup" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <section class="add-new-card-section">
                                                <h2><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></h2>
                                                <p class="ancs-text">
                                                    <vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param>
                                                </p>
                                                <div class="from-section" v-if="card_form.length > 0">
                                                    <form class="form-div" name="cardform" @submit.prevent="saveCard" novalidate>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pr-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Name on Card')}} <span>*</span></label>
                                                                    <input :type="card_form[0].field"
                                                                        :class="['form-control', v$.form[card_form[0].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[0].placeholder)"
                                                                        v-model="form[card_form[0].input]" @copy.prevent @paste.prevent
                                                                        @cut.prevent autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[0].input].$error">
                                                                        {{i18n(v$.form[card_form[0].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pl-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Card Details')}} <span>*</span></label>
                                                                    <input name="card-number" :type="card_form[1].field"
                                                                        :class="['form-control', v$.form[card_form[1].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[1].placeholder)"
                                                                        v-model="form[card_form[1].input]" v-ccnumber @copy.prevent
                                                                        @paste.prevent @cut.prevent autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[1].input].$error">
                                                                        {{i18n(v$.form[card_form[1].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pr-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Expiry')}} <span>*</span></label>
                                                                    <input name="card-expiry" :type="card_form[2].field"
                                                                        :class="['form-control', v$.form[card_form[2].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[2].placeholder)" @input="setExpiry"
                                                                        v-ccexpiry @copy.prevent @paste.prevent @cut.prevent
                                                                        autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[2].input].$error">
                                                                        {{i18n(v$.form[card_form[2].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pl-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Card CVV')}} <span>*</span></label>
                                                                    <input :type="card_form[3].field"
                                                                        :class="['form-control', v$.form[card_form[3].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n('Security code')"
                                                                        v-model="form[card_form[3].input]" v-cccvc @copy.prevent
                                                                        @paste.prevent @cut.prevent autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[3].input].$error">
                                                                        {{i18n(v$.form[card_form[3].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pr-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Country')}} <span>*</span></label>
                                                                    <input :type="card_form[7].field"
                                                                        :class="['form-control', v$.form[card_form[7].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[7].placeholder)"
                                                                        v-model="form[card_form[7].input]" autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[7].input].$error">
                                                                        {{i18n(v$.form[card_form[7].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pl-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('State/Province')}} <span>*</span></label>
                                                                    <input :type="card_form[6].field"
                                                                        :class="['form-control', v$.form[card_form[6].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[6].placeholder)"
                                                                        v-model="form[card_form[6].input]" autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[6].input].$error">
                                                                        {{i18n(v$.form[card_form[6].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pr-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('City')}} <span>*</span></label>
                                                                    <input :type="card_form[9].field"
                                                                        :class="['form-control', v$.form[card_form[9].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[9].placeholder)"
                                                                        v-model="form[card_form[9].input]" autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[9].input].$error">
                                                                        {{i18n(v$.form[card_form[9].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pr-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Zip Code')}} <span>*</span></label>
                                                                    <input :type="card_form[8].field"
                                                                        :class="['form-control', v$.form[card_form[8].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[8].placeholder)"
                                                                        v-model="form[card_form[8].input]" maxlength="12"
                                                                        autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[8].input].$error">
                                                                        {{i18n(v$.form[card_form[8].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pr-9">
                                                                <div class="form-group">
                                                                    <label>{{i18n('Address')}} <span>*</span></label>
                                                                    <input :type="card_form[4].field"
                                                                        :class="['form-control', v$.form[card_form[4].input].$error ? 'error-fild' : '']"
                                                                        :placeholder="i18n(card_form[4].placeholder)"
                                                                        v-model="form[card_form[4].input]" autocomplete="off" />
                                                                    <p class="error-msg mb-0 mt-1" v-if="v$.form[card_form[4].input].$error">
                                                                        {{i18n(v$.form[card_form[4].input].$errors[0].$message)}}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 pl-0">
                                                            <p class="ancs-text" v-if="tokenization_amount > 0">
                                                                <vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param> {{default_currency}} ({{default_currency_symbol}} {{tokenization_amount}}) <vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param>
                                                            </p>
                                                        </div>
                                                        <div class="text-right mt-4">
                                                            <button type="button" class="btn dismiss" @click="closeAddModal">
                                                                <vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param>
                                                            </button>
                                                            <button type="submit" class="btn addbutton" v-html="i18n('Add')"></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>
                <div class="card mb-3" v-if="!is_third_party_gateway">
                    <div class="card-header" id="headingThree">
                        <h5 class="mb-0">
                        <button class="btn btn-link small-text collapsed pl-5 text-left" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <i class="fa fa-basket-shopping"></i><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                        </button>
                        </h5>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                        <div class="card-body form-div">
                            <!--Table start Here-->
                            <div class="row ph-row" v-if="paymentHistoryList.length != 0">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                    <div class="purches-history">
                                        <div class="table-responsive-lg">
                                            <table class="table">
                                                <tbody>
                                                    <tr v-for="paymentHistory in paymentHistoryList">
                                                        <td>{{paymentHistory.item_name}}</td>
                                                        <td>{{paymentHistory.transaction_date}} UTC</td>
                                                        <td>
                                                            <span>{{i18n("Order ID")}} {{paymentHistory.order_uuid}}</span><br>
                                                            <span v-if="paymentHistory.transaction_status == 'Success' ">{{i18n("Transaction ID")}} {{paymentHistory.transaction_uuid}}</span>
                                                        </td>
                                                        <td class="status paid" v-if="paymentHistory.transaction_status == 'Success' ">
                                                            {{i18n("Paid")}}</td>
                                                        <td class="status unpaid" v-else-if="paymentHistory.transaction_status == 'Failed' ">
                                                            {{paymentHistory.transaction_status}}</td>
                                                        <td v-if="paymentHistory.transaction_status == 'Success' ">
                                                                <a class="callByAjax" href="javascript:void(0);"
                                                                    @click="viewInvoiceDetails(paymentHistory.order_uuid)">
                                                                    <!-- <i class="fas fa-download"></i>-->
                                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M14 10V12.6667C14 13.0203 13.8595 13.3594 13.6095 13.6095C13.3594 13.8595 13.0203 14 12.6667 14H3.33333C2.97971 14 2.64057 13.8595 2.39052 13.6095C2.14048 13.3594 2 13.0203 2 12.6667V10"
                                                                            stroke="white" stroke-opacity="0.48" stroke-width="1.33"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path d="M4.66406 6.66797L7.9974 10.0013L11.3307 6.66797" stroke="white"
                                                                            stroke-opacity="0.48" stroke-width="1.33" stroke-linecap="round"
                                                                            stroke-linejoin="round" />
                                                                        <path d="M8 10V2" stroke="white" stroke-opacity="0.48"
                                                                            stroke-width="1.33" stroke-linecap="round"
                                                                            stroke-linejoin="round" />
                                                                    </svg>
                                                                </a>&nbsp;
                                                                    <vd-component-param type="label14"
                                                                        v-html="i18n($attrs['label14'])"></vd-component-param>
                                                        </td>
                                                        <td v-else></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                </div>
                            <!--Table End Here-->
                            <!--No Records Found start here-->
                            <div class="no-result-found ph-row" v-else>
                                <div class="container-fluid">
                                    <div class="row justify-content-center">
                                        <div class="col-md-8">
                                            <div class="w-100 text-center">
                                                <img :src="getRootUrl() +'img/no-result.gif'" alt="no result" class="mw-100" />
                                                <h3>
                                                    <vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- No Records Found End Here-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
         <!--All plan starts Here-->
        <div class="new-all-plans-page" v-if="show_device === 'showplan'">
            <div class="row">
                <div class="col-lg-8 col-md-12 col-12">
                    <div class="plan-area" v-if="is_subscription_enabled">
                        <h1 class="dashboard-heading white-color mbottom-20">
                            <span class="span-backarrow" @click="backTo()">
                                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M9.5026 20.7341L0.702604 11.9341C0.569271 11.8008 0.474604 11.6563 0.418604 11.5008C0.363493 11.3452 0.335938 11.1785 0.335938 11.0008C0.335938 10.823 0.363493 10.6563 0.418604 10.5008C0.474604 10.3452 0.569271 10.2008 0.702604 10.0674L9.5026 1.26743C9.74705 1.02298 10.0524 0.894983 10.4186 0.883428C10.7857 0.872761 11.1026 1.00076 11.3693 1.26743C11.6359 1.51187 11.775 1.81721 11.7866 2.18343C11.7973 2.55054 11.6693 2.86743 11.4026 3.13409L4.86927 9.66743H19.7693C20.147 9.66743 20.4639 9.79498 20.7199 10.0501C20.975 10.3061 21.1026 10.623 21.1026 11.0008C21.1026 11.3785 20.975 11.695 20.7199 11.9501C20.4639 12.2061 20.147 12.3341 19.7693 12.3341H4.86927L11.4026 18.8674C11.647 19.1119 11.775 19.423 11.7866 19.8008C11.7973 20.1785 11.6693 20.4896 11.4026 20.7341C11.1582 21.0008 10.847 21.1341 10.4693 21.1341C10.0915 21.1341 9.76927 21.0008 9.5026 20.7341Z"
                                        fill="#7B8794" />
                                </svg>
                            </span>
                            {{i18n("All Plans")}}
                        </h1>
                    
                            <div class="row" v-if="is_subscription_enabled">
                                <div class="col-md-12" v-for="(itemData,index) in myPlan">
                                    <input class="form-check-input" type="radio" :id="itemData.subscription_plan_uuid"
                                        @click="selectedPlan(index, itemData)" :checked="selectedindex == index" @change="(e) => {
                                                    if(promocode) validatePromocode(promocode);
                                                }">
                                    <label class="single-plan" :for="itemData.subscription_plan_uuid"
                                        :class="{ 'selected-plan': (selectedindex == index) }">
                                        <div class="row justify-content-between align-items-center">
                                            <div class="col-md-auto col-sm-auto col-xs-12 plan-d">
                                                <div class="plan-d-1">
                                                    <div class="plan-time">{{itemData.plan_name.toUpperCase()}}
                                                        <span class="svg position-relative" v-if="itemData.plan_description">
                                                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M7.0026 0.582031C3.45885 0.582031 0.585938 3.45495 0.585938 6.9987C0.585938 10.5424 3.45885 13.4154 7.0026 13.4154C10.5464 13.4154 13.4193 10.5424 13.4193 6.9987C13.4193 3.45495 10.5464 0.582031 7.0026 0.582031ZM6.71094 3.4987C6.55623 3.4987 6.40785 3.56016 6.29846 3.66955C6.18906 3.77895 6.1276 3.92732 6.1276 4.08203C6.1276 4.23674 6.18906 4.38511 6.29846 4.49451C6.40785 4.60391 6.55623 4.66536 6.71094 4.66536H7.0026C7.15731 4.66536 7.30569 4.60391 7.41508 4.49451C7.52448 4.38511 7.58594 4.23674 7.58594 4.08203C7.58594 3.92732 7.52448 3.77895 7.41508 3.66955C7.30569 3.56016 7.15731 3.4987 7.0026 3.4987H6.71094ZM5.83594 5.83203C5.68123 5.83203 5.53285 5.89349 5.42346 6.00289C5.31406 6.11228 5.2526 6.26065 5.2526 6.41536C5.2526 6.57007 5.31406 6.71845 5.42346 6.82784C5.53285 6.93724 5.68123 6.9987 5.83594 6.9987H6.41927V8.7487H5.83594C5.68123 8.7487 5.53285 8.81016 5.42346 8.91955C5.31406 9.02895 5.2526 9.17732 5.2526 9.33203C5.2526 9.48674 5.31406 9.63511 5.42346 9.74451C5.53285 9.85391 5.68123 9.91536 5.83594 9.91536H8.16927C8.32398 9.91536 8.47235 9.85391 8.58175 9.74451C8.69115 9.63511 8.7526 9.48674 8.7526 9.33203C8.7526 9.17732 8.69115 9.02895 8.58175 8.91955C8.47235 8.81016 8.32398 8.7487 8.16927 8.7487H7.58594V6.41536C7.58594 6.26065 7.52448 6.11228 7.41508 6.00289C7.30569 5.89349 7.15731 5.83203 7.0026 5.83203H5.83594Z"
                                                                    fill="#BBBBBB" fill-opacity="0.6" />
                                                            </svg>
                                                            <div class="hover-tooltip">
                                                                <div class="inner-tooltip position-relative">
                                                                    <ul>
                                                                        <li>
                                                                            <span class="mr-2">
                                                                                <svg width="15" height="16" viewBox="0 0 15 16"
                                                                                    fill="none"
                                                                                    xmlns="http://www.w3.org/2000/svg">
                                                                                    <path fill-rule="evenodd"
                                                                                        clip-rule="evenodd"
                                                                                        d="M13.4862 3.27244C13.6697 3.09081 13.8807 3 14.1193 3C14.3578 3 14.5688 3.09081 14.7523 3.27244C14.9174 3.4359 15 3.64022 15 3.88542C15 4.13061 14.9174 4.33494 14.7523 4.4984L5.97248 13.2436C5.95413 13.2618 5.93578 13.2799 5.91743 13.2981C5.89908 13.3162 5.88073 13.3344 5.86238 13.3526C5.69725 13.5342 5.49083 13.625 5.24312 13.625C4.99541 13.625 4.78899 13.5342 4.62385 13.3526L0.247706 9.04808C0.082568 8.88461 0 8.68029 0 8.4351C0 8.1899 0.082568 7.98558 0.247706 7.82212C0.431194 7.64049 0.642201 7.54968 0.880734 7.54968C1.11927 7.54968 1.33027 7.64049 1.51376 7.82212L5.22936 11.5L13.4862 3.27244Z"
                                                                                        fill="#4A8858" />
                                                                                </svg>
                                                                            </span>
                                                                            {{displayDescription(itemData.plan_description)}}
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </span>
                                                    </div>
                                                    <div class="d-flex align-items-center justify-content-start" v-if="itemData.is_free_plan == 0">
                                                        <!--<div class="active-text-area mr-2 " :class="(isSelected && selectedindex == index)? 'selected' : ''" v-if="selectedindex == index"> Active </div>-->
                                                        <div class="free-plan"
                                                            v-if="itemData.price[0].plan_free_trial_interval === 0">{{i18n("No free trial!")}}</div>
                                                        <div class="free-plan"
                                                            v-else-if="itemData.price[0].plan_free_trial_interval === 1">{{i18n("First")}} {{itemData.price[0].plan_free_trial_interval}} {{i18n(itemData.price[0].plan_free_trial_unit)}} {{i18n("is free!")}}</div>
                                                        <div class="free-plan" v-else>{{i18n("First")}}
                                                            {{itemData.price[0].plan_free_trial_interval}}
                                                            {{i18n(itemData.price[0].plan_free_trial_unit)}}{{language_code ==='en' ? 's' : ''}} {{i18n("are free!")}}</div>
                                                    </div>
                                                </div>
                                                <!--<div class="plan-d-2">
                                                    <span class="plan-d-txt position-relative">{{i18n("Plan Details")}}
                                                        <div class="plan-d-list hover-tooltip">
                                                            <div class="inner-tooltip position-relative">
                                                                <ul>
                                                                    <li v-for="(elements, inDx) in contentList[index]" :class="[types.includes(elements) ? 'fw-bold' : '']">
                                                                        <span class="mr-2">
                                                                            <svg width="15" height="16" viewBox="0 0 15 16"
                                                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                                    d="M13.4862 3.27244C13.6697 3.09081 13.8807 3 14.1193 3C14.3578 3 14.5688 3.09081 14.7523 3.27244C14.9174 3.4359 15 3.64022 15 3.88542C15 4.13061 14.9174 4.33494 14.7523 4.4984L5.97248 13.2436C5.95413 13.2618 5.93578 13.2799 5.91743 13.2981C5.89908 13.3162 5.88073 13.3344 5.86238 13.3526C5.69725 13.5342 5.49083 13.625 5.24312 13.625C4.99541 13.625 4.78899 13.5342 4.62385 13.3526L0.247706 9.04808C0.082568 8.88461 0 8.68029 0 8.4351C0 8.1899 0.082568 7.98558 0.247706 7.82212C0.431194 7.64049 0.642201 7.54968 0.880734 7.54968C1.11927 7.54968 1.33027 7.64049 1.51376 7.82212L5.22936 11.5L13.4862 3.27244Z"
                                                                                    fill="#4A8858" />
                                                                            </svg>
                                                                        </span>
                                                                        {{elements.charAt(0).toUpperCase() + elements.slice(1)}}
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>-->
                                            </div>

                                            <div v-if="itemData.is_free_plan == 0" class="col-md-auto col-sm-auto col-xs-12 mt-3 mt-sm-0"
                                                v-for="price of itemData.price">
                                                <div class="plan-price">
                                                    {{price.currency_symbol}}{{price.subscription_plan_price.toFixed(2)}}
                                                </div>
                                                <div class="billed-time mt-1">/{{price.plan_interval}}
                                                    {{i18n(price.plan_interval_unit)}}{{language_code ==='en' ? '(s)' : ''}} </div>
                                            </div>
                                            <div v-else class="col-md-auto col-sm-auto col-xs-12 mt-3 mt-sm-0">
                                                <div class="plan-price">
                                                    {{i18n('Free')}}
                                                </div>
                                                <div class="billed-time mt-1">/
                                                    {{i18n('No Bill')}}</div>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-12 mt-5">
                        <div class="final-amount-area mt-md-3 mt-lg-1 pos-sticky">
                            <div class="newpromo-code-area">
                            <div v-if="is_promotion_enabled && isFreePlan == 0 && !is_multiple_gateway">
                                    <label class="label-text d-block">{{i18n("Promo Code")}}</label>
                                    <div class="input-btn-grp">
                                        <input type="search" class="form-control input-promocode" v-model="promocode"
                                        :placeholder="i18n('Enter code here')" aria-label="promo code"
                                            aria-describedby="button-addon2">
                                        <button class="apply-promocode btn" type="button" @click="validatePromocode(promocode)"
                                            :disabled="promocode.length === 0 || this.applied_promocode.length > 0"
                                            :style="[(promocode.length === 0 || this.applied_promocode.length > 0) ? 'pointer-events: none;' : '']">
                                            {{i18n("Apply")}}
                                        </button>
                                    </div>
                                    <div class="apply-confirm-text" :class="{'text-danger' : applied_promocode_type === 0}">
                                        {{i18n(promocode_message)}}</div>
                                    <div class="border-line"></div>
                                </div>
                                <template v-if = "selected_plan_tax_type === 1">
                                <div class="d-flex justify-content-between align-items-center"
                                :class="{'mt-4' : (is_promotion_enabled && isFreePlan == 0 && !is_multiple_gateway)}">
                                        <div class="plan-price-text">{{i18n("Plan Price(Exclusive of tax)")}}</div>
                                        <div class="plan-price-number" v-if="isFreePlan == 0">
                                            {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                        <div class="plan-price-number" v-else>{{i18n('Free')}}</div>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center mt-2"
                                        :class="{'mt-4' : (is_promotion_enabled && isFreePlan == 0 && !is_multiple_gateway)}">
                                        <div class="plan-price-text">{{selected_plan_tax_name}}({{selected_plan_tax_rate}}%)</div>
                                        <div class="plan-price-number">{{selected_plan_currency_symbol}}{{selected_plan_tax_amount}}</div>
                                    </div>
                                    
                                </template>

                                <template v-else-if ="selected_plan_tax_type === 2">
                                <div class="d-flex justify-content-between align-items-center"
                                :class="{'mt-4' : (is_promotion_enabled && isFreePlan == 0 && !is_multiple_gateway)}">
                                        <div class="plan-price-text">{{i18n("Plan Price(Inclusive of tax)")}}</div>
                                        <div class="plan-price-number" v-if="isFreePlan == 0">
                                            {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                        <div class="plan-price-number" v-else>{{i18n('Free')}}</div>
                                    </div>
                                </template>

                                <template v-else>
                                <div class="d-flex justify-content-between align-items-center"
                                :class="{'mt-4' : (is_promotion_enabled && isFreePlan == 0 && !is_multiple_gateway)}">
                                        <div class="plan-price-text">{{i18n("Plan Price")}}</div>
                                        <div class="plan-price-number" v-if="isFreePlan == 0">
                                            {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                        <div class="plan-price-number" v-else>{{i18n('Free')}}</div>
                                    </div>
                                </template>
                           
                                <!-- <div class="d-flex justify-content-between align-items-center mt-2">
                                    <div class="plan-price-text">Tax (0%)</div>
                                    <div class="plan-price-number">+ $0.00</div>
                                </div> -->
                                <div class="d-flex justify-content-between align-items-center mt-2" v-if="applied_promocode">
                                    <div class="plan-price-text" v-if="applied_promocode_type === 1">{{i18n("Coupon Discount")}}({{coupon_discount}})</div>
                                    <div class="plan-price-text" v-if="applied_promocode_type === 2">{{i18n("Voucher Discount")}}(100%)</div>
                                    <div class="plan-price-number" v-if = "applied_promocode_type === 1">- {{selected_plan_currency_symbol}}{{coupon_discount_amount}}</div>
                                    <div class="plan-price-number" v-if = "applied_promocode_type === 2">- {{selected_plan_currency_symbol}}{{selected_plan_price}}</div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mt-4">
                                    <div class="plan-total-text">{{i18n("Final Amount")}}</div>
                                    <div class="plan-total-number" v-if="applied_promocode_type == 2">{{selected_plan_currency_symbol}}0
                                    </div>
                                    <div class="plan-total-number" v-else-if="isFreePlan == 0">
                                        {{selected_plan_currency_symbol}}{{selected_plan_tax_type === 1 ? selected_plan_final_amount : (selected_plan_price - coupon_discount_amount).toFixed(2)}}</div>
                                    <div class="plan-total-number" v-else>{{i18n('Free')}}</div>
                                </div>
                            </div>
                            <div class="checkout-btn-area mt-3">
                                <button type="button" class="checkout-btn"
                                    @click="internalCheckout(selectedindex, selected_plan)"
                                    v-if="this.applied_promocode_type === 2 || isFreePlan == 1">
                                    {{i18n("Activate")}}
                                </button>
                                <button type="button" class="checkout-btn"
                                    @click="redirectCheckout(selectedindex, selected_plan)" v-else>
                                    {{i18n("Proceed to checkout")}}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blank-card-info" v-if="!is_subscription_enabled">
                    <p>
                        <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                    </p>
                </div>
            </div>
            <!--Choose Your plan End Here-->
        </div>
    </div>    
    </vd-component>

    `,

    components: {
        account_cancellation_modal: defineAsyncComponent(() => import(window.importAssetJs('js/modals/account-cancellation-modal.js'))),
        ConfirmModal: defineAsyncComponent(() => import(window.importAssetJs('js/modals/confirm-modal.js')))

    },
    props: {
        tab: String
    },

    setup(props) {
        const tab = props.tab;
        return { tab };
    },
    setup() {
        return {
            v$: useVuelidate()
        };
    },
    validations() {
        if (this.card_form.length > 0) {
            let form = {

            };

            for (let i = 0; i < this.card_form.length; i++) {
                form[this.card_form[i].input] = {};

                form[this.card_form[i].input]['$autoDirty'] = true;

                let validators = this.card_form[i].validation;
                for (let j = 0; j < validators.length; j++) {
                    if (validators[j].name === 'is_not_null') {
                        form[this.card_form[i].input]['ccrequired'] = helpers.withMessage(validators[j].message, (value) => {
                            let regex = new RegExp(validators[j].pattern);
                            let val = value.toString().replace(/\s+|-/g, '');
                            return regex.test(val);
                        });
                    } else if (validators[j].name === 'is_alphabet') {
                        form[this.card_form[i].input]['ccalpha'] = helpers.withMessage(validators[j].message, (value) => {
                            let regex = new RegExp(validators[j].pattern);
                            let val = value.toString().replace(/\s+|-/g, '');
                            return regex.test(val);
                        });
                    } else if (validators[j].name === 'is_numeric') {
                        form[this.card_form[i].input]['ccnumeric'] = helpers.withMessage(validators[j].message, (value) => {
                            let regex = new RegExp(validators[j].pattern);
                            let val = value.toString().replace(/\s+|-/g, '');
                            return regex.test(val);
                        });
                    } else if (validators[j].name === 'is_min_length') {
                        form[this.card_form[i].input]['ccminlength'] = helpers.withMessage(validators[j].message, (value) => {
                            let regex = new RegExp(validators[j].pattern);
                            let val = value.toString().replace(/\s+|-/g, '');
                            return regex.test(val);
                        });
                    } else if (validators[j].name === 'is_max_length') {
                        form[this.card_form[i].input]['ccmaxlength'] = helpers.withMessage(validators[j].message, (value) => {
                            let regex = new RegExp(validators[j].pattern);
                            let val = value.toString().replace(/\s+|-/g, '');
                            return regex.test(val);
                        });
                    }
                }

                if (this.card_form[i].input === 'card_expiry') {
                    form[this.card_form[i].input]['alreadyexpired'] = helpers.withMessage('Invalid expiry month or year', (value) => {
                        return moment(value, "MM / YY").isBefore(moment(current, "MM / YY")) ? false : true;
                    });
                }
            }

            return {
                form
            };
        }
    },
    data() {
        return {
            is_user_subscribed: false,
            valid: false,
            show_device: 'billing_and_purchases_seven',
            my_plans: [],
            subscription_plans: [],
            noPlanMsg: '',
            planlist: [],
            ActivePlan: false,
            myPlan: [],
            selectedPlanIndex: Number,
            selectedindex: Number,
            isSelected: false,
            isActive: false,
            planDetail: {
                plan_uuid: "",
                pricing_uuid: "",
                billing_type: 2,
                //87419 Raj
                promo_code: "",
                promo_type: ""
            },
            countryCode: 'US',
            name: '',
            cards: [],
            card_form: [],
            selected_card_uuid: null,
            selected_operation: null,
            modal_title: '',
            modal_message: '',
            modal_type: '',
            tokenization_amount: 0,
            default_currency: "",
            default_currency_symbol: "",
            form: {
                card_uuid: '',
                card_name: '',
                card_number: '',
                card_expiry: '',
                card_cvv: '',
                address1: '',
                address2: '',
                state: '',
                country: '',
                zip: '',
                city: ''
            },
            confirm_modal_el: null,
            message: '',
            paymentHistoryList: [],
            invoiceHtml: "",
            apiResponse: {},
            //87419 Raj
            selected_plan: {},
            selected_plan_price: 0.00,
            //92032 Sidhhant start
            selected_plan_tax_uuid: "",
            selected_plan_tax_amount: 0.00,
            selected_plan_tax_rate: 0.00,
            selected_plan_tax_name: "",
            selected_plan_tax_type: null,
            selected_plan_final_amount: 0.00,
            //92032 Sidhhant end
            selected_plan_promo_discount: 0.00,
            selected_plan_currency_symbol: '$',
            promocode: '',
            promocode_message: '',
            applied_promocode: '',
            applied_promocode_type: 0,
            contentList: [],
            contentListMyPlan: [],
            types: ['cast', 'group', 'content type', 'category'],
            language_code: 'en',
            isFreePlan: 0,
            //87269 Raj
            coupon_discount: '',
            coupon_discount_amount: 0.00,
        };
    },
    computed: {
        ...mapGetters({
            is_subscription_enabled: 'is_subscription_enabled',
            is_non_hosted_gateway: 'is_non_hosted_gateway',
            is_test_gateway: 'is_test_gateway',
            is_carrier_billing: 'is_carrier_billing',
            //Sanjeev 104785
            is_third_party_gateway: 'is_third_party_gateway',
            //87419 Raj
            is_promotion_enabled : 'is_promotion_enabled',
            is_multiple_gateway: 'is_multiple_gateway'

        }),
        ...mapState({
            show_account_cancellation_modal: state => state.show_account_cancellation_modal
        }),
        username() {
            return this.name;
        },
        is_subscribed() {
            if (this.my_plans.length > 0) {
                return this.my_plans.some(obj => obj.hasOwnProperty('plan_status') && obj['plan_status'] === 1);
            } else {
                return false;
            }
        },
        is_cancelled() {
            if (this.my_plans.length > 0) {
                return this.my_plans.some(obj => obj.hasOwnProperty('plan_status') && obj['plan_status'] === 2);
            } else {
                return false;
            }
        },
        is_expired() {
            if (this.my_plans.length > 0) {
                return this.my_plans.some(obj => obj.hasOwnProperty('plan_status') && obj['plan_status'] === 0);
            } else if (this.my_plans.length === 0) {
                return true;
            } else {
                return false;
            }
        },
        is_renews_on_panding() {
            if (this.my_plans.length > 0) {
                return this.my_plans.some(obj => obj.hasOwnProperty('plan_status') && obj['plan_status'] === 3);
            } else {
                return false;
            }
        },
    },
    watch: {
        show_device(newValue) {
            this.svgnCloseOpen();
        },
        async show_account_cancellation_modal(cv) {
            if (!cv) {
                const my_plans_response = await getMyPlan();
                if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
                    this.my_plans = my_plans_response.data.data.myPlans.my_plans_list;
                } else {
                    this.noPlanMsg = my_plans_response.data.message;
                }
            }
        },
        //87419 Raj, 87269 Raj
        selected_plan() {
            return this.selected_plan;
        },
        applied_promocode_type() {
            return this.applied_promocode_type;
        },
        promocode() {
            if (!this.promocode) {
                this.promocode = '';
                this.applied_promocode = '';
                this.promocode_message = '';
                this.applied_promocode_type = 0;
                this.coupon_discount = '';
                this.coupon_discount_amount = 0.00;
            }
        },
    },
    methods: {
        getRootUrl,
        i18n,
        backTo() {
            this.show_device = "billing_and_purchases_seven";
            this.resetPromocode();
        },
        async subscriptionPlanContent(newValue) {
            if (newValue) {
                if (newValue.is_specific_plan == 1 && newValue.is_bulk_content == 0) {
                    if (newValue.content_uuIds.length > 0) {
                        return this.getContentByContentUuid(newValue.content_uuIds.join(','));
                    }
                } else if (newValue.is_specific_plan == 1 && newValue.is_bulk_content == 1) {
                    if (newValue.bulk_content_pattern) {
                        newValue.bulk_content_pattern = newValue.bulk_content_pattern.replaceAll('"key"', 'key').replaceAll('"value"', 'value').replaceAll('"operator"', 'operator');
                        return this.getvalidateContentPatterns(newValue.bulk_content_pattern);
                    }
                } else {
                    return ['All Content'];
                }
            }
        },
        async getContentByContentUuid(contentUUids) {
            let contentLists = [];
            if (contentUUids) {
                let res = await getContentByContentUuid(contentUUids).then(res => {
                    if (res.data.status === "SUCCESS") {
                        const content_list = res.data.data.contentList.content_list;
                        content_list.forEach(obj => {
                            contentLists.push(obj.content_name);
                        });
                    } else {
                        contentLists = ['No Detail Found'];
                    }
                });
            }
            return contentLists;
        },
        async getvalidateContentPatterns(pattern) {
            let contentLists = [];
            if (pattern) {
                const response = await getvalidateContentPattern(pattern);
                if (
                    response.data.code == 200 &&
                    response.data.data.validateContentPattern
                ) {
                    response.data.data.validateContentPattern.data.forEach(obj => {
                        if (contentLists.length == 0 || !contentLists.includes(obj.type)) {
                            contentLists.push(obj.type);
                            contentLists.push(obj.value);
                        } else if (contentLists.includes(obj.type)) {
                            contentLists.push(obj.value);
                        }
                    });
                } else {
                    contentLists = ['No Detail Found'];
                }
            }
            return contentLists;
        },
        is_free_Trial(i) {
            const plan = this.my_plans[i];
            if (plan.plan_free_trial_unit === 'Day' && plan.plan_free_trial_interval > 0) {
                const subscriptionDate = new Date(plan.subscription_start_date);
                subscriptionDate.setDate(subscriptionDate.getDate() + plan.plan_free_trial_interval);
                const nextBillingDate = new Date(plan.next_billing_date);
                subscriptionDate.setHours(0, 0, 0);
                nextBillingDate.setHours(0, 0, 0);
                if (subscriptionDate.getTime() === nextBillingDate.getTime() && plan.plan_status === 1) {
                    return true;
                } else {
                    return false;
                }
            } else if (plan.plan_free_trial_unit === 'Month' && plan.plan_free_trial_interval > 0) {
                const subscriptionDate = new Date(plan.subscription_start_date);
                subscriptionDate.setMonth(subscriptionDate.getMonth() + plan.plan_free_trial_interval);
                const nextBillingDate = new Date(plan.next_billing_date);
                subscriptionDate.setHours(0, 0, 0);
                nextBillingDate.setHours(0, 0, 0);
                if (subscriptionDate.getTime() === nextBillingDate.getTime() && plan.plan_status === 1) {
                    return true;
                } else {
                    return false;
                }
            }
        },
        displayDescription(plan_description) {
            if (plan_description.length > 500) {
                return plan_description.slice(0, 500).concat('...');
            } else {
                return plan_description;
            }
        },
        openAccountCancellationModal(subscription_uuid) {
            this.$store.dispatch(TOGGLE_ACCOUNT_CANCELLATION_MODAL, [true, subscription_uuid]);
        },

        checkPlan: function () {
            getMyPlan().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    JsLoadingOverlay.hide();
                    this.planlist = res.data.data.myPlans.my_plans_list;
                    this.planlist.forEach((elment) => {
                        //this.isActive = true;
                        if (elment.plan_status === 1) {
                            this.ActivePlan = elment;
                        } else if (elment.plan_status === 0) {
                            this.ActivePlan = elment;
                        }
                    });
                } else {
                    this.noPlanMsg = res.data.message;
                    JsLoadingOverlay.hide();
                }
            });
        },
        showPlan() {
            JsLoadingOverlay.show();
            this.showplan = true;
            this.getPlan();
            this.show_device = 'showplan';
        },
        getPlan: function () {
            getSubscriptionPlans(this.countryCode).then(async (res) => {
                if (res.data.code == 200 && res.data.status === "SUCCESS") {
                    const subscription = res.data.data.subscriptionPlans.subscription_plans_list;
                    /*let contentName = [];
                    for (const obj of subscription) {
                        let content = await this.subscriptionPlanContent(obj);
                        contentName.push(content);
                    }
                    this.contentList = contentName;*///It was commented because the Plan Detail is hidden.
                    this.myPlan = subscription;
                    this.myPlan.sort((obj1, obj2) => (obj2.hasOwnProperty('is_free_plan') && obj2.is_free_plan === 1 ? 1 : 0) - (obj1.hasOwnProperty('is_free_plan') && obj1.is_free_plan === 1 ? 1 : 0));
                    this.selectedindex = this.myPlan.findIndex(sp => sp.is_default === 1);
                    this.isSelected = true;
                    JsLoadingOverlay.hide();
                    //87419 Raj
                    this.selectedindex = this.selectedindex >= 0 ? this.selectedindex : 0;
                    this.selected_plan = this.myPlan[this.selectedindex];
                    this.isFreePlan = this.myPlan[this.selectedindex].is_free_plan;
                    this.selected_plan_price = this.myPlan[this.selectedindex].price[0].subscription_plan_price.toFixed(2);
                    this.selected_plan_currency_symbol = this.myPlan[this.selectedindex].price[0].currency_symbol;
                    //92032 Sidhhant
                    if (this.selected_plan.price[0].tax_data != null) {
                        this.selected_plan_tax_uuid = this.selected_plan.price[0].tax_data.tax_uuid;
                        this.selected_plan_tax_name = this.selected_plan.price[0].tax_data.tax_name;
                        this.selected_plan_tax_rate = this.selected_plan.price[0].tax_data.amount;
                        this.selected_plan_tax_amount = (this.selected_plan.price[0].subscription_plan_price * ((this.selected_plan_tax_rate) / 100)).toFixed(2);
                        this.selected_plan_tax_type = this.selected_plan.price[0].tax_data.tax_type;
                        this.selected_plan_final_amount = (this.selected_plan.price[0].subscription_plan_price + parseFloat(this.selected_plan_tax_amount)).toFixed(2);
                    }
                    else {
                        this.selected_plan_tax_uuid = null;
                        this.selected_plan_tax_name = "";
                        this.selected_plan_tax_rate = 0.00;
                        this.selected_plan_tax_amount = 0.00;
                        this.selected_plan_tax_type = null;
                        this.selected_plan_final_amount = this.selected_plan_price;
                    }

                }
                if ((res.data.code === 600 || res.data.code === 601) && res.data.status === "FAILED") {
                    JsLoadingOverlay.hide();
                } else {
                    JsLoadingOverlay.hide();
                }
            });
        },
        //87419 Raj
        selectedPlan: function (data, plan) {
            this.selectedindex = data;
            this.isSelected = true;
            this.selected_plan = plan,
                this.selected_plan_price = plan.price[0].subscription_plan_price.toFixed(2);

            this.selected_plan_promo_discount = 0.00;
            this.selected_plan_currency_symbol = plan.price[0].currency_symbol;
            this.isFreePlan = plan.is_free_plan;
            if(this.isFreePlan === 1){
                this.promocode = '';
            }
            //92032 Sidhhant
            if (plan.price[0].tax_data != null) {
                this.selected_plan_tax_uuid = plan.price[0].tax_data.tax_uuid;
                this.selected_plan_tax_name = plan.price[0].tax_data.tax_name;
                this.selected_plan_tax_rate = plan.price[0].tax_data.amount;
                this.selected_plan_tax_amount = (plan.price[0].subscription_plan_price * ((this.selected_plan_tax_rate / 100))).toFixed(2);
                this.selected_plan_tax_type = plan.price[0].tax_data.tax_type;
                this.selected_plan_final_amount = (plan.price[0].subscription_plan_price + parseFloat(this.selected_plan_tax_amount)).toFixed(2);

            }
            else {
                this.selected_plan_tax_uuid = null;
                this.selected_plan_tax_name = null;
                this.selected_plan_tax_rate = 0.00;
                this.selected_plan_tax_amount = 0.00;
                this.selected_plan_tax_type = null;
                this.selected_plan_final_amount = this.selected_plan_price;
            }

        },
        redirectCheckout(i, plan) {
            this.selectedPlanIndex = i + 1;
            if (localStorage.getItem('isloggedin') == "true") {
                const user = JSON.parse(window.localStorage.getItem("user"));
                const parts = user.name.split(' ');
                //92032 Sidhhant
                if (this.selected_plan_tax_uuid != null) {
                    this.planDetail = {
                        plan_uuid: plan.subscription_plan_uuid,
                        pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        billing_type: 2,
                        //87419 Raj
                        promo_code: this.applied_promocode,
                        promo_type: this.applied_promocode_type === 2 ? "voucher" : "coupon",
                        //92032 Sidhhant(set tax_uuid  : can be taxUuid or null)
                        tax_uuid: this.selected_plan_tax_uuid,
                        gateway_order: {
                            first_name: parts[0],
                            last_name: parts[1],
                            email: user.email,
                            subscription_plan_uuid: plan.subscription_plan_uuid,
                            plan_free_trial_interval: plan.price[0].plan_free_trial_interval,
                            subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                            cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                            return_url: window.location.origin + '/checkout-success?billing_type=2',
                            promo_code: this.applied_promocode
                        }
                    };
                }
                else {
                    this.planDetail = {
                        plan_uuid: plan.subscription_plan_uuid,
                        pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        billing_type: 2,
                        //87419 Raj
                        promo_code: this.applied_promocode,
                        promo_type: this.applied_promocode_type === 2 ? "voucher" : "coupon",
                        gateway_order: {
                            first_name: parts[0],
                            last_name: parts[1],
                            email: user.email,
                            subscription_plan_uuid: plan.subscription_plan_uuid,
                            plan_free_trial_interval: plan.price[0].plan_free_trial_interval,
                            subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                            cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                            return_url: window.location.origin + '/checkout-success?billing_type=2',
                            promo_code: this.applied_promocode
                        }
                    };
                }
                if (this.selectedPlanIndex !== undefined) {
                    generateSST(this.planDetail).then((res) => {
                        let sst_token = res.data.data.sst_token;
                        window.location.href = "/checkout/" + sst_token + "/" + this.planDetail.billing_type;
                    });
                }
            } else {
                window.location.href = "/sign-up";
            }
        },
        setExpiry($event) {
            this.form.card_expiry = $event.target.value;
            this.v$.form.card_expiry.$touch();
        },
        setConfirmModal(e) {
            if (e) {
                this.confirm_modal_el = e.$el;
            }
        },
        openConfirm(card_uuid, operation) {
            this.selected_card_uuid = card_uuid;
            this.selected_operation = operation;
            switch (operation) {
                case 'makedefault':
                    this.modal_type = 'makedefault';
                    this.modal_title = 'Default Card!';
                    this.modal_message = 'Are you sure you want to make default?';
                    break;
                case 'delete':
                    this.modal_type = 'delete';
                    this.modal_title = 'Are you sure, you want to delete this card?';
                    this.modal_message = 'Confirming this action will remove this card from your account. Do you want to proceed?';
                    break;
                default:
                    break;
            }
            jQuery(this.confirm_modal_el).modal('show');
        },
        dismissConfirm() {
            this.selected_card_uuid = null;
            this.selected_operation = null;
            this.modal_title = '';
            this.modal_message = '';
            this.modal_type = '';
            jQuery(this.confirm_modal_el).modal('hide');
        },
        openAddModal() {
            this.v$.$reset();
            jQuery(this.$refs.add_modal_el).modal('show');
        },
        closeAddModal() {
            this.v$.$reset();

            for (let key in this.form) {
                if (this.form.hasOwnProperty(key)) {
                    this.form[key] = '';
                }
            }

            document.forms['cardform']['card-number'].className = 'form-control';
            document.forms['cardform']['card-expiry'].value = '';
            jQuery(this.$refs.add_modal_el).modal('hide');
        },
        proceedWith() {
            switch (this.selected_operation) {
                case 'makedefault':
                    this.makeDefaultCard();
                    break;
                case 'delete':
                    this.removeCard();
                    break;
                default:
                    break;
            }
        },
        getCardLists() {
            getCardList().then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.cards = res.data.data.cards.cards_list;
                }
            });
        },
        async saveCard() {
            const isFormCorrect = await this.v$.$validate();
            if (!isFormCorrect && (this.v$.$errors.length > 0 ? this.v$.$errors[0].$property != 'cancel_reason_uuid' : true)) {
                return;
            }

            addCard(this.form).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.closeAddModal();
                    Alert.fire({
                        icon: 'success',
                        text: i18n(res.data.message),
                    });
                    this.getCardLists();
                } else {
                    Toast.fire({
                        icon: 'error',
                        text: i18n(res.data.message),
                    });
                }
            });
        },
        makeDefaultCard() {
            makeDefault({ card_uuid: this.selected_card_uuid }).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.dismissConfirm();
                    Alert.fire({
                        icon: 'success',
                        title: 'Make Primary Card',
                        text: i18n(res.data.message),
                    });
                    this.getCardLists();
                } else {
                    this.dismissConfirm();
                    Toast.fire({
                        icon: 'error',
                        text: i18n(res.data.message),
                    });
                }
            });
        },
        removeCard() {
            deleteCard({ card_uuid: this.selected_card_uuid }).then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.dismissConfirm();
                    Alert.fire({
                        icon: 'success',
                        title: 'Delete',
                        text: i18n(res.data.message),
                    });
                    this.getCardLists();
                } else {
                    this.dismissConfirm();
                    Toast.fire({
                        icon: 'error',
                        text: i18n(res.data.message),
                    });
                }
            });
        },
        purchase_history: function () {
            purchaseHistory().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    JsLoadingOverlay.hide();
                    this.apiResponse = res;
                    this.paymentHistoryList = res.data.data.paymentHistory.payment_history_list;
                    this.isPayment = true;
                } else {
                    JsLoadingOverlay.hide();
                    this.isPayment = false;
                }
            });
        },
        viewInvoiceDetails(orderId) {
            viewInvoiceDetails(orderId).then((res) => {
                // Decode escaped characters
                const htmlString = res.data.invoice_details
                    .replace(/\\n/g, '')      // remove newlines
                    .replace(/\\"/g, '"')     // fix escaped double quotes
                    .replace(/\\'/g, "'");    // fix escaped single quotes

                // Open new window
                const printInvoice = window.open('', '', '');
                printInvoice.document.open();
                printInvoice.document.write(`
                    <html>
                        <head>
                            <title>Invoice-${orderId}</title>
                        </head>
                        <body>
                            ${htmlString}
                        </body>
                    </html>
                `);
                printInvoice.document.close();

                // Ensure image is loaded before printing
                const img = printInvoice.document.querySelector('img');
                if (img) {
                    img.onload = () => printInvoice.print();
                } else {
                    printInvoice.print();
                }
            });
        },
        svgnCloseOpen() {
            $(".h1-flex-ci .open-svg").click(function () {
                $(".h1-flex-ci .open-svg").hide();
                $(".h1-flex-ci .close-svg").show();
                $(".card-info-child").hide();
                $(".h1-flex-ci").css("margin-bottom", "0px");
            });
            $(".h1-flex-ci .close-svg").click(function () {
                $(".h1-flex-ci .close-svg").hide();
                $(".h1-flex-ci .open-svg").show();
                $(".card-info-child").show();
                $(".h1-flex-ci").css("margin-bottom", "");
            });
            $(".h1-flex-ph .open-svg").click(function () {
                $(".h1-flex-ph .open-svg").hide();
                $(".h1-flex-ph .close-svg").show();
                $(".ph-row").hide();
                $(".h1-flex-ph").css("margin-bottom", "0px");
            });
            $(".h1-flex-ph .close-svg").click(function () {
                $(".h1-flex-ph .close-svg").hide();
                $(".h1-flex-ph .open-svg").show();
                $(".ph-row").show();
                $(".h1-flex-ph").css("margin-bottom", "");
            });
        },
        //87419 Raj, 87269 Raj
        async validatePromocode(promo) {
            const plans = [];

            plans.push(this.selected_plan.subscription_plan_uuid);

            let params = {
                promo_code: promo,
                subscription_plan_uuid: plans,
                billing_type: 2,
                subscription_pricing_uuid: this.selected_plan.price[0].subscription_pricing_uuid
            };

            const validate_promocode_response = await validatePromocode(params);

            if (validate_promocode_response.data.status === 'SUCCESS') {
                this.applied_promocode = promo;
                if (validate_promocode_response.data.data.promocode_type === 2) {
                    this.promocode_message = "Voucher applied";
                    this.applied_promocode_type = 2;
                    // JsLoadingOverlay.hide();
                } else {

                    const data = validate_promocode_response.data.data;

                    if (data.discount_type === 1) {
                        //percent
                        this.coupon_discount = `${data.discount}%`;

                        this.coupon_discount_amount = (this.selected_plan_price * (parseFloat(data.discount) / 100)).toFixed(2);
                        this.coupon_discount_amount;
                    } else {
                        //flat
                        if (data.discount > this.selected_plan_price) {
                            this.coupon_discount = `${this.selected_plan_currency_symbol} ${this.selected_plan_price}`;
                            this.coupon_discount_amount = this.selected_plan_price;
                        } else {
                            this.coupon_discount = `${this.selected_plan_currency_symbol} ${data.discount}`;
                            this.coupon_discount_amount = data.discount;
                        }
                    }
                    this.promocode_message = "Coupon discount of " + this.coupon_discount + " applied";
                    this.applied_promocode_type = 1;
                }

            } else if (validate_promocode_response.data.status === 'FAILURE') {
                this.promocode_message = validate_promocode_response.data.message;
                this.applied_promocode_type = 0;
                this.applied_promocode = '';
                this.coupon_discount = '';
                this.coupon_discount_amount = 0.00;
                // JsLoadingOverlay.hide();
            }
        },
        resetPromocode() {
            this.promocode = '';
            this.applied_promocode = '';
            this.promocode_message = '';
            this.applied_promocode_type = 0;
            this.coupon_discount = '';
            this.coupon_discount_amount = 0.00;
        },
        async internalCheckout(i, plan) {
            JsLoadingOverlay.show();
            /**
             * Generate SST
             */
            this.selectedPlanIndex = i + 1;
            let sst_token = '';
            if (localStorage.getItem('isloggedin') == "true") {
                const user = JSON.parse(window.localStorage.getItem("user"));
                const parts = user.name.split(' ');
                this.planDetail = {
                    plan_uuid: plan.subscription_plan_uuid,
                    pricing_uuid: plan.price[0].subscription_pricing_uuid,
                    billing_type: 2,
                    promo_code: this.applied_promocode,
                    promo_type: this.applied_promocode_type === 2 ? "voucher" : "coupon",
                    // tax_uuid: this.selected_plan_tax_uuid,
                    gateway_order: {
                        first_name: parts[0],
                        last_name: parts[1],
                        email: user.email,
                        subscription_plan_uuid: plan.subscription_plan_uuid,
                        subscription_pricing_uuid: plan.price[0].subscription_pricing_uuid,
                        cancel_url: window.location.origin + '/checkout-fail?callback_url=' + encodeURI(window.location.href),
                        return_url: window.location.origin + '/checkout-success?billing_type=2',
                        promo_code: this.applied_promocode
                    }
                };
                if (this.selectedPlanIndex !== undefined) {
                    try {
                        const res = await generateSST(this.planDetail);
                        const sst_token = res.data.data.sst_token;
                        let form = {
                            sst_token: '',
                            billing_type: Number
                        };
                        form.sst_token = sst_token;
                        form.billing_type = 2;

                        const checkoutResponse = await confirmCheckout(form);
                        JsLoadingOverlay.hide();
                        console.log(checkoutResponse);

                        if (checkoutResponse.data.code === 200) {
                            console.log("inside if");
                            let query_params = {
                                gateway_type: 'na',
                                transaction_uuid: 'na',
                                is_free_plan: plan.is_free_plan,
                            };
                            const params = new URLSearchParams(query_params);
                            console.log(params);
                            window.location.replace(`/checkout-success?${params.toString()}`);
                        } else {
                            console.log("inside else");
                            window.location.replace('/checkout-fail');
                        }
                    } catch (error) {
                        console.error(error);
                    }
                }

                JsLoadingOverlay.hide();

            } else {
                window.location.href = "/sign-up";
            }
        }
    },
    async beforeMount() {
        if (notLoggedinUser()) {
            window.location.href = "/";
        }
        let regLogRes = await getEndUserRegdLoginSetting();
        if (regLogRes.data.code === 200 && regLogRes.data.data !== null) {
            const requireRegistrationAndLogin = parseInt(regLogRes.data.data.sections[0].groups[0].nodes[0].node_value);
            if (requireRegistrationAndLogin !== 1) {
                window.location.href = "/";
            }
        }
        await expireCanceledPlan();
    },
    async mounted() {
        //103551-remove redirectUrl from localStorage(start)
        if (window.localStorage.getItem("redirectAfterPurchase") !== null) {
            window.localStorage.removeItem("redirectAfterPurchase");
        }
        //103551-remove redirectUrl from localStorage(end)
        //let languageCode = getCookie('lang_code');
        if (this.languageCode) {
            this.language_code = this.languageCode;
        }
        this.getPlan();
        this.svgnCloseOpen();
        if (this.show_device == localStorage.getItem('profile.currenttab')) {
            JsLoadingOverlay.show();
        }
        getCardList()
            .then((res) => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.cards = res.data.data.cards.cards_list;
                }
                return getCardForms();
            }).then(res => {
                if (res.data.code === 200 && res.data.status === "SUCCESS") {
                    this.card_form = res.data.data.card_form;
                }
            });
        try {
            let userGeoLocation = getUserGeoLocationFromCookies();
            if (!userGeoLocation) {
                await setUserGeoLocationOnCookies();
                userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
            } else {
                userGeoLocation = JSON.parse(getUserGeoLocationFromCookies());
            }
            this.countryCode = userGeoLocation.country_code;
        } catch (error) {
            console.error("Something went wrong!", error.message);
        }
        const subsciption_enabled_response = await isSubscriptionEnabled(this.countryCode);
        if (subsciption_enabled_response.data.code === 200) {
            this.is_user_subscribed = subsciption_enabled_response.data.data.isSubscriptionEnabled.is_user_subscribed;
        }

        const my_plans_response = await getMyPlan();
        if (my_plans_response.data.code === 200 && my_plans_response.data.status == "SUCCESS") {
            const subscribedPlan = my_plans_response.data.data.myPlans.my_plans_list;
            /*let contentName = [];
            for (const obj of subscribedPlan) {
                let content = await this.subscriptionPlanContent(obj);
                    contentName.push(content);
                }
                this.contentListMyPlan = contentName;*///It was commented because the Plan Detail is hidden.
            this.my_plans = subscribedPlan;
        } else {
            this.noPlanMsg = my_plans_response.data.message;
        }

        // const subscription_plans_response = await getSubscriptionPlans(this.countryCode);
        // if (subscription_plans_response.data.code === 200 && subscription_plans_response.data.status === "SUCCESS") {
        //     this.subscription_plans = subscription_plans_response.data.data.subscriptionPlans.subscription_plans_list;
        //     this.selectedindex = this.subscription_plans.findIndex(sp => sp.is_default === 1);
        //     this.isSelected = true;
        // }
        this.purchase_history();

        const check_gateway_response = await checkGateway();
        if (check_gateway_response.data.code == 200 && check_gateway_response.data.status === 'SUCCESS') {
            this.tokenization_amount = check_gateway_response.data.tokenization_amount;
            this.default_currency = check_gateway_response.data.default_currency;
            this.default_currency_symbol = check_gateway_response.data.default_currency_symbol;
        }

        JsLoadingOverlay.hide();

        //$('#ajaxApp').removeClass('body-container');
    },
};

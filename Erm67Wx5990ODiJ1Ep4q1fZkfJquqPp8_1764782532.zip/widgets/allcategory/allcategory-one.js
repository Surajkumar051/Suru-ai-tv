let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {allCategories}=await import(window.importAssetJs('js/webservices.js'));
export default {
    name: "allcategory_one",
    data() {
        return {
            rootUrl: getRootUrl(),
            categoryDetails: [],
            randomImagess: {
                0: {
                    0: "red",
                    1: "blue",
                    2:"white",
                    3: "yellow",
                    4: "greenyellow",
                },
                1: {
                    0: "pink",
                    1: "green",
                    2: "purple",
                    3: "orange",
                    4: "coral",
                },
                // 0:"./img/st-cl-genre-img1.png",
                // 1:"./img/st-cl-genre-img2.png",
                // 2:"./img/st-cl-genre-img3.png",
                // 3:"./img/st-cl-genre-img4.png",
                // 4:"./img/st-cl-genre-img5.png",
                // 5:"./img/st-genre-img1.png",
                // 6:"./img/st-genre-img2.png",
                // 7:"./img/st-genre-img3.png",
                // 8:"./img/st-genre-img4.png",
                // 9:"./img/st-genre-img5.png"
            },
            angle: '50',
        };
    },
    mounted() {
        allCategories()
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    
                    this.categoryDetails = res.data.data.categoryList.category_list;
                    this.categoryDetails.forEach(element => {
                        element.linearGradient = this.createBackgroundString();
                    });
                }
            })
            .catch((ex) => {
                console.log(ex);
            });
    },
    methods: {
        i18n,
        getRootUrl,
        pickRandomImg() {
            return Math.floor(Math.random() * 5)
        },
        createBackgroundString() {
            return `linear-gradient(${this.angle}deg, ${this.randomImagess[0][this.pickRandomImg()]}, ${this.randomImagess[1][this.pickRandomImg()]})`;
        }
    },
    // computed: {
    //     createBackgroundString() {
    //          return `linear-gradient(${this.angle}deg, ${this.randomImagess[this.pickRandomImg()]}, ${this.randomImagess[this.pickRandomImg()]})`;
    //     }
    // },
    template: `
    <vd-component class="vd allcategory-one" type="allcategory-one">
        <section class="season-content pt-32">
            <div class="container-fluid plr-88">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="episode-heading pb-16">
                            <h3 vd-readonly="true" class="sub-heading white-color"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h3>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="row">
                            <template v-for="data of categoryDetails">
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5">
                                    <div class="tiles grid-hover d-bg fs-tiles mb-16">              
                                    <a :href="'/category/'+data.category_permalink" class="callByAjax">          
                                        <div class="picture h-144" :style="{ backgroundImage: data.linearGradient }"  > 
                                            <span class="genre-text">{{data.category_name}}</span>  
                                        </div>            
                                    </a>   
                                    </div>
                                </div>
                            </template>    
                        </div>
                    </div>        
                </div>
            </div>
        </section>
    </vd-component>
    `,
};

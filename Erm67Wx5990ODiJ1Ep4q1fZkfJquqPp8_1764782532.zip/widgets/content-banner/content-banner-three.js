let {
    getContentSettingsDetails,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getPlayerParentPermarlinkDetails,
    getVideoDetails,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
    getParentCouseDetails,
    getAllMaturityRatings,
    logDownloadsToAnalytics
} =await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl, getRootUrl }=await import(window.importAssetJs('js/web-service-url.js'));


let {default:watch_now_three}=await import(window.importLocalJs('widgets/watch-now/watch-now-three.js'));
let {default:watch_trailer_one}=await import(window.importLocalJs('widgets/watch-trailer/watch-trailer-one.js'));
let {default:add_to_queue_one}=await import(window.importLocalJs('widgets/add-to-queue/add-to-queue-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:like_favourite_share_content_five}=await import(window.importLocalJs('widgets/like-favourite-share-content/like_favourite_share_content_five.js'));
let {default:product_details_five}=await import(window.importLocalJs('widgets/product-details/product-details-five.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));


export default {
    name: "content_banner_three",
    components: {
        watch_now_three,
        watch_trailer_one,
        add_to_queue_one,
        like_favourite_share_content_five,
        audio_player_one,
        product_details_five
    },
    data() {
        return {
            // shareVideoText:$attrs['label7'],
            // linkText:$attrs['label8'],
            // socialText:$attrs['label9'],
            contentDetails: [],
            content_readmore: "",
            contentlevel: 0,
            pointerevents: "none",
            seasonCount: false,
            noOfSession: 0,
            bannerImg: "",
            contentUuid: localStorage.getItem("contentId"),
            seasonLevelData: [],
            count: [],
            child_contentDetails: [],
            optNo: 0,
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            isAuthorized: null,
            childContentUuid: "",
            nestedContentplayBtnShow: false,
            showAddToQueueBtn: false,
            // audio content
            audioUuid: "",
            uniqueId: "",
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: "",
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            contentParentUuid: "",
            stickyAudioData: "",
            removeJs: true,
            playBackRatesValue: [],
            contentPermalink:permalink,// window.location.pathname.toString().split("/")[2],
            contentName: "",
            videoDuration: "",
            audioDuration: "",
            like_status: "",
            dislike_status: "",
            count: 0,
            userLiked: false,
            userDisliked: false,
            descLength: "",
            no_of_child_content: "",
            contentGroupDetails: Object,
            selectedLabel1Content: Object,
            isFavourite: 0,
            isFavouriteEnabled: false,
            likeReviewRatingsSettings: {
                is_like_enabled: false,
                is_dislike_enabled: false,
                is_like_count_enabled: false,
                is_dislike_count_enabled: false,
                is_rating_enabled:false,
                is_comment_enabled:false,
            },
            contentReadMoreObj: {},
            level1PageNo: -100,
            isNextLevel1PageExist: true,
            level2PageNo: -100,
            isNextLevel2PageExist: true,
            isButtonShow: false,
            playerRequiredObj: {},
            isQueueBtnShow: false,
            queueObj: {},
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            isCitrine:1,
            castname: [],
            CouseDetails:"",
            showPlayAllAndWatchTrailerButton : false,
            loggingDocDownloads: {}

        };
    },
    created() {
        JsLoadingOverlay.hide();
    },

    props: {
        isAuth: String,
    },

    mounted() {
        this.enduserURL = window.location.origin + "/";
        this.baseURL = getBaseUrl();
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    (content.permalink_type == "content" ||
                                        content.is_playlist == 1) &&
                                    content.content_permalink ==
                                        this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        let contentObj =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ];
                        this.contentParentUuid = contentObj.content_uuid;
                        console.log(
                            this.contentParentUuid + "----1----",
                            contentObj.is_playlist
                        );
                        this.getContentDetailsData(
                            this.contentParentUuid,
                            contentObj.is_playlist
                        );
                        // this.getContentFavouriteAction(contentObj.content_uuid);
                        this.getContentSettingsDetails(
                            contentObj.structure_uuid
                        );

                        // if(contentObj.is_parent == 1){
                        //     this.getChildDetails(this.contentParentUuid,this.level1PageNo,false);
                        // }
                    }
                    this.getParentCouseDetails(this.contentParentUuid);
                }
            });
            //this.loadMore();
        }
    },
    methods: {
        i18n,
        getRootUrl,
        async getParentCouseDetails(contentParentUuid){ 
            var CouseDetails=await getParentCouseDetails(contentParentUuid);
            if(CouseDetails.data.code==200) { 
                this.CouseDetails=CouseDetails.data.data;
            } 
        },
        setPlayerObj(contentObj) {
            this.playerRequiredObj = {
                rootParentUuid: contentObj.root_parent_uuid,
                contentUuid: contentObj.content_uuid,
                isPlayList: contentObj.is_playlist,
                contentPermalink: contentObj.content_permalink,
                contentAssetType: contentObj.content_asset_type,
                isParent: contentObj.is_parent,
                isFreeContent: contentObj.is_free_content //ER-101092
            };
        },

        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                console.log("2----", res);
                if (res.data.code == 200 && res.data.data !== null) {
                    //BUTTON SHOW
                    this.isButtonShow = true;
                    // this.isContentBannerShow=true;
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                    console.log("contentDetails+++++++++", this.contentDetails);
                    //Set player required data
                    this.setPlayerObj(this.contentDetails);
                    this.descLength = this.contentDetails.content_desc.length;
                    // this.content_readmore = this.contentDetails.content_desc.substring(0, 120);
                    this.noDefaultImage =
                        res.data.data.contentList.content_list[0].no_image_available_url;
                    if (
                        this.contentDetails.banners.website != null &&
                        this.contentDetails.banners.website.file_url !== ""
                    ) {
                        this.bannerImg =
                            this.contentDetails.banners.website[0].file_url;
                    } else {
                        this.bannerImg =
                            this.getRootUrl()+"img/video-after-login-banner.png"; //res.data.data.contentList.content_list[0].no_image_available_url;
                    }
                    // this.castDetails = res.data.data.contentList.content_list[0];
                    this.no_of_child_content =
                        res.data.data.contentList.content_list[0].no_of_child_content;

                    res.data.data.contentList.content_list.forEach((ele) => {
                        if (
                            ele.video_details !== null &&
                            ele.content_asset_type === 1
                        ) {
                            const vDuration =
                                ele.video_details.duration.replace(
                                    /^0(?:0:0?)?/,
                                    ""
                                );
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration
                                    .replace(":", "m ")
                                    .concat("s");
                            } else {
                                this.videoDuration = vDuration
                                    .replace(":", "h ")
                                    .replace(":", "m ")
                                    .concat("s");
                            }
                        }
                        if (
                            ele.audio_details !== null &&
                            ele.content_asset_type === 2
                        ) {
                            const aDuration =
                                ele.audio_details.duration.replace(
                                    /^0(?:0:0?)?/,
                                    ""
                                );
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration
                                    .replace(":", "m ")
                                    .concat("s");
                            } else {
                                this.audioDuration = aDuration
                                    .replace(":", "h ")
                                    .replace(":", "m ")
                                    .concat("s");
                            }
                        }
                    });
                }
            }).then(() => {
                this.mapMaturityRatings();
            });
            if(this.contentDetails?.cast_details != null ||this.contentDetails?.cast_details !=undefined){
                this.contentDetails?.cast_details.forEach((elment, index) => {
                  this.castname.push(this.contentDetails?.cast_details[index].cast_name);
                });

            }
        },

        mapMaturityRatings(){
            getAllMaturityRatings().then( resp => {
                if (resp.data.code === 200){
                    let maturityRatings = resp.data.data.maturityRatings;
                    maturityRatings.filter( x => {
                        if(x.min_age === this.contentDetails.maturity_rating){
                            this.contentDetails.maturityRatingName = x.maturity_rating_name;
                        }
                    })
                }
            });
        },
        // getChildDetails(contentParentUuid,pageNo,onScroll) {
        //     this.isNextLevel1PageExist = false;
        //     getChildDetails(contentParentUuid,pageNo).then((res) => {
        //        //console.log("child_contentDetails res", res.data.data.childList.child_list)
        //        // this.child_contentDetails = res.data.data.childList.child_list;
        //         if (onScroll && res.data.data.childList.child_list.child_content != null) {
        //             this.isNextLevel1PageExist = true;
        //             this.child_contentDetails.child_content.push(...res.data.data.childList.child_list.child_content);
        //         }
        //         else if(!onScroll && res.data.data.childList.child_list.child_content != null) {
        //             this.isNextLevel1PageExist = true;
        //             this.child_contentDetails = res.data.data.childList.child_list;
        //         }

        //         if (this.seasonLevelData) {
        //             this.seasonLevelData = res.data.data.childList.child_list.child_content;
        //             this.getChildContentDetails(this.child_contentDetails);
        //             // if (this.child_contentDetails.is_parent) {
        //             //     this.getPlayerPermalink(contentParentUuid);
        //             // }

        //          }
        //     });

        // },

        // getChildContentDetails(content) {
        //     if (content && content.child_content && content.child_content.length > 0) {
        //         let promiseCollection = [];
        //         for (let i = 0; i < content.child_content.length; i++) {
        //             getChildDetails(content.child_content[i].content_uuid,this.level2PageNo,false).then((result) => {
        //                 content.child_content[i].child_content = result.data.data.childList.child_list.child_content;
        //                 if(i==0){
        //                     this.selectedLabel1Content = result.data.data.childList.child_list;
        //                 }
        //                 // if(i == content.child_content.length-1){
        //                 //     this.generateCustomDropdown();
        //                 // }
        //             });

        //         }
        //     }
        // },
        // getEpisodeData(episodeData, index) {
        //     return episodeData[index];
        // },
        // showGridListView(optNum) {
        //     this.optNo = optNum;
        // },

        /**
         * Used for copy the message to the system clip board.
         * @param val : contain the string value which need to be copy.
         */
        copyMessage(val) {
            const selBox = document.createElement("textarea");
            selBox.style.position = "fixed";
            selBox.style.left = "0";
            selBox.style.top = "0";
            selBox.style.opacity = "0";
            selBox.value = val;
            document.body.appendChild(selBox);
            selBox.focus();
            selBox.select();
            document.execCommand("copy");
            document.body.removeChild(selBox);
        },

        getContentSettingsDetails(structureUuid) {
            getContentSettingsDetails(structureUuid).then((res) => {
                if (res.data.code == 200) {
                    if (
                        res.data.data.contentSettings.level_structures !=
                            null &&
                        res.data.data.contentSettings.level_structures.length >
                            0
                    ) {
                        this.contentGroupDetails =
                            res.data.data.contentSettings.level_structures[0];
                        this.contentGroupDetails.level_structure_detail =
                            this.contentGroupDetails.level_structure_detail.sort(
                                (a, b) => {
                                    let fa = a.level,
                                        fb = b.level;
                                    if (fa < fb) {
                                        return -1;
                                    }
                                    if (fa > fb) {
                                        return 1;
                                    }
                                    return 0;
                                }
                            );
                    }
                    this.isFavouriteEnabled =
                        res.data.data.contentSettings
                            .content_favourite_settings != null
                            ? res.data.data.contentSettings
                                  .content_favourite_settings?.is_enabled
                            : false;
                    if (
                        res.data.data.contentSettings
                            .content_like_and_review_settings != null
                    ) {
                        this.likeReviewRatingsSettings =
                            res.data.data.contentSettings.content_like_and_review_settings;
                    }
                    console.log(this.contentGroupDetails,'this.contentGroupDetails')
                }
            });
        },

        selectL1Dropdown() {
            let selectedContentUuid = $(
                ".custom-select .select-items .same-as-selected input"
            )
                .val()
                .replaceAll("#_#", "");
            this.selectedLabel1Content =
                this.child_contentDetails?.child_content?.filter(
                    (l1Obj) => l1Obj.content_uuid == selectedContentUuid
                )[0];
        },

        setDataReadMorePop(contentObj) {
            this.contentReadMoreObj = contentObj;
        },

        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration", videoDuration);
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration else", videoDuration);
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },
        isQueueBtn(value) {
            this.isQueueBtnShow = value;
        },
        isQueueObj(value) {
            this.queueObj = value;
        },
        playAudioContent(content_detail) {//ER-101092
            this.contentUuidAudio = content_detail.contentUuid;//ER-101092
            this.isFreeContent = content_detail.isFreeContent; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        playerPermalinkEmitted(value) {
            let playerPermalinkIsCalled = value;
            if (playerPermalinkIsCalled) {
                this.showPlayAllAndWatchTrailerButton = true;
            }
        },
        async isAuthorizedDocumentContent(value) {
            this.isRegdLogin = this.end_user_regd_login_setting.sections[0].groups[0].nodes[0].node_value ? 1 : 0;

            if (this.isRegdLogin === 0) {
                // window.location.href = value;
                window.open(value, '_blank');
            } else {
                if (!this.isLogedIn) {
                    let freeContentLoginRequired = JSON.parse(localStorage.getItem("freeContentLoginRequired"));
                    if (this.isFreeContent && !freeContentLoginRequired) {
                        // window.location.href = value;
                        window.open(value, '_blank');
                    } else {
                        // const redirectAfterLogin = window.localStorage.getItem("addOnContentPageUrl");
                        // if (redirectAfterLogin) {
                        //     window.localStorage.removeItem("addOnContentPageUrl");
                        //     window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                        // }
                        window.location.href = "/sign-in";
                        return false;
                    }
                } else {
                    const res = await isAuthorizedContent( this.contentDetails.content_uuid );
                    if (res.data.code == 200) {
                        if (res.data.data.isAuthorized.is_content_authorized) {
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                            // window.location.href = value;
                            window.open(value, '_blank');
                        } else {
                            this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                content_uuid:  this.contentDetails.content_uuid ,
                                monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                            });
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);//true
                        }
                    } else {
                        JsLoadingOverlay.hide();
                        Toast.fire({ icon: "error", title: res.data.message });
                    }
                }
            }

            this.loggingDocDownloads.body = {
                content_parent_uuid: this.contentDetails?.content_parent_uuid ? this.contentDetails?.content_parent_uuid: null,
                content_type: this.contentDetails?.content_asset_type,
                content_uuid: this.contentDetails?.content_uuid,
                content_name: this.contentDetails?.content_name,
                media_type: 3,
                content_created_by: this.contentDetails?.content_created_by,
                uploaded_user_type: this.contentDetails?.user_type
            }

            logDownloadsToAnalytics(this.loggingDocDownloads ).then( resp => {
            });

            return false;
        }
    },
    computed: {
        level0Name() {
            return this.contentGroupDetails.level_structure_detail[0]
                ?.level_name;
        },
        level1Name() {
            return this.contentGroupDetails.level_structure_detail != undefined
                ? this.contentGroupDetails.level_structure_detail[1]?.level_name
                : "Seasons";
        },
        level2Name() {
            return this.contentGroupDetails.allowed_level == 3
                ? this.contentGroupDetails.level_structure_detail[2].level_name
                : "";
        },
        getQuizNumber() {
            var text = '';
            if(this.CouseDetails?.totalQuiz > 0) {
            if(this.contentDetails?.level_one_count == 0) {
                    text =  this.CouseDetails?.totalQuiz;
            } else {
            text = ' | ' + this.CouseDetails?.totalQuiz;
            }
                
                if(this.CouseDetails?.totalQuiz == 1) {
                    text += ' Quiz';
                } else {
                    text += ' Quizzes';
                }
            }
            return text
            
        }
    },
    watch: {
        optNo(optNo) {},
    },
    template: `


    <vd-component class="vd content-banner-three" type="content-banner-three">
 
    <!--================================================================
    BANNER AREA START 
    ==================================================================-->
    <div class="banner-area-secondary">
    <div class="container-fluid max">
    <div class="row align-items-center gx-4">
    <div class="col-lg-5">
    <div class="banner-left">
    <h1 vd-readonly="true" class="sm-title"><span class="grdient-text">{{contentDetails.content_name}}</span> </h1><p>{{contentDetails.content_desc}}</p>
    <span vd-readonly="true" class="price"></span>
    <p vd-readonly="true" v-if="castname.length>0" >Created By: {{castname.toString()}}</p>
    <ul class="">
    <li class="ratings" v-if="contentDetails?.avg_rating"> <span vd-readonly="true"> {{contentDetails.avg_rating}}</span>
    <svg   v-for="rate in parseInt(contentDetails.avg_rating)" width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"/>
    </svg>

    <svg v-if="(parseFloat(contentDetails.avg_rating)-parseInt(contentDetails.avg_rating))>0" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
     <path d="M8.43641 2.29284C8.61983 1.92125 9.1497 1.92125 9.33312 2.29284L11.086 5.84407C11.1588 5.99149 11.2994 6.09372 11.4621 6.1175L15.3829 6.69058C15.7928 6.7505 15.9562 7.25442 15.6594 7.5435L12.8232 10.306C12.7052 10.4209 12.6514 10.5865 12.6792 10.7487L13.3485 14.6508C13.4185 15.0593 12.9898 15.3708 12.6229 15.1779L9.11749 13.3344C8.9718 13.2578 8.79773 13.2578 8.65204 13.3344L5.14658 15.1779C4.77977 15.3708 4.35099 15.0593 4.42105 14.6508L5.09031 10.7487C5.11814 10.5865 5.06431 10.4209 4.94637 10.306L2.1101 7.5435C1.81331 7.25442 1.9767 6.7505 2.38666 6.69058L6.30745 6.1175C6.47013 6.09372 6.61072 5.99149 6.68349 5.84407L8.43641 2.29284Z" fill="#C4C4C4"></path>
    </svg>


     <svg v-for="nullstar in (5-Math.ceil(contentDetails.avg_rating))" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
     <path d="M8.43641 2.29284C8.61983 1.92125 9.1497 1.92125 9.33312 2.29284L11.086 5.84407C11.1588 5.99149 11.2994 6.09372 11.4621 6.1175L15.3829 6.69058C15.7928 6.7505 15.9562 7.25442 15.6594 7.5435L12.8232 10.306C12.7052 10.4209 12.6514 10.5865 12.6792 10.7487L13.3485 14.6508C13.4185 15.0593 12.9898 15.3708 12.6229 15.1779L9.11749 13.3344C8.9718 13.2578 8.79773 13.2578 8.65204 13.3344L5.14658 15.1779C4.77977 15.3708 4.35099 15.0593 4.42105 14.6508L5.09031 10.7487C5.11814 10.5865 5.06431 10.4209 4.94637 10.306L2.1101 7.5435C1.81331 7.25442 1.9767 6.7505 2.38666 6.69058L6.30745 6.1175C6.47013 6.09372 6.61072 5.99149 6.68349 5.84407L8.43641 2.29284Z" fill="#C4C4C4"></path>
     </svg>
       
       
    </li>
    <li class="d-none">(23,467 ratings) 45,987 students</li>
    </ul>
    <div class="row g-3">
    <div class="col-auto d-none" v-if="!isButtonShow">
    <a class="callByAjax vd-no-navigation" href="#/" class="btn-solid callByAjax" >Buy Now</a>
    </div>
    <div class="col-auto" v-if="isButtonShow">
        <div class="watch-now" v-if="contentDetails?.content_asset_type ==6 &&
            contentDetails?.is_parent!=1 && 
            contentDetails?.is_playlist!=1 && 
            contentDetails?.content_asset_uuid!='' &&
            contentDetails?.document_details?.file_url != ''">
            <a class="watch callByAjax"  href="javascript:void(0);" @click="isAuthorizedDocumentContent(contentDetails?.document_details?.file_url)">
                <vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param>
            </a>
        </div>
        <div class="row g-3">
            <div class="col-auto">
                <div class="watch-trailer" v-show="contentDetails.content_trailer_uuid 
                && showPlayAllAndWatchTrailerButton && contentDetails?.content_asset_uuid !=6">
                    <watch_trailer_one 
                        :id="$attrs['id'] +'_watch_trailer_one_1'" 
                        :contentUuid="contentDetails.content_uuid"
                        :labelIntro="$attrs['label13']"
                    />
                </div>
            </div>
            <div class="col-auto">

                <div class="watch-now" v-show="showPlayAllAndWatchTrailerButton">
                <watch_now_three
                    :root_url="getRootUrl()"
                    :id="$attrs['id'] +'_watch_now_three_3'"
                    @isQueueButton="isQueueBtn"
                    @queueObjEmit="isQueueObj"
                    @playAudioContent="playAudioContent"
                    :playerRequiredObj="playerRequiredObj"
                    :isCitrine="isCitrine"
                    @player_permalink="playerPermalinkEmitted"
                />
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-auto">
    <like_favourite_share_content_five :id="$attrs['id'] +'_like_favourite_share_content_five_5'" :contentData="contentDetails" :likeReviewRatingsSettingsData="likeReviewRatingsSettings"
    :isFavouriteSettings="isFavouriteEnabled" :shareVideoText="$attrs['label7']" :linkText="$attrs['label8']" :socialText="$attrs['label9']"/>
   </div>
   
    </div>
    </div>
    </div>
    <div class="col-lg-7 text-end" v-if="contentDetails?.banners">
    
    <img loading="lazy" v-if="this.contentDetails?.banners?.website != null && this.contentDetails?.banners?.website?.file_url !== ''" :src="bannerImg" :alt="contentDetails.content_name" class="mg-fluid"/>
    <img loading="lazy" v-else :src="getRootUrl()+'img/girl-with-laptop.png'" :alt="contentDetails.content_name" class="mg-fluid"/>

    </div>
    </div>
    </div>
    </div>



    <!--================================================================
    BANNER AREA END 
    ==================================================================-->


    <!--================================================================
    CORSE INFO START 
==================================================================-->
<div class="course-infos overflow-hidden">
<div class="container-fluid max">
<div class="row gx-5">
<div class="col-lg-8">
<div class="info-wrapper">
<div class="about-course box-padding" v-if="contentDetails.content_desc">
   <h3 vd-readonly="true"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h3>

   <p vd-readonly="true" v-html="i18n(contentDetails.content_desc)"></p> 
</div>
<div class="learn-box box-padding d-none">
   <h3><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></h3>
   <ul>
       <li>
           <div class="svg">
               <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path d="M7.41322 13.01L5.99822 11.597L10.5982 6.99699L5.99822 2.39699L7.41322 0.98999L13.4232 6.99999L7.41422 13.01H7.41322ZM1.98822 13.01L0.574219 11.597L5.17422 6.99699L0.574219 2.40399L1.98822 0.98999L7.99922 6.99999L1.98922 13.01H1.98822Z" fill="#C4C4C4"/>
               </svg>                                            
           </div>
           Sed ut perspiciatis unde omnis iste natus error accusantium
       </li>
       <li>
           <div class="svg">
               <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path d="M7.41322 13.01L5.99822 11.597L10.5982 6.99699L5.99822 2.39699L7.41322 0.98999L13.4232 6.99999L7.41422 13.01H7.41322ZM1.98822 13.01L0.574219 11.597L5.17422 6.99699L0.574219 2.40399L1.98822 0.98999L7.99922 6.99999L1.98922 13.01H1.98822Z" fill="#C4C4C4"/>
               </svg>                                            
           </div>
           Sed ut perspiciatis unde omnis iste</li>
       <li>
           <div class="svg">
               <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path d="M7.41322 13.01L5.99822 11.597L10.5982 6.99699L5.99822 2.39699L7.41322 0.98999L13.4232 6.99999L7.41422 13.01H7.41322ZM1.98822 13.01L0.574219 11.597L5.17422 6.99699L0.574219 2.40399L1.98822 0.98999L7.99922 6.99999L1.98922 13.01H1.98822Z" fill="#C4C4C4"/>
               </svg>                                            
           </div>
           Sed ut perspiciatis unde omnis iste natus error</li>
       <li>
           <div class="svg">
               <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path d="M7.41322 13.01L5.99822 11.597L10.5982 6.99699L5.99822 2.39699L7.41322 0.98999L13.4232 6.99999L7.41422 13.01H7.41322ZM1.98822 13.01L0.574219 11.597L5.17422 6.99699L0.574219 2.40399L1.98822 0.98999L7.99922 6.99999L1.98922 13.01H1.98822Z" fill="#C4C4C4"/>
               </svg>                                            
           </div>
           Sed ut perspiciatis unde omnis iste natus error sit voluptatem</li>
       <li>
           <div class="svg">
               <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path d="M7.41322 13.01L5.99822 11.597L10.5982 6.99699L5.99822 2.39699L7.41322 0.98999L13.4232 6.99999L7.41422 13.01H7.41322ZM1.98822 13.01L0.574219 11.597L5.17422 6.99699L0.574219 2.40399L1.98822 0.98999L7.99922 6.99999L1.98922 13.01H1.98822Z" fill="#C4C4C4"/>
               </svg>                                            
           </div>
           Sed ut perspiciatis unde</li>
   </ul>
</div>

<product_details_five 
    id="content_product_details_five_5" 
    :label1="$attrs['label22']"
    :label2="$attrs['label23']" 
    :label3="$attrs['label24']" 
    :label4="$attrs['label24']" 
    :label5="$attrs['label25']" 
    :label6="$attrs['label26']"
    :label7="$attrs['label27']" 
    :label8="$attrs['label8']" 
    :label9="$attrs['label9']" 
    :label10="$attrs['label27']" 
    :label11="$attrs['label28']"
    :label12="$attrs['label24']" 
    :label13="$attrs['label26']" 
    :label14="$attrs['label29']" 
    :label17="$attrs['label30']" 
    :label18="$attrs['label31']"
    :label19="$attrs['label25']" 
    :label20="$attrs['label32']" 
/>

</div>
</div>

<div class="col-lg-4">
<div class="course-include">
<ul class="list-items ">
<li class="d-none">
   <span>Skill level</span>
   All Levels
</li>
<li v-if="contentDetails.video_details !== null" class="d-none">

    <span vd-readonly="true">Estimated time</span> {{videoDuration}} {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}}
</li> 
<li v-else-if="contentDetails.audio_details !== null">
    <span vd-readonly="true">Estimated time</span>{{audioDuration}} {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}}</p>
</li>
<li v-else class="d-none">
    <span vd-readonly="true">Estimated time</span><p id="estimated_time"></p>
</li>
<li v-if="contentDetails?.level_one_count">
   <span vd-readonly="true" vd-node="text">This course includes</span>
   <p vd-readonly="true" v-if="contentDetails.level_one_count > 0">
   {{contentDetails.level_one_count}} {{contentDetails.level_one_count > 1 ? level1Name + 's' : level1Name }}
   {{contentDetails.level_two_count>0?'|':''}}
   {{contentDetails.level_two_count>0?contentDetails.level_two_count:''}}
   {{level2Name != '' && contentDetails.level_two_count > 1 ? level2Name + 's': level2Name}} 
   {{ getQuizNumber }}

   </p>
<p vd-readonly="true" v-else-if="contentDetails.content_level==1 && contentDetails.level_two_count > 0">
   {{contentDetails.level_two_count>0?contentDetails.level_two_count:''}}
   {{contentDetails.level_two_count>1?level2Name+'s':level2Name}}
   {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}}
   
   </p>
</li>
<span class="ratingstarsCounts" v-if="likeReviewRatingsSettings.is_rating_enabled">
    <!-- <span class="hrs-span">|</span> -->
    <a id="openRatingID" class="openRating" href="javascript:void(0);">
        <span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_3965_17115)">
                    <path
                        d="M6 1L7.545 4.13L11 4.635L8.5 7.07L9.09 10.51L6 8.885L2.91 10.51L3.5 7.07L1 4.635L4.455 4.13L6 1Z"
                        fill="#FFB75E" stroke="#FFB75E" stroke-linecap="round"
                        stroke-linejoin="round" />
                </g>
                <defs>
                    <clipPath id="clip0_3965_17115">
                        <rect width="12" height="12" fill="white" />
                    </clipPath>
                </defs>
            </svg>
        </span>
        <span class="ratingCount">{{contentDetails.avg_rating}}</span>
    </a>
    <div class="showstarRatingpopup">
        <span class="srp-left-arrow">
            <svg width="8" height="11" viewBox="0 0 8 11" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M0.455158 4.69656L6.87812 0.414587C7.14394 0.237372 7.5 0.427929 7.5 0.747407L7.5 10.1678C7.5 10.5032 7.11203 10.6896 6.85012 10.4801L0.427161 5.34173C0.215762 5.17261 0.229903 4.84673 0.455158 4.69656Z"
                    fill="white" />
            </svg>
        </span>
        <div class="starRatingpopup">
            <ul class="srp-ul">
                <li class="srp-ul-li">
                    <span class="srp-ul-li-span1">
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_2679_23226)">
                                <path
                                    d="M11.8307 14V12.6667C11.8307 11.9594 11.5498 11.2811 11.0497 10.781C10.5496 10.281 9.87131 10 9.16406 10H3.83073C3.12349 10 2.44521 10.281 1.94511 10.781C1.44501 11.2811 1.16406 11.9594 1.16406 12.6667V14"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M6.50261 7.33333C7.97537 7.33333 9.16927 6.13943 9.16927 4.66667C9.16927 3.19391 7.97537 2 6.50261 2C5.02985 2 3.83594 3.19391 3.83594 4.66667C3.83594 6.13943 5.02985 7.33333 6.50261 7.33333Z"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M15.8359 13.9993V12.6659C15.8355 12.0751 15.6388 11.5011 15.2768 11.0341C14.9149 10.5672 14.408 10.2336 13.8359 10.0859"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M11.1641 2.08594C11.7377 2.2328 12.2461 2.5664 12.6092 3.03414C12.9722 3.50188 13.1693 4.07716 13.1693 4.66927C13.1693 5.26138 12.9722 5.83666 12.6092 6.3044C12.2461 6.77214 11.7377 7.10574 11.1641 7.2526"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </g>
                            <defs>
                                <clipPath id="clip0_2679_23226">
                                    <rect width="16" height="16" fill="white"
                                        transform="translate(0.5)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span class="srpli-span1-txt">Rated By</span>
                    </span>
                    <span class="srp-ul-li-span2">{{contentDetails.rated_by}}</span>
                </li>
                <li class="srp-ul-li">
                    <span class="srp-ul-li-span1">
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8.5026 1.33398L10.5626 5.50732L15.1693 6.18065L11.8359 9.42732L12.6226 14.014L8.5026 11.8473L4.3826 14.014L5.16927 9.42732L1.83594 6.18065L6.4426 5.50732L8.5026 1.33398Z"
                                stroke="#15151A" stroke-width="1.33" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        <span class="srpli-span1-txt">Average Rating</span>
                    </span>
                    <span class="srp-ul-li-span2">{{contentDetails.avg_rating}}</span>
                </li>
                <li class="srp-ul-li" v-if="likeReviewRatingsSettings.is_comment_enabled">
                    <span class="srp-ul-li-span1">
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_2679_23236)">
                                <path
                                    d="M11.8307 14V12.6667C11.8307 11.9594 11.5498 11.2811 11.0497 10.781C10.5496 10.281 9.87131 10 9.16406 10H3.83073C3.12349 10 2.44521 10.281 1.94511 10.781C1.44501 11.2811 1.16406 11.9594 1.16406 12.6667V14"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M6.50261 7.33333C7.97537 7.33333 9.16927 6.13943 9.16927 4.66667C9.16927 3.19391 7.97537 2 6.50261 2C5.02985 2 3.83594 3.19391 3.83594 4.66667C3.83594 6.13943 5.02985 7.33333 6.50261 7.33333Z"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M15.8359 13.9993V12.6659C15.8355 12.0751 15.6388 11.5011 15.2768 11.0341C14.9149 10.5672 14.408 10.2336 13.8359 10.0859"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M11.1641 2.08594C11.7377 2.2328 12.2461 2.5664 12.6092 3.03414C12.9722 3.50188 13.1693 4.07716 13.1693 4.66927C13.1693 5.26138 12.9722 5.83666 12.6092 6.3044C12.2461 6.77214 11.7377 7.10574 11.1641 7.2526"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </g>
                            <defs>
                                <clipPath id="clip0_2679_23236">
                                    <rect width="16" height="16" fill="white"
                                        transform="translate(0.5)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span class="srpli-span1-txt">Reviewed By</span>
                    </span>
                    <span class="srp-ul-li-span2">{{contentDetails.reviewed_by}}</span>
                </li>
            </ul>
        </div>
    </div>
</span>
<li v-if="contentDetails?.level_one_count == 0">
    <span vd-readonly="true" vd-node="text">This course includes</span>
    <p>{{ getQuizNumber }}</p>
</li>


<li class="d-none">
   <span>Students</span> 
   40,886
</li>
<li class="d-none">
   <span>Language</span>
   English
</li>

</ul>
<p vd-readonly="true" class="d-none">This course includes:</p>
<ul class="list-includes d-none">
<li v-if="contentDetails.level_one_count > 0">
   <div class="svg">
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C21.9939 17.5203 17.5203 21.9939 12 22ZM4 12.172C4.04732 16.5732 7.64111 20.1095 12.0425 20.086C16.444 20.0622 19.9995 16.4875 19.9995 12.086C19.9995 7.68451 16.444 4.10977 12.0425 4.086C7.64111 4.06246 4.04732 7.59876 4 12V12.172ZM10 16.5V7.5L16 12L10 16.5Z" fill="#C4C4C4"/>
       </svg>                                    
   </div>
   <p vd-readonly="true" v-if="contentDetails.level_one_count > 0">
                            {{contentDetails.level_one_count}} {{level1Name}}
                            {{contentDetails.level_two_count>0?'|':''}}
                            {{contentDetails.level_two_count>0?contentDetails.level_two_count:''}}
                            {{contentDetails.level_two_count>0?level2Name:''}}
                            {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}} </p>
                        <p vd-readonly="true" v-else-if="contentDetails.content_level==1 && contentDetails.level_two_count > 0">
                            {{contentDetails.level_two_count>0?contentDetails.level_two_count:''}}
                            {{contentDetails.level_two_count>0?level2Name:''}}
                            {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}} </p>
</li>
<span class="ratingstarsCounts" v-if="likeReviewRatingsSettings.is_rating_enabled">
    <!-- <span class="hrs-span">|</span> -->
    <a id="openRatingID" class="openRating" href="javascript:void(0);">
        <span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_3965_17115)">
                    <path
                        d="M6 1L7.545 4.13L11 4.635L8.5 7.07L9.09 10.51L6 8.885L2.91 10.51L3.5 7.07L1 4.635L4.455 4.13L6 1Z"
                        fill="#FFB75E" stroke="#FFB75E" stroke-linecap="round"
                        stroke-linejoin="round" />
                </g>
                <defs>
                    <clipPath id="clip0_3965_17115">
                        <rect width="12" height="12" fill="white" />
                    </clipPath>
                </defs>
            </svg>
        </span>
        <span class="ratingCount">{{contentDetails.avg_rating}}</span>
    </a>
    <div class="showstarRatingpopup">
        <span class="srp-left-arrow">
            <svg width="8" height="11" viewBox="0 0 8 11" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M0.455158 4.69656L6.87812 0.414587C7.14394 0.237372 7.5 0.427929 7.5 0.747407L7.5 10.1678C7.5 10.5032 7.11203 10.6896 6.85012 10.4801L0.427161 5.34173C0.215762 5.17261 0.229903 4.84673 0.455158 4.69656Z"
                    fill="white" />
            </svg>
        </span>
        <div class="starRatingpopup">
            <ul class="srp-ul">
                <li class="srp-ul-li">
                    <span class="srp-ul-li-span1">
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_2679_23226)">
                                <path
                                    d="M11.8307 14V12.6667C11.8307 11.9594 11.5498 11.2811 11.0497 10.781C10.5496 10.281 9.87131 10 9.16406 10H3.83073C3.12349 10 2.44521 10.281 1.94511 10.781C1.44501 11.2811 1.16406 11.9594 1.16406 12.6667V14"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M6.50261 7.33333C7.97537 7.33333 9.16927 6.13943 9.16927 4.66667C9.16927 3.19391 7.97537 2 6.50261 2C5.02985 2 3.83594 3.19391 3.83594 4.66667C3.83594 6.13943 5.02985 7.33333 6.50261 7.33333Z"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M15.8359 13.9993V12.6659C15.8355 12.0751 15.6388 11.5011 15.2768 11.0341C14.9149 10.5672 14.408 10.2336 13.8359 10.0859"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M11.1641 2.08594C11.7377 2.2328 12.2461 2.5664 12.6092 3.03414C12.9722 3.50188 13.1693 4.07716 13.1693 4.66927C13.1693 5.26138 12.9722 5.83666 12.6092 6.3044C12.2461 6.77214 11.7377 7.10574 11.1641 7.2526"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </g>
                            <defs>
                                <clipPath id="clip0_2679_23226">
                                    <rect width="16" height="16" fill="white"
                                        transform="translate(0.5)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span class="srpli-span1-txt">Rated By</span>
                    </span>
                    <span class="srp-ul-li-span2">{{contentDetails.rated_by}}</span>
                </li>
                <li class="srp-ul-li">
                    <span class="srp-ul-li-span1">
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M8.5026 1.33398L10.5626 5.50732L15.1693 6.18065L11.8359 9.42732L12.6226 14.014L8.5026 11.8473L4.3826 14.014L5.16927 9.42732L1.83594 6.18065L6.4426 5.50732L8.5026 1.33398Z"
                                stroke="#15151A" stroke-width="1.33" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                        <span class="srpli-span1-txt">Average Rating</span>
                    </span>
                    <span class="srp-ul-li-span2">{{contentDetails.avg_rating}}</span>
                </li>
                <li class="srp-ul-li" v-if="likeReviewRatingsSettings.is_comment_enabled">
                    <span class="srp-ul-li-span1">
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_2679_23236)">
                                <path
                                    d="M11.8307 14V12.6667C11.8307 11.9594 11.5498 11.2811 11.0497 10.781C10.5496 10.281 9.87131 10 9.16406 10H3.83073C3.12349 10 2.44521 10.281 1.94511 10.781C1.44501 11.2811 1.16406 11.9594 1.16406 12.6667V14"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M6.50261 7.33333C7.97537 7.33333 9.16927 6.13943 9.16927 4.66667C9.16927 3.19391 7.97537 2 6.50261 2C5.02985 2 3.83594 3.19391 3.83594 4.66667C3.83594 6.13943 5.02985 7.33333 6.50261 7.33333Z"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M15.8359 13.9993V12.6659C15.8355 12.0751 15.6388 11.5011 15.2768 11.0341C14.9149 10.5672 14.408 10.2336 13.8359 10.0859"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M11.1641 2.08594C11.7377 2.2328 12.2461 2.5664 12.6092 3.03414C12.9722 3.50188 13.1693 4.07716 13.1693 4.66927C13.1693 5.26138 12.9722 5.83666 12.6092 6.3044C12.2461 6.77214 11.7377 7.10574 11.1641 7.2526"
                                    stroke="#15151A" stroke-width="1.33"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </g>
                            <defs>
                                <clipPath id="clip0_2679_23236">
                                    <rect width="16" height="16" fill="white"
                                        transform="translate(0.5)" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span class="srpli-span1-txt">Reviewed By</span>
                    </span>
                    <span class="srp-ul-li-span2">{{contentDetails.reviewed_by}}</span>
                </li>
            </ul>
        </div>
    </div>
</span>
<li class="d-none">
   <div class="svg">
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M22 19C22 19.5304 21.7893 20.0391 21.4142 20.4142C21.0391 20.7893 20.5304 21 20 21H4C3.46957 21 2.96086 20.7893 2.58579 20.4142C2.21071 20.0391 2 19.5304 2 19V5C2 4.46957 2.21071 3.96086 2.58579 3.58579C2.96086 3.21071 3.46957 3 4 3H9L11 6H20C20.5304 6 21.0391 6.21071 21.4142 6.58579C21.7893 6.96086 22 7.46957 22 8V19Z" stroke="#C4C4C4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
       </svg>                                                                        
   </div>
   4 downloadable resources
</li>
<li v-if="CouseDetails?.totalQuiz >0">
   <div class="svg">
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M8.85 9.62465C8.84916 9.82381 8.92503 10.0157 9.06188 10.1604C9.1988 10.3052 9.38624 10.3917 9.58527 10.4019C9.7843 10.4121 9.97961 10.3453 10.1306 10.2152C10.2817 10.0852 10.3768 9.902 10.3963 9.70366L10.3966 9.70369L10.3969 9.69464L10.4028 9.5366C10.4532 8.66267 11.2464 7.9 12.125 7.9C13.0347 7.9 13.85 8.71439 13.85 9.625V9.62512C13.8502 9.9164 13.7964 10.1595 13.6644 10.4186C13.5302 10.682 13.3127 10.9665 12.9762 11.3363C12.976 11.3365 12.9758 11.3368 12.9756 11.337L12.4634 11.8845L12.4626 11.8854C11.6368 12.7832 11.2621 13.4302 11.269 14.3806V14.3807C11.2705 14.5725 11.3431 14.7571 11.4728 14.8985C11.6025 15.0399 11.78 15.1282 11.9711 15.1463C12.1621 15.1643 12.3531 15.1109 12.5069 14.9962C12.6608 14.8816 12.7667 14.7139 12.8041 14.5257L12.8043 14.5258L12.8054 14.5181L12.8144 14.456L12.8155 14.4488L12.8158 14.4415L12.8188 14.3775L12.8189 14.3775L12.819 14.3733L12.8204 14.2943C12.8375 13.9227 13.0094 13.5955 13.5141 13.0333L14.0206 12.4909L14.021 12.4905L15.25 9.6245H15.4C15.4 9.62445 15.4 9.6244 15.4 9.62436C15.3999 7.85801 13.8902 6.35 12.125 6.35C10.3603 6.35 8.8502 7.85944 8.85 9.62465ZM8.85 9.62465C8.85 9.62477 8.85 9.62488 8.85 9.625H9L8.85 9.6243C8.85 9.62442 8.85 9.62454 8.85 9.62465ZM22.15 12C22.15 6.39416 17.6058 1.85 12 1.85C6.39416 1.85 1.85 6.39416 1.85 12C1.85 17.6058 6.39416 22.15 12 22.15C17.6058 22.15 22.15 17.6058 22.15 12ZM3.4 12C3.4 7.25034 7.25034 3.4 12 3.4C16.7497 3.4 20.6 7.25034 20.6 12C20.6 16.7497 16.7497 20.6 12 20.6C7.25034 20.6 3.4 16.7497 3.4 12ZM12.7614 16.1136C12.5926 15.9448 12.3637 15.85 12.125 15.85C11.8863 15.85 11.6574 15.9448 11.4886 16.1136C11.3198 16.2824 11.225 16.5113 11.225 16.75C11.225 16.9887 11.3198 17.2176 11.4886 17.3864C11.6574 17.5552 11.8863 17.65 12.125 17.65C12.3637 17.65 12.5926 17.5552 12.7614 17.3864C12.9302 17.2176 13.025 16.9887 13.025 16.75C13.025 16.5113 12.9302 16.2824 12.7614 16.1136Z" fill="#C4C4C4" stroke="#C4C4C4" stroke-width="0.3"/>
       </svg>                                                                       
   </div>
   {{CouseDetails.totalQuiz}} Quiz
</li>
<li class="d-none">
   <div class="svg">
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M5.636 16C2.91 16 2 14 2 12C2 10 2.91 8 5.636 8C9.273 8 14.727 16 18.364 16C21.09 16 22 14 22 12C22 10 21.09 8 18.364 8C14.727 8 9.273 16 5.636 16V16Z" stroke="#C4C4C4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
       </svg>                                                                     
   </div>
   Full lifetime access
</li>
<li class="d-none">
   <div class="svg">
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M10 21H4C2.89543 21 2 20.1046 2 19V9C2 7.89543 2.89543 7 4 7H5V5C5 3.89543 5.89543 3 7 3H20C21.1046 3 22 3.89543 22 5V16C22 17.1046 21.1046 18 20 18H12V19C12 20.1046 11.1046 21 10 21ZM4 9V19H10V9H4ZM7 7H10C11.1046 7 12 7.89543 12 9V16H20V5H7V7Z" fill="#C4C4C4"/>
       </svg>                                                                                                        
   </div>
   Access on mobile and laptop
</li>
<li class="d-none">
   <div class="svg">
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M18 10C18.7702 9.99965 19.5242 10.2216 20.1713 10.6393C20.8184 11.057 21.3311 11.6527 21.6479 12.3547C21.9648 13.0568 22.0721 13.8354 21.9572 14.597C21.8423 15.3585 21.5099 16.0708 21 16.648V21.248C21.0003 21.3764 20.9675 21.5028 20.905 21.6149C20.8424 21.727 20.7521 21.8212 20.6427 21.8885C20.5334 21.9557 20.4085 21.9937 20.2802 21.9989C20.1519 22.0041 20.0245 21.9762 19.91 21.918L19.82 21.863L18 20.591L16.18 21.863C16.0749 21.9364 15.9527 21.9816 15.8252 21.9944C15.6976 22.0071 15.5689 21.987 15.4514 21.9358C15.3338 21.8847 15.2313 21.8042 15.1537 21.7022C15.0761 21.6002 15.0259 21.48 15.008 21.353L15.001 21.248V16.646C14.4918 16.0688 14.16 15.3568 14.0454 14.5957C13.9308 13.8345 14.0382 13.0564 14.3548 12.3548C14.6714 11.6532 15.1837 11.0578 15.8303 10.6401C16.4769 10.2224 17.2302 10.0002 18 10ZM19.5 17.71C19.0234 17.9028 18.5141 18.0016 18 18.001C17.4859 18.0016 16.9766 17.9028 16.5 17.71V19.809L17.571 19.062C17.6806 18.9852 17.8089 18.9391 17.9423 18.9286C18.0758 18.918 18.2096 18.9434 18.33 19.002L18.43 19.062L19.5 19.809V17.71ZM19.25 3.00403C19.9503 3.00399 20.6242 3.27112 21.1343 3.75092C21.6444 4.23072 21.9522 4.88705 21.995 5.58603L22 5.75403L22.001 11C21.5955 10.4601 21.0853 10.0074 20.501 9.66903L20.5 5.75403C20.5001 5.44457 20.3855 5.14606 20.1782 4.91626C19.971 4.68647 19.6858 4.54172 19.378 4.51003L19.25 4.50403H4.75C4.44054 4.50389 4.14203 4.61854 3.91223 4.8258C3.68244 5.03306 3.53769 5.3182 3.506 5.62603L3.5 5.75403V15.254C3.5 15.901 3.992 16.434 4.622 16.497L4.75 16.504L13.672 16.505L13.795 16.708L13.929 16.904L14 16.998L13.999 18.004H4.75C4.04955 18.004 3.37549 17.7368 2.86538 17.2568C2.35526 16.7768 2.04754 16.1202 2.005 15.421L2 15.254V5.75403C1.99997 5.05374 2.26709 4.37982 2.74689 3.86973C3.22669 3.35964 3.88302 3.05181 4.582 3.00903L4.75 3.00403H19.25ZM18 11.5C17.3368 11.5 16.7008 11.7635 16.2319 12.2324C15.7629 12.7013 15.4995 13.3374 15.4995 14.0005C15.4995 14.6637 15.7629 15.2997 16.2319 15.7686C16.7008 16.2376 17.3368 16.501 18 16.501C18.6632 16.501 19.2992 16.2376 19.7681 15.7686C20.2371 15.2997 20.5005 14.6637 20.5005 14.0005C20.5005 13.3374 20.2371 12.7013 19.7681 12.2324C19.2992 11.7635 18.6632 11.5 18 11.5ZM11.25 12.5C11.44 12.5001 11.6229 12.5723 11.7618 12.702C11.9006 12.8317 11.9851 13.0093 11.998 13.1989C12.011 13.3885 11.9515 13.5759 11.8316 13.7233C11.7117 13.8707 11.5402 13.9671 11.352 13.993L11.25 14H6.75C6.55998 14 6.37706 13.9278 6.23821 13.7981C6.09936 13.6683 6.01493 13.4907 6.00197 13.3011C5.98902 13.1116 6.04852 12.9241 6.16843 12.7767C6.28835 12.6293 6.45975 12.5329 6.648 12.507L6.75 12.5H11.25ZM17.25 7.00003C17.44 7.00009 17.6229 7.07227 17.7618 7.202C17.9006 7.33173 17.9851 7.50933 17.998 7.69891C18.011 7.88849 17.9515 8.07592 17.8316 8.22333C17.7117 8.37073 17.5402 8.46713 17.352 8.49303L17.25 8.50003H6.75C6.55998 8.49997 6.37706 8.42778 6.23821 8.29806C6.09936 8.16833 6.01493 7.99073 6.00197 7.80115C5.98902 7.61157 6.04852 7.42414 6.16843 7.27673C6.28835 7.12932 6.45975 7.03293 6.648 7.00703L6.75 7.00003H17.25Z" fill="#C4C4C4"/>
       </svg>                                                                                                                                          
   </div>
   Certificate of completion
</li>
<li v-if="contentDetails.video_details !== null">

    <span vd-readonly="true">Estimated time</span> {{videoDuration}} {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}}
</li> 
<li v-else-if="contentDetails.audio_details !== null">
    <span vd-readonly="true">Estimated time</span>{{audioDuration}} {{likeReviewRatingsSettings.is_rating_enabled ? '|':''}}</p>
</li>
<li v-else class="d-none">
    <span vd-readonly="true">Estimated time</span><p id="estimated_time"></p>
</li>
</ul>
</div> 
</div>
</div>
<div class="row gx-5">
<div class="col-lg-8" v-if="contentDetails.cast_details">
<div class="info-wrapper bottom-info">
<div class="box-padding meet-instructor">
   <div class="row justify-content-between">
       <div class="col-lg-6">
           <h3 vd-readonly="true">Meet your instructor</h3> 
         
       </div>
       
       <div class="col-lg-auto text-sm-end d-none" >
          <ul>
               <li>Students Rating:</li>
               <li>
                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                   </svg>
                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                   </svg>
                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                   </svg>
                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                   </svg>
                   <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <path d="M8.43641 2.29296C8.61983 1.92137 9.1497 1.92137 9.33312 2.29296L11.086 5.84419C11.1588 5.99161 11.2994 6.09384 11.4621 6.11762L15.3829 6.6907C15.7928 6.75062 15.9562 7.25454 15.6594 7.54362L12.8232 10.3061C12.7052 10.421 12.6514 10.5866 12.6792 10.7488L13.3485 14.651C13.4185 15.0594 12.9898 15.3709 12.6229 15.178L9.11749 13.3345C8.9718 13.2579 8.79773 13.2579 8.65204 13.3345L5.14658 15.178C4.77977 15.3709 4.35099 15.0594 4.42105 14.651L5.09031 10.7488C5.11814 10.5866 5.06431 10.421 4.94637 10.3061L2.1101 7.54362C1.81331 7.25454 1.9767 6.75062 2.38666 6.6907L6.30745 6.11762C6.47013 6.09384 6.61072 5.99161 6.68349 5.84419L8.43641 2.29296Z" fill="#C4C4C4"/>
                   </svg>
               </li>
           </ul>
       </div>
   </div>
   <div class="row mt-3" v-if="contentDetails.cast_details" v-for="(cast,j) in contentDetails.cast_details" :key="j">
   <div class="col-md-4">
           <img loading="lazy" v-if="cast.cast_image_details?.file_url != null && cast.cast_image_details?.file_url !== ''" :src="cast.cast_image_details?.file_url" alt="{{cast.cast_name}}" class="img-fluid"/>
          <img  loading="lazy" v-else :src="getRootUrl()+'img/instructor-image.png'" alt="{{cast.cast_name}}" class="img-fluid"/>
       </div>
       <div class="col-md-8">
           <div class="instructor-info">
               <ul>
                   <li><a :href="'/cast-details/'+cast.cast_uuid" class="details-btn callByAjax">{{cast.cast_name}}</a></li>
                   <li v-if="cast_type_name">{{cast.cast_type_name}}</li>
               </ul>
               <p vd-readonly="true" v-if="cast.cast_bio">{{cast.cast_bio}}</p>
           </div>
       </div>
   </div>
</div>
<div class="box-padding student-feedback d-none">
   <h3>Students Feedback</h3>
   <div class="row gx-4">
       <div class="col-md-5">
           <div class="overall-rating shadow-1 box">
               <h6>
                   <div class="svg">
                       <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <circle cx="5" cy="5" r="5" fill="url(#paint0_linear_366_3485)"/>
                           <defs>
                           <linearGradient id="paint0_linear_366_3485" x1="0" y1="0" x2="12.0586" y2="5.41911" gradientUnits="userSpaceOnUse">
                           <stop stop-color="#09C6F9"/>
                           <stop offset="1" stop-color="#045DE9"/>
                           </linearGradient>
                           </defs>
                       </svg>     
                   </div>
                   Overall Rating
               </h6>
               <p vd-readonly="true">4.5<span> / 5</span></p>
               <ul>
                   <li>
                       <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M14.3602 3.21601C14.5437 2.84442 15.0735 2.84442 15.2569 3.21601L18.5549 9.89724C18.6276 10.0447 18.7682 10.1469 18.9309 10.1707L26.3067 11.2488C26.7167 11.3087 26.8801 11.8126 26.5833 12.1017L21.247 17.2992C21.1291 17.4141 21.0752 17.5796 21.1031 17.7419L22.3623 25.084C22.4324 25.4925 22.0036 25.804 21.6368 25.6111L15.0413 22.1426C14.8956 22.066 14.7216 22.066 14.5759 22.1426L7.98041 25.6111C7.6136 25.804 7.18482 25.4925 7.25488 25.084L8.51414 17.7419C8.54197 17.5796 8.48814 17.4141 8.3702 17.2992L3.03393 12.1017C2.73714 11.8126 2.90053 11.3087 3.31049 11.2488L10.6863 10.1707C10.849 10.1469 10.9895 10.0447 11.0623 9.89724L14.3602 3.21601Z" fill="#FFC960"/>
                       </svg>
                       <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M14.3602 3.21601C14.5437 2.84442 15.0735 2.84442 15.2569 3.21601L18.5549 9.89724C18.6276 10.0447 18.7682 10.1469 18.9309 10.1707L26.3067 11.2488C26.7167 11.3087 26.8801 11.8126 26.5833 12.1017L21.247 17.2992C21.1291 17.4141 21.0752 17.5796 21.1031 17.7419L22.3623 25.084C22.4324 25.4925 22.0036 25.804 21.6368 25.6111L15.0413 22.1426C14.8956 22.066 14.7216 22.066 14.5759 22.1426L7.98041 25.6111C7.6136 25.804 7.18482 25.4925 7.25488 25.084L8.51414 17.7419C8.54197 17.5796 8.48814 17.4141 8.3702 17.2992L3.03393 12.1017C2.73714 11.8126 2.90053 11.3087 3.31049 11.2488L10.6863 10.1707C10.849 10.1469 10.9895 10.0447 11.0623 9.89724L14.3602 3.21601Z" fill="#FFC960"/>
                       </svg>
                       <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M14.3602 3.21601C14.5437 2.84442 15.0735 2.84442 15.2569 3.21601L18.5549 9.89724C18.6276 10.0447 18.7682 10.1469 18.9309 10.1707L26.3067 11.2488C26.7167 11.3087 26.8801 11.8126 26.5833 12.1017L21.247 17.2992C21.1291 17.4141 21.0752 17.5796 21.1031 17.7419L22.3623 25.084C22.4324 25.4925 22.0036 25.804 21.6368 25.6111L15.0413 22.1426C14.8956 22.066 14.7216 22.066 14.5759 22.1426L7.98041 25.6111C7.6136 25.804 7.18482 25.4925 7.25488 25.084L8.51414 17.7419C8.54197 17.5796 8.48814 17.4141 8.3702 17.2992L3.03393 12.1017C2.73714 11.8126 2.90053 11.3087 3.31049 11.2488L10.6863 10.1707C10.849 10.1469 10.9895 10.0447 11.0623 9.89724L14.3602 3.21601Z" fill="#FFC960"/>
                       </svg>   
                       <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M14.3602 3.21601C14.5437 2.84442 15.0735 2.84442 15.2569 3.21601L18.5549 9.89724C18.6276 10.0447 18.7682 10.1469 18.9309 10.1707L26.3067 11.2488C26.7167 11.3087 26.8801 11.8126 26.5833 12.1017L21.247 17.2992C21.1291 17.4141 21.0752 17.5796 21.1031 17.7419L22.3623 25.084C22.4324 25.4925 22.0036 25.804 21.6368 25.6111L15.0413 22.1426C14.8956 22.066 14.7216 22.066 14.5759 22.1426L7.98041 25.6111C7.6136 25.804 7.18482 25.4925 7.25488 25.084L8.51414 17.7419C8.54197 17.5796 8.48814 17.4141 8.3702 17.2992L3.03393 12.1017C2.73714 11.8126 2.90053 11.3087 3.31049 11.2488L10.6863 10.1707C10.849 10.1469 10.9895 10.0447 11.0623 9.89724L14.3602 3.21601Z" fill="#FFC960"/>
                       </svg>
                       <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M14.3602 3.21601C14.5437 2.84442 15.0735 2.84442 15.2569 3.21601L18.5549 9.89724C18.6276 10.0447 18.7682 10.1469 18.9309 10.1707L26.3067 11.2488C26.7167 11.3087 26.8801 11.8126 26.5833 12.1017L21.247 17.2992C21.1291 17.4141 21.0752 17.5796 21.1031 17.7419L22.3623 25.084C22.4324 25.4925 22.0036 25.804 21.6368 25.6111L15.0413 22.1426C14.8956 22.066 14.7216 22.066 14.5759 22.1426L7.98041 25.6111C7.6136 25.804 7.18482 25.4925 7.25488 25.084L8.51414 17.7419C8.54197 17.5796 8.48814 17.4141 8.3702 17.2992L3.03393 12.1017C2.73714 11.8126 2.90053 11.3087 3.31049 11.2488L10.6863 10.1707C10.849 10.1469 10.9895 10.0447 11.0623 9.89724L14.3602 3.21601Z" fill="#C4C4C4"/>
                        </svg>                                                    
                   </li>
               </ul>
               <span vd-readonly="true" class="reviews">192 reviews</span>
           </div>
       </div>
       <div class="col-md-6">
           <div class="rating-breakdown shadow-1 box">
               <h6 vd-readonly="true">
                   <div class="svg">
                       <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <circle cx="5" cy="5" r="5" fill="url(#paint0_linear_366_3485)"/>
                           <defs>
                           <linearGradient id="paint0_linear_366_3485" x1="0" y1="0" x2="12.0586" y2="5.41911" gradientUnits="userSpaceOnUse">
                           <stop stop-color="#09C6F9"/>
                           <stop offset="1" stop-color="#045DE9"/>
                           </linearGradient>
                           </defs>
                       </svg>     
                   </div>
                   Rating breakdown
               </h6>
               <ul>
                   <li>
                       <span vd-readonly="true">5</span>
                       <div class="svg">
                           <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                               <path d="M7.43641 0.292927C7.61983 -0.0786566 8.1497 -0.0786558 8.33312 0.292928L10.086 3.84416C10.1588 3.99158 10.2994 4.09381 10.4621 4.11759L14.3829 4.69067C14.7928 4.75059 14.9562 5.25451 14.6594 5.54359L11.8232 8.30612C11.7052 8.42099 11.6514 8.58655 11.6792 8.74882L12.3485 12.6509C12.4185 13.0594 11.9898 13.3709 11.6229 13.178L8.11749 11.3345C7.9718 11.2579 7.79773 11.2579 7.65204 11.3345L4.14658 13.178C3.77977 13.3709 3.35099 13.0594 3.42105 12.6509L4.09031 8.74882C4.11814 8.58655 4.06431 8.42099 3.94637 8.30612L1.1101 5.54359C0.813307 5.25451 0.9767 4.75059 1.38666 4.69067L5.30745 4.11759C5.47013 4.09381 5.61072 3.99158 5.68349 3.84416L7.43641 0.292927Z" fill="#FFC960"/>
                           </svg>                                                        
                       </div>
                       <div class="progress">
                           <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="80"></div>
                       </div>
                   </li>
                   <li>
                       <span vd-readonly="true">4</span>
                       <div class="svg">
                           <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                               <path d="M7.43641 0.292927C7.61983 -0.0786566 8.1497 -0.0786558 8.33312 0.292928L10.086 3.84416C10.1588 3.99158 10.2994 4.09381 10.4621 4.11759L14.3829 4.69067C14.7928 4.75059 14.9562 5.25451 14.6594 5.54359L11.8232 8.30612C11.7052 8.42099 11.6514 8.58655 11.6792 8.74882L12.3485 12.6509C12.4185 13.0594 11.9898 13.3709 11.6229 13.178L8.11749 11.3345C7.9718 11.2579 7.79773 11.2579 7.65204 11.3345L4.14658 13.178C3.77977 13.3709 3.35099 13.0594 3.42105 12.6509L4.09031 8.74882C4.11814 8.58655 4.06431 8.42099 3.94637 8.30612L1.1101 5.54359C0.813307 5.25451 0.9767 4.75059 1.38666 4.69067L5.30745 4.11759C5.47013 4.09381 5.61072 3.99158 5.68349 3.84416L7.43641 0.292927Z" fill="#FFC960"/>
                           </svg>                                                        
                       </div>
                       <div class="progress">
                           <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="60"></div>
                       </div>
                   </li>
                   <li>
                       <span>3</span>
                       <div class="svg">
                           <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                               <path d="M7.43641 0.292927C7.61983 -0.0786566 8.1497 -0.0786558 8.33312 0.292928L10.086 3.84416C10.1588 3.99158 10.2994 4.09381 10.4621 4.11759L14.3829 4.69067C14.7928 4.75059 14.9562 5.25451 14.6594 5.54359L11.8232 8.30612C11.7052 8.42099 11.6514 8.58655 11.6792 8.74882L12.3485 12.6509C12.4185 13.0594 11.9898 13.3709 11.6229 13.178L8.11749 11.3345C7.9718 11.2579 7.79773 11.2579 7.65204 11.3345L4.14658 13.178C3.77977 13.3709 3.35099 13.0594 3.42105 12.6509L4.09031 8.74882C4.11814 8.58655 4.06431 8.42099 3.94637 8.30612L1.1101 5.54359C0.813307 5.25451 0.9767 4.75059 1.38666 4.69067L5.30745 4.11759C5.47013 4.09381 5.61072 3.99158 5.68349 3.84416L7.43641 0.292927Z" fill="#FFC960"/>
                           </svg>                                                        
                       </div>
                       <div class="progress">
                           <div class="progress-bar" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="30"></div>
                       </div>
                   </li>
                   <li>
                       <span>2</span>
                       <div class="svg">
                           <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                               <path d="M7.43641 0.292927C7.61983 -0.0786566 8.1497 -0.0786558 8.33312 0.292928L10.086 3.84416C10.1588 3.99158 10.2994 4.09381 10.4621 4.11759L14.3829 4.69067C14.7928 4.75059 14.9562 5.25451 14.6594 5.54359L11.8232 8.30612C11.7052 8.42099 11.6514 8.58655 11.6792 8.74882L12.3485 12.6509C12.4185 13.0594 11.9898 13.3709 11.6229 13.178L8.11749 11.3345C7.9718 11.2579 7.79773 11.2579 7.65204 11.3345L4.14658 13.178C3.77977 13.3709 3.35099 13.0594 3.42105 12.6509L4.09031 8.74882C4.11814 8.58655 4.06431 8.42099 3.94637 8.30612L1.1101 5.54359C0.813307 5.25451 0.9767 4.75059 1.38666 4.69067L5.30745 4.11759C5.47013 4.09381 5.61072 3.99158 5.68349 3.84416L7.43641 0.292927Z" fill="#FFC960"/>
                           </svg>                                                        
                       </div>
                       <div class="progress">
                           <div class="progress-bar" role="progressbar" style="width: 10%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="10"></div>
                       </div>
                   </li>
                   <li>
                       <span vd-readonly="true" >1</span>
                       <div class="svg">
                           <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                               <path d="M7.43641 0.292927C7.61983 -0.0786566 8.1497 -0.0786558 8.33312 0.292928L10.086 3.84416C10.1588 3.99158 10.2994 4.09381 10.4621 4.11759L14.3829 4.69067C14.7928 4.75059 14.9562 5.25451 14.6594 5.54359L11.8232 8.30612C11.7052 8.42099 11.6514 8.58655 11.6792 8.74882L12.3485 12.6509C12.4185 13.0594 11.9898 13.3709 11.6229 13.178L8.11749 11.3345C7.9718 11.2579 7.79773 11.2579 7.65204 11.3345L4.14658 13.178C3.77977 13.3709 3.35099 13.0594 3.42105 12.6509L4.09031 8.74882C4.11814 8.58655 4.06431 8.42099 3.94637 8.30612L1.1101 5.54359C0.813307 5.25451 0.9767 4.75059 1.38666 4.69067L5.30745 4.11759C5.47013 4.09381 5.61072 3.99158 5.68349 3.84416L7.43641 0.292927Z" fill="#FFC960"/>
                           </svg>                                                        
                       </div>
                       <div class="progress">
                           <div class="progress-bar" role="progressbar" style="width: 3%" aria-valuenow="3" aria-valuemin="0" aria-valuemax="3"></div>
                       </div>
                   </li>
               </ul>
           </div>
       </div>
   </div>
</div>
<div class="box-padding pb-4 d-none">
   <div class="single-comment">
       <div class="row">
           <div class="col-12">
               <div class="row">
                   <div class="col-md-auto">
                       <div class="row align-items-center gx-3">
                           <div class="col-auto">
                               <div class="student-name">
                                   JD
                               </div>
                           </div>
                           <div class="col d-md-none">
                               <div class="student-info">
                                   <h6>John Doe</h6>
                               </div>
                           </div>
                       </div>
                       
                       
                   </div>
                   <div class="col">
                       <div class="student-info">
                           <h6 vd-readonly="true" class="d-none d-md-block">John Doe</h6>
                           <ul>
                               <li>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M8.43641 2.29296C8.61983 1.92137 9.1497 1.92137 9.33312 2.29296L11.086 5.84419C11.1588 5.99161 11.2994 6.09384 11.4621 6.11762L15.3829 6.6907C15.7928 6.75062 15.9562 7.25454 15.6594 7.54362L12.8232 10.3061C12.7052 10.421 12.6514 10.5866 12.6792 10.7488L13.3485 14.651C13.4185 15.0594 12.9898 15.3709 12.6229 15.178L9.11749 13.3345C8.9718 13.2579 8.79773 13.2579 8.65204 13.3345L5.14658 15.178C4.77977 15.3709 4.35099 15.0594 4.42105 14.651L5.09031 10.7488C5.11814 10.5866 5.06431 10.421 4.94637 10.3061L2.1101 7.54362C1.81331 7.25454 1.9767 6.75062 2.38666 6.6907L6.30745 6.11762C6.47013 6.09384 6.61072 5.99161 6.68349 5.84419L8.43641 2.29296Z" fill="#C4C4C4"></path>
                                   </svg>
                               </li>
                               <li>4 weeks ago</li>
                           </ul>
                           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ex ea commodo ditinect anet at etincididunt ut labore et dolore magna aliqua. Ut enim ad ut minim veniam, quis nostrud eiusmod tempor ex ea ullamco exercitation ullamco laboris.</p>
                       </div>

                   </div>
               </div>
           </div>
       </div>
   </div>
   <div class="single-comment">
       <div class="row">
           <div class="col-12">
               <div class="row">
                   <div class="col-md-auto">
                       <div class="row align-items-center gx-3">
                           <div class="col-auto">
                               <div class="student-name">
                                   BC
                               </div>
                           </div>
                           <div class="col d-md-none">
                               <div class="student-info">
                                   <h6 vd-readonly="true">Bessie Cooper</h6>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="col">
                       <div class="student-info">
                           <h6 class="d-none d-md-block">Bessie Cooper</h6>
                           <ul>
                               <li>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M8.43641 2.29296C8.61983 1.92137 9.1497 1.92137 9.33312 2.29296L11.086 5.84419C11.1588 5.99161 11.2994 6.09384 11.4621 6.11762L15.3829 6.6907C15.7928 6.75062 15.9562 7.25454 15.6594 7.54362L12.8232 10.3061C12.7052 10.421 12.6514 10.5866 12.6792 10.7488L13.3485 14.651C13.4185 15.0594 12.9898 15.3709 12.6229 15.178L9.11749 13.3345C8.9718 13.2579 8.79773 13.2579 8.65204 13.3345L5.14658 15.178C4.77977 15.3709 4.35099 15.0594 4.42105 14.651L5.09031 10.7488C5.11814 10.5866 5.06431 10.421 4.94637 10.3061L2.1101 7.54362C1.81331 7.25454 1.9767 6.75062 2.38666 6.6907L6.30745 6.11762C6.47013 6.09384 6.61072 5.99161 6.68349 5.84419L8.43641 2.29296Z" fill="#C4C4C4"></path>
                                   </svg>
                               </li>
                               <li>2 weeks ago</li>
                           </ul>
                           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ex ea commodo ditinect anet at etincididunt ut labore et dolore magna aliqua. Ut enim ad ut minim veniam, quis nostrud eiusmod tempor ex ea ullamco exercitation ullamco laboris.</p>
                       </div>

                   </div>
               </div>
           </div>
       </div>
   </div>
   <div class="single-comment">
       <div class="row">
           <div class="col-12">
               <div class="row">
                   <div class="col-md-auto">
                       <div class="row align-items-center gx-3">
                           <div class="col-auto">
                               <div class="student-name">
                                   LJ
                               </div>
                           </div>
                           <div class="col d-md-none">
                               <div class="student-info">
                                   <h6 vd-readonly="true">Lara Jean</h6>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="col">
                       <div class="student-info">
                           <h6 class="d-none d-md-block">Lara Jean</h6>
                           <ul>
                               <li>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M8.43641 2.29296C8.61983 1.92137 9.1497 1.92137 9.33312 2.29296L11.086 5.84419C11.1588 5.99161 11.2994 6.09384 11.4621 6.11762L15.3829 6.6907C15.7928 6.75062 15.9562 7.25454 15.6594 7.54362L12.8232 10.3061C12.7052 10.421 12.6514 10.5866 12.6792 10.7488L13.3485 14.651C13.4185 15.0594 12.9898 15.3709 12.6229 15.178L9.11749 13.3345C8.9718 13.2579 8.79773 13.2579 8.65204 13.3345L5.14658 15.178C4.77977 15.3709 4.35099 15.0594 4.42105 14.651L5.09031 10.7488C5.11814 10.5866 5.06431 10.421 4.94637 10.3061L2.1101 7.54362C1.81331 7.25454 1.9767 6.75062 2.38666 6.6907L6.30745 6.11762C6.47013 6.09384 6.61072 5.99161 6.68349 5.84419L8.43641 2.29296Z" fill="#C4C4C4"></path>
                                   </svg>
                               </li>
                               <li>1 weeks ago</li>
                           </ul>
                           <p vd-readonly="true">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ex ea commodo ditinect anet at etincididunt ut labore et dolore magna aliqua. Ut enim ad ut minim veniam, quis nostrud eiusmod tempor ex ea ullamco exercitation ullamco laboris.</p>
                       </div>

                   </div>
               </div>
           </div>
       </div>
   </div>
   <div class="single-comment border-0">
       <div class="row">
           <div class="col-12">
               <div class="row">
                   <div class="col-md-auto">
                       <div class="row align-items-center gx-3">
                           <div class="col-auto">
                               <div class="student-name">
                                   JD
                               </div>
                           </div>
                           <div class="col d-md-none">
                               <div class="student-info">
                                   <h6>Jessiee Doe</h6>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="col">
                       <div class="student-info">
                           <h6 class="d-none d-md-block">Jessiee Doe</h6>
                           <ul>
                               <li>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="15" height="14" viewBox="0 0 15 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M7.43641 0.292836C7.61983 -0.0787482 8.1497 -0.0787474 8.33312 0.292837L10.086 3.84407C10.1588 3.99149 10.2994 4.09372 10.4621 4.1175L14.3829 4.69058C14.7928 4.7505 14.9562 5.25442 14.6594 5.5435L11.8232 8.30602C11.7052 8.42089 11.6514 8.58646 11.6792 8.74872L12.3485 12.6508C12.4185 13.0593 11.9898 13.3708 11.6229 13.1779L8.11749 11.3344C7.9718 11.2578 7.79773 11.2578 7.65204 11.3344L4.14658 13.1779C3.77977 13.3708 3.35099 13.0593 3.42105 12.6508L4.09031 8.74872C4.11814 8.58646 4.06431 8.42089 3.94637 8.30602L1.1101 5.5435C0.813307 5.25442 0.9767 4.7505 1.38666 4.69058L5.30745 4.1175C5.47013 4.09372 5.61072 3.99149 5.68349 3.84407L7.43641 0.292836Z" fill="#FFC960"></path>
                                   </svg>
                                   <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M8.43641 2.29296C8.61983 1.92137 9.1497 1.92137 9.33312 2.29296L11.086 5.84419C11.1588 5.99161 11.2994 6.09384 11.4621 6.11762L15.3829 6.6907C15.7928 6.75062 15.9562 7.25454 15.6594 7.54362L12.8232 10.3061C12.7052 10.421 12.6514 10.5866 12.6792 10.7488L13.3485 14.651C13.4185 15.0594 12.9898 15.3709 12.6229 15.178L9.11749 13.3345C8.9718 13.2579 8.79773 13.2579 8.65204 13.3345L5.14658 15.178C4.77977 15.3709 4.35099 15.0594 4.42105 14.651L5.09031 10.7488C5.11814 10.5866 5.06431 10.421 4.94637 10.3061L2.1101 7.54362C1.81331 7.25454 1.9767 6.75062 2.38666 6.6907L6.30745 6.11762C6.47013 6.09384 6.61072 5.99161 6.68349 5.84419L8.43641 2.29296Z" fill="#C4C4C4"></path>
                                   </svg>
                               </li>
                               <li>4 weeks ago</li>
                           </ul>
                           <p vd-readonly="true">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ex ea commodo ditinect anet at etincididunt ut labore et dolore magna aliqua. Ut enim ad ut minim veniam, quis nostrud eiusmod tempor ex ea ullamco exercitation ullamco laboris.</p>
                       </div>

                   </div>
               </div>
           </div>
       </div>
   </div>
   <div class="text-center">
       <a href="#/" class="txt-theme callByAjax">See More Reviews</a>
   </div>
</div>
</div>
</div>
</div>

</div>
</div>
<!--================================================================
    CORSE INFO END 
==================================================================-->




    <audio_player_one
        v-if="isAudioPlay && contentUuidAudio"
        :id="$attrs['id'] +'_audio_player_one_1'"
        @queueEmit="setQueueEmit" :key="resetAudioPlayer"
        :contentUuid="contentUuidAudio" :isFreeContent ="isFreeContent"
    />
</vd-component>`,
};


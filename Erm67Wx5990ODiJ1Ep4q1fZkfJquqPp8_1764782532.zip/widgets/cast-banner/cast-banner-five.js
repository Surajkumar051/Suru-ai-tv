let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
export default {
    name: "cast_banner_five",
    data() {
        return {};
    },

    methods: {
        getRootUrl,
    },
    props: {
        cast: {},
    },

    template: `
<vd-component class="vd cast-banner-five" type="cast-banner-five">
<section class="symphony-banner-content pos-relative mb-32">
  <div class="container-fluid plr-88">
    <div class="row">          
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="album-details-banner d-md-flex d-lg-flex align-items-end">
          <div class="left-thamble">
            <img loading="lazy" class="w-100" v-if="cast?.cast_image_details !=null"  :src="cast?.cast_image_details?.file_url" >
            <img loading="lazy" class="w-100" v-else :src="cast?.no_image_available_url" >
          </div>
          <div class="data-content mw-600">           
            <h1 vd-readonly="true" class="sub-heading white-color separate-page-heading truncate-text lc-two">{{cast?.cast_name}}</h1>
            <p vd-readonly="true" class="content-data white-color">{{(cast.cast_bio?.length>350)?cast.cast_bio.substr(0,350) +'...': cast.cast_bio}}  <a class="callByAjax" href="javascript:void(0);" v-if="cast.cast_bio?.length>350" data-toggle="modal" data-target=".readmore-banner">ReadMore</a></p>
          </div>
       </div>
      </div>
    </div>
  </div>    
</section>

<!--popup design readmore Start Here-->
  <div class="modal fade readmore-banner" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header flex-column">
                  <h5 class="modal-title" id="exampleModalLabel">{{cast?.cast_name}}</h5>
                  <h6> </h6>
                  <span class="close-model" data-dismiss="modal"><img  vd-node="image" :src="getRootUrl() +'img/modalCloseCross.png'" alt="popup" class="modalCloseCross"></span>
              </div>
              <div class="modal-body">
                  <p>{{cast?.cast_bio}}</p>
              </div>
          </div>
      </div>
  </div>
<!--popup desihn End Here-->

</vd-component>
    `,
    //    inheritAttrs: false
};

let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: 'cast_banner_six',
    data() {
        return {

        }
    },

    methods: {
        getRootUrl,
        i18n,
    },
    props: {
        cast: {},

    },

    template: `
    <vd-component class="vd cast-banner-six" type="cast-banner-six">

    <section class="banner-section">
      <div class="container-fluid">
        <div class="row">          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0 m-0">
            <div class="banner-content">
              <div class="owl-banner owl-carousel owl-theme custom-banner-nocrew custom-banner-nocast owl-loaded owl-drag">
            
                <!-- <div class="item"><img src="images/persion-banner.png" alt="banner"/></div>
                <div class="item"><img src="images/persion-banner.png" alt="banner"/></div> -->
                <div class="owl-stage-outer">
                  <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1560px;">
                    <div class="owl-item active" style="width: 1558.2px; margin-right: 1px;">
                      <div class="item">
                        <img vd-node="image" :src="getRootUrl() + 'img/persion-banner.png'">
                      </div>
                    </div>
                  </div>
                </div>                   
              </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 banner-text-left custom-vpd-mobile">
              <div class="banner-data">
                <div class="custom-vpd-box">
                  <div class="profile-pic">
                    
                    <img loading="lazy" v-if="cast?.cast_image_details !=null"
                      style="border-radius: 50%!important;" :src="cast?.cast_image_details?.file_url" >
                    <img loading="lazy" v-else style="border-radius: 50%!important;" :src="cast?.no_image_available_url" >
                    
                  </div>
                  <div class="comment-data">           
                    <h1 class="main-heading white-color truncate-text lc-two">{{cast?.cast_name}}</h1>
                    <!-- <h2 class="sub-heading white-color">Actor</h2> -->
                    <p class="content-data white-color">{{(cast.cast_bio?.length>350)?cast.cast_bio.substr(0,350) +'...': cast.cast_bio}}  <a class="callByAjax" href="javascript:void(0);" v-if="cast.cast_bio?.length>350" data-toggle="modal" data-target=".readmore-banner">{{i18n("ReadMore")}}</a></p>                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>        
      </div>
    </section>

    <!--popup design readmore Start Here-->
    <div class="modal fade readmore-banner" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header flex-column">
                  <h5 class="modal-title" id="exampleModalLabel">{{cast?.cast_name}}</h5>
                  <h6> </h6>
                  <span class="close-model" data-dismiss="modal"><img  vd-node="image" :src="getRootUrl() +'img/modalCloseCross.png'" alt="popup" class="modalCloseCross"></span>
                </div>
                <div class="modal-body">
                  <p>{{cast?.cast_bio}}</p>
                </div>
            </div>
        </div>
    </div>
    <!--popup desihn End Here-->

    </vd-component>
`,
    //    inheritAttrs: false
}
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
export default {
    name: "cast_banner_two",
    data() {
        return {};
    },
    methods: {
        getRootUrl,
    },
    props: {
        cast: {},
    },
    template: `
<vd-component class="vd cast-banner-two" type="cast-banner-two">
  <section class="homepage-banner">
    <div class="container-fluid">
      <div class="row">          
        <div class="col-12 p-0 m-0">
          <div class="banner-section">
            <div class="owl-banner owl-carousel owl-loaded owl-drag">
             <div class="item"v-if="cast?.cast_image_details !=null" :style="{'background-image': 'url('+cast?.cast_image_details?.file_url+')' }">
              <div class="banner-content h-100">
                <div class="container h-100">
                  <div class="row justify-content-center h-100">
                    <div class="col-xl-6">                                               
                      <div class="gen-movie-info">
                          <h3 vd-readonly="true">{{cast?.cast_name}}</h3>
                      </div>
                      <div class="gen-movie-meta-holder">
                        <p vd-readonly="true">{{(cast.cast_bio?.length>350)?cast.cast_bio.substr(0,350) +'...': cast.cast_bio}} <a class="callByAjax" href="javascript:void(0);" v-if="cast.cast_bio?.length>350" data-toggle="modal" data-target=".readmore-banner">ReadMore</a></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             </div> 
             <div class="item" v-else :style="{'background-image': 'url('+cast?.no_image_available_url+')' }">
              <div class="banner-content h-100">
                <div class="container h-100">
                  <div class="row justify-content-center h-100">
                    <div class="col-xl-11">                                               
                      <div class="gen-movie-info">
                          <h3 vd-readonly="true">{{cast?.cast_name}}</h3>
                      </div>
                      <div class="gen-movie-meta-holder">
                        <p vd-readonly="true">{{(cast.cast_bio?.length>350)?cast.cast_bio.substr(0,350) +'...': cast.cast_bio}} <a class="callByAjax" href="javascript:void(0);" v-if="cast.cast_bio?.length>350" data-toggle="modal" data-target=".readmore-banner">ReadMore</a></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             </div> 
            </div> 
          </div>
        </div>
      </div>
  </div>        
</section>

<!--popup design readmore Start Here-->
  <div class="modal fade readmore-banner" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header flex-column">
                  <h5 class="modal-title" id="exampleModalLabel">{{cast?.cast_name}}</h5>
                  <h6> </h6>
                        
                  <span class="close-model" data-dismiss="modal"><img vd-node="image" :src="getRootUrl() +'img/modalCloseCross.png'" alt="popup" class="modalCloseCross"></span>
                    
                  
              </div>
              <div class="modal-body">
                  <p>{{cast?.cast_bio}}</p>
              </div>
          </div>
      </div>
  </div>
<!--popup desihn End Here-->

</vd-component>
    `,
};

let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
// let { getVdConfig } = await import(window.importAssetJs('js/webservices.js'));
const { mapState} = Vuex;

export default {
    name: "passwordsuccess_six",
    data() {
        return {
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
        };
    },
    mounted() {
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             //this.logo = res.data.data;
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    methods: {
        getRootUrl,
        i18n,
    },
    computed: {
        ...mapState({
          logo_details: (state) => state.logo_details,
        })
      },
    template: `
    <vd-component class="vd passwordsuccess-six" type="passwordsuccess-six">
        <section class="header bg-color-bh">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a v-if="logo_details['logo']"  class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                               :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                            <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="getRootUrl() +'img/logo.png'"
                                alt="Symphony" /></a> 
                        </nav>
                    </div>
                </div>
            </div>
        </section>
      <!--Header Section End Here-->
      <!--Sign Up From Start Here-->
      <section class="sign-process">
          <div class="content">
              <!--From Section Start Here-->
              <div class="sign-form-layout check-inbox forgot-pwd-layout">
                  <!--Sign up Confirmation Mail-->
                  <div class="email-otp-validate text-center">
                      <img vd-node="image" :src="getRootUrl() + 'img/mail1.png'" alt="Email Confirm"
                          class="mb-32" />
                      <h1><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h1>
                      <p><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></p>
                  </div>
                  <div class="form-group">
                      <a vd-node="link" href="/sign-in" class="btn primary-button callByAjax" role="button"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
                  </div>
                  <!--Sign up Confirmation Mail-->
              </div>
              <!--From Section End Here-->
          </div>
      </section>
    </vd-component>
    `,
};

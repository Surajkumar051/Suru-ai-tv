let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { mapState} = Vuex;

export default {
    name: "passwordsuccess_five",
    data() {
        return {
          logo_src: "",
          logo_alt: "",
          logo_style: "",
          isLogoUpdated: Boolean,
            
        };
    },

    methods: {
        getRootUrl,
        i18n,
    },
    computed: {
      ...mapState({
        logo_details: (state) => state.logo_details,
      })
    },
    template: `
    <vd-component class="vd passwordsuccess-five" type="passwordsuccess-five">
    <section class="header" style="background: transparent;">
      <div class="container-fluid plr-65">
          <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                  <nav class="navbar navbar-expand-lg navbar-light flex-nowrap p-0 ">
                
                                       <a v-if="logo_details['logo']"  class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="logo_details['logo']['src']"
                     :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
                  <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" :src="getRootUrl() +'img/garnetLogo.png'"
                     alt="Garnet" /></a> 
                      
                    </nav>
              </div>
          </div>
      </div>
  </section>
 <!--Sign Up From Start Here-->
    <section class="sign-process mb-94">
      <div class="content">
        <!--From Section Start Here-->
        <div class="sign-form-layout check-inbox">
          <!--Sign up Confirmation Mail-->
          <div class="email-otp-validate text-center">
            <img vd-node="image" :src="getRootUrl() + 'img/mail1.png'" alt="Email Confirm" class="mb-32" />
            <h3 class="heading-h2 text-center"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h3>
            <div class="or-text"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></div>
          </div>
          <div class="form-group">
            <a vd-node="link" href="/sign-in" class="common-btn blue callByAjax" role="button"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
          </div>
          <!--Sign up Confirmation Mail-->
        </div>
        <!--From Section End Here-->
      </div>
    </section>
    </vd-component>
    `,
};

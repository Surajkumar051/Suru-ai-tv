let {
    resetPassword,
    // getVdConfig,
  } = await import(window.importAssetJs('js/webservices.js'));
  let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
  let {i18n} = await import(window.importAssetJs('js/i18n.js'));
  let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
  const { mapState} = Vuex;
  
  export default {
    name: "resetpassword_four",
    data() {
        return {
            newpassword: "",
            confirmpassword: "",
            passkey: "",
            isFormValid: false,
            showPassword: false,
            showConfPassword: false,
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            errors: {},
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
        };
    },
    mounted() {
        this.passkey = new URLSearchParams(window.location.search).get(
            "pass_key"
        );
        setTimeout(() => {
            JsLoadingOverlay.hide();
        }, 1000);
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             // this.logo = res.data.data;
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    computed: {
        newpassword() {
            return this.newpassword;
        },
        confirmpassword() {
            return this.confirmpassword;
        },
        ...mapState({
            logo_details: (state) => state.logo_details,
          })
    },
    watch: {
        newpassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.newpassword = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
            } else if (value.length < 8) {
                this.errors.valid = false;
  
                this.isFormValid = false;
                this.errors.newpassword =
                i18n("Password should be more than 8 characters long.");
                this.passwordFieldNotValidate = true;
            } else if (value === this.confirmpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.password = null;
                this.passwordFieldNotValidate = true;
                this.errors.confirmpassword = null;
                this.errors.newpassword = null;
            } else {
                this.errors.newpassword = null;
                this.passwordFieldNotValidate = false;
                if (value !== this.confirmpassword) {
                    this.errors.valid = false;
                    this.isFormValid = false;
                    this.errors.confirmpassword = i18n("Password do not match");
                    this.confirmPwdFieldNotValidate = true;
                }
                if (
                    this.errors.newpassword !== undefined &&
                    this.errors.newpassword == null &&
                    this.errors.confirmpassword !== undefined &&
                    this.errors.confirmpassword == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
        confirmpassword(value) {
            if (!value.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword =
                i18n("New Password field is required");
                this.confirmPwdFieldNotValidate = true;
            } else if (value !== this.newpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword = i18n("Passwords do not match");
                this.confirmPwdFieldNotValidate = true;
            } else {
                this.errors.confirmpassword = null;
                this.confirmPwdFieldNotValidate = false;
  
                if (
                    this.errors.newpassword !== undefined &&
                    this.errors.newpassword == null &&
                    this.errors.confirmpassword !== undefined &&
                    this.errors.confirmpassword == null
                ) {
                    this.errors.valid = true;
                    this.isFormValid = true;
                }
            }
        },
    },
  
    methods: {
        getRootUrl,
        i18n,
        submitResetPassword() {
            if (!this.newpassword.length) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.newpassword = i18n("Password field is required");
                this.passwordFieldNotValidate = true;
                return;
            } else {
                this.errors.newpassword = null;
                this.passwordFieldNotValidate = false;
            }
  
            if (this.newpassword != this.confirmpassword) {
                this.errors.valid = false;
                this.isFormValid = false;
                this.errors.confirmpassword =
                i18n("New password field not matched");
                this.confirmPwdFieldNotValidate = true;
                return;
            }
  
            this.errors.valid = true;
            this.isFormValid = true;
  
            let passwordData = {
                password_key: this.passkey,
                new_password: this.newpassword,
                confirm_password: this.confirmpassword,
            };
            resetPassword(passwordData)
                .then((res) => {
                    if (
                        res.data.code === 200 &&
                        res.data.status === "SUCCESS"
                    ) {
                        //show modal
                        $('.resetPassword').addClass('d-none');
                        $('.rp-success').removeClass('d-none');
                        //show modal end her
                        // Toast.fire({
                        //     icon: "success",
                        //     text: res.data.message,
                        // });
  
                        // window.location.href = "/"+this.languageCode+"/sign-in";
                        // setTimeout(() => {
                        //     window.location.href = "/login";
                        // }, 1000);
                    } else {
                        Toast.fire({
                            icon: "error",
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    console.log("error", err);
                });
        },
    },
    template: `
  <vd-component class="vd resetpassword-four" type="resetpassword-four">
    <div class="main-container ptb-10">
  <section class="box-section">
    <div class="sign-first mobile-input">
      <div class="all-content fp-ac resetPassword">
        <h2 class="heading-h2"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
        </h2>
        <p class="fp-subHeading mb-4"><vd-component-param type="label2"
            v-html="i18n($attrs['label2'])"></vd-component-param></p>
  
        <div class="input-section">
          <div class="mobile-input-container position-relative mb-0">
            <input @keyup.enter="submitResetPassword" v-bind:type="[showPassword ? 'text' : 'password']"
              v-model="newpassword" id="Password-old" class="form-control enter-input pr-46  vd-component-attr"
              vd-component-attr-placeholder="label5" :placeholder=i18n($attrs['label5'])
              vd-component-attr-title="label5" :title=i18n($attrs['label5']) autocomplete="off"
              :class="passwordFieldNotValidate ? '_required' : ''">
  
            <button type="button" class="showhide-pwd-btn" id="showhide-pwd-btnOld"
              @click="showPassword = !showPassword">
              <svg v-show="!showPassword" class="closeEye" xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                viewBox="0 0 18 18" fill="none">
                <path fill-rule="evenodd" clip-rule="evenodd"
                  d="M17.6652 7.37587C17.8993 7.52223 17.9705 7.8307 17.8242 8.06487C17.2831 8.93052 16.6369 9.71486 15.9004 10.393L17.4149 11.9075C17.6102 12.1028 17.6102 12.4194 17.4149 12.6147C17.2197 12.8099 16.9031 12.8099 16.7078 12.6147L15.1308 11.0376C14.1421 11.7888 13.0218 12.3631 11.7987 12.7125L12.3631 14.819C12.4346 15.0858 12.2763 15.3599 12.0096 15.4314C11.7428 15.5029 11.4687 15.3446 11.3972 15.0779L10.8241 12.9387C10.2355 13.0446 9.62656 13.0999 9.00016 13.0999C8.37376 13.0999 7.76483 13.0446 7.17623 12.9387L6.60313 15.0778C6.53167 15.3446 6.25751 15.5029 5.99077 15.4314C5.72404 15.36 5.56574 15.0858 5.6372 14.8191L6.20156 12.7125C4.97845 12.3631 3.85816 11.7888 2.86952 11.0376L1.29246 12.6146C1.0972 12.8099 0.780619 12.8099 0.585357 12.6146C0.390094 12.4194 0.390094 12.1028 0.585357 11.9075L2.09991 10.393C1.36345 9.71484 0.717194 8.93051 0.176166 8.06487C0.0298103 7.8307 0.100996 7.52223 0.335164 7.37587C0.569332 7.22952 0.877807 7.3007 1.02416 7.53487C1.60553 8.46505 2.31593 9.28806 3.13336 9.97003C3.14483 9.97874 3.15601 9.98801 3.16686 9.99785C4.76179 11.3163 6.76015 12.0999 9.00016 12.0999C12.408 12.0999 15.2566 10.2862 16.9762 7.53487C17.1225 7.3007 17.431 7.22952 17.6652 7.37587Z"
                  fill="#C1C1C1"></path>
              </svg>
              <svg v-show="showPassword" class="openEye" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                viewBox="0 0 20 20" fill="none">
                <path
                  d="M0.833496 10.0002C0.833496 10.0002 4.16683 3.3335 10.0002 3.3335C15.8335 3.3335 19.1668 10.0002 19.1668 10.0002C19.1668 10.0002 15.8335 16.6668 10.0002 16.6668C4.16683 16.6668 0.833496 10.0002 0.833496 10.0002Z"
                  stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                <path
                  d="M10 12.5C11.3807 12.5 12.5 11.3807 12.5 10C12.5 8.61929 11.3807 7.5 10 7.5C8.61929 7.5 7.5 8.61929 7.5 10C7.5 11.3807 8.61929 12.5 10 12.5Z"
                  stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
              </svg>
            </button>
  
          </div>
  
               <span v-if="errors.newpassword" class="validationError mt-min10">{{ errors.newpassword }}</span>
            
          <div class="mobile-input-container position-relative mb-0">
            <input @keyup.enter="submitResetPassword" v-bind:type="[showConfPassword ? 'text' : 'password']"
              v-model="confirmpassword" id="Password-new" class="form-control enter-input pr-46 vd-component-attr"
              vd-component-attr-placeholder="label6" :placeholder=i18n($attrs['label6'])
              vd-component-attr-title="label6" :title=i18n($attrs['label6']) @copy.prevent @paste.prevent @cut.prevent
              autocomplete="off" :class="confirmPwdFieldNotValidate ? 'is-invalid' : ''">
  
            <button type="button" class="showhide-pwd-btn" id="showhide-pwd-btnNew"
              @click="showConfPassword = !showConfPassword">
              <svg v-show="!showConfPassword" class="closeEye" xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                viewBox="0 0 18 18" fill="none">
                <path fill-rule="evenodd" clip-rule="evenodd"
                  d="M17.6652 7.37587C17.8993 7.52223 17.9705 7.8307 17.8242 8.06487C17.2831 8.93052 16.6369 9.71486 15.9004 10.393L17.4149 11.9075C17.6102 12.1028 17.6102 12.4194 17.4149 12.6147C17.2197 12.8099 16.9031 12.8099 16.7078 12.6147L15.1308 11.0376C14.1421 11.7888 13.0218 12.3631 11.7987 12.7125L12.3631 14.819C12.4346 15.0858 12.2763 15.3599 12.0096 15.4314C11.7428 15.5029 11.4687 15.3446 11.3972 15.0779L10.8241 12.9387C10.2355 13.0446 9.62656 13.0999 9.00016 13.0999C8.37376 13.0999 7.76483 13.0446 7.17623 12.9387L6.60313 15.0778C6.53167 15.3446 6.25751 15.5029 5.99077 15.4314C5.72404 15.36 5.56574 15.0858 5.6372 14.8191L6.20156 12.7125C4.97845 12.3631 3.85816 11.7888 2.86952 11.0376L1.29246 12.6146C1.0972 12.8099 0.780619 12.8099 0.585357 12.6146C0.390094 12.4194 0.390094 12.1028 0.585357 11.9075L2.09991 10.393C1.36345 9.71484 0.717194 8.93051 0.176166 8.06487C0.0298103 7.8307 0.100996 7.52223 0.335164 7.37587C0.569332 7.22952 0.877807 7.3007 1.02416 7.53487C1.60553 8.46505 2.31593 9.28806 3.13336 9.97003C3.14483 9.97874 3.15601 9.98801 3.16686 9.99785C4.76179 11.3163 6.76015 12.0999 9.00016 12.0999C12.408 12.0999 15.2566 10.2862 16.9762 7.53487C17.1225 7.3007 17.431 7.22952 17.6652 7.37587Z"
                  fill="#C1C1C1"></path>
              </svg>
              <svg v-show="showConfPassword" class="openEye" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                viewBox="0 0 20 20" fill="none">
                <path
                  d="M0.833496 10.0002C0.833496 10.0002 4.16683 3.3335 10.0002 3.3335C15.8335 3.3335 19.1668 10.0002 19.1668 10.0002C19.1668 10.0002 15.8335 16.6668 10.0002 16.6668C4.16683 16.6668 0.833496 10.0002 0.833496 10.0002Z"
                  stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                <path
                  d="M10 12.5C11.3807 12.5 12.5 11.3807 12.5 10C12.5 8.61929 11.3807 7.5 10 7.5C8.61929 7.5 7.5 8.61929 7.5 10C7.5 11.3807 8.61929 12.5 10 12.5Z"
                  stroke="#C1C1C1" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
              </svg>
            </button>
  
          </div>
               <span v-if="errors.confirmpassword" class="validationError mt-min10">{{ errors.confirmpassword }}</span>
  
          <div class="otp-btn-div">
            <button class="common-btn blue rp-btn" vd-node="styleOnly" vd-readonly="true"
              @click="submitResetPassword()"><span><vd-component-param type="label3"
                  v-html="i18n($attrs['label3'])"></vd-component-param></span></button>
          </div>
        </div>
      </div>
      <div class="rp-success d-none">
        <span class="rps-svg">
          <svg xmlns="http://www.w3.org/2000/svg" width="106" height="107" viewBox="0 0 106 107" fill="none">
            <circle cx="53" cy="53.5" r="51.5" stroke="#24AE60" stroke-width="3" />
            <path d="M29 53.5L47 71.5L77 35.5" stroke="#24AE60" stroke-width="4" stroke-linecap="round"
              stroke-linejoin="round" />
          </svg>
        </span>
        <div class="rps-bottom">
          <div class="rpsb-heading">
            <h2 class="heading-h2"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h2>
            <p class="fp-subHeading pb-0 mb-0"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></p>
          </div>
          <div class="create-account-div">
            <span class="span-create-account">
              <a class="create-account-a" vd-node="link"  href="/sign-in">
                <span class="d-flex">
                  <svg xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none">
                    <path d="M13.1666 8H3.83331" stroke="#bf000a" stroke-width="1.33" stroke-linecap="round"
                      stroke-linejoin="round" />
                    <path d="M8.49998 12.6667L3.83331 8.00004L8.49998 3.33337" stroke="#bf000a" stroke-width="1.33"
                      stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                </span>
                <span>
                     <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
            </span>
          </div>
        </div>
      </div>
    </div>
  </section>
  </div>
    </vd-component>
    `,
  };
  
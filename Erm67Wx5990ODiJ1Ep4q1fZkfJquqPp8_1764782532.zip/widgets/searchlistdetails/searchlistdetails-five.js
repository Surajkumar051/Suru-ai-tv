let { default: content_hover_eight } = await import(window.importLocalJs('widgets/content-hover/content-hover-eight.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { default: content_title_eight } = await import(window.importLocalJs('widgets/content-title/content-title-eight.js'));
let { getContentSettingsDetails, getSerachContentBasedOnCondition, getUgcSettingStatus, getPartnerAndUserSettingDetails, fetchUserAndPartnersForSearch } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { default: audio_player_one } = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { getRootUrl,getAssetUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
let contentHelper = await import(window.importAssetJs('js/content-helper.js'));
export default {
    name: "searchlistdetails_five",
    components: {
        content_hover_eight,
        audio_player_one,
        content_title_eight
    },
    data() {
        return {
            searchListData: [],
            // contentUuid: decodeURIComponent(
            //     (
            //         window.location.pathname.toString().split("/")[2] + ""
            //     ).replace(/\+/g, "%20")
            // ),
            contentUuid: permalink,
            nodatafound: false,
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            pageNo: 1,
            isNextPageCallReqd: true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            assetUrl:getAssetUrl(),
            reloadOnUpdateLifeCycle: true,
            userList: [],
            isAudioNextPageCallReqd: true,
            searchAudioListData: [],
            nodatafoundAudio: false,
            audioPageNo: 1,
            isPartnerNextPageCallReqd: true,
            searchPartnerListData: [],
            nodatafoundPartner: false,
            partnerPageNo: 1,
            isNestedContentNextPageCallReqd: true,
            searchNestedContentListData: [],
            nodatafoundNestedContent: false,
            nestedContentPageNo: 1,
            isPlaylistNextPageCallReqd: true,
            searchPlaylistListData: [],
            nodatafoundPlaylist: false,
            playlistPageNo: 1,
            isUGCNextPageCallReqd: true,
            searchUGCListData: [],
            nodatafoundUGC: false,
            ugcPageNo: 1,
            isMiniNextPageCallReqd: true,
            searchMiniListData: [],
            nodatafoundMini: false,
            miniPageNo: 1,
            currentTab: "movies",
            ugcFeatureEnabled: false,
            ugcVodEnables: false,
            miniEnabled: false,
            ugcProfileEnabled: false,
            partnerEnabled: false,
            partnerProfileEnabled: false,
            isCreatorsNextPageCallReqd: true,
            searchCreatorsListData: [],
            nodatafoundCreators: false,
            creatorsPageNo: 1,
            searchListTotalCount: 0,
            searchCreatorsTotalCount: 0,
            searchMiniTotalCount: 0,
            searchUGCTotalCount: 0,
            searchPlaylistTotalCount: 0,
            searchPartnerTotalCount: 0,
            searchAudioTotalCount: 0,
            searchNestedContentTotalCount: 0,
            assignedArray: [],
            gutterSpace: null,
            isDocumentNextPageCallReqd: true,
            searchDocumentListData: [],
            nodatafoundDocument:false,
            documentPageNo: 1,
            searchDocumentTotalCount:0,
            isFavouriteEnabled: false,
        };
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        JsLoadingOverlay.hide();
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.getSerachContentDeatils(this.contentUuid, this.pageNo, false);
        this.fetchSettings();
        this.loadMore();
         getContentSettingsDetails().then((res) => {
            if (res.data.code == 200) {
                
                this.isFavouriteEnabled =
                    res.data.data.contentSettings
                        .content_favourite_settings != null
                        ? res.data.data.contentSettings
                              .content_favourite_settings?.is_enabled
                        : false;
              
            }
        });  
    },
computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    methods: {
        getRootUrl,
        getAssetUrl,
        i18n,
        getSerachDocumentContentDeatils(onScroll) {
            if (this.isDocumentNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isDocumentNextPageCallReqd = false;
                if(!onScroll){
                    this.documentPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,6,1,null,0, this.documentPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchDocumentListData || 
                        this.searchDocumentListData?.length==0)
                    ) {
                        this.searchDocumentListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchDocumentListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchDocumentTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchDocumentListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isDocumentNextPageCallReqd = true;
                    }
                    if (
                        this.searchDocumentListData == null ||
                        this.searchDocumentListData?.length <= 0
                    ) {
                        this.nodatafoundDocument = true;
                    }
                });
            }
        },

        fetchSettings(){
            getUgcSettingStatus().then((res) => {
                if (res.data.status == 'SUCCESS' && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(element => {
                        if (element.node_code == 'ugc') {
                            this.ugcEnabled = (element.node_value && element.node_value == 1) ? true : false;
                        }
                        if (element.node_code == "partner_portal") {
                            this.partnerEnabled =
                                element.node_value &&
                                    element.node_value == 1
                                    ? true
                                    : false;
                        }
                    });
                    res.data.data.sections[0].groups[1].nodes.forEach(element => {
                        if (element.node_code == 'mini_access') {
                            this.miniEnabled = (element.node_value && element.node_value == 1) ? true : false;
                            if (this.ugcEnabled && this.miniEnabled) {
                                $('#minis-t-tab').parent().show();
                            } else {
                                $('#minis-t-tab').parent().hide();
                            }
                        }
                        if (element.node_code == 'vod_access') {
                            this.ugcVodEnables = (element.node_value && element.node_value == 1) ? true : false;
                            if (this.ugcEnabled && this.ugcVodEnables) {
                                $('#ugc-t-tab').parent().show();
                            } else {
                                $('#ugc-t-tab').parent().hide();
                            }
                        }
                        if (element.node_code == "user_profile") {
                            this.ugcProfileEnabled =
                                element.node_value &&
                                    element.node_value == 1
                                    ? true
                                    : false;
                        }
                    });
                }
            });
            getPartnerAndUserSettingDetails().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "profile_page") {
                                this.partnerProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        });
                }
            });
        },
        getSerachContentDeatils(onScroll) {
            if (this.isNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isNextPageCallReqd = false;
                if (!onScroll) {
                    this.pageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid, 1, 1, null, 0, this.pageNo).then((res) => {
                    JsLoadingOverlay.hide();
                   
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchListData ||
                            this.searchListData?.length == 0)
                    ) {
                        this.searchListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    }
                    this.searchListTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchListData?.length <
                        res.data.data.contentList.page_info.total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.searchListData == null ||
                        this.searchListData?.length <= 0
                    ) {
                        this.nodatafound = true;
                    }
                });
            }
        },
        getSerachAudioContentDeatils(onScroll) {
            if (this.isAudioNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isAudioNextPageCallReqd = false;
                if (!onScroll) {
                    this.audioPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid, 2, 1, null, 0, this.audioPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchAudioListData ||
                            this.searchAudioListData?.length == 0)
                    ) {
                        this.searchAudioListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchAudioListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    }
                    this.searchAudioTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchAudioListData?.length <
                        res.data.data.contentList.page_info.total_count
                    ) {
                        this.isAudioNextPageCallReqd = true;
                    }
                    if (
                        this.searchAudioListData == null ||
                        this.searchAudioListData?.length <= 0
                    ) {
                        this.nodatafoundAudio = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForNestedContent(onScroll) {
            if (this.isNestedContentNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isNestedContentNextPageCallReqd = false;
                if (!onScroll) {
                    this.nestedContentPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid, "", 2, null, 0, this.nestedContentPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchNestedContentListData ||
                            this.searchNestedContentListData?.length == 0)
                    ) {
                        this.searchNestedContentListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchNestedContentListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    }
                    this.searchNestedContentTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchNestedContentListData?.length <
                        res.data.data.contentList.page_info.total_count
                    ) {
                        this.isNestedContentNextPageCallReqd = true;
                    }
                    if (
                        this.searchNestedContentListData == null ||
                        this.searchNestedContentListData?.length <= 0
                    ) {
                        this.nodatafoundNestedContent = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForPlaylistContent(onScroll) {
            if (this.isPlaylistNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isPlaylistNextPageCallReqd = false;
                if (!onScroll) {
                    this.playlistPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid, "", null, null, 1, this.playlistPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchPlaylistListData ||
                            this.searchPlaylistListData?.length == 0)
                    ) {
                        this.searchPlaylistListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchPlaylistListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    }
                    this.searchPlaylistTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchPlaylistListData?.length <
                        res.data.data.contentList.page_info.total_count
                    ) {
                        this.isPlaylistNextPageCallReqd = true;
                    }
                    if (
                        this.searchPlaylistListData == null ||
                        this.searchPlaylistListData?.length <= 0
                    ) {
                        this.nodatafoundPlaylist = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForUGCContent(onScroll) {
            if (this.isUGCNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isUGCNextPageCallReqd = false;
                if (!onScroll) {
                    this.ugcPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid, 1, null, 1, 0, this.ugcPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchUGCListData ||
                            this.searchUGCListData?.length == 0)
                    ) {
                        this.searchUGCListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchUGCListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    }
                    this.searchUGCTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchUGCListData?.length <
                        res.data.data.contentList.page_info.total_count
                    ) {
                        this.isUGCNextPageCallReqd = true;
                    }
                    if (
                        this.searchUGCListData == null ||
                        this.searchUGCListData?.length <= 0
                    ) {
                        this.nodatafoundUGC = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForMiniContent(onScroll) {
            if (this.isMiniNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isMiniNextPageCallReqd = false;
                if (!onScroll) {
                    this.miniPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid, 1, null, 2, 0, this.miniPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchMiniListData ||
                            this.searchMiniListData?.length == 0)
                    ) {
                        this.searchMiniListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchMiniListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list, this.userList);
                    }
                    this.searchMiniTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchMiniListData?.length <
                        res.data.data.contentList.page_info.total_count
                    ) {
                        this.isMiniNextPageCallReqd = true;
                    }
                    if (
                        this.searchMiniListData == null ||
                        this.searchMiniListData?.length <= 0
                    ) {
                        this.nodatafoundMini = true;
                    }
                });
            }
        },
        getSerachCreatorDeatils(onScroll) {
            if (this.isCreatorsNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isCreatorsNextPageCallReqd = false;
                if (!onScroll) {
                    this.creatorsPageNo = 1;
                }
                fetchUserAndPartnersForSearch(this.contentUuid, "user", this.creatorsPageNo, 16).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getEndUserList.end_user_list &&
                        (this.searchCreatorsListData ||
                            this.searchCreatorsListData?.length == 0)
                    ) {
                        this.searchCreatorsListData =
                            res.data.data.getEndUserList.end_user_list;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getEndUserList.end_user_list
                    ) {
                        this.searchCreatorsListData.push(
                            ...res.data.data.getEndUserList.end_user_list
                        );
                    }
                    this.searchCreatorsTotalCount = res?.data?.data?.getEndUserList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchCreatorsListData?.length <
                        res.data.data.getEndUserList.page_info.total_count
                    ) {
                        this.isCreatorsNextPageCallReqd = true;
                    }
                    if (
                        this.searchCreatorsListData == null ||
                        this.searchCreatorsListData?.length <= 0
                    ) {
                        this.nodatafoundCreators = true;
                    }
                });
            }
        },
        getSerachPartnerDeatils(onScroll) {
            if (this.isPartnerNextPageCallReqd) {
                JsLoadingOverlay.show();
                this.isPartnerNextPageCallReqd = false;
                if (!onScroll) {
                    this.partnerPageNo = 1;
                }
                fetchUserAndPartnersForSearch(this.contentUuid, "partner", this.partnerPageNo, 16).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getPartners.users_list &&
                        (this.searchPartnerListData ||
                            this.searchPartnerListData?.length == 0)
                    ) {
                        this.searchPartnerListData =
                            res.data.data.getPartners.users_list;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getPartners.users_list
                    ) {
                        this.searchPartnerListData.push(
                            ...res.data.data.getPartners.users_list
                        );
                    }
                    this.searchPartnerTotalCount = res?.data?.data?.getPartners?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchPartnerListData?.length <
                        res.data.data.getPartners.page_info.total_count
                    ) {
                        this.isPartnerNextPageCallReqd = true;
                    }
                    if (
                        this.searchPartnerListData == null ||
                        this.searchPartnerListData?.length <= 0
                    ) {
                        this.nodatafoundCreators = true;
                    }
                });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                    document.documentElement.clientHeight +
                    20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && this.currentTab == 'movies' && scrollLoad) {
                    this.pageNo++;
                    this.getSerachContentDeatils(
                        true
                    );
                }
                if (bottomOfWindow && this.isAudioNextPageCallReqd && this.currentTab == 'audio' && scrollLoad) {
                    this.audioPageNo++;
                    this.getSerachAudioContentDeatils(
                        true
                    );
                }
                if (bottomOfWindow && this.isDocumentNextPageCallReqd && this.currentTab=='document' && scrollLoad) {
                    this.documentPageNo++;
                    this.getSerachDocumentContentDeatils(
                        true
                    );
                }

                if (bottomOfWindow && this.isNestedContentNextPageCallReqd && this.currentTab=='series' && scrollLoad) {
                    this.nestedContentPageNo++;
                    this.getSerachContentDeatilsForNestedContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isPlaylistNextPageCallReqd && this.currentTab == 'playlist' && scrollLoad) {
                    this.playlistPageNo++;
                    this.getSerachContentDeatilsForPlaylistContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isUGCNextPageCallReqd && this.currentTab == 'ugc' && scrollLoad) {
                    this.ugcPageNo++;
                    this.getSerachContentDeatilsForUGCContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isMiniNextPageCallReqd && this.currentTab == 'mini' && scrollLoad) {
                    this.miniPageNo++;
                    this.getSerachContentDeatilsForMiniContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isCreatorsNextPageCallReqd && this.currentTab == 'creators' && scrollLoad) {
                    this.creatorsPageNo++;
                    this.getSerachCreatorDeatils(
                        true
                    );
                }
                if (bottomOfWindow && this.isPartnerNextPageCallReqd && this.currentTab == 'partners' && scrollLoad) {
                    this.partnerPageNo++;
                    this.getSerachPartnerDeatils(
                        true
                    );
                }
            };
        },
        playAudioContent(content_detail) { //ER-105910
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-105910
            this.isFreeContent = content_detail.is_free_content; //ER-105910
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: /*html*/`
    <vd-component class="vd searchlistdetails-five" type="searchlistdetails-five">
<section class="season-content mt-94">
    <div class="container-fluid pl-65 pt-100">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <ul class="profile-tab-options nav nav-tabs">
                    <li class="nav-item"
                        @click="currentTab='movies';this.isNextPageCallReqd=true;getSerachContentDeatils(false)">
                        <a class="nav-link active" id="movies-t-tab" data-toggle="tab" href="#movies-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label8"
                                v-html="i18n($attrs['label8'])"></vd-component-param></a>
                    </li>
                    <li class="nav-item"
                        @click="currentTab='audio';this.isAudioNextPageCallReqd=true;getSerachAudioContentDeatils(false)">
                        <a class="nav-link" id="audio-t-tab" data-toggle="tab" href="#audio-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label9"
                                v-html="i18n($attrs['label9'])"></vd-component-param></a>
                    </li>
                    <li class="nav-item"
                        @click="currentTab='document';this.isDocumentNextPageCallReqd=true;getSerachDocumentContentDeatils(false)">
                        <a class="nav-link" id="document-t-tab" data-toggle="tab" href="#document-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label19"
                                v-html="i18n($attrs['label19'])"></vd-component-param></a>
                    </li>
                    <li class="nav-item"
                        @click="currentTab='series';this.isNestedContentNextPageCallReqd=true;getSerachContentDeatilsForNestedContent(false)">
                        <a class="nav-link" id="series-t-tab" data-toggle="tab" href="#series-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label10"
                                v-html="i18n($attrs['label10'])"></vd-component-param></a>
                    </li>
                    <li class="nav-item"
                        @click="currentTab='playlist';this.isPlaylistNextPageCallReqd=true;getSerachContentDeatilsForPlaylistContent(false)">
                        <a class="nav-link" id="playlist-t-tab" data-toggle="tab" href="#playlist-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label11"
                                v-html="i18n($attrs['label11'])"></vd-component-param></a>
                    </li>
                    <li v-show="ugcEnabled && ugcVodEnables" class="nav-item"
                        @click="currentTab='ugc';this.isUGCNextPageCallReqd=true;getSerachContentDeatilsForUGCContent(false)">
                        <a class="nav-link" id="ugc-t-tab" data-toggle="tab" href="#ugc-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label12"
                                v-html="i18n($attrs['label12'])"></vd-component-param></a>
                    </li>
                    <!--<li v-show="ugcEnabled && miniEnabled"  class="nav-item" @click="currentTab='mini';this.isMiniNextPageCallReqd=true;getSerachContentDeatilsForMiniContent(false)">
                        <a class="nav-link" id="minis-t-tab" data-toggle="tab" href="#minis-t" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></a>
                    </li>-->
                    <li class="nav-item" v-show="ugcEnabled && ugcProfileEnabled"
                        @click="currentTab='creators';this.isCreatorsNextPageCallReqd=true;getSerachCreatorDeatils(false)">
                        <a class="nav-link" id="creators-t-tab" data-toggle="tab" href="#creators-t" role="tab"
                            aria-controls="home" aria-selected="true"><vd-component-param type="label16"
                                v-html="i18n($attrs['label16'])"></vd-component-param></a>
                    </li>
                    <li class="nav-item" v-show="partnerEnabled && partnerProfileEnabled"
                        @click="currentTab='partners';this.isPartnerNextPageCallReqd=true;getSerachPartnerDeatils(false)">
                        <a class="nav-link" id="contentpartner-t-tab" data-toggle="tab" href="#contentpartner-t"
                            role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label17"
                                v-html="i18n($attrs['label17'])"></vd-component-param></a>
                    </li>
                </ul>
                <div class="tab-content profile-tab-contents" id="myTabContent">
                    <div class="resultsfor-div">
                        <span class="search-garnet"
                            v-if="currentTab=='movies' && searchListTotalCount>0">&nbsp;{{searchListTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='audio'  && searchAudioTotalCount>0 ">&nbsp;{{searchAudioTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span
                            v-else-if="currentTab=='document'  && searchDocumentTotalCount>0 ">{{searchDocumentTotalCount}}
                            <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                            “<span>{{contentUuid}}</span>”</span>
                        <span
                            v-else-if="currentTab=='series'  && searchNestedContentTotalCount>0">{{searchNestedContentTotalCount}}
                            <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                            “<span>{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='series'  && searchNestedContentTotalCount>0">&nbsp;{{searchNestedContentTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='playlist'  && searchPlaylistTotalCount>0">&nbsp;{{searchPlaylistTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='ugc' && searchUGCTotalCount>0">&nbsp;{{searchUGCTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='mini'  && searchMiniTotalCount>0">&nbsp;{{searchMiniTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='creators'  && searchCreatorsTotalCount>0">&nbsp;{{searchCreatorsTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span class="searchText">{{contentUuid}}</span>”</span>
                        <span class="search-garnet"
                            v-else-if="currentTab=='partners'  && searchPartnerTotalCount>0">&nbsp;{{searchPartnerTotalCount}}&nbsp;
                            <vd-component-param type="label14"
                                v-html="i18n($attrs['label14'])"></vd-component-param>&nbsp;
                            “<span>{{contentUuid}}</span>”</span>
                        <span class="search-garnet" v-else><vd-component-param type="label15"
                                v-html="i18n($attrs['label15'])"></vd-component-param></span>
                    </div>
                    <!-- Tab movies -->
                    <div class="tab-pane fade show active" id="movies-t" role="tabpanel" aria-labelledby="all-tab">
                        <!--Video Section Start Here-->
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
            <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
            <span class="view-all"><a href="javascript:void(0);">See All</a>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                </svg>              
            </span>
            </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                    <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                    <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                        <div class="data">

                                                             <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList"  />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />
                                                        </div>
                                                    

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!--Video Section End Here-->
                    </div>
                    <!-- Tab movies -->
                    <div class="tab-pane fade" id="audio-t" role="tabpanel" aria-labelledby="all-tab">
                        <!--audio  Start Here-->
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
            <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
            <span class="view-all"><a href="javascript:void(0);">See All</a>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                </svg>              
            </span>
            </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchAudioListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                    <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                    <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                        <div class="data">

                                                            <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList"  />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />

                                                        </div>
                                                    

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!--Audio Section End Here-->
                    </div>
                    <!-- Document Tab -->
                    <div class="tab-pane fade" id="document-t" role="tabpanel" aria-labelledby="all-tab">
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
                                    <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
                                    <span class="view-all"><a href="javascript:void(0);">See All</a>
                                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                                        </svg>              
                                    </span>
                                    </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchDocumentListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                        <div class="data">
                                                            
                                                            <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList"  />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />
                                                        </div>
                                                   

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <!-- Document Tab End -->

                    <!-- Tab Series -->
                    <div class="tab-pane fade" id="series-t" role="tabpanel" aria-labelledby="all-tab">
                        <!--Top Series Section Start Here-->
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
                                    <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
                                    <span class="view-all"><a href="javascript:void(0);">See All</a>
                                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                                        </svg>              
                                    </span>
                                    </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchNestedContentListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                        <div class="data">
                                                            
                                                            <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList"  />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />
                                                        </div>
                                                    

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!--TOp Series Section End Here-->
                    </div>
                    <!-- Tab Playlist -->
                    <div class="tab-pane fade" id="playlist-t" role="tabpanel" aria-labelledby="all-tab">
                        <!--Top Series Section Start Here-->
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
                                    <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
                                    <span class="view-all"><a href="javascript:void(0);">See All</a>
                                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                                        </svg>              
                                    </span>
                                    </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchPlaylistListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                        <div class="data">
                                                            
                                                           <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList" />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />
                                                        </div>
                                                    

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!--TOp Series Section End Here-->
                    </div>
                    <!-- Tab UGC -->
                    <div class="tab-pane fade" id="ugc-t" role="tabpanel" aria-labelledby="all-tab">
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
                                    <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
                                    <span class="view-all"><a href="javascript:void(0);">See All</a>
                                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                                        </svg>              
                                    </span>
                                    </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchUGCListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                             <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                            <div class="data">
                                                                
                                                            <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList"  />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />
                                                        </div>
                                                    

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <!-- Tab Minis -->
                    <div class="tab-pane fade" id="minis-t" role="tabpanel" aria-labelledby="all-tab">
                        <section class="product-listing p-0" vd-readonly="true">
                            <div class="container-fluid pl-65">
                                <div class="row">

                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <!--<div class="episode-heading">
                                    <h2 class="sub-heading white-color" >{{featuredSectionDetails?.feature_section_name}}</h2>
                                    <span class="view-all"><a href="javascript:void(0);">See All</a>
                                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                                        </svg>              
                                    </span>
                                    </div>-->
                                            <div class="owl-product owl-carousel owl-theme">
                                                <div class="item" v-for="data in searchMiniListData">
                                                    <a v-if="data?.is_playlist==1"
                                                        :href="'/playlist/'+data.content_permalink" class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                           <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                            
                                                    </a>
                                                    <a v-else :href="'/content/'+data.content_permalink"
                                                        class="callByAjax">
                                                        <div class="picture">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18"
                                                                        v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <img loading="lazy"
                                                                v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                                                                :src="data.posters.website[0].file_url"
                                                                :alt="data.posters.website[0].file_url" />
                                                            <img loading="lazy"
                                                                v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                                                                :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                                                            <!--Button Show on Hover start Here-->
                                                            <div class="box-hover">
                                                                <!-- <a href="javascript:void(0);">Play Now</a>
                                            <a href="javascript:void(0);">View Trailer</a>                      -->
                                                            </div>
                                                            <!--Button Show on Hover End Here-->
                                                        </div>
                                                        </a>
                                                        <div class="data">
                                                            
                                                            <content_title_eight
                                                            :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                                                            :userList="userList"  />
                                                        <content_hover_eight :content="data"
                                                            :isFavouriteSettings="isFavouriteEnabled"
                                                            :id="$attrs['id'] +'_content_hover_eight_1'"
                                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                                            :viewTrailerBtnTxt="i18n($attrs['label5'])"
                                                            :playAllBtnTxt="i18n($attrs['label6'])"
                                                            :watchNowBtnTxt="i18n($attrs['label7'])"
                                                            :isLogedIn="isLogedIn"
                                                            @playAudioContent="playAudioContent" />
                                                        </div>
                                                    

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <!-- Tab Creators -->
                    <div class="tab-pane fade" id="creators-t" role="tabpanel" aria-labelledby="all-tab">
                        <section class="product-listing pt-24">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <div class="content-partners">
                                                <ul class="cp-ul">
                                                    <li class="cp-ul-li" v-for="data in searchCreatorsListData">
                                                        <img class="cp-img" :src="data.profile_imageurl">
                                                        <a class="cp-name" :href="'/user/'+data?.end_user_uuid">
                                                            <label vd-disable="true"
                                                                class="truncate-text lc-two cp-name">{{data?.name}}</label>
                                                        </a>
                                                        <!--<label class="cp-views">199K Views</label>-->
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <!-- Tab Content Partners -->
                    <div class="tab-pane fade" id="contentpartner-t" role="tabpanel" aria-labelledby="all-tab">
                        <section class="product-listing pt-24">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <div class="contect-listing">
                                            <div class="content-partners">
                                                <ul class="cp-ul">
                                                    <li class="cp-ul-li" v-for="data in searchPartnerListData">
                                                        <img class="cp-img" :src="data.profile_image_url">
                                                        <a class="cp-name" :href="'/partner/'+data?.user_uuid">
                                                            <p vd-disable="true" class="truncate-text lc-two">
                                                                {{data?.name}}</p>
                                                        </a>
                                                        <!-- <label class="cp-views">199K Views</label> -->
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>
        `,
};

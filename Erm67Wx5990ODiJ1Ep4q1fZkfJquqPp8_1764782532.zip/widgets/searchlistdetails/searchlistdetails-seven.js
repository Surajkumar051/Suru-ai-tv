let { getMetaData,getSerachContentDeatils,getSerachContentBasedOnCondition,getUgcSettingStatus,getPartnerAndUserSettingDetails,fetchUserAndPartnersForSearch } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
export default {
    name: "searchlistdetails_seven",
    components: {
        content_hover_six,
        audio_player_one,
        content_title_one,
    },
    data() {
        return {
            searchListData: [],
            // contentUuid: decodeURIComponent(
            //     (
            //         window.location.pathname.toString().split("/")[2] + ""
            //     ).replace(/\+/g, "%20")
            // ),
            contentUuid:permalink,
            nodatafound: false,
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            pageNo: 1,
            isNextPageCallReqd: true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle : true,
            userList:[],
            isAudioNextPageCallReqd: true,
            searchAudioListData: [],
            nodatafoundAudio:false,
            audioPageNo: 1,
            isPartnerNextPageCallReqd: true,
            searchPartnerListData: [],
            nodatafoundPartner:false,
            partnerPageNo: 1,
            isNestedContentNextPageCallReqd: true,
            searchNestedContentListData: [],
            nodatafoundNestedContent:false,
            nestedContentPageNo: 1,
            isPlaylistNextPageCallReqd: true,
            searchPlaylistListData: [],
            nodatafoundPlaylist:false,
            playlistPageNo: 1,
            isUGCNextPageCallReqd: true,
            searchUGCListData: [],
            nodatafoundUGC:false,
            ugcPageNo: 1,
            isMiniNextPageCallReqd: true,
            searchMiniListData: [],
            nodatafoundMini:false,
            miniPageNo: 1,
            currentTab:"audio",
            ugcFeatureEnabled:false,
            ugcVodEnables:false,
            miniEnabled:false,
            ugcProfileEnabled:false,
            partnerEnabled:false,
            partnerProfileEnabled:false,
            isCreatorsNextPageCallReqd: true,
            searchCreatorsListData: [],
            nodatafoundCreators:false,
            creatorsPageNo: 1,
            content_asset_type:2,
            searchListTotalCount:0,
            searchCreatorsTotalCount:0,
            searchMiniTotalCount:0,
            searchUGCTotalCount:0,
            searchPlaylistTotalCount:0,
            searchPartnerTotalCount:0,
            searchAudioTotalCount:0,
            searchNestedContentTotalCount:0,
            assignedArray: [],
            gutterSpace: null,
        };
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },

    mounted() {
        scrollLoad = true; //@ER: 74207
        JsLoadingOverlay.show();
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        //this.getSerachContentDeatils(this.contentUuid, this.pageNo, false);
        this.getSerachAudioContentDeatils(false);
        this.fetchSettings();
        this.loadMore();
         //feature-list Meta data deiatils statrs here
const metaKey='meta-feature-list';
getMetaData(metaKey).then((res) => {

    this.gutterSpace=res.data.data["gutter-space"];
    this.assignedArray=res.data.data.assigned; 
 
});
    },
    methods: {
        getRootUrl,
        i18n,
        fetchSettings(){
            getUgcSettingStatus().then((res) => {
                if(res.data.status == 'SUCCESS' && res.data.code==200){
                    res.data.data.sections[0].groups[0].nodes.forEach(element => {
                      if(element.node_code == 'ugc'){
                        this.ugcEnabled = (element.node_value && element.node_value ==1)?true:false;
                      }
                      if (element.node_code == "partner_portal") {
                        this.partnerEnabled =
                            element.node_value &&
                            element.node_value == 1
                                ? true
                                : false;
                    }
                    });
                    res.data.data.sections[0].groups[1].nodes.forEach(element => {
                        if(element.node_code == 'mini_access'){
                          this.miniEnabled = (element.node_value && element.node_value ==1)?true:false;
                          if( this.ugcEnabled && this.miniEnabled){
                            $('#minis-t-tab').parent().show();
                          }else{
                            $('#minis-t-tab').parent().hide();
                          }
                        }
                        if(element.node_code == 'vod_access'){
                          this.ugcVodEnables = (element.node_value && element.node_value ==1)?true:false;
                          if( this.ugcEnabled && this.ugcVodEnables){
                            $('#ugc-t-tab').parent().show();
                          }else{
                            $('#ugc-t-tab').parent().hide();
                          }
                        }
                        if (element.node_code == "user_profile") {
                            this.ugcProfileEnabled =
                                element.node_value &&
                                element.node_value == 1
                                    ? true
                                    : false;
                        }
                      });
                }
            });
            getPartnerAndUserSettingDetails().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "profile_page") {
                                this.partnerProfileEnabled =
                                    element.node_value &&
                                    element.node_value == 1
                                        ? true
                                        : false;
                            }
                      });
                }
            });
        },
        getSerachContentDeatils( onScroll) {
            if (this.isNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isNextPageCallReqd = false;
                if(!onScroll){
                    this.pageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,1,1,null,0, this.pageNo).then((res) => {
                    JsLoadingOverlay.hide();

                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchListData || 
                            this.searchListData?.length==0)
                    ) {
                        this.searchListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchListTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.searchListData == null ||
                        this.searchListData?.length <= 0
                    ) {
                        this.nodatafound = true;
                    }
                });
            }
        },
        getSerachAudioContentDeatils(onScroll) {
            if (this.isAudioNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isAudioNextPageCallReqd = false;
                if(!onScroll){
                    this.audioPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,this.content_asset_type,1,null,0, this.audioPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchAudioListData || 
                        this.searchAudioListData?.length==0)
                    ) {
                        this.searchAudioListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchAudioListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchAudioTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchAudioListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isAudioNextPageCallReqd = true;
                    }
                    if (
                        this.searchAudioListData == null ||
                        this.searchAudioListData?.length <= 0
                    ) {
                        this.nodatafoundAudio = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForNestedContent(onScroll) {
            if (this.isNestedContentNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isNestedContentNextPageCallReqd = false;
                if(!onScroll){
                    this.nestedContentPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,this.content_asset_type,2,null,0, this.nestedContentPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchNestedContentListData || 
                        this.searchNestedContentListData?.length==0)
                    ) {
                        this.searchNestedContentListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchNestedContentListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchNestedContentTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchNestedContentListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isNestedContentNextPageCallReqd = true;
                    }
                    if (
                        this.searchNestedContentListData == null ||
                        this.searchNestedContentListData?.length <= 0
                    ) {
                        this.nodatafoundNestedContent = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForPlaylistContent(onScroll) {
            if (this.isPlaylistNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isPlaylistNextPageCallReqd = false;
                if(!onScroll){
                    this.playlistPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,this.content_asset_type,null,null,1, this.playlistPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchPlaylistListData || 
                        this.searchPlaylistListData?.length==0)
                    ) {
                        this.searchPlaylistListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchPlaylistListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchPlaylistTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchPlaylistListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isPlaylistNextPageCallReqd = true;
                    }
                    if (
                        this.searchPlaylistListData == null ||
                        this.searchPlaylistListData?.length <= 0
                    ) {
                        this.nodatafoundPlaylist = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForUGCContent(onScroll) {
            if (this.isUGCNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isUGCNextPageCallReqd = false;
                if(!onScroll){
                    this.ugcPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,1,null,1,0, this.ugcPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchUGCListData || 
                        this.searchUGCListData?.length==0)
                    ) {
                        this.searchUGCListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchUGCListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchUGCTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchUGCListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isUGCNextPageCallReqd = true;
                    }
                    if (
                        this.searchUGCListData == null ||
                        this.searchUGCListData?.length <= 0
                    ) {
                        this.nodatafoundUGC = true;
                    }
                });
            }
        },
        getSerachContentDeatilsForMiniContent(onScroll) {
            if (this.isMiniNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isMiniNextPageCallReqd = false;
                if(!onScroll){
                    this.miniPageNo = 1;
                }
                getSerachContentBasedOnCondition(this.contentUuid,1,null,2,0, this.miniPageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list &&
                        (this.searchMiniListData || 
                        this.searchMiniListData?.length==0)
                    ) {
                        this.searchMiniListData =
                            res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchMiniListData.push(
                            ...res.data.data.contentList.content_list
                        );
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }
                    this.searchMiniTotalCount = res?.data?.data?.contentList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchMiniListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isMiniNextPageCallReqd = true;
                    }
                    if (
                        this.searchMiniListData == null ||
                        this.searchMiniListData?.length <= 0
                    ) {
                        this.nodatafoundMini = true;
                    }
                });
            }
        },
        getSerachCreatorDeatils(onScroll) {
            if (this.isCreatorsNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isCreatorsNextPageCallReqd = false;
                if(!onScroll){
                    this.creatorsPageNo = 1;
                }
                fetchUserAndPartnersForSearch(this.contentUuid,"user",this.creatorsPageNo,16).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getEndUserList.end_user_list &&
                        (this.searchCreatorsListData || 
                        this.searchCreatorsListData?.length==0)
                    ) {
                        this.searchCreatorsListData =
                            res.data.data.getEndUserList.end_user_list;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getEndUserList.end_user_list
                    ) {
                        this.searchCreatorsListData.push(
                            ...res.data.data.getEndUserList.end_user_list
                        );
                    }
                    this.searchCreatorsTotalCount = res?.data?.data?.getEndUserList?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchCreatorsListData?.length <
                            res.data.data.getEndUserList.page_info.total_count
                    ) {
                        this.isCreatorsNextPageCallReqd = true;
                    }
                    if (
                        this.searchCreatorsListData == null ||
                        this.searchCreatorsListData?.length <= 0
                    ) {
                        this.nodatafoundCreators = true;
                    }
                });
            }
        },
        getSerachPartnerDeatils(onScroll) {
            if (this.isPartnerNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isPartnerNextPageCallReqd = false;
                if(!onScroll){
                    this.partnerPageNo = 1;
                }
                fetchUserAndPartnersForSearch(this.contentUuid,"partner",this.partnerPageNo,16).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getPartners.users_list &&
                        (this.searchPartnerListData || 
                        this.searchPartnerListData?.length==0)
                    ) {
                        this.searchPartnerListData =
                            res.data.data.getPartners.users_list;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.getPartners.users_list
                    ) {
                        this.searchPartnerListData.push(
                            ...res.data.data.getPartners.users_list
                        );
                    }
                    this.searchPartnerTotalCount = res?.data?.data?.getPartners?.page_info?.total_count;
                    if (
                        res.data.code == 200 &&
                        this.searchPartnerListData?.length <
                            res.data.data.getPartners.page_info.total_count
                    ) {
                        this.isPartnerNextPageCallReqd = true;
                    }
                    if (
                        this.searchPartnerListData == null ||
                        this.searchPartnerListData?.length <= 0
                    ) {
                        this.nodatafoundCreators = true;
                    }
                });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && this.currentTab=='movies' && scrollLoad) {
                    this.pageNo++;
                    this.getSerachContentDeatils(
                        true
                    );
                }
                if (bottomOfWindow && this.isAudioNextPageCallReqd && this.currentTab=='audio' && scrollLoad) {
                    this.audioPageNo++;
                    this.getSerachAudioContentDeatils(
                        true
                    );
                }
                if (bottomOfWindow && this.isNestedContentNextPageCallReqd && this.currentTab=='series' && scrollLoad) {
                    this.nestedContentPageNo++;
                    this.getSerachContentDeatilsForNestedContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isPlaylistNextPageCallReqd && this.currentTab=='playlist' && scrollLoad) {
                    this.playlistPageNo++;
                    this.getSerachContentDeatilsForPlaylistContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isUGCNextPageCallReqd && this.currentTab=='ugc' && scrollLoad) {
                    this.ugcPageNo++;
                    this.getSerachContentDeatilsForUGCContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isMiniNextPageCallReqd && this.currentTab=='mini' && scrollLoad) {
                    this.miniPageNo++;
                    this.getSerachContentDeatilsForMiniContent(
                        true
                    );
                }
                if (bottomOfWindow && this.isCreatorsNextPageCallReqd && this.currentTab=='creators' && scrollLoad) {
                    this.creatorsPageNo++;
                    this.getSerachCreatorDeatils(
                        true
                    );
                }
                if (bottomOfWindow && this.isPartnerNextPageCallReqd && this.currentTab=='partners' && scrollLoad) {
                    this.partnerPageNo++;
                    this.getSerachPartnerDeatils(
                        true
                    );
                }
            };
        },
        playAudioContent(content_detail){ //ER-105910
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-105910
            this.isFreeContent = content_detail.is_free_content; //ER-105910
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
    <vd-component class="vd searchlistdetails-seven" type="searchlistdetails-seven">
	    <section class="season-content search-results-section">
            <div class="container-fluid plr-80">
				<div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 tabviews">
                        <ul class="nav nav-tabs">
                            <li class="nav-item" @click="currentTab='audio';this.isAudioNextPageCallReqd=true;getSerachAudioContentDeatils(false)">
                                <a class="nav-link active"  id="audio-t-tab" data-toggle="tab" href="#audio-t" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></a>
                            </li>
                            <li class="nav-item" @click="currentTab='series';this.isNestedContentNextPageCallReqd=true;getSerachContentDeatilsForNestedContent(false)">
                                <a class="nav-link" id="series-t-tab" data-toggle="tab" href="#series-t" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></a>
                            </li>
                            <li class="nav-item" @click="currentTab='playlist';this.isPlaylistNextPageCallReqd=true;getSerachContentDeatilsForPlaylistContent(false)">
                                <a class="nav-link" id="playlist-t-tab" data-toggle="tab" href="#playlist-t" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></a>
                            </li>
                            <li class="nav-item" v-show="ugcEnabled && ugcProfileEnabled" @click="currentTab='creators';this.isCreatorsNextPageCallReqd=true;getSerachCreatorDeatils(false)">
                                <a class="nav-link" id="creators-t-tab" data-toggle="tab" href="#creators-t" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></a>
                            </li>
                            <li class="nav-item" v-show="partnerEnabled && partnerProfileEnabled" @click="currentTab='partners';this.isPartnerNextPageCallReqd=true;getSerachPartnerDeatils(false)">
                                <a class="nav-link" id="contentpartner-t-tab" data-toggle="tab" href="#contentpartner-t" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></a>
                            </li>
                        </ul>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="tab-content profile-tab-contents" id="myTabContent">
                            <div class="resultsfor-div">
                                <span v-if="currentTab=='audio'  && searchAudioTotalCount>0 ">{{searchAudioTotalCount}} <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>  “<span>{{contentUuid}}</span>”</span>
                                <span v-else-if="currentTab=='series'  && searchNestedContentTotalCount>0">{{searchNestedContentTotalCount}} <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>  “<span>{{contentUuid}}</span>”</span>
                                <span v-else-if="currentTab=='playlist'  && searchPlaylistTotalCount>0">{{searchPlaylistTotalCount}} <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>  “<span>{{contentUuid}}</span>”</span>
                                <span v-else-if="currentTab=='creators'  && searchCreatorsTotalCount>0">{{searchCreatorsTotalCount}} <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param> “<span>{{contentUuid}}</span>”</span>
                                <span v-else-if="currentTab=='partners'  && searchPartnerTotalCount>0">{{searchPartnerTotalCount}} <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param> “<span>{{contentUuid}}</span>”</span>
                                <span v-else><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></span>
                             <!-- 
                                <div v-else class="w-100 text-center no-result-div">
                                    <img :src="getRootUrl() +'img/no-result.gif'" alt="no result" class="mw-100 no-result-img">
                                    <h2 class="no-result-h2"><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></h2>
                                </div>-->
                            </div>
                        <!-- Tab Audios -->
                        <div class="tab-pane fade active show" id="audio-t" role="tabpanel" aria-labelledby="all-tab">
                            <section class="product-listing pt-24">
                                <div class="container-fluid p-0">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5" v-for="data in searchAudioListData">
                                            <div class="tiles grid-hover fs-tiles">
                                                <div class="picture">
                                                    <div class="freeContent-tag" v-if="data?.is_free_content">
                                                        <span><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                    </div>
                                                    <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                                        <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
                                                    </div>
                                                    <img loading="lazy" class="w-216" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt=""/>
                                                    <img loading="lazy" class="w-216" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url"/>
                                                    <!--Button Show on Hover start Here-->
                                                    <content_hover_six :content="data" 
                                                        :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                                        :playNowBtnTxt="i18n($attrs['label2'])" 
                                                        :viewTrailerBtnTxt="i18n($attrs['label5'])" 
                                                        :playAllBtnTxt="i18n($attrs['label6'])" 
                                                        :watchNowBtnTxt="i18n($attrs['label7'])"
                                                        :isLogedIn="isLogedIn"
                                                        @playAudioContent="playAudioContent"
                                                    />
                                                </div>
                                                <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  
                                                :content="data" :userList="userList" :assignedArray="assignedArray"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <!-- Tab Series -->
                        <div class="tab-pane fade" id="series-t" role="tabpanel" aria-labelledby="all-tab">
                            <!--Top Series Section Start Here-->
                            <section class="product-listing pt-24">
                                <div class="container-fluid p-0">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5" v-for="data in searchNestedContentListData">
                                            <div class="tiles grid-hover fs-tiles">
                                                <div class="picture">
                                                <div class="freeContent-tag" v-if="data?.is_free_content">
                                                    <span><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                </div>
                                                <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                                <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
                                            </div>
                                                    <!--Icon Aply Here-->
                                                    <!--<div :class="(data.content_asset_type == 2 && data.is_playlist!=1)?'icons-apply-audio':'icons-apply'">
                                                        <img v-if="data.is_playlist==0 && data.content_asset_type == 1" :src="rootUrl + 'img/video-icons.png'" alt="icon"/>
                                                        <img v-if="data.is_playlist==0 && data.content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'" alt="icon"/>
                                                        <img v-if="data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                                    </div> -->
                                                    <!--Icon Aply Here-->
                                                    <img loading="lazy" class="w-216" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt=""/>
                                                    <img loading="lazy" class="w-216" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url"/>
                                                    <!--Button Show on Hover start Here-->
                                                    <content_hover_six :content="data" 
                                                        :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                                        :playNowBtnTxt="i18n($attrs['label2'])" 
                                                        :viewTrailerBtnTxt="i18n($attrs['label5'])" 
                                                        :playAllBtnTxt="i18n($attrs['label6'])" 
                                                        :watchNowBtnTxt="i18n($attrs['label7'])" 
                                                        :isLogedIn="isLogedIn"
                                                        @playAudioContent="playAudioContent"
                                                    />
                                                    <!--Button Show on Hover End Here-->  
                                                </div>
                                                <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  
                                                :content="data" :userList="userList" :assignedArray="assignedArray"/>
								            </div>
							            </div>
						            </div>
					            </div>
                            </section>
                            <!--TOp Series Section End Here-->
				        </div>
                        <!-- Tab Playlist -->
                        <div class="tab-pane fade" id="playlist-t" role="tabpanel" aria-labelledby="all-tab">
                            <section class="product-listing ugc-section pt-24">
                                <div class="container-fluid p-0">
                                    <div class="row m-0">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0">
                                            <div class="contect-listing">
                                                <ul class="tiles-ul">
                                                    <li class="tiles-li w-308" v-for="data in searchPlaylistListData">
                                                        <div class="tiles grid-hover fs-tiles">
                                                            <div class="picture h-176">
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></span>
                                                            </div>
                                                            <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                                                <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
                                                            </div>
                                                                <img loading="lazy" class="w-216" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt=""/>
                                                                <img loading="lazy" class="w-216" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url"/>
                                                                <!--Button Show on Hover start Here-->
                                                                <content_hover_six :content="data" 
                                                                    :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                                                    :playNowBtnTxt="i18n($attrs['label2'])" 
                                                                    :viewTrailerBtnTxt="i18n($attrs['label5'])" 
                                                                    :playAllBtnTxt="i18n($attrs['label6'])" 
                                                                    :watchNowBtnTxt="i18n($attrs['label7'])" 
                                                                    :isLogedIn="isLogedIn"
                                                                    @playAudioContent="playAudioContent"
                                                                />
                                                                <!--Button Show on Hover End Here-->
                                                            </div>
                                                            <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  
                                                            :content="data" :userList="userList" :assignedArray="assignedArray"/>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <!-- Tab Creators -->
                        <div class="tab-pane fade" id="creators-t" role="tabpanel" aria-labelledby="all-tab">
                            <section class="product-listing pt-24">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <div class="contect-listing">
                                                <div class="content-partners">
                                                    <ul class="cp-ul">
                                                        <li class="cp-ul-li" v-for="data in searchCreatorsListData">
                                                            <img class="cp-img" :src="data.profile_imageurl">
                                                            <a class="cp-name" :href="'/user/'+data?.end_user_uuid">
                                                                <label vd-disable="true" class="truncate-text lc-two cp-name">{{data?.name}}</label>
                                                        </a>
                                                            <!--<label class="cp-views">199K Views</label>-->
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <!-- Tab Content Partners -->
                        <div class="tab-pane fade" id="contentpartner-t" role="tabpanel" aria-labelledby="all-tab">
                            <section class="product-listing pt-24">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <div class="contect-listing">
                                                <div class="content-partners">
                                                    <ul class="cp-ul">
                                                        <li class="cp-ul-li" v-for="data in searchPartnerListData">
                                                            <img class="cp-img" :src="data.profile_image_url">
                                                            <a class="cp-name" :href="'/partner/'+data?.user_uuid">
                                                                <p vd-disable="true" class="truncate-text lc-two">{{data?.name}}</p>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
        `,
};

let { getSerachContentDeatils } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "searchlist_three",
    components: {
        content_hover_one,
        audio_player_one,
    },
    data() {
        return {
            searchListData: [],
            // contentUuid: decodeURIComponent(
            //     (
            //         window.location.pathname.toString().split("/")[2] + ""
            //     ).replace(/\+/g, "%20")
            // ),
            contentUuid:permalink,
            nodatafound: false,
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            pageNo: 1,
            isNextPageCallReqd: true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle : true,
        };
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },

    mounted() {
        scrollLoad = true; //@ER: 74207
        JsLoadingOverlay.show();
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.getSerachContentDeatils(this.contentUuid, this.pageNo, false);
        this.loadMore();
    },
    methods: {
        getRootUrl,
        i18n,
        getSerachContentDeatils(contentUuid, page, onScroll) {
            if (this.isNextPageCallReqd) {
                //JsLoadingOverlay.show();
                this.isNextPageCallReqd = false;
                getSerachContentDeatils(contentUuid, page).then((res) => {
                    JsLoadingOverlay.hide();

                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchListData =
                            res.data.data.contentList.content_list;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.searchListData.push(
                            ...res.data.data.contentList.content_list
                        );
                    }

                    if (
                        res.data.code == 200 &&
                        this.searchListData?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.searchListData == null ||
                        this.searchListData?.length <= 0
                    ) {
                        this.nodatafound = true;
                    }
                });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getSerachContentDeatils(
                        this.contentUuid,
                        this.pageNo,
                        true
                    );
                }
            };
        },
        playAudioContent(content_detail){ //ER-105910
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-105910
            this.isFreeContent = content_detail.is_free_content; //ER-105910
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
    <vd-component class="vd search-list-three" type="search-list-three">
    <template v-if="!nodatafound">
    <div class="search-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-12" v-if="searchListData.length">
                <div class="section-heading">
                    <span><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></span>
                    <h2>{{contentUuid}}</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="topics-area pb-4">
        <div class="container">
            <div class="row row-cols-md-3 row-cols-lg-5 gx-3 gy-3" >
            <div class="col-md" v-for="data in searchListData">
            <div class="single-topic-box">
                                    <div class="topic-preview">
                                        <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" class="img-fluid"  />
                                        <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="Godzilla vs Kong" class="img-fluid"  />

                                    </div>
                                    <div class="topic-overlay">
                                        <div class="topic-details">
                                            <p>{{data.content_name}}</p>
                                           
                                        </div>
                                        <!-- Hover Text Start -->
                                        
                                        <div class="hover-details col-12">
                                            <div class="row justify-content-end gx-0 h-100">
                                                <div class="col-12  align-self-start">
                                                  
                                                    <p v-if="data.content_name">{{data.content_name}}</p>
                                                </div>
                                                <div class="col-12 align-self-end px-0">
                                                    <div class="row gx-0 justify-content-between">
                                                       
                                                        <div v-if="data.cast_details" class="col-auto" v-for="(cast,j) in data.cast_details" :key="j">
                                                            <span class="author">{{cast.cast_name}}</span>
                                                        </div>
                                                    </div>
                                                    <div class="row gx-0"> 
                                                        <div class="col-12">
                                                            <div class="course-info" v-if="data.content_desc">
                                                                {{content_desc}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row gx-0 justify-content-between align-items-center">
                                                        <div class="col-auto">
                                                          
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="row gx-0 justify-content-between align-items-center mt-3">
                                                        
                                                        <div class="col-auto">
                                                      
                            
                                                            <a :href="'/content/'+data.content_permalink" class="details-btn">
                                                                View Detail
                                                                <div class="svg">
                                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                                                    </svg>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Hover Text End -->
                                    </div>
                                </div>
            </div>
            </div>
        </div>
        <!-- Line -->
        <div class="container mt-4">
            <div class="row">
                <div class="col-12">
                    <div class="border-bottom"></div>
                </div>
            </div>
        </div>
         <!-- Line -->
    </div>
   </div>
    </template>
    <template v-if="nodatafound">
        <section class="no-result-found">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="w-100 text-center">
                            <img :src="$attrs['root_url'] +'img/no-result.gif'" alt="no result" class="mw-100"/>
                            <h2>
                            <vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </template>
    <audio_player_one :root_url="$attrs['root_url']" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>
        `,
};

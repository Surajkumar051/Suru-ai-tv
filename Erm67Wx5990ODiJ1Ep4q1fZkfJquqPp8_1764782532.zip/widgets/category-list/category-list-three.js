let {cmsCategory,
    getPlaylistContentDetails,
    isAuthorizedContent}=await import(window.importAssetJs('js/webservices.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {default:content_hover_two}=await import(window.importLocalJs('widgets/content-hover/content-hover-two.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "category_list_three",
    components: {
        content_hover_two,
        audio_player_one,
        ContentPurchaseTwo: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-two.js'))),
    },
    data() {
        return {
            playlistTitle: "",
            noplaylist: false,
            categoryList: [],
            contentList: [],
            contentTitle: "",
            featureContentList: [],
            featurecontentTitle: "",
            categoryContentList: [],
            playListContent: [],
            contentUuid: "",
            categoryPermalink: permalink,
            isLogedIn: localStorage.getItem("isloggedin"),
            pageNo: 1,
            categoryUuid: "",
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            selectedContentUuid: "",
            monetizationMethods: [],
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
        };
    },
    updated() {
        owlCarousal();
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        // var path = window.location.href;
        // var params = path.split("category/")[1];
        let uuid = this.categoryPermalink;
        cmsCategory().then((res) => {
            JsLoadingOverlay.hide();

            if (res.data.code == 200 && res.data.data.categoryList.category_list.length>0) {
                this.categoryList = res.data.data.categoryList.category_list;
                this.categoryList.filter(categorydata => (categorydata.category_permalink === uuid)).map(ele => {
                    if (ele) {
                        this.contentTitle = ele.category_name;
                        this.categoryUuid = ele.category_uuid;
                    } else {
                        this.categoryUuid = ele.category_uuid;
                    }
                });
                /** Setted Subcategory content title */
                if (this.categoryUuid=='' || this.categoryUuid === undefined) {
                    for (const category of this.categoryList) {
                        if (category.sub_category) {
                            for (const subCat of category.sub_category) {
                                if (subCat.category_permalink === uuid) {
                                    this.contentTitle = subCat.category_name;
                                    this.categoryUuid = subCat.category_uuid;
                                    break;
                                }
                            }
                        }
                    }
                }
                //content

                this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, false);

            }
        });
        this.loadMore();
    },
    methods: {
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration", videoDuration);
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration else", videoDuration);
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },

        getContentId(uuid) {
            this.contentUuid = uuid;
            localStorage.setItem("contentId", this.contentUuid);
        },
        playContent(content_uuid, content_name, assetType) {
            isAuthorizedContent(content_uuid).then((res) => {
                if (res.data.code == 200) {
                    this.isAuthorized =
                        res.data.data.isAuthorized.is_content_authorized;
                    if (this.isAuthorized == true) {
                        $(".post-checkout-popup").modal("hide");
                        if (assetType == 1) {
                            window.location.href = "/player/" + content_uuid;
                        } else {
                            this.audioPlayControl = false;
                            this.audioUuid = content_uuid;
                        }
                    } else {
                        $(".post-checkout-popup").modal("show");
                        localStorage.setItem("content_uuid", content_uuid);
                        //window.location.href = "/content-purchase/" + content_uuid;
                    }
                }
            });
        },
        loadMore() {
            // window.onscroll = () => {
            //     //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //     let bottomOfWindow =
            //         document.documentElement.scrollTop +
            //             document.documentElement.clientHeight +
            //             20 >=
            //         document.documentElement.scrollHeight;
            //     //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
            //         this.pageNo++;
            //         this.getPlaylistContentDetails(
            //             this.categoryUuid,
            //             this.pageNo,
            //             true
            //         );
            //     }
            // };
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                       this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, true)
                }
            };
        },

        getPlaylistContentDetails(categoryUuid, pageNo, onScroll) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false;
                    JsLoadingOverlay.show();
                getPlaylistContentDetails(categoryUuid, pageNo).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        var result = res.data.data.contentList.content_list.filter(item => !item.is_playlist);
                        
                        this.contentList = result;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        var result = res.data.data.contentList.content_list.filter(item => !item.is_playlist);
                        this.contentList.push(
                            ...result
                        );
                    }

                    if (
                        res.data.code == 200 &&
                        this.contentList?.length <
                            res.data.data.contentList.page_info.total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.contentList == null ||
                        this.contentList?.length <= 0
                    ) {
                        this.noRecordMsgShow = true;
                    }
                });
            }
        },
        playAudioContent(content_detail) {//ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template:`
    <vd-component class="vd category-list-three" type="category-list-three">
    <template v-if="contentList.length ">
    <!--================================================================
    TOPICS AREA START 
==================================================================-->
<div class="topics-area border-bottom"  v-if="contentList.length" :class="contentList.length?'season-content':'no-result-found'">
<div class="container">
<div class="row">
<div class="col-12">
<div class="section-heading">
<h2 vd-readonly="true">All <span vd-readonly="true" class="text-blue">{{contentTitle}}</span> Courses</h2>
</div>
</div>
</div>
<div class="row">
<div class="col-12 mt-5">
<!-- Tabs List Start -->
<ul class="nav nav-tabs mu-tab d-none" id="myTab" role="tablist">
<!-- Tab List -->
<li class="nav-item" role="presentation">
<button class="nav-link active" id="trending-tab" data-bs-toggle="tab" data-bs-target="#trending" type="button" role="tab" aria-controls="trending" aria-selected="true">Trending</button>
</li>
<!-- Tab List -->
<!-- Tab List -->
<li class="nav-item" role="presentation">
<button class="nav-link" id="toppic-tab" data-bs-toggle="tab" data-bs-target="#toppic" type="button" role="tab" aria-controls="toppic" aria-selected="false">Top Pick</button>
</li>
<!-- Tab List -->
<!-- Tab List -->
<li class="nav-item" role="presentation">
<button class="nav-link" id="recent-tab" data-bs-toggle="tab" data-bs-target="#recent" type="button" role="tab" aria-controls="recent" aria-selected="false">Recent Added</button>
</li>
<!-- Tab List -->
<!-- Tab List -->
<li class="nav-item" role="presentation">
<button class="nav-link" id="popular-tab" data-bs-toggle="tab" data-bs-target="#popular" type="button" role="tab" aria-controls="home" aria-selected="false">Popular Category</button>
</li>
<!-- Tab List -->
</ul>
<!-- Tabs List End -->
<!-- Tabs Category Start -->
<div class="scroll-bar d-none">
<ul class="categories-list text-uppercase">
<li><a href="#">SQL</a></li>
<li><a href="#">pmp</a></li>
<li><a href="#">AGILE</a></li>
<li><a href="#">PMBOK</a></li>
<li><a href="#">TABLEAU</a></li>
<li><a href="#">SCRUM</a></li>
<li>
   <select class="selectpicker">
       <option selected disabled>MORE</option>
       <option>One</option>
       <option>Two</option>
       <option>Three</option>
   </select>
     
     
</li>
</ul>
</div>
<!-- Tabs Category End -->
<div class="tab-content" id="myTabContent">
<div class="tab-pane fade show active" id="trending" role="tabpanel" aria-labelledby="trending-tab">
<div class="row row-cols-md-3 row-cols-lg-5 gx-3 gy-4">
   <div class="col-md" v-for="data in contentList">
   <div class="single-topic-box">
   <div class="freeContent-tag" v-if="data?.is_free_content">
        <span><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>
    </div>
   <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
        <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
    </div>
   <div class="topic-preview">
       <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" alt="" class="img-fluid"  />
       <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="Godzilla vs Kong" class="img-fluid"  />

   </div>
   <div class="topic-overlay">
       <div class="topic-details d-none">
           <span class="d-none">$400.00</span>
           <p>{{data.content_name}}</p>
           <span class="rating">
               <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
               </svg>
               4.5
           </span>
       </div>
       <!-- Hover Text Start -->
       
       <div class="hover-details col-12">
           <div class="row justify-content-end gx-0 h-100">
               <div class="col-12  align-self-start">
                   <span class="d-block text-end wishlist d-none">
                       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                       </svg>
                   </span>
                   <p v-if="data.content_name">{{data.content_name}}</p>
               </div>
               <div class="col-12 align-self-end px-0">
                   <div class="row gx-0 justify-content-between">
                       <div class="col-auto">
                           <div class="badge">
                               {{contentTitle}}
                           </div>
                       </div>
                       <div v-if="data.cast_details" class="col-auto" v-for="(cast,j) in data.cast_details" :key="j">
                           <span class="author">{{cast.cast_name}}</span>
                       </div>
                   </div>
                   <div class="row gx-0">
                       <div class="col-12">
                           <div class="course-info" v-if="data.content_desc">
                                {{data.content_desc.substring(0, 120)}}
                           </div>
                       </div>
                   </div>
                   <div class="row gx-0 justify-content-between align-items-center">
                       <div class="col-auto">
                           <span class="price d-none">$350.00</span>
                       </div>
                       <div class="col-auto d-none">
                           <button class="buy-btn">Buy Now</button>
                       </div>
                       <div class="col-auto">
                           <content_hover_three :id="$attrs['id'] +'_content_hover_three_1'"
                               :content="data"
                               :playNowBtnTxt="$attrs['label2']"
                               :viewTrailerBtnTxt="$attrs['label4']"
                               :playAllBtnTxt="$attrs['label5']"
                               :watchNowBtnTxt="$attrs['label3']"
                               :isLogedIn="isLogedIn"
                               @playAudioContent="playAudioContent"
                           />
                       </div>
                   </div>
                   <div class="row gx-0 justify-content-between align-items-center mt-3">
                       <div class="col-auto d-none">
                           <span class="rating">
                               <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                               </svg>
                               4.5
                           </span>
                       </div>
                       <div class="col-auto">
                     

                           <a :href="'/content/'+data.content_permalink" class="details-btn callByAjax">
                               View Detail
                               <div class="svg">
                                   <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                   </svg>
                               </div>
                           </a>
                       </div>
                   </div>
               </div>
           </div>
       </div>
       <!-- Hover Text End -->
   </div>
</div>
   </div>


</div>
</div>
<div class="tab-pane fade" id="toppic" role="tabpanel" aria-labelledby="toppic-tab">
<div class="row row-cols-md-3 row-cols-lg-5 gx-3 gy-4">
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       {{contentTitle}}
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a  href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a  href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                               class="callByAjax" href="#/" class="details-btn">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>

</div>
</div>
<div class="tab-pane fade" id="recent" role="tabpanel" aria-labelledby="recent-tab">
<div class="row row-cols-md-3 row-cols-lg-5 gx-3 gy-4">
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a  href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>

</div>
</div>
<div class="tab-pane fade" id="popular" role="tabpanel" aria-labelledby="popular-tab">
<div class="row row-cols-md-3 row-cols-lg-5 gx-3 gy-4">
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>
   <div class="col-md">
       <div class="single-topic-box">
           <div class="topic-preview">
               <img src="./assests/images/adobe-photoshop.png" class="img-fluid" alt="">
           </div>
           <div class="topic-overlay">
               <div class="topic-details">
                   <span>$400.00</span>
                   <p>Complete Javascript Course</p>
                   <span class="rating">
                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                       </svg>
                       4.5
                   </span>
               </div>
               <!-- Hover Text Start -->
               <div class="hover-details col-12">
                   <div class="row justify-content-end gx-0 h-100">
                       <div class="col-12  align-self-start">
                           <span class="d-block text-end wishlist">
                               <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                   <path d="M12 21C11.355 20.428 10.626 19.833 9.85502 19.2H9.84502C7.13002 16.98 4.05302 14.468 2.69402 11.458C2.24754 10.4998 2.01093 9.45715 2.00001 8.40003C1.99703 6.94951 2.57879 5.55901 3.61383 4.54279C4.64887 3.52657 6.04981 2.97042 7.50002 3.00003C8.68065 3.00189 9.83586 3.34311 10.828 3.98303C11.264 4.26599 11.6584 4.60828 12 5.00003C12.3435 4.60982 12.7381 4.26773 13.173 3.98303C14.1648 3.34298 15.3197 3.00174 16.5 3.00003C17.9502 2.97042 19.3512 3.52657 20.3862 4.54279C21.4213 5.55901 22.003 6.94951 22 8.40003C21.9898 9.45884 21.7532 10.5032 21.306 11.463C19.947 14.473 16.871 16.984 14.156 19.2L14.146 19.208C13.374 19.837 12.646 20.432 12.001 21.008L12 21ZM7.50002 5.00003C6.56853 4.98837 5.67009 5.34487 5.00002 5.99203C4.35441 6.62619 3.99358 7.49507 3.99994 8.40003C4.01135 9.17053 4.18585 9.92988 4.51202 10.628C5.15353 11.9267 6.01913 13.1021 7.06902 14.1C8.06002 15.1 9.20002 16.068 10.186 16.882C10.459 17.107 10.737 17.334 11.015 17.561L11.19 17.704C11.457 17.922 11.733 18.148 12 18.37L12.013 18.358L12.019 18.353H12.025L12.034 18.346H12.039H12.044L12.062 18.331L12.103 18.298L12.11 18.292L12.121 18.284H12.127L12.136 18.276L12.8 17.731L12.974 17.588C13.255 17.359 13.533 17.132 13.806 16.907C14.792 16.093 15.933 15.126 16.924 14.121C17.9741 13.1236 18.8397 11.9485 19.481 10.65C19.8131 9.94583 19.9901 9.17853 20.0001 8.40003C20.0042 7.49786 19.6435 6.63232 19 6.00003C18.3312 5.34995 17.4326 4.99051 16.5 5.00003C15.3619 4.99035 14.274 5.46739 13.51 6.31103L12 8.05103L10.49 6.31103C9.72609 5.46739 8.6381 4.99035 7.50002 5.00003Z" fill="white"/>
                               </svg>
                           </span>
                           <p>Fundamentals of Photo
                               & Video Editing</p>
                       </div>
                       <div class="col-12 align-self-end px-0">
                           <div class="row gx-0 justify-content-between">
                               <div class="col-auto">
                                   <div class="badge">
                                       Web Dev
                                   </div>
                               </div>
                               <div class="col-auto">
                                   <span class="author">By Phil Ebiner</span>
                               </div>
                           </div>
                           <div class="row gx-0">
                               <div class="col-12">
                                   <div class="course-info">
                                       Lorem ipsum dor sit ament se tempho unet et com...
                                   </div>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center">
                               <div class="col-auto">
                                   <span class="price">$350.00</span>
                               </div>
                               <div class="col-auto">
                                   <button class="buy-btn">Buy Now</button>
                               </div>
                           </div>
                           <div class="row gx-0 justify-content-between align-items-center mt-3">
                               <div class="col-auto">
                                   <span class="rating">
                                       <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                           <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"/>
                                       </svg>
                                       4.5
                                   </span>
                               </div>
                               <div class="col-auto">
                                   <a href="#/" class="details-btn callByAjax">
                                       View Detail
                                       <div class="svg">
                                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                               <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                           </svg>
                                       </div>
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <!-- Hover Text End -->
           </div>
       </div>
   </div>

</div>
</div>
</div>
<!-- Tabs Area End -->
</div>
</div>
</div>
</div>
<!--================================================================
    TOPICS AREA END 
==================================================================-->


</template>

     
       <template v-else>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="noRecordMsgShow">
                <div class="w-100 text-center">
                    <img :src="$attrs['root_url'] + 'img/no-result.gif'" class="mw-100"/>
                    <h2 vd-readonly="true">No Contents present in {{contentTitle}} category !</h2>
                </div>
            </div>
        </template> 
        <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
    `,
};

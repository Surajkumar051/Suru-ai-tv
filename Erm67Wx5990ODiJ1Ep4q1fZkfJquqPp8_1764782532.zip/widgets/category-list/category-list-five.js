let {cmsCategory,
    getPlaylistContentDetails,
    isAuthorizedContent,
    getContentSettingsDetails, categoryContentList}=await import(window.importAssetJs('js/webservices.js'));
    let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
    let {default:content_hover_eight}=await import(window.importLocalJs('widgets/content-hover/content-hover-eight.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {getRootUrl,getAssetUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let { default: content_title_eight } = await import(window.importLocalJs('widgets/content-title/content-title-eight.js'));
let contentHelper = await import(window.importAssetJs('js/content-helper.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "category_list_five",
    components: {
        content_hover_eight,
        audio_player_one,
        content_title_eight,
    },
    data() {
        return {
            playlistTitle: '',
            noplaylist: false,
            categoryList: [],
            contentList: [],
            contentTitle: '',
            featureContentList: [],
            featurecontentTitle: '',
            categoryContentList: [],
            playListContent: [],
            contentUuid: '',
            categoryPermalink: permalink,
            isLogedIn: localStorage.getItem('isloggedin'),
            pageNo: 1,
            categoryUuid: "",
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            selectedContentUuid: '',
            monetizationMethods: [],
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            assetUrl:getAssetUrl(),
            reloadOnUpdateLifeCycle: true,
            userList:[],
            gutterSpace:null,
            isFavouriteEnabled: false,
            category_list: [],
            permacategoryUuid: '',
            parentContent_list: [],
            subcategoryContents: [],
            orphanContent:[],
            subcontent_permalink:[],
            isData:false
            
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        // var path = window.location.href;
        // var params = path.split("category/")[1];
				
                getContentSettingsDetails().then((res) => {
                if (res.data.code == 200) {
                    
                    this.isFavouriteEnabled =
                        res.data.data.contentSettings
                            .content_favourite_settings != null
                            ? res.data.data.contentSettings
                                  .content_favourite_settings?.is_enabled
                            : false;
                  
                }
            });
						//feature-list Meta data deiatils ends here
        let uuid = this.categoryPermalink;
        cmsCategory().then(res => {
            JsLoadingOverlay.hide();
            if (res.data.code == 200 && res.data.data.categoryList.category_list.length>0) {
                this.categoryList = res.data.data.categoryList.category_list;
                this.category_list = res.data.data.categoryList.category_list;
                this.categoryList.filter(categorydata => (categorydata.category_permalink === uuid)).map(ele => {
                    if (ele) {
                        this.contentTitle = ele.category_name;
                        this.categoryUuid = ele.category_uuid;
                        this.permacategoryUuid = ele.category_uuid;
                       
                    } else {
                        this.categoryUuid = ele.category_uuid;
                        //this.permacategoryUuid = ele.category_uuid;

                    }
                    
                });
                /** Setted Subcategory content title */
                if (this.categoryUuid=='' || this.categoryUuid === undefined) {
                    for (const category of this.categoryList) {
                        if (category.sub_category) {
                            for (const subCat of category.sub_category) {
                                if (subCat.category_permalink === uuid) {
                                    this.contentTitle = subCat.category_name;
                                    this.categoryUuid = subCat.category_uuid;
                                    break;
                                }
                            }
                        }
                    }
                }
                //content
               
                if (this.permacategoryUuid != '') {
                    this.categoryContent(this.permacategoryUuid);
                }
                else {

                    this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, false);
                }

            }
        });
        
    },
    methods: {
        i18n,
        getRootUrl,
        getAssetUrl,
        categoryContent(categoryUuid) {
            categoryContentList(categoryUuid).then(res => {
               const contentCategoryList = res.data.data.categoryContentList.categories[0];

                //Parent categories 
                contentCategoryList.category_content_list.content_list.map(content => {
                    this.orphanContent.push(content);//orphanContent
                    //Adding content_permalink and content_name from parent content as content_permalink is not avaliable for subcategory
                    this.subcontent_permalink.push({
                        "content_name":content.content_name,
                        "content_permalink":content.content_permalink
                    })
                });

                //sub categories 
                contentCategoryList.subcategories.subcategory_list.forEach(subcategory => {
                    this.subcategoryContents.push({
                        subcategoryName: subcategory.category_name,
                        contents: subcategory.subcategory_content_list.content_list,
                        contentCount: subcategory.subcategory_content_list.page_info.total_count,
                        sub_category_uuid: subcategory.category_uuid,
                    });
                    //match content name and get content permalink
                    subcategory.subcategory_content_list.content_list.forEach(contentItem => {
                        const match_content = this.subcontent_permalink.find(
                            permalinkItem => permalinkItem.content_name === contentItem.content_name
                        );
                        if (match_content) {
                            contentItem.content_permalink = match_content.content_permalink;
                        }
                    });

                });

                //get content_uuid in sub content_list
                const contentUUIDs = this.subcategoryContents.flatMap(subcat =>
                    (subcat.contents || []).map(content => content.content_uuid)
                );
                //filter parent content with content_uuid and remove the duplicats from parent content
                const orphanContent = this.orphanContent.filter(
                    orphan => !contentUUIDs.includes(orphan.content_uuid)
                );

                //push the uniq contents to parent rray
                this.parentContent_list.push(...orphanContent);
                this.isData=true;


      
            
            });
           

            
        },
        timeFormating(duration, contentType) {

            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration.replace(':', 'm ').concat('s');

                }
                else {
                    videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');

                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration.replace(':', 'm ').concat('s');
                } else {
                    var audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                }
                return audioDuration;
            }
        },

        getContentId(uuid) {
            this.contentUuid = uuid;
            localStorage.setItem("contentId", this.contentUuid)
        },
        playContent(content_uuid, content_name, assetType) {
            isAuthorizedContent(content_uuid).then((res) => {
                if (res.data.code == 200) {
                    this.isAuthorized = res.data.data.isAuthorized.is_content_authorized;
                    if (this.isAuthorized == true) {
                        $('.post-checkout-popup').modal('hide');
                        if (assetType == 1) {
                            window.location.href = "/player/" + content_uuid;
                        } else {
                            this.audioPlayControl = false;
                            this.audioUuid = content_uuid;
                        }
                    } else {
                        $('.post-checkout-popup').modal('show');
                        localStorage.setItem('content_uuid', content_uuid)
                        //window.location.href = "/content-purchase/" + content_uuid;
                    }
                }
            });
        },
        loadMore() {
            // window.onscroll = () => {
            //     //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //     let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight + 20 >= document.documentElement.scrollHeight - document.getElementById("footer").offsetHeight;
            //     // console.log(document.documentElement.scrollTop +"-----"+ document.documentElement.clientHeight +"----"+document.documentElement.scrollHeight+"----"+document.getElementById("footer").offsetHeight+"-----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
            //         this.pageNo++;
            //         this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, true);
            //     }
            // }
              window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                       this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, true)
                }
            };
        },

        getPlaylistContentDetails(categoryUuid, pageNo, onScroll) {
           
            //this.contentTitle = subcategoryName;
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                    JsLoadingOverlay.show();
                getPlaylistContentDetails(categoryUuid, pageNo).then(res => {
                    JsLoadingOverlay.hide();
                    this.isData=true;
                    if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
                        this.contentList = res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
                        this.contentList.push(...res.data.data.contentList.content_list);
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }

                    if (res.data.code == 200 && this.contentList?.length < res.data.data.contentList.page_info.total_count) {
                        this.isNextPageCallReqd = true;
                    }
                    if (this.contentList == null || this.contentList?.length <= 0) {
                        this.noRecordMsgShow = true;
                    }
                });
            }

        },
       
        playAudioContent(content_detail) {//ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        showCategory(category_typ,category_id,pageNu){
       this.contentTitle=category_typ;
         getPlaylistContentDetails(category_id, pageNu).then(res => {

                    if (res.data.code == 200 && res.data.data.contentList.content_list) {
                        this.contentList = res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }

                    
                  
                });
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template: /*html*/ `
<vd-component class="vd category-list-five" type="category-list-five">
<!--Banner Section Start Here-->
<section class="category-heading-section" vd-readonly="true">
  <!--<div class="chsd-category-list">
            <template v-for="list in category_list">
              <span class="chsdcl-span"  @click="showCategory(list.category_name,list.category_uuid,1)" >{{list.category_name}}</span>
            </template>
            </div>
        </div>-->
</section>
<!-- Banner Section End Here-->

<template v-for="parentData in subcategoryContents">
  <section class="product-listing p-0 1" vd-readonly="true" v-if="isData && parentData.contents.length > 0" >
    <div class="container-fluid pl-65">
      <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="contect-listing">
            <div class="episode-heading">
              <h2 class="sub-heading white-color" v-if="parentData.contents.length">{{parentData.subcategoryName}}
              </h2>
              <span vd-readonly="true" class="view-all" v-if="parentData.contentCount > 6">
                <a class="callByAjax" :href="'/category/'+ parentData.subcategoryName.toLowerCase()"><vd-component-param
                    type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></a>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z"
                    fill="#bf000a" stroke="#bf000a" stroke-width="0.2" />
                </svg>
              </span>
            </div>
            <div class="owl-product-garnet owl-carousel owl-theme">
              <div class="item" v-for="data in parentData.contents">
                <a v-if="data?.is_playlist==1" :href="'/playlist/'+data.content_permalink" class="callByAjax">
                  <div class="picture">

                    <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                      :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                    <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                      :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                    <!--Button Show on Hover start Here-->
                    <div class="box-hover">
                      <!-- <a href="javascript:void(0);">Play Now</a>
                  <a href="javascript:void(0);">View Trailer</a>                      -->
                    </div>
                    <!--Button Show on Hover End Here-->
                  </div>

                </a>
                <a v-else :href="'/content/'+data.content_permalink" class="callByAjax">
                  <div class="picture">

                    <img loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                      :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                    <img loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                      :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                    <!--Button Show on Hover start Here-->
                    <div class="box-hover">
                      <!-- <a href="javascript:void(0);">Play Now</a>
                  <a href="javascript:void(0);">View Trailer</a>                      -->
                    </div>
                    <!--Button Show on Hover End Here-->
                  </div>
                </a>
                <div class="data">

                  <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                    :userList="userList" />

                  <content_hover_eight :id="$attrs['id'] +'_content_hover_eight_1'" :content="data"
                    :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])"
                    :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])"
                    :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
                    :downloadBtnText="i18n($attrs['label6'])" :openBtnText="i18n($attrs['label7'])"
                    :isFavouriteSettings="isFavouriteEnabled" />
                </div>


              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
</template>
<!--Subcategory Movies Section End Here-->
<template v-if="isData && parentContent_list.length" >
  <!--Other Category Section Start Here-->
  <section class="product-listing p-0 2" vd-readonly="true" v-if="parentContent_list.length > 0">
    <div class="container-fluid pl-65">
      <div class="row">
        <template v-if="parentContent_list.length">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="contect-listing">
              <div class="episode-heading">
                <h2 class="sub-heading white-color">{{i18n("Others")}}</h2>

              </div>
              <div class="owl-product-garnet owl-carousel owl-theme">
                <div class="item" v-for="data in parentContent_list">
                  <a v-if="data?.is_playlist==1" :href="'/playlist/'+data.content_permalink" class="callByAjax">
                    <div class="picture">

                      <img loading="lazy"
                        v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                        :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                      <img loading="lazy"
                        v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                        :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                      <!--Button Show on Hover start Here-->
                      <div class="box-hover">
                        <!-- <a href="javascript:void(0);">Play Now</a>
                  <a href="javascript:void(0);">View Trailer</a>                      -->
                      </div>
                      <!--Button Show on Hover End Here-->
                    </div>

                  </a>
                  <a v-else :href="'/content/'+data.content_permalink" class="callByAjax">
                    <div class="picture">

                      <img loading="lazy"
                        v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                        :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                      <img loading="lazy"
                        v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                        :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                      <!--Button Show on Hover start Here-->
                      <div class="box-hover">
                        <!-- <a href="javascript:void(0);">Play Now</a>
                  <a href="javascript:void(0);">View Trailer</a>                      -->
                      </div>
                      <!--Button Show on Hover End Here-->
                    </div>
                  </a>
                  <div class="data">

                    <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                      :userList="userList" />
                    <content_hover_eight :id="$attrs['id'] +'_content_hover_eight_1'" :content="data"
                      :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])"
                      :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])"
                      :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
                      :downloadBtnText="i18n($attrs['label6'])" :openBtnText="i18n($attrs['label7'])"
                      :isFavouriteSettings="isFavouriteEnabled" />
                  </div>

                </div>
              </div>
            </div>
          </div>
        </template>

      </div>
    </div>
  </section>
</template>
<!--TOp Movies Section End Here-->

<!--See All Category-->
<section class="product-listing p-0 3" id="see-allCategory" v-if="isData && contentList.length > 0" vd-readonly="true">
  <div class="container-fluid pl-65">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="episode-heading seeallTitle seeAll-heading">

          <h2 class="sub-heading white-color ">{{contentTitle}}</h2>
        </div>
      </div>
      <div class="contect-listing">

        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="see-all row" id="categoryContentList">
            <template v-if="contentList.length">
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="data in contentList">
                <div class="item" >
                  <a v-if="data?.is_playlist==1" :href="'/playlist/'+data.content_permalink" class="callByAjax">
                    <div class="picture">
                      <div class="freeContent-tag" v-if="data?.is_free_content">
                        <span><vd-component-param type="label5"
                            v-html="i18n($attrs['label5'])"></vd-component-param></span>
                      </div>
                      <img loading="lazy"
                        v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                        :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                      <img loading="lazy"
                        v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                        :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                      <div class="box-hover"></div>
                    </div>
                  </a>
                  <a v-else :href="'/content/'+data.content_permalink" class="callByAjax">
                    <div class="picture">
                      <div class="freeContent-tag" v-if="data?.is_free_content">
                        <span><vd-component-param type="label5"
                            v-html="i18n($attrs['label5'])"></vd-component-param></span>
                      </div>
                      <img loading="lazy"
                        v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                        :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                      <img loading="lazy"
                        v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                        :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                      <div class="box-hover"></div>
                    </div>
                  </a>
                  <div class="data">
                    <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                      :userList="userList" />
                    <content_hover_eight :id="$attrs['id'] +'_content_hover_eight_1'" :content="data"
                      :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])"
                      :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])"
                      :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
                      :downloadBtnText="i18n($attrs['label6'])" :openBtnText="i18n($attrs['label7'])"
                      :isFavouriteSettings="isFavouriteEnabled" />
                  </div>
                </div>
              </div>
              <content_purchase_one :id="$attrs['id'] +'_content_purchase_one_1'" />
            </template>

          </div>
        </div>

      </div>
    </div>
  </div>
</section>

<!--See All Category-->

<div class="col-xs-12 text-center"
  v-if="isData && !subcategoryContents.length && !parentContent_list.length && !contentList.length">
  <img :src="rootUrl + 'img/no-result.gif'" class="mw-100" />
  <h2 vd-readonly="true">No Contents present in {{contentTitle}} category!</h2>
</div>
    <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio"
        v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent" />
</vd-component>
    `,
};

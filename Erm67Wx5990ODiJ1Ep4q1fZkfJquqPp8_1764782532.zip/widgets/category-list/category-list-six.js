let {
    allCategories,
    cmsCategory,
    getPlaylistContentDetails,
    isAuthorizedContent}=await import(window.importAssetJs('js/webservices.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "category_list_six",
    components: {
        content_hover_six,
        audio_player_one,
        content_title_one,
        content_purchase_five: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-five.js'))),
    },
    data() {
        return {
            playlistTitle: '',
            noplaylist: false,
            categoryList: [],
            contentList: [],
            contentTitle: '',
            featureContentList: [],
            featurecontentTitle: '',
            categoryContentList: [],
            playListContent: [],
            contentUuid: '',
            categoryPermalink: permalink,
            isLogedIn: localStorage.getItem('isloggedin'),
            pageNo: 1,
            categoryUuid: "",
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            selectedContentUuid: '',
            monetizationMethods: [],
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true,
            userList:[],
			assignedArray: [],
            gutterSpace: null,
            content_asset_type:2
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        // var path = window.location.href;
        // var params = path.split("category/")[1];
        
        let uuid = this.categoryPermalink;
        allCategories().then(res => {
            JsLoadingOverlay.hide();
            if (res.data.code == 200 && res.data.data != null) {
                this.categoryList = res.data.data.categoryList.category_list;
                for (const categorydata of this.categoryList) {
                    if (categorydata.category_permalink === uuid) {
                        this.contentTitle = categorydata.category_name;
                        this.categoryUuid = categorydata.category_uuid;
                        break;
                    }
                }
                this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, false,this.content_asset_type);
            }
        });
        cmsCategory().then(res => {
            JsLoadingOverlay.hide();

            if (res.data.code == 200 && res.data.data.categoryList.category_list.length>0) {
                this.categoryList = res.data.data.categoryList.category_list;
                this.categoryList.filter(categorydata => (categorydata.category_permalink === uuid)).map(ele => {
                    if (ele) {
                        this.contentTitle = ele.category_name;
                        this.categoryUuid = ele.category_uuid;
                    } else {
                        this.categoryUuid = ele.category_uuid;
                    }
                });
                /** Setted Subcategory content title */
                if (this.categoryUuid=='' || this.categoryUuid === undefined) {
                    for (const category of this.categoryList) {
                        if (category.sub_category) {
                            for (const subCat of category.sub_category) {
                                if (subCat.category_permalink === uuid) {
                                    this.contentTitle = subCat.category_name;
                                    this.categoryUuid = subCat.category_uuid;
                                    break;
                                }
                            }
                        }
                    }
                }
                //content

                this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, false,this.content_asset_type);

            }
        });
        this.loadMore();
    },
    methods: {
        i18n,
        getRootUrl,
        timeFormating(duration, contentType) {

            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration.replace(':', 'm ').concat('s');
                    console.log("this.videoDuration", videoDuration);

                }
                else {
                    videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                    console.log("this.videoDuration else", videoDuration);

                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration.replace(':', 'm ').concat('s');
                } else {
                    var audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                }
                return audioDuration;
            }
        },

        getContentId(uuid) {
            this.contentUuid = uuid;
            localStorage.setItem("contentId", this.contentUuid)
        },
        playContent(content_uuid, content_name, assetType) {
            isAuthorizedContent(content_uuid).then((res) => {
                if (res.data.code == 200) {
                    this.isAuthorized = res.data.data.isAuthorized.is_content_authorized;
                    if (this.isAuthorized == true) {
                        $('.post-checkout-popup').modal('hide');
                        if (assetType == 1) {
                            window.location.href = "/player/" + content_uuid;
                        } else {
                            this.audioPlayControl = false;
                            this.audioUuid = content_uuid;
                        }
                    } else {
                        $('.post-checkout-popup').modal('show');
                        localStorage.setItem('content_uuid', content_uuid)
                        //window.location.href = "/content-purchase/" + content_uuid;
                    }
                }
            });
        },
        loadMore() {
            // window.onscroll = () => {
            //     //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //     let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight + 20 >= document.documentElement.scrollHeight;
            //     //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
            //         this.pageNo++;
            //         this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, true,this.content_asset_type);
            //     }
            // }
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                       this.getPlaylistContentDetails(this.categoryUuid, this.pageNo, true)
                }
            };
        },

        getPlaylistContentDetails(categoryUuid, pageNo, onScroll,content_asset_type) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                    JsLoadingOverlay.show();
                getPlaylistContentDetails(categoryUuid, pageNo,content_asset_type).then(res => {
                    JsLoadingOverlay.hide();
                    if (!onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
                        this.contentList = res.data.data.contentList.content_list;
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    } else if (onScroll && res.data.code == 200 && res.data.data.contentList.content_list) {
                        this.contentList.push(...res.data.data.contentList.content_list);
                        contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list,this.userList);
                    }

                    if (res.data.code == 200 && this.contentList?.length < res.data.data.contentList.page_info.total_count) {
                        this.isNextPageCallReqd = true;
                    }
                    if (this.contentList == null || this.contentList?.length <= 0) {
                        this.noRecordMsgShow = true;
                    }
                });
            }
        },
        playAudioContent(content_detail) {//ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template: `
    <vd-component class="vd category-list-six" type="category-list-six">
        <section class="season-content" :class="contentList.length?'season-content':'no-result-found'">
            <div class="container-fluid plr-88">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" >
                        <div class="episode-heading pb-40">
                            <h3 vd-readonly="true" class="sub-heading white-color separate-page-heading">{{contentTitle}}</h3>
                        </div>
                    </div>
                    <template v-if="contentList.length " >
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="row" id="categoryContentList" vd-readonly="true" meta-key='meta-category-list' vd-node="metaData">
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5" v-for="data in contentList">
                                <div class="tiles grid-hover fs-tiles" >
                                    <div class="picture">
                                        <div class="freeContent-tag" v-if="data?.is_free_content">
                                            <span><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>
                                        </div>
                                        <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                            <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
                                        </div>
                                        <!--Button Show on Hover start Here-->
                                        <content_hover_six
                                            :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                            :content="data"
                                            :playNowBtnTxt="i18n($attrs['label1'])"
                                            :viewTrailerBtnTxt="i18n($attrs['label2'])"
                                            :playAllBtnTxt="i18n($attrs['label3'])"
                                            :watchNowBtnTxt="i18n($attrs['label4'])"
                                            :isLogedIn="isLogedIn"
                                            @playAudioContent="playAudioContent"
                                            :downloadBtnText="i18n($attrs['label6'])"
                                            :openBtnText="i18n($attrs['label7'])"
                                        />
                                        <!--Button Show on Hover End Here-->
                                        <img class="w-100"   loading="lazy" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url"/>
                                        <img class="w-100"  loading="lazy" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="no image"/>
                                    </div>
                                    <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  
                                    :content="data" :userList="userList"  :assignedArray="assignedArray"/>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <content_purchase_five  :id="$attrs['id'] +'_content_purchase_five_5'" />
                    </template>
                    <template v-else>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="noRecordMsgShow">
                            <div class="w-100 text-center">
                                <img :src="rootUrl + 'img/no-result.gif'" class="mw-100"/>
                                <h2 vd-readonly="true">No Contents present in {{contentTitle}} category !</h2>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </section>
        <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
    `,
};

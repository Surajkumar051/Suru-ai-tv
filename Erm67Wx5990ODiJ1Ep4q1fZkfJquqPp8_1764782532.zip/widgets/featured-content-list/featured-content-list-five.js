let { getFeaturedSectionDataByUuid, getContentSettingsDetails } = await import(window.importAssetJs('js/webservices.js'));
let { default: content_hover_eight } = await import(window.importLocalJs('widgets/content-hover/content-hover-eight.js'));
let { default: audio_player_one } = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { getRootUrl, getAssetUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { default: content_title_eight } = await import(window.importLocalJs('widgets/content-title/content-title-eight.js'));
let contentHelper = await import(window.importAssetJs('js/content-helper.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
const { mapState, mapActions } = Vuex;

export default {
    name: "featured_content_list_five",

    components: {
        content_hover_eight,
        audio_player_one,
        content_title_eight
    },
    data() {
        return {
            featuredSectionUuid: permalink,
            // window.location.pathname
            //     .toString()
            //     .split("/")[2],
            featuredSectionDetails: Object,
            isLogedIn: localStorage.getItem("isloggedin"),
            pageNo: 1,
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            assetUrl: getAssetUrl(),
            userList: [],
            isFavouriteEnabled: false,
        };
    },
    updated() {
        owlCarousal();
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        $('.owl-carousel').trigger('destroy.owl.carousel');
        // console.log("mounted in default-featureslist1 page");
        this.getFeaturedSectionData(this.pageNo, false);
        this.loadMore();
        getContentSettingsDetails().then((res) => {
            if (res.data.code == 200) {

                this.isFavouriteEnabled =
                    res.data.data.contentSettings
                        .content_favourite_settings != null
                        ? res.data.data.contentSettings
                            .content_favourite_settings?.is_enabled
                        : false;

            }
        });
    },
    methods: {
        i18n,
        getAssetUrl,
        getFeaturedSectionData(page, onScroll) {
            JsLoadingOverlay.show();

            if (this.isNextPageCallReqd) {
                (this.isNextPageCallReqd = false),
                    getFeaturedSectionDataByUuid(
                        this.featuredSectionUuid,
                        page
                    ).then((res) => {
                        JsLoadingOverlay.hide();
                        // if (res.data.code == 200 && res.data.data.featuredContentList) {
                        //         this.featuredSectionDetails = res.data.data.featuredContentList.featured_content_list[0];
                        // }
                        if (res.data.code !== 200) {
                            window.location.href ="/404";
                        }

                        if (
                            !onScroll &&
                            res.data.code == 200 &&
                            res.data.data.featuredContentList
                                .featured_content_list
                        ) {
                            this.featuredSectionDetails =
                                res.data.data.featuredContentList.featured_content_list[0];
                            contentHelper.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list[0].section_content_list.content_list, this.userList);
                        } else if (
                            onScroll &&
                            res.data.code == 200 &&
                            res.data.data.featuredContentList
                                .featured_content_list &&
                            res.data.data.featuredContentList
                                .featured_content_list[0].section_content_list
                                .content_list?.length > 0
                        ) {
                            this.featuredSectionDetails.section_content_list.content_list.push(
                                ...res.data.data.featuredContentList
                                    .featured_content_list[0]
                                    .section_content_list.content_list
                            );
                            contentHelper.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list[0].section_content_list.content_list, this.userList);
                        }

                        if (
                            res.data.code == 200 &&
                            this.featuredSectionDetails.section_content_list
                                .content_list?.length <
                            res.data.data.featuredContentList
                                .featured_content_list[0]
                                .section_content_list.page_info.total_count
                        ) {
                            this.isNextPageCallReqd = true;
                        }
                        if (
                            this.featuredSectionDetails.section_content_list
                                .content_list == null ||
                            this.featuredSectionDetails.section_content_list
                                .content_list?.length <= 0
                        ) {
                            this.noRecordMsgShow = true;
                        }
                    });
            }
        },
        loadMore() {
            // window.onscroll = () => {
            //     //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //     let bottomOfWindow =
            //         document.documentElement.scrollTop +
            //         document.documentElement.clientHeight +
            //         20 >=
            //         document.documentElement.scrollHeight;
            //     //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
            //         this.pageNo++;
            //         this.getFeaturedSectionData(this.pageNo, true);
            //     }
            // };
             window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;

                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getFeaturedSectionData(this.pageNo, true);
                }
            };
          },
        playAudioContent(content_detail) { //ER-114072
            this.contentUuidAudio = content_detail.content_uuid; //ER-114072
            this.isFreeContent = content_detail.is_free_content; //ER-114072
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),
    },
    template: /*html*/ `
       <vd-component class="vd featured-content-list-five" type="featured-content-list-five">
    <!--Banner Section Start Here-->
        <section class="seeAllheading mt-94"  v-if="featuredSectionDetails?.section_content_list?.content_list.length">
 <div class="container-fluid pl-65">
        <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="episode-heading seeAll-heading">

              <h2 class="sub-heading white-color">{{featuredSectionDetails?.feature_section_name}}</h2>
            </div>
          </div>
           </div>
          </div>
        </section>
    <!--Banner Section End Here-->
  <!--Top Movies Section Start Here-->
  <section class="product-listing p-0"
    :class="featuredSectionDetails?.section_content_list?.content_list?'season-content':'no-result-found'"
    vd-readonly="true">
    <div class="container-fluid pl-65">
      <div class="row">

        <div class="contect-listing">
          
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <div class="see-all row"  id="categoryContentList">
              <template v-if="featuredSectionDetails?.section_content_list?.content_list.length">
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="data in featuredSectionDetails.section_content_list.content_list">
                  <div class="item " >
                    <a v-if="data?.is_playlist==1" :href="'/playlist/'+data.content_permalink" class="callByAjax">
                      <div class="picture">
                        <div class="freeContent-tag" v-if="data?.is_free_content">
                          <span><vd-component-param type="label5"
                              v-html="i18n($attrs['label5'])"></vd-component-param></span>
                        </div>
                        <img loading="lazy"
                          v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                          :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                        <img loading="lazy"
                          v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                          :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" class="mw-100 no-img" alt="no image" />
                        <div class="box-hover"></div>
                      </div>
                    </a>
                    <a v-else :href="'/content/'+data.content_permalink" class="callByAjax">
                      <div class="picture">
                        <div class="freeContent-tag" v-if="data?.is_free_content">
                          <span><vd-component-param type="label5"
                              v-html="i18n($attrs['label5'])"></vd-component-param></span>
                        </div>
                        <img loading="lazy"
                          v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''"
                          :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url" />
                        <img loading="lazy"
                          v-if="data.posters.website === null  || data.posters.website[0].file_url === ''"
                          :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                        <div class="box-hover"></div>
                      </div>
                    </a>
                    <div class="data">
                      <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'" :content="data"
                        :userList="userList" />
                      <content_hover_eight :id="$attrs['id'] +'_content_hover_eight_1'" :content="data"
                        :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])"
                        :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])"
                        :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
                        :downloadBtnText="i18n($attrs['label6'])" :openBtnText="i18n($attrs['label7'])"
                        :isFavouriteSettings="isFavouriteEnabled" />
                    </div>
                  </div>
                </div>
                <content_purchase_one :id="$attrs['id'] +'_content_purchase_one_1'" />
              </template>
              <template v-else>
                <div class="col-xs-12 text-center" v-if="noRecordMsgShow">
                  <img :src="rootUrl + 'img/no-result.gif'" class="mw-100" />
                  <h2 vd-readonly="true">No Contents present in {{contentTitle}} category!</h2>
                </div>
              </template>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  <!--TOp Movies Section End Here-->
  <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio"
    v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent" />
</vd-component>
        `,
};

let { getFeaturedSectionDataByUuid } = await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "featured_content_list_four",
    components: {
        content_hover_six,
        audio_player_one,
        content_title_one
    },
    data() {
        return {
            featuredSectionUuid: permalink,
            // window.location.pathname
            //     .toString()
            //     .split("/")[2],
            featuredSectionDetails: Object,
            isLogedIn: localStorage.getItem("isloggedin"),
            pageNo: 1,
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            userList:[],
            assignedArray: [],
            gutterSpace: null,           
        };
    },

    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        // console.log("mounted in default-featureslist1 page");
        this.getFeaturedSectionData(this.pageNo, false);
        this.loadMore();
    },
    methods: {
        i18n,
        getFeaturedSectionData(page, onScroll) {
            JsLoadingOverlay.show();
                        
            if (this.isNextPageCallReqd) {
                (this.isNextPageCallReqd = false),
                    getFeaturedSectionDataByUuid(
                        this.featuredSectionUuid,
                        page
                    ).then((res) => {
                        JsLoadingOverlay.hide();
                        // if (res.data.code == 200 && res.data.data.featuredContentList) {
                        //         this.featuredSectionDetails = res.data.data.featuredContentList.featured_content_list[0];
                        // }
                        if(res.data.code !== 200){
                            window.location.href = "/404";
                        }

                        if (
                            !onScroll &&
                            res.data.code == 200 &&
                            res.data.data.featuredContentList
                                .featured_content_list
                        ) {
                            this.featuredSectionDetails =
                                res.data.data.featuredContentList.featured_content_list[0];
                            contentHelper.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list[0].section_content_list.content_list,this.userList);
                        } else if (
                            onScroll &&
                            res.data.code == 200 &&
                            res.data.data.featuredContentList
                                .featured_content_list &&
                            res.data.data.featuredContentList
                                .featured_content_list[0].section_content_list
                                .content_list?.length > 0
                        ) {
                            this.featuredSectionDetails.section_content_list.content_list.push(
                                ...res.data.data.featuredContentList
                                    .featured_content_list[0]
                                    .section_content_list.content_list
                            );
                            contentHelper.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list[0].section_content_list.content_list,this.userList);
                        }

                        if (
                            res.data.code == 200 &&
                            this.featuredSectionDetails.section_content_list
                                .content_list?.length <
                                res.data.data.featuredContentList
                                    .featured_content_list[0]
                                    .section_content_list.page_info.total_count
                        ) {
                            this.isNextPageCallReqd = true;
                        }
                        if (
                            this.featuredSectionDetails.section_content_list
                                .content_list == null ||
                            this.featuredSectionDetails.section_content_list
                                .content_list?.length <= 0
                        ) {
                            this.noRecordMsgShow = true;
                        }
                    });
            }
        },
        loadMore() {
            // window.onscroll = () => {
            //     //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //     let bottomOfWindow =
            //         document.documentElement.scrollTop +
            //             document.documentElement.clientHeight +
            //             20 >=
            //         document.documentElement.scrollHeight;
            //     //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
            //         this.pageNo++;
            //         this.getFeaturedSectionData(this.pageNo, true);
            //     }
            // };
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;

                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getFeaturedSectionData(this.pageNo, true);
                }
            };
        },
        playAudioContent(content_detail) { //ER-114072
            this.contentUuidAudio = content_detail.content_uuid; //ER-114072
            this.isFreeContent = content_detail.is_free_content; //ER-114072
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template: `
        <vd-component class="vd featured-content-list-four" type="featured-content-list-four">
        <div class="main-content music-listing-content">
            <section :class="featuredSectionDetails?.section_content_list?.content_list?'season-content':'no-result-found'">
                <div class="container-fluid plr-88">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="featuredSectionDetails?.section_content_list?.content_list.length">
                            <div class="episode-heading pb-40">
                                <h3 class="sub-heading white-color separate-page-heading">{{featuredSectionDetails?.feature_section_name}}</h3>
                            </div>
                        </div>
                        <template v-if="featuredSectionDetails?.section_content_list?.content_list.length ">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="row" id="categoryContentList" meta-key='meta-feature-list' vd-node="metaData">
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5" v-for="data in featuredSectionDetails.section_content_list.content_list">
                                    <div class="tiles grid-hover fs-tiles">
                                        <div class="picture">
                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                <span><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>
                                            </div>
                                            <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                                <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
                                            </div>
                                            <div :class="(data.content_asset_type == 2 && data.is_playlist!=1)?'icons-apply-audio':'icons-apply'">
                                                <img v-if=" data.content_asset_type == 1 && data.is_playlist!=1" :src="rootUrl + 'img/video-icons.png'"/>
                                                <img v-if=" data.content_asset_type == 2 && data.is_playlist!=1" :src="rootUrl + 'img/audio-icon.png'"/>
                                                <img v-if=" data.content_asset_type == 6 && data.is_playlist!=1" :src="rootUrl + 'img/file-icon.png'"/>
                                                <img v-if=" data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                            </div>
                                            <img  loading="lazy" class="w-100" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url"/>
                                            <img loading="lazy" class="w-100" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="data.no_image_available_url" alt="no image"/>
                                            <!--Button Show on Hover start Here-->
                                                <content_hover_six 
                                                :id="$attrs['id'] +'_content_hover_six_6'"
                                                :root_url="rootUrl"
                                                :content="data" 
                                                :playNowBtnTxt="i18n($attrs['label1'])"
                                                :viewTrailerBtnTxt="i18n($attrs['label2'])"
                                                :playAllBtnTxt="i18n($attrs['label3'])"
                                                :watchNowBtnTxt="i18n($attrs['label4'])"
                                                :isLogedIn="isLogedIn"
                                                @playAudioContent="playAudioContent"
                                                :downloadBtnText="i18n($attrs['label6'])"
                                                :openBtnText="i18n($attrs['label7'])"
                                                />
                                            <!--Button Show on Hover End Here-->
                                        </div>
                                        <!--<div class="data">
                                                <a class="callByAjax data-a" :href="'/content/'+data.content_permalink" @click="getContentId(data.content_uuid)">
                                                        <span v-if="data.content_name">{{data.content_name}}</span>
                                                </a>
                                        </div>-->
                                        <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  :content="data"
                                                                            :userList="userList" :assignedArray="assignedArray"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </template>
                        <template v-else>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="noRecordMsgShow">
                                        <div class="w-100 text-center">
                                                <img :src="$attrs['root_url'] + 'img/no-result.gif'" class="mw-100"/>
                                                <h2>No Contents present in {{contentTitle}} category !</h2>
                                        </div>
                                </div>
                        </template>
                    </div>
                </div>
            </section>
         </div>    
        <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
        `,
};

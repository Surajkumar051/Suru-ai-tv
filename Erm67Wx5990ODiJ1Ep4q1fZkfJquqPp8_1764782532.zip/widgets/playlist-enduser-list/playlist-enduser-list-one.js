let { TooltipDirective } = await import(window.importAssetJs('js/directives/tooltip.directive.js'));
let { TOGGLE_ENDUSER_PLAYLIST_MODAL, GET_ENDUSER_PLAYLIST, GET_STORE_CONTENT_TYPE } = await import(window.importAssetJs('js/configurations/actions.js'));
let {
    deleteEnduserPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let {default:playlist_enduser_one}=await import(window.importLocalJs('widgets/playlist-enduser/playlist-enduser-one.js'));
let {default:playlist_enduser_details_one}=await import(window.importLocalJs('widgets/playlist-enduser-details/playlist-enduser-details-one.js'));
let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapGetters } = Vuex;

export default {
    name: 'playlist_enduser_list_one',
    components: {
        playlist_enduser_one,
        playlist_enduser_details_one,
        audio_player_one,
        content_hover_one,
        content_purchase_one: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'))),
    },
    template: `
    <vd-component class="vd playlist-enduser-list-one" type="playlist-enduser-list-one">
        <div class="dashboard-tiles bg-black" v-if="showDetailsPage === false">
            <!--Title start here-->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <h1 class="dashboard-heading white-color mbottom-20 h1-wh">{{i18n('My Playlists')}}
                        <div class="div-ap">
                            <button class="ap-modalBtn" href="javascript:void(0);" @click="myPlaylistEvent">
                                <span class="ap-plusIcon d-flex">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 3.33203V12.6654" stroke="white" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                        <path d="M3.33594 8H12.6693" stroke="white" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                    </svg>
                                </span>
                                {{i18n('Add Playlist')}}
                            </button>
                        </div>
                    </h1>
                </div>
            </div>
            <!--Title End here-->
            <div class="no-wh d-none" v-if="!enduser_playlist && !isLoading">
                <span>
                    {{i18n("You haven't created any playlist yet, create playlist now and let it groove.")}}
                </span>
            </div>
            <section class="no-result-found" v-if="!enduser_playlist && !isLoading">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="w-100 text-center">
                                <img :src="rootUrl+'img/no-result.gif'" alt="no result"
                                    class="mw-100" />
                                <h2>
                                    {{i18n("You haven't created any playlist yet, create playlist now and let it groove.")}}
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--Playlist start Here-->
            <div class="all-mp" v-else>
                <div class="row">
                    <div class="col-12 mplitems-parent">
                        <!--Loop File Start Here-->
                        <div class="myplaylist-items" v-for="(plist, index) in enduser_playlist?.content_list" :key="plist.content_uuid">
                            <div class="picture" @click="openDetailsPage(plist.content_uuid)" style="cursor:pointer;">
                                <a href="javascript:void(0)" class="h-100">
                                    <img :src="plist?.playlist_content_list?.[0]?.posters?.website?.[0]?.file_url" v-if="plist?.playlist_content_list?.[0]?.posters?.website?.[0]?.file_url" alt="playlist" class="w-100 h-100">
                                    <span class="playlist-type-icon" v-if="plist.content_asset_type === 1">
                                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M4 8C4 5.79087 5.79087 4 8 4H18.6667C20.8759 4 22.6667 5.79087 22.6667 8V18.6667C22.6667 20.8759 20.8759 22.6667 18.6667 22.6667H8C5.79087 22.6667 4 20.8759 4 18.6667V8Z"
                                                stroke="white" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round"></path>
                                            <path
                                                d="M28.0026 9.33203V23.9987C28.0026 26.2079 26.2118 27.9987 24.0026 27.9987H9.33594"
                                                stroke="white" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round"></path>
                                            <path d="M12 16.0013V10.668L16.1905 13.3346L12 16.0013Z" fill="white" stroke="white"
                                                stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </span>
                                    <span class="playlist-type-icon" v-if="plist.content_asset_type === 2">
                                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path 
                                                d="M20 8H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                            <path 
                                                d="M17.3333 13.332H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                            <path 
                                                d="M12 18.668H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                            <path 
                                                d="M10.6667 24H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                            <path 
                                                d="M22.6641 22.0013V16.668V10.668" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                            <path
                                                d="M19.3333 25.3346C21.1743 25.3346 22.6667 23.8423 22.6667 22.0013C22.6667 20.1604 21.1743 18.668 19.3333 18.668C17.4924 18.668 16 20.1604 16 22.0013C16 23.8423 17.4924 25.3346 19.3333 25.3346Z"
                                                stroke="white" stroke-width="1.5"></path>
                                            <path 
                                                d="M27.9974 16.0013C25.0519 16.0013 22.6641 13.6134 22.6641 10.668" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                        </svg>
                                    </span>
                                </a>
                            </div>
                            <div class="mpi-data">
                                <div class="data-contents">
                                    <h2 class="mp-heading" @click="openDetailsPage(plist.content_uuid)">
                                        {{ formatText(plist.content_name) }}
                                    </h2>
                                    <div class="createDateTrack">
                                        <span class="cd-date">
                                            {{ formatDate(plist.content_created_date) }}
                                        </span>
                                        <span class="cdt-divide">|</span>
                                        <span class="cdt-track">
                                            {{ plist.playlist_size}} {{ plist.content_asset_type === 1 ? 'Video(s)' : 'Audio(s)' }}
                                        </span>
                                    </div>
                                </div>
                                <div class="actionbuttons">
                                    <div class="playAll">
                                        <content_hover_one 
                                            v-if="plist.playlist_size > 0" 
                                            :id="$attrs['id'] +'_content_hover_one_1_'+index"
                                            :content="plist"
                                            :playAllBtnTxt="i18n($attrs['label3'])"
                                            :isLogedIn="isLogedIn" 
                                            :fromEnduserPlaylist="true"
                                            @playAudioContent="playAudioContent"
                                        />
                                        <button class="pa-btn disabled" v-else>
                                            <span class="pa-icon d-flex">
                                                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M2.91406 3.58167C2.91406 2.7905 3.78931 2.31266 4.45482 2.74049L9.77223 6.15882C10.3846 6.55246 10.3846 7.44754 9.77223 7.84118L4.45482 11.2595C3.78931 11.6873 2.91406 11.2095 2.91406 10.4183V3.58167Z"
                                                        fill="#E9E9E9" stroke="#E9E9E9" stroke-width="1.33"
                                                        stroke-linecap="round" stroke-linejoin="round">
                                                    </path>
                                                </svg>
                                            </span>
                                            Play All
                                        </button>
                                    </div>
                                    <div class="ed-btns">
                                        <button class="btns btnEdit" data-toggle="modal" @click="myPlaylistEvent(plist.content_uuid, plist.content_asset_type, plist.content_name)">
                                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M11.5909 1.58492C11.7763 1.39948 11.9964 1.25238 12.2387 1.15201C12.481 1.05165 12.7407 1 13.003 1C13.2652 1 13.5249 1.05165 13.7672 1.15201C14.0095 1.25238 14.2296 1.39948 14.4151 1.58492C14.6005 1.77036 14.7476 1.99051 14.848 2.2328C14.9483 2.47509 15 2.73478 15 2.99703C15 3.25928 14.9483 3.51897 14.848 3.76126C14.7476 4.00355 14.6005 4.2237 14.4151 4.40914L4.88331 13.9409L1 15L2.05909 11.1167L11.5909 1.58492Z"
                                                    stroke="white" stroke-opacity="0.64" stroke-width="1.5"
                                                    stroke-linecap="round" stroke-linejoin="round">
                                                    </path>
                                            </svg>
                                        </button>
                                        <button class="btns btnDelete" data-toggle="modal" @click="openDeleteModal(plist.content_uuid, plist.content_name)">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2.25 4.5H3.75H15.75" stroke="white" stroke-opacity="0.64" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path
                                                    d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72065 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5"
                                                    stroke="white" stroke-opacity="0.64" stroke-width="1.5"
                                                    stroke-linecap="round" stroke-linejoin="round">
                                                    </path>
                                                <path d="M7.5 8.25V12.75" stroke="white" stroke-opacity="0.64" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M10.5 8.25V12.75" stroke="white" stroke-opacity="0.64" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Loop File End Here-->
                    </div>
                    
                </div>
                <div class="playlistItems pt-3" v-if="total_count > enduser_playlist?.content_list?.length">
                    <div class="plic-left">
                        <button class="loadMore" @click="loadMore">
                            <span class="pa-icon d-flex">
                                <img src=${rootUrl}img/playlist-icon.png style="width: 14px;">                           
                            </span>
                                {{i18n("Load More")}}
                        </button>
                    </div>
                </div>
                <div class="playlistItems pt-3 d-none" v-else-if="enduser_playlist?.content_list?.length > 10">
                    <span class="pa-icon d-flex white-color samll-content">
                        {{i18n("No more playlists to show")}}!                         
                    </span>
                </div>
            </div>
            <!--Playlist End Here-->
        </div>
        <!--delete playlist start Here-->
        <div class="modal fade delete-playlist-modal p-0" id="deletePlaylist" tabindex="-1" role="dialog" aria-labelledby="deletePlaylist" aria-hidden="true" ref="del_modal_el">
            <div class="modal-dialog modal-dialog-centered justify-content-center" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="dplm-mb-contents">
                            <div class="dplmmbc-delIcon">
                                <span class="delicon-span">
                                    <svg width="42" height="42" viewBox="0 0 42 42" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.25 10.5H8.75H36.75" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path
                                            d="M33.25 10.5V35C33.25 35.9283 32.8813 36.8185 32.2249 37.4749C31.5685 38.1313 30.6783 38.5 29.75 38.5H12.25C11.3217 38.5 10.4315 38.1313 9.77513 37.4749C9.11875 36.8185 8.75 35.9283 8.75 35V10.5M14 10.5V7C14 6.07174 14.3688 5.1815 15.0251 4.52513C15.6815 3.86875 16.5717 3.5 17.5 3.5H24.5C25.4283 3.5 26.3185 3.86875 26.9749 4.52513C27.6313 5.1815 28 6.07174 28 7V10.5"
                                            stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M17.5 19.25V29.75" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M24.5 19.25V29.75" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </span>
                            </div>
                            <div class="dplmmbc-delMessage">
                                <span class="delMessage-heading">{{i18n("Delete Playlist")}}?</span>
                                <span class="delMessage-para">You are about to permanently delete the playlist '{{playlist_name}}' from your account. This action cannot be undone. Are you sure you want to proceed?</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer no-border">
                        <button type="button" class="btn dismiss" data-dismiss="modal">{{i18n('Cancel')}}</button>
                        <button type="button" class="btn btnProceed" id="proceedDelPl" @click="deletePlaylist">{{i18n('Proceed')}}</button>
                    </div>
                </div>
            </div>
        </div>
        <!--delete playlist End Here-->
        <playlist_enduser_one :id="$attrs['id'] +'_playlist_enduser_one_1'" v-if="show_enduser_playlist_modal" @reset-page="resetPage" :content-details="contentDetails" />

        <div class="dashboard-tiles bg-black" v-if="showDetailsPage">
            <playlist_enduser_details_one :id="$attrs['id'] +'_playlist_enduser_details_one_1'" :playlistId="playlistId" @show-list="goToListPage" @click-delete-playlist="openDeleteModalDetails" @playAudioContent="playAudioContent" :playAllBtnTxt="i18n($attrs['label3'])" />
        </div>
        <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent" :isEnduserPlayList="true" :playlistId="contentUuidAudio !== playlistId ? playlistId : ''" />
        <content_purchase_one  :id="$attrs['id'] +'_content_purchase_one_1'" :fromEnduserPlaylist="true" />
    </vd-component>
    `,
    props: {
        
    },
    directives: {
        tooltip: TooltipDirective
    },
    data() {
        return {
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            reloadOnUpdateLifeCycle: true,
            isJsLoader: false,
            isBack: false,
            pageNo: 1,
            total_count: 0,
            showDetailsPage: false,
            isLoading: true,
            playlistId: '',
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            contentDetails: { 
                content_asset_type: 0,
                content_uuid: '',
                playlist_uuid: '',
                isListing: false
            },
            selectedIndex: 0,
            rootUrl: getRootUrl(),
            hideCnPlaylist: false,
            disableCnPlaylist: false,
            hideDynamicPlaylist: true,
            hideBtnCreatePlaylist: true,
            disableBtnSavePlaylist: true,
            hideBtnSavePlaylist: false,
            hideCpinputDiv: true,
            hideNoPlaylist: false,
            playlist_type: 0,
            playlist_name: '',
            isFormValid: false,
            errors: {},
            isReset:false,
            invalidPlaylistType: false,
            invalidPlaylistName: false,
            footerPadding: false,
            checkedValues: [],
        }
    },
    computed: {
        ...mapState({
            current_content_uuid: state => state.current_content_uuid,
            store_content_type: (state) => state.store_content_type,
            enduser_playlist: function (state) {
                const vm = this;
                console.log('vm', vm);
                console.log('state.enduser_playlist', state.enduser_playlist);
                this.total_count = state.enduser_playlist ? state.enduser_playlist?.page_info?.total_count : 0;
                return state.enduser_playlist;
            },
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal
        }),
        // 87419 Raj
        ...mapGetters({
            will_show_apply_promocode: 'is_promotion_enabled',
            //is_third_party_gateway: 'is_third_party_gateway',
        }),
    },
    watch: {
        show_enduser_playlist_modal(cv) {
            console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                    // $('#addPlaylist').data('bs.modal')._config.backdrop = 'static';
                    // $('#addPlaylist').data('bs.modal')._config.keyboard = 'false';
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
    },
    async beforeMount() {
        if (localStorage.getItem('isloggedin')) {

        }
    },
    async mounted() {
        if (this.isLogedIn) {
            $('[data-toggle="tooltip"]').tooltip();
            
            await this.getMyPlaylist();

        } else {
            window.location.href = "/sign-up";
        }
    },
    methods: {
        i18n,
        getRootUrl,
        formatDate(inputDate) {
            const local = moment.utc(inputDate).local();
            const dstr = moment(local).format('Do MMMM, YYYY');
            // console.log('Created on '+dstr);
            return 'Created on '+dstr;
        },
        formatText(inputText) {
            return inputText.length > 30 ? inputText.substring(0, 30) + '..' : inputText;
        },
        async getMyPlaylist() {
            !this.isJsLoader ? JsLoader.show() : '';
            try {
                // await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                const params = {
                    content_asset_type: '',
                    page: this.isBack ? 1 : this.pageNo
                };
                await this.$store.dispatch(GET_ENDUSER_PLAYLIST, params);
                // await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                
                if(this.isBack && this.enduser_playlist?.page_no === 1) {
                    this.pageNo = 1;
                    this.isBack = false;
                }
                this.isJsLoader = false;
                console.log('total_count', this.total_count);
                console.log('Playlists', this.enduser_playlist);
                console.log('this.pageNo', this.pageNo);
                
            } catch (error) {
                console.error("Something went wrong!", error.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: error.message,
                });
            }
            console.clear();
            console.log('Hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii');
            this.isLoading = false;
            // JsLoader.hide();
            if(document.getElementById('spinner')) {
                document.getElementById('spinner').remove();
            }
            if(document.getElementById('overlay')) {
                document.getElementById('overlay').remove();
            }
        },
        async loadMore() {
            console.log('loadmore called');
            console.log('this.pageNo', this.pageNo);
            console.log('this.enduser_playlist', this.enduser_playlist);
            console.log(this.enduser_playlist?.content_list?.length);
            console.log('total', this.total_count);
            
            if (this.enduser_playlist && this.enduser_playlist?.content_list?.length < this.total_count) {
                console.log('called 123');
                this.pageNo++;
                await this.getMyPlaylist();
            }
        },
        resetPage(pageNo = 1) {
            console.log('resetPage', pageNo);
            this.pageNo = pageNo;
            // jQuery(this.$refs.del_modal_el).modal('show');
        },
        openDeleteModal(...args) {
            console.log('args', args);
            console.log('plId', args[0]);
            this.playlistId = args[0];
            this.playlist_name = args[1];
            jQuery(this.$refs.del_modal_el).modal('show');
        },
        openDeleteModalDetails({plId, plName}) {
            console.log('plId', plId);
            console.log('plName', plName);
            this.playlistId = plId;
            this.playlist_name = plName;
            jQuery(this.$refs.del_modal_el).modal('show');
        },
        async deletePlaylist() {
            jQuery(this.$refs.del_modal_el).modal('hide');
            console.log('playlistId', this.playlistId);
            JsLoader.show();
            let delResponse = await deleteEnduserPlaylist({ playlist_uuid: this.playlistId });
            if (delResponse.data.code == 200 && delResponse.data.status == "SUCCESS") {
                this.isJsLoader = true;
                this.showDetailsPage = false;
                this.pageNo = 1;
                Toast.fire({ 
                    icon: "success", 
                    title: "Success",
                    text: delResponse.data.message 
                });
                const params = {
                    content_asset_type: '',
                    page: this.pageNo
                };
                // await this.$store.dispatch(GET_ENDUSER_PLAYLIST, params);
                await this.getMyPlaylist();
            } else {
                Toast.fire({ 
                    icon: "error", 
                    title: "Error", 
                    text: delResponse.data.message 
                });
            }
            JsLoader.hide();
        },
        async myPlaylistEvent(plId, asset_type, plist_name) {
            console.log('open modal');
            if (this.isLogedIn) {
                JsLoader.show();
                try {
                    if(plId && asset_type) {
                        this.contentDetails.content_asset_type = asset_type;
                        this.contentDetails.playlist_uuid = plId;
                        this.contentDetails.playlist_name = plist_name;
                    } else {
                        this.contentDetails.content_asset_type = 0;
                        this.contentDetails.playlist_uuid = '';
                        this.contentDetails.playlist_name = '';
                    }
                    await this.$store.dispatch(GET_STORE_CONTENT_TYPE);
                    // await this.$store.dispatch(GET_ENDUSER_PLAYLIST, '');
                    await this.$store.dispatch(TOGGLE_ENDUSER_PLAYLIST_MODAL, true);
                } catch (error) {
                    console.error("Something went wrong!", error.message);
                    Toast.fire({
                        icon: "info",
                        title: 'Something went wrong!',
                        text: error.message,
                    });
                }
                JsLoader.hide();
            } else {
                window.location.href = "/sign-up";
            }
        },
        openDetailsPage(plId) {
            this.showDetailsPage = true;
            this.playlistId = plId;
            console.log('this.playlistId', this.playlistId);
        },
        goToListPage() {
            this.playlistId = '';
            this.isBack = true;
            this.showDetailsPage = false;
            this.getMyPlaylist();
        },
        playAudioContent(content_detail) {//ER-101092
            console.log('content_detail', content_detail);
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    }
}

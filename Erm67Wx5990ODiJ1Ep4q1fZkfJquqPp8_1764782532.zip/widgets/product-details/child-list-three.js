let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
const ChildListOne = {
    name: "ChildListThree",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
    },
    components: {
        content_hover_one,
        audio_player_one,
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
        };
    },
    watch: {
        optView(optView) {},
    },

    methods: {
        playAudioContent(contentUuid){
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration", videoDuration);
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration else", videoDuration);
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },
    },

    template: `
    <ul>
    <li v-for="(childObj,i) in parentContent.child_content"> 
   
                    <div class="row gx-3 align-items-center justify-content-end">
                        <div class="col-md-9">
                            <div class="d-flex align-items-center">
                                <a :href="'/content/'+childObj.content_permalink">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.99935 18.3333C5.39698 18.3333 1.66602 14.6023 1.66602 9.99996C1.66602 5.39759 5.39698 1.66663 9.99935 1.66663C14.6017 1.66663 18.3327 5.39759 18.3327 9.99996C18.3276 14.6002 14.5996 18.3282 9.99935 18.3333ZM3.33268 10.1433C3.37211 13.811 6.36694 16.7579 10.0348 16.7383C13.7027 16.7185 16.6656 13.7395 16.6656 10.0716C16.6656 6.40371 13.7027 3.42477 10.0348 3.40496C6.36694 3.38534 3.37211 6.33226 3.33268 9.99996V10.1433ZM8.33268 13.75V6.24996L13.3327 9.99996L8.33268 13.75Z" fill="#979797"/>
                                    </svg> 
                                </a>
                                <p>{{childObj.content_name}}</p>
                            </div>
                        </div>
                        <div class="col-md-3 col-auto">
                            <div class="d-flex">
                              <!-- <span><button class="txt-theme">Preview</button class="text-theme"></span>-->
                               <content_hover_one
                               :id="$attrs['id'] +'_content_hover_one_1'"
                               :content="childObj" 
                               :playNowBtnTxt="playNowBtnTxt"
                               :viewTrailerBtnTxt="viewTrailerBtnTxt"
                               :playAllBtnTxt="playAllBtnTxt"
                               :watchNowBtnTxt="watchNowBtnTxt"
                               :isLogedIn="isLogedIn"
                               @playAudioContent="playAudioContent"
                           />
                                <span v-if="childObj?.video_details.duration"> {{timeFormating(childObj?.video_details.duration,childObj?.content_asset_type)}}</span>
                            </div>
                           
                        </div>
                    </div>
    </li>
</ul>


<audio_player_one :root_url="$attrs['root_url']" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
      `,
};
export default ChildListOne;

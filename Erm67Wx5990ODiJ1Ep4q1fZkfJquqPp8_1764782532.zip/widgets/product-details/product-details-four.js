let {
    getContentSettingsDetails,
    getContentCastList,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getPlayerParentPermarlinkDetails,
    getVideoDetails,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:like_favourite_share_content_four}=await import(window.importLocalJs('widgets/like-favourite-share-content/like-favourite-share-content-four.js'));
let { default: content_views_two } = await import(window.importLocalJs('widgets/content-views/content-views-two.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: "product_details_four",
    components: {
        content_views_two,
        like_favourite_share_content_four,
    },
    data() {
        return {
            contentCastList: [],
            contentDetails: {},
            isFetchReqd: false,
            showViews: false,
            vdosubTracks: [],
            subKind: "",
        };
    },
    mounted() {},
    methods: {
        i18n,
        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                    console.log(
                        "this.contentDetails methods--------",
                        this.contentDetails
                    );
                }
            });
        },
        getCastcrewDetails(contentUuid) {
            getContentCastList(contentUuid).then((res) => {
                // JsLoadingOverlay.hide();
                if (
                    res.data.code == 200 &&
                    res.data.data !== null &&
                    res.data.data.contentList.content_list?.length > 0
                ) {
                    this.contentCastList =
                        res.data.data.contentList.content_list[0].cast_details;
                }
            });
        },
    },

    props: {
        contentObj: Object,
        contentUuid: "",
        isPlaylist: 0,
        videotracks: Array,
    },
    watch: {
        videotracks(videotracks) {
            this.vdosubTracks = videotracks;
        },
        contentObj(contentObj) {
            this.contentDetails = contentObj;
            console.log("this.contentDetails--------", this.contentDetails);

            this.getCastcrewDetails(contentObj.content_uuid);
            this.isFetchReqd = true;
            this.showViews = true;
        },
        contentUuid(contentUuid) {
            console.log("pithan contentUuid--------" + contentUuid);
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getCastcrewDetails(contentUuid);
        },
    },
    computed: {
        getvdoTracks() {
            let tracks = "";
            this.vdosubTracks.forEach((val, index) => {
                this.subKind = val.kind;
                console.log("val", val.label);
                if (tracks == "") {
                    tracks += val.label;
                } else {
                    tracks += ", " + val.label;
                }
            });

            return tracks;
        },

        castListCommaSeperated() {
            let castNames = "";
            this.contentCastList.forEach((cast, index) => {
                if (castNames == "") {
                    castNames += cast.cast_name;
                } else {
                    castNames += ", " + cast.cast_name;
                }
            });

            return castNames;
        },
    },
    template: `
    
<vd-component class="vd product-details-four" type="product-details-four">
    <section class="videocontent-descption">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 colsm-12 col-md-12 col-lg-12 plr-30">
                    <div class=" single-movie-info">
                        <h4 vd-readonly="true" class="heading-title">{{contentDetails.content_name}}</h4>
                        <div class=" single-meta-holder">
                            <ul class=" single-meta-holder">
                                <li><content_views_two :id="$attrs['id'] +'_content_views_two_2'" :content_uuid="contentDetails.content_uuid" v-if="showViews"></content_views_two></li>
                            </ul> 
                        </div>                   
                        <p vd-readonly="true">{{contentDetails.content_desc}} </p>
                        <p vd-readonly="true" v-if="contentCastList?.length"><span>{{i18n("Crew")}} :</span> {{castListCommaSeperated}}   </p>
                        <div class="after-excerpt">
                            <div class="extra-data">
                                <ul v-if="getvdoTracks?.length">
                                    <li>
                                       <span vd-readonly="true">{{subKind}} :</span>
                                        <span vd-readonly="true">{{getvdoTracks}}</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="socail-share">
                                <!--- like favourite share component -->
                                <like_favourite_share_content_four :id="$attrs['id'] +'_like_favourite_share_content_four_4'" :contentData="contentDetails" :likeReviewRatingsSettingsDataAvailable="isFetchReqd" 
                                shareVideoText="Share this video" linkText="Link" socialText="Social"/>
                                <!--- like favourite share component -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</vd-component>`,
};

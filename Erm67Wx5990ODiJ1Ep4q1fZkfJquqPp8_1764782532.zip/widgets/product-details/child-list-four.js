let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
const ChildListOne = {
    name: "ChildListFour",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
    },
    components: {
        content_hover_one,
        audio_player_one,
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
        };
    },
    watch: {
        optView(optView) {},
    },

    methods: {
        playAudioContent(contentUuid){
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                   // console.log("this.videoDuration", videoDuration);
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                   // console.log("this.videoDuration else", videoDuration);
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },
    },

    template: `
    <div class="single-course course-box border-bottom " v-for="(childObj,i) in parentContent.child_content">
    <div class="row gx-3">
        <div class="col-auto">
            <input class="form-check-input" type="radio" name="courseOne" id="courseOne" disabled checked>
        </div>
        <div class="col">
            <p>{{childObj.content_name}}</p>
            <div class="d-flex align-items-center">
                <button class="play-course">
                <a :href="'/content/'+childObj.content_permalink"> <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9C16.4955 13.1403 13.1403 16.4955 9 16.5ZM3 9.129C3.03549 12.4299 5.73083 15.0822 9.0319 15.0645C12.333 15.0467 14.9997 12.3656 14.9997 9.0645C14.9997 5.76338 12.333 3.08233 9.0319 3.0645C5.73083 3.04684 3.03549 5.69907 3 9V9.129ZM7.5 12.375V5.625L12 9L7.5 12.375Z" fill="#555578"/>
                    </svg> </a>                                               
                </button>
                <span v-if="childObj?.video_details.duration">{{timeFormating(childObj?.video_details.duration,childObj?.content_asset_type)}}</span>
            </div>
        </div>
    </div>
</div>




<audio_player_one :root_url="$attrs['root_url']" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
      `,
};
export default ChildListOne;

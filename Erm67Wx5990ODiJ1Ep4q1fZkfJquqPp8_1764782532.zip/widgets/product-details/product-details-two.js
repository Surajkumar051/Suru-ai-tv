let { getContentSettingsDetails,getContentCastList, getContentDetails, getChildDetails, isAuthorizedContent, getPlayerParentPermarlinkDetails, getVideoDetails, getLocation, categorizedPermalink, likeDislike, makeContentFavorite, getContentFavoriteStatus } = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:like_favourite_share_content_two}=await import(window.importLocalJs('widgets/like-favourite-share-content/like-favourite-share-content-two.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));//ER-95176
export default {
    name: 'product_details_two',
    components: {
        like_favourite_share_content_two
    },
    data() {
        return {
            contentCastList: [],
            contentDetails: {},
            isFetchReqd: false,
        }
    },
    mounted() {
    },
    methods: {
        i18n,
        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails = res.data.data.contentList.content_list[0];
                }
            });
        },
        getCastcrewDetails(contentUuid) {
            getContentCastList(contentUuid).then((res) => {
                // JsLoadingOverlay.hide();
                if (res.data.code == 200 && res.data.data !== null &&
                    res.data.data.contentList.content_list?.length > 0) {
                    this.contentCastList = res.data.data.contentList.content_list[0].cast_details;
                }
            });
        }
    },
    props: {
        contentObj: Object,
        contentUuid: "",
        isPlaylist: 0

    },
    watch: {

        contentObj(contentObj) {
            this.contentDetails = contentObj;
            this.getCastcrewDetails(contentObj.content_uuid);
            this.isFetchReqd = true;
        },
        contentUuid(contentUuid) {
            console.log("pithan contentUuid--------" + contentUuid);
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getCastcrewDetails(contentUuid);

        },
    },
    computed: {
        castListCommaSeperated() {
            let castNames = "";
            this.contentCastList.forEach((cast, index) => {
                if (castNames == "") {
                    castNames += cast.cast_name;
                } else {
                    castNames += ", " + cast.cast_name;
                }
            });

            return castNames;
        },
    },
    template: `<vd-component class="vd product-details-two" type="product-details-two">
    <section class="videocontent-descption">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 colsm-12 col-md-12 col-lg-12">
                    <div class="video-data">
                        <h1 vd-readonly="true">{{contentDetails.content_name}}</h1>
                        <!--- like favourite share component -->
                        <like_favourite_share_content_two :id="$attrs['id'] +'_like_favourite_share_content_two_1'"
                            :contentData="contentDetails" :likeReviewRatingsSettingsDataAvailable="isFetchReqd"
                            shareVideoText="Share this video" linkText="Link" socialText="Social" />
                        <!--- like favourite share component -->

                        <p vd-readonly="true" >{{contentDetails.content_desc}} </p>
                        <p vd-readonly="true" v-if="contentCastList?.length"><span>{{i18n("Crew")}} :</span>
                            {{castListCommaSeperated}} </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</vd-component>`,
}

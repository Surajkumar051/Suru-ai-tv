let { getContentSettingsDetails, getContentDetails, getChildDetails, categorizedPermalink, likeDislike, makeContentFavorite, getContentFavoriteStatus } = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {default:child_list_eight}=await import(window.importLocalJs('widgets/child-list/child-list-eight.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));

export default {
    name: 'product_details_twelve',
    components: {
        child_list_eight
    },
    data() {
        return {
            contentDetails: [],
            content_readmore: '',
            contentlevel: 0,
            pointerevents: 'none',
            seasonCount: false,
            noOfSession: 0,
            bannerImg: '',
            contentUuid: localStorage.getItem("contentId"),
            seasonLevelData: [],
            count: [],
            child_contentDetails: [],
            optNo: 0,
            isLogedIn: JSON.parse(localStorage.getItem('isloggedin')),
            isAuthorized: null,
            childContentUuid: '',
            nestedContentplayBtnShow: false,
            showAddToQueueBtn: false,
            // audio content
            audioUuid: '',
            uniqueId: '',
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: '',
            user_Info: JSON.parse(localStorage.getItem('user')), // Get user_uuid from  local storage 
            contentParentUuid: '',
            stickyAudioData: '',
            removeJs: true,
            playBackRatesValue: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            isHidden: false,
            copiedText: false,
            contentName: '',
            videoDuration: '',
            audioDuration: '',
            like_status: '',
            dislike_status: '',
            count: 0,
            userLiked: false,
            userDisliked: false,
            descLength: '',
            no_of_child_content: '',
            contentGroupDetails: Object,
            selectedLabel1Content: Object,
            isFavourite: 0,
            isFavouriteEnabled: false,
            likeReviewRatingsSettings: {
                is_like_enabled: false,
                is_dislike_enabled: false,
                is_like_count_enabled: false,
                is_dislike_count_enabled: false
            },
            contentReadMoreObj: {},
            level1PageNo: 1,
            level1PerPage: 5,
            isNextLevel1PageExist: true,
            level2PageNo: 1,
            level2PerPage: 12,
            isNextLevel2PageExist: true,
            isPerent: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true
        }
    },
    created() {
         JsLoadingOverlay.show();

    },
    beforeUpdate() {
        $('.owl-product').trigger('destroy.owl.carousel');
        $('.owl-product').html($('.owl-product').find('.owl-stage-outer').html()).removeClass('owl-loaded');
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },

    props: {
        isAuth: String
    },

    created() {
        scrollLoad = true; //@ER: 74207
        this.loadMore();
    },
    mounted() {
        this.enduserURL = window.location.origin + '/';
        this.baseURL = getBaseUrl();
        this.optNo = 0;
        console.log("Pithan-----", this.contentPermalink);

        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    setTimeout(() => {
                        JsLoadingOverlay.hide();

                    }, 2000);
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if ((content.permalink_type == "content" || content.is_playlist == 1) && content?.content_permalink == this.contentPermalink) return true;
                                else return false;
                    })
                    if (findContentParentIndex > -1) {
                        let contentObj = res.data.data.contentList.content_list[findContentParentIndex]
                        this.contentParentUuid = contentObj.content_uuid;
                        this.isPerent = contentObj.is_parent;
                        console.log(this.contentParentUuid + "----1----", contentObj.is_playlist);
                        this.getContentDetailsData(this.contentParentUuid, contentObj.is_playlist);
                        this.getContentSettingsDetails(contentObj.structure_uuid);
                        // this.getContentFavouriteAction(contentObj.content_uuid);



                    }
                } else {
                    window.location.href = "/404";
                }
            });

        }


    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
        closeAllSelect(elmnt) {
            /*a function that will close all select boxes in the document,
            except the current select box:*/
            var x, y, i, xl, yl, arrNo = [];
            x = document.getElementsByClassName("select-items");
            y = document.getElementsByClassName("select-selected");
            xl = x.length;
            yl = y.length;
            for (i = 0; i < yl; i++) {
                if (elmnt == y[i]) {
                    arrNo.push(i)
                } else {
                    y[i].classList.remove("select-arrow-active");
                }
            }
            for (i = 0; i < xl; i++) {
                if (arrNo.indexOf(i)) {
                    x[i].classList.add("select-hide");
                }
            }

        },
        generateCustomDropdown() {
            console.log("sadasdasdas");
            var x, i, j, l, ll, selElmnt, a, b, c;
            /*look for any elements with the class "custom-select":*/
            x = document.getElementsByClassName("custom-select");
            l = x.length;
            for (i = 0; i < l; i++) {
                selElmnt = x[i].getElementsByTagName("select")[0];
                console.log("selElmnt---", selElmnt);
                ll = selElmnt.length;
                /*for each element, create a new DIV that will act as the selected item:*/
                a = document.createElement("DIV");
                a.setAttribute("class", "select-selected");
                a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
                x[i].appendChild(a);
                /*for each element, create a new DIV that will contain the option list:*/
                b = document.createElement("DIV");
                b.setAttribute("class", "select-items select-hide");
                for (j = 0; j < ll; j++) {
                    /*for each option in the original select element,
                    create a new DIV that will act as an option item:*/
                    c = document.createElement("DIV");
                    c.innerHTML = selElmnt.options[j].innerHTML;
                    $('<input>', {
                        type: 'hidden',
                        class: 'hello',
                        value: '#_#' + selElmnt.options[j].value + '#_#'
                    }).appendTo(c);
                    let ths = this;
                    c.addEventListener("click", function(e) {
                        /*when an item is clicked, update the original select box,
                        and the selected item:*/
                        var y, i, k, s, h, sl, yl;
                        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                        sl = s.length;
                        h = this.parentNode.previousSibling;
                        for (i = 0; i < sl; i++) {
                            if (s.options[i].value == this.innerHTML.split('#_#')[1]) {
                                s.selectedIndex = i;
                                h.innerHTML = this.innerHTML;
                                y = this.parentNode.getElementsByClassName("same-as-selected");
                                yl = y.length;
                                for (k = 0; k < yl; k++) {
                                    y[k].removeAttribute("class");
                                }
                                this.setAttribute("class", "same-as-selected");
                                break;
                            }
                        }

                        ths.selectL1Dropdown();
                    });
                    b.appendChild(c);
                }
                x[i].appendChild(b);
                let ths = this;
                a.addEventListener("click", function(e) {
                    /*when the select box is clicked, close any other select boxes,
                    and open/close the current select box:*/
                    e.stopPropagation();
                    ths.closeAllSelect(this);



                    this.nextSibling.classList.toggle("select-hide");
                    this.classList.toggle("select-arrow-active");
                });
            }

            /*if the user clicks anywhere outside the select box,
            then close all select boxes:*/
            document.addEventListener("click", this.closeAllSelect);


        },
        likeEvent(event, likeStatus, content_uuid) {
            if (this.isLogedIn) {

                const param = {
                    "app_token": ":app_token",
                    "product_key": ":product_key",
                    "store_key": ":store_key",
                    "end_user_uuid": ":me",
                    "content_uuid": content_uuid,
                    "like_status": likeStatus
                }
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(param.content_uuid, this.contentDetails.is_playlist);
                        // this.contentDetails.like_status = 1;
                        //  this.contentDetails.total_likes_count = this.contentDetails.total_likes_count+1;
                    }
                })
            } else if (!this.isLogedIn) {
                window.location.href = "/sign-up";
            }
        },
        dislikeEvent(event, dislikeStatus, content_uuid) {
            if (this.isLogedIn) {
                const param = {
                    "app_token": ":app_token",
                    "product_key": ":product_key",
                    "store_key": ":store_key",
                    "end_user_uuid": ":me",
                    "content_uuid": content_uuid,
                    "like_status": dislikeStatus
                }
                likeDislike(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentDetailsData(param.content_uuid, this.contentDetails.is_playlist);

                        // this.contentDetails.total_dislikes_count++;
                        // if(this.contentDetails.like_status == 1){
                        //     this.contentDetails.total_likes_count--;
                        // }
                        // this.contentDetails.like_status = 0;
                    }
                })
            } else {
                window.location.href = "/sign-up";
            }
        },
        favouriteEvent(contentDetails) {
            if (this.isLogedIn) {
                const param = {
                    "app_token": ":app_token",
                    "product_key": ":product_key",
                    "store_key": ":store_key",
                    "end_user_uuid": ":me",
                    "content_uuid": contentDetails.content_uuid,
                    "is_favourite": this.isFavourite == 0 ? 1 : 0,
                }
                makeContentFavorite(param).then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        this.getContentFavouriteAction(contentDetails.content_uuid);
                    }
                })
            } else {
                window.location.href = "/sign-up";
            }
        },
        getContentFavouriteAction(contentUuid) {
            getContentFavoriteStatus(contentUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.isFavourite = res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
                } else {
                    this.isFavourite = 0;
                }
            });
        },
        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                console.log("2----", res);
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails = res.data.data.contentList.content_list[0];
                    this.descLength = this.contentDetails.content_desc.length;
                    this.content_readmore = this.contentDetails.content_desc.substring(0, 120);
                    this.noDefaultImage = res.data.data.contentList.content_list[0].no_image_available_url;
                    if (this.contentDetails.banners.website != null && this.contentDetails.banners.website.file_url !== '') {
                        this.bannerImg = this.contentDetails.banners.website[0].file_url;
                    } else {
                        this.bannerImg = this.getRootUrl()+"img/video-after-login-banner.png"; //res.data.data.contentList.content_list[0].no_image_available_url;
                    }
                    // this.castDetails = res.data.data.contentList.content_list[0];
                    this.no_of_child_content = res.data.data.contentList.content_list[0].no_of_child_content;


                    res.data.data.contentList.content_list.forEach(ele => {
                        if (ele.video_details !== null && ele.content_asset_type === 1) {
                            const vDuration = ele.video_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                        if (ele.audio_details !== null && ele.content_asset_type === 2) {
                            const aDuration = ele.audio_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                    });

                }
            });
        },
        getChildDetails(contentParentUuid, pageNo, perPage, onScroll) {
            this.isNextLevel1PageExist = false;
            getChildDetails(contentParentUuid, pageNo, perPage).then((res) => {
                //console.log("child_contentDetails res", res.data.data.childList.child_list)
                // this.child_contentDetails = res.data.data.childList.child_list;
                if (onScroll && res.data.data.childList.child_list.child_content != null) {
                    this.isNextLevel1PageExist = true;
                    this.child_contentDetails.child_content.push(...res.data.data.childList.child_list.child_content);
                } else if (!onScroll && res.data.data.childList.child_list.child_content != null) {
                    this.isNextLevel1PageExist = true;
                    this.child_contentDetails = res.data.data.childList.child_list;
                }

                if (this.seasonLevelData) {
                    this.seasonLevelData = res.data.data.childList.child_list.child_content;
                    this.getChildContentDetails(this.child_contentDetails);
                    // if (this.child_contentDetails.is_parent) {
                    //     this.getPlayerPermalink(contentParentUuid);
                    // }

                }
            });


        },



        getChildContentDetails(content) {
            console.log("rupin content", content);
            if (content && content.child_content && content.child_content.length > 0) {
                let parentContents = content.child_content.filter(function(con) { return con.no_of_child_content > 0 });
                for (let i = 0; i < content.child_content.length; i++) {
                    if (content.child_content[i].no_of_child_content > 0 &&
                        (content.child_content[i] ?.child_content == null || content.child_content[i] ?.child_content == undefined)
                    ) {
                        getChildDetails(content.child_content[i].content_uuid, this.level2PageNo, this.level2PerPage).then((result) => {
                            content.child_content[i].child_content = result.data.data.childList.child_list.child_content;
                            if (i == 0) {
                                this.selectedLabel1Content = result.data.data.childList.child_list;
                            }
                            if (i == parentContents.length - 1) {
                                this.generateCustomDropdown();
                            }
                        });

                    }


                }
            }
        },
        getEpisodeData(episodeData, index) {
            return episodeData[index];
        },
        showGridListView(optNum) {
            this.optNo = optNum;
        },
        copyURL() {
            const el = document.createElement('textarea');
            el.value = window.location.href;
            el.setAttribute('readonly', '');
            el.style.position = 'absolute';
            el.style.left = '-9999px';
            document.body.appendChild(el);
            const selected = document.getSelection().rangeCount > 0 ? document.getSelection().getRangeAt(0) : false;
            el.select();
            document.execCommand('copy');
            document.body.removeChild(el);
            if (selected) {
                document.getSelection().removeAllRanges();
                document.getSelection().addRange(selected);
            }
            this.copiedText = true;
        },
        openSocialShare(type) {
            let sharing_link = window.location.href;
            if (type === 'facebook') {
                window.open(`https://www.facebook.com/sharer/sharer.php?u=${sharing_link}`,
                    '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
            } else if (type === 'twitter') {
                window.open(`https://twitter.com/share?text=${this.contentDetails.content_name}&url=${window.location.href}`, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
            } else if (type === 'linkedin') {
                window.open(`
                https://www.linkedin.com/shareArticle?mini=true&url=${sharing_link}&title=${this.contentDetails.content_name}&source={LinkedIn}`)
            } else if (type === 'pinterest') {
                window.open(`http://pinterest.com/pin/create/button/?url=${sharing_link}&description=${this.contentDetails.content_desc}`)
            } else if (type === 'tumblr') {
                window.open(`http://www.tumblr.com/share/link?url=${sharing_link}`)
            }
            // else if (type === 'link') {
            //     this.copyMessage(window.location.href);
            //     // this.toastr.info('Link copied to clipboard');
            // }
        },
        initMultipleSelect() {
            $('#l1ContentDropdown').selectpicker();
            $('#l1ContentDropdown').selectpicker('refresh');
        },
        /**
         * Used for copy the message to the system clip board.
         * @param val : contain the string value which need to be copy.
         */
        copyMessage(val) {
            const selBox = document.createElement('textarea');
            selBox.style.position = 'fixed';
            selBox.style.left = '0';
            selBox.style.top = '0';
            selBox.style.opacity = '0';
            selBox.value = val;
            document.body.appendChild(selBox);
            selBox.focus();
            selBox.select();
            document.execCommand('copy');
            document.body.removeChild(selBox);
        },

        closePopup() {
            this.isHidden = false;
            this.copiedText = false;
        },
        openSocialSharing() {
            this.isHidden = true;
            this.pageLink = window.location.href;
        },

        getContentSettingsDetails(structureUuid) {
            getContentSettingsDetails(structureUuid).then((res) => {
                if (res.data.code == 200) {
                    if (res.data.data.contentSettings.level_structures != null && res.data.data.contentSettings.level_structures.length > 0) {
                        this.contentGroupDetails = res.data.data.contentSettings.level_structures[0];
                        this.contentGroupDetails.level_structure_detail = this.contentGroupDetails.level_structure_detail.sort((a, b) => {
                                    let fa = a.level,
                                        fb = b.level;
                                    if (fa < fb) {
                                return -1
                                    }
                                    if (fa > fb) {
                                return 1
                                    }
                            return 0
                        });
                                }
                    this.isFavouriteEnabled = (res.data.data.contentSettings.content_favourite_settings != null) ? res.data.data.contentSettings.content_favourite_settings ?.is_enabled : false;
                    if (res.data.data.contentSettings.content_like_and_review_settings != null) {
                        this.likeReviewRatingsSettings = res.data.data.contentSettings.content_like_and_review_settings;
                    }
                    if (this.isPerent == 1) {
                        console.log("Rijun----", this.contentGroupDetails)
                        if (this.contentGroupDetails.display_style == 'DISPLAY_STYLE_DROPDOWN' || this.contentGroupDetails.display_style == 'DISPLAY_STYLE_TAB') {
                            this.level1PageNo = -100;
                        }
                        this.getChildDetails(this.contentParentUuid, this.level1PageNo, this.level1PerPage, false);
                    }

                }
            });
        },

        selectL1Dropdown() {
            let selectedContentUuid = $('.custom-select .select-items .same-as-selected input').val().replaceAll('#_#', '');
            this.selectedLabel1Content = this.child_contentDetails ?.child_content ?.filter(l1Obj => l1Obj.content_uuid == selectedContentUuid)[0];
        },



        timeFormating(duration, contentType) {

            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration.replace(':', 'm ').concat('s');
                    console.log("this.videoDuration", videoDuration);

                } else {
                    videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                    console.log("this.videoDuration else", videoDuration);

                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, '');
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration.replace(':', 'm ').concat('s');
                } else {
                    var audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                }
                return audioDuration;
            }
        },

        loadMore() {
            //  window.onscroll = () => {

            //     console.log("Pithan deb ----"+$('#childContainer').height() )
            //  }
            let ths = this;
            window.addEventListener("scroll", function() {
                //ths.myFunc();
                // console.log($('#childListDiv').height()+"-----Pithan deb ----"+$('#childContainer').height() )

                let scrollPos = document.documentElement.scrollTop + document.documentElement.clientHeight;
                //console.log(ths.contentParentUuid+"------Debarghya hello----"+$('#childContainer').outerHeight(true)+"---"+scrollPos+"--------------"+document.documentElement.scrollTop +"---"+ document.documentElement.clientHeight+"----"+document.documentElement.scrollHeight);
                let nextLevelCount ;
                if(ths.child_contentDetails.content_level == 0){
                    nextLevelCount = ths.child_contentDetails?.level_one_count;
                }else{
                    nextLevelCount = ths.child_contentDetails?.level_two_count;
                }

                if ($('#childContainer').height() < scrollPos && ths.isNextLevel1PageExist &&
                    nextLevelCount  > ths.child_contentDetails ?.child_content ?.length && scrollLoad) {
                    console.log("Debarghya called");
                    ths.getChildDetails(ths.contentParentUuid, ++ths.level1PageNo, ths.level1PerPage, true);
                }
            }, false);
        },
        myFunc() {
            let scrollPos = document.documentElement.scrollTop + document.documentElement.clientHeight;
            if ($('#childContainer').height() < scrollPos) {

            }
            //console.log("------Pithan hello----"+$('#childContainer').height())
            console.log("------Pithan hello----" + $('#childContainer').height() + "---" + document.documentElement.scrollTop + "---" + document.documentElement.clientHeight + "----" + document.documentElement.scrollHeight);

        },
        setDataReadMorePop(contentObj) {
            this.contentReadMoreObj = contentObj;
            console.log("debarghya", this.contentReadMoreObj)
        },

    },
    computed: {
        level0Name() {
            return this.contentGroupDetails.level_structure_detail[0] ?.level_name;
        },
        level1Name() {
            return (this.contentGroupDetails.level_structure_detail != undefined) ? this.contentGroupDetails.level_structure_detail[1] ?.level_name : "Seasons";
        },
        level2Name() {
            return (this.contentGroupDetails.allowed_level == 3) ? this.contentGroupDetails.level_structure_detail[2].level_name : "";
        },
    },
    watch: {
        optNo(optNo) {

        }
    },
    template: `
    <vd-component class="vd product-details-twelve" type="product-details-twelve">

    <section class="season-content" v-if="contentDetails.is_playlist==0 && child_contentDetails != null && child_contentDetails?.child_content?.length>0">

        <!--DISPLAY_STYLE_HEADING-->
        <div class="slide-wrapper" id="childContainer" 
            v-if="contentGroupDetails?.display_style=='DISPLAY_STYLE_HEADING' && 
            contentDetails?.content_level < (contentGroupDetails?.allowed_level-2) && child_contentDetails?.child_content?.length>0">
            <div class="container-fluid" v-for="(seasonLevel,i) in child_contentDetails.child_content" :key="i">
                <div class="row" v-if="seasonLevel?.child_content?.length>0">
                    <div class="season-heading col-sm-6 text-left mb-4 mt-4">
                        <h2>{{seasonLevel.content_name}}</h2>
                    </div>
                    <!-- <div class="episode-heading">
                        <h3 class="sub-heading">All {{contentDetails.level_two_count>1?level2Name+'s':level2Name}}</h3>
                        <span class="view-all" v-if="seasonLevel?.no_of_child_content>12">
                            <a class="callByAjax" :href="'/child-details/'+seasonLevel?.content_permalink">
                                <vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param>
                            </a>
                        </span>
                    </div> -->
                </div>
                <child_list_eight id="chiildListDiv" v-if="seasonLevel?.child_content?.length>0" :optView="optNo" 
                    :downloadBtnText="i18n($attrs['label23'])"
                    :openBtnText="i18n($attrs['label24'])"
                    :parentContent="seasonLevel" 
                    :contentGroupDetails="contentGroupDetails" 
                    :key="child_contentDetails?.content_uuid" 
                    :playNowBtnTxt="i18n($attrs['label12'])" 
                    :viewTrailerBtnTxt="i18n($attrs['label13'])" 
                    :playAllBtnTxt="i18n($attrs['label19'])"  
                    :watchNowBtnTxt="i18n($attrs['label3'])" 
                    :isLogedIn="isLogedIn" 
                    :freeContentText="i18n($attrs['label22'])" 
                    @set-data-read-more="setDataReadMorePop"
                />
            </div>
        </div>

        <!--DISPLAY_STYLE_DROPDOWN-->
        <div class="slide-wrapper" id="childContainer" 
            v-if="contentGroupDetails?.display_style=='DISPLAY_STYLE_DROPDOWN' && 
            contentDetails?.content_level < (contentGroupDetails?.allowed_level-2) && child_contentDetails?.child_content?.length>0">
            <div class="container-fluid">
                <div class="row season-heading">
                    <div class="col-sm-6 text-left mb-4 mt-4">
                        <h2>{{selectedLabel1Content?.content_name}}</h2>
                    </div>
                    <div class="col-sm-6 mb-4 mt-4">
                        <div class="custom-select">
                            <select id="l1ContentDropdown" @change="selectL1Dropdown">
                                <option v-for="(seasonLevel,i) in child_contentDetails?.child_content" :key="i" :value="seasonLevel?.content_uuid">{{seasonLevel?.content_name}}</option>
                            </select>
                        </div>
                    </div>
                    <!-- <div class="episode-heading">
                        <h3 class="sub-heading">{{level2Name}} ({{selectedLabel1Content?.no_of_child_content}})</h3>
                        <span class="view-all" v-if="selectedLabel1Content?.no_of_child_content>12">
                            <a class="callByAjax" :href="'/child-details/'+selectedLabel1Content?.content_permalink">
                                <vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param>
                            </a>
                        </span>
                    </div> -->
                </div>
                <child_list_eight :optView="optNo" :parentContent="selectedLabel1Content" 
                    :contentGroupDetails="contentGroupDetails" :key="seasonLevel?.content_uuid" 
                    :playNowBtnTxt="i18n($attrs['label12'])" 
                    :viewTrailerBtnTxt="i18n($attrs['label13'])" 
                    :playAllBtnTxt="i18n($attrs['label19'])" 
                    :watchNowBtnTxt="i18n($attrs['label3'])"
                    :isLogedIn="isLogedIn" 
                    :freeContentText="i18n($attrs['label22'])"
                    @set-data-read-more="setDataReadMorePop"
                    :downloadBtnText="i18n($attrs['label23'])"
                    :openBtnText="i18n($attrs['label24'])"
                />
            </div>
        </div>

        <!--DISPLAY_STYLE_TAB-->
        <div class="slide-wrapper" id="childContainer" 
            v-if="contentGroupDetails?.display_style=='DISPLAY_STYLE_TAB' && 
            contentDetails?.content_level < (contentGroupDetails?.allowed_level-2) && child_contentDetails?.child_content?.length>0">
            <div class="tabviews">
                <div class="season-heading col-sm-12 text-left mb-4 mt-4">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" v-for="(seasonLevel,i) in child_contentDetails?.child_content" :key="i">
                            <a class="nav-link" :class="i==0?'active':''" id="Season1-tab" data-toggle="tab" :href="'#Season_'+i" role="tab" aria-controls="home" aria-selected="true">{{seasonLevel?.content_name}}</a>
                        </li>
                    </ul>
                </div>
                <div class="container-fluid tab-content" id="myTabContent">
                    <div class="tab-pane fade show" :class="i==0?'active':''" v-for="(seasonLevel,i) in child_contentDetails?.child_content" :key="i" :id="'Season_'+i" role="tabpanel" aria-labelledby="Season1-tab">
                        <div class="row" v-if="seasonLevel?.child_content?.length>0">
                            <!-- <div class="episode-heading">
                                <h3 class="sub-heading">All {{contentDetails.level_two_count>1?level2Name+'s':level2Name}}</h3>
                                <span class="view-all" v-if="seasonLevel?.no_of_child_content>12">
                                    <a class="callByAjax" :href="'/child-details/'+seasonLevel?.content_permalink">
                                        <vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param>
                                    </a>
                                </span>
                            </div> -->
                        </div>
                        <div>
                            <child_list_eight id="chiildListDiv" v-if="seasonLevel?.child_content?.length>0" :optView="optNo"
                                :downloadBtnText="i18n($attrs['label23'])"
                                :openBtnText="i18n($attrs['label24'])"
                                :parentContent="seasonLevel"
                                :key="child_contentDetails?.content_uuid"
                                :playNowBtnTxt="i18n($attrs['label12'])"
                                :viewTrailerBtnTxt="i18n($attrs['label13'])"
                                :playAllBtnTxt="i18n($attrs['label19'])"
                                :watchNowBtnTxt="i18n($attrs['label3'])"
                                :isLogedIn="isLogedIn"
                                :freeContentText="i18n($attrs['label22'])" 
                                @set-data-read-more="setDataReadMorePop"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--DISPLAY_STYLE_PAGE-->
        <div class="slide-wrapper" id="childContainer" 
            v-if="contentGroupDetails?.display_style=='DISPLAY_STYLE_PAGE' && 
            (contentGroupDetails?.allowed_level==2?(contentDetails?.content_level  < (contentGroupDetails?.allowed_level-1)):(contentDetails?.content_level  < (contentGroupDetails?.allowed_level-2))) && child_contentDetails.child_content?.length>0">
            <div class="container-fluid">
                <div class="row" v-show="child_contentDetails.child_content !== null">
                    <div class="season-heading col-sm-6 text-left mb-4 mt-4">
                        <h2><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param>&nbsp;{{contentDetails.content_level==0? level1Name: level2Name}}</h2>
                    </div>
                </div>
                <child_list_eight :optView="optNo" :parentContent="child_contentDetails" 
                    :contentGroupDetails="contentGroupDetails" 
                    :key="child_contentDetails?.content_uuid" 
                    :playNowBtnTxt="i18n($attrs['label12'])" 
                    :viewTrailerBtnTxt="i18n($attrs['label13'])" 
                    :playAllBtnTxt="i18n($attrs['label19'])" 
                    :watchNowBtnTxt="i18n($attrs['label3'])"
                    :isLogedIn="isLogedIn"  
                    :freeContentText="i18n($attrs['label22'])"
                    @set-data-read-more="setDataReadMorePop"
                    :downloadBtnText="i18n($attrs['label23'])"
                    :openBtnText="i18n($attrs['label24'])"
                />
            </div>
        </div>
        <div class="slide-wrapper" id="childContainer" 
            v-if="contentGroupDetails?.display_style=='DISPLAY_STYLE_PAGE' && contentDetails?.content_level == 1 && child_contentDetails.child_content?.length>0">
            <div class="container-fluid">
                <div class="row" v-show="child_contentDetails.child_content !== null">
                    <div class="season-heading col-sm-6 text-left mb-4 mt-4">
                        <h2 v-if="contentGroupDetails?.display_style=='DISPLAY_STYLE_PAGE'" ><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param>&nbsp;{{level2Name}}</h2>
                    </div>
                </div>
                <child_list_eight :optView="optNo" :parentContent="child_contentDetails" 
                    :downloadBtnText="i18n($attrs['label23'])"
                    :openBtnText="i18n($attrs['label24'])"
                    :contentGroupDetails="contentGroupDetails" 
                    :key="child_contentDetails?.content_uuid" 
                    :playNowBtnTxt="i18n($attrs['label12'])" 
                    :viewTrailerBtnTxt="i18n($attrs['label13'])" 
                    :playAllBtnTxt="i18n($attrs['label19'])" 
                    :watchNowBtnTxt="i18n($attrs['label3'])" 
                    :isLogedIn="isLogedIn" 
                    :freeContentText="i18n($attrs['label22'])" 
                    @set-data-read-more="setDataReadMorePop"
                />
            </div>
        </div>


    </section>

    <div class="modal fade readmore-banner" id="readmoreDesc" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header flex-column">
                    <h5 class="modal-title" id="exampleModalLabel">{{contentReadMoreObj?.content_name}}</h5>
                    <h6 v-if="contentReadMoreObj?.level_one_count > 0">{{contentReadMoreObj?.level_one_count}}
                        {{level1Name}} {{contentReadMoreObj?.level_two_count>0?'|':''}}
                        {{contentReadMoreObj?.level_two_count>0?contentReadMoreObj?.level_two_count:''}}
                        {{contentReadMoreObj?.level_two_count>0?level2Name:''}}</h6>
                    <h6 v-if="contentReadMoreObj?.content_level==1 && contentReadMoreObj?.level_two_count > 0">
                        {{contentReadMoreObj?.level_two_count>0?contentReadMoreObj?.level_two_count:''}}
                        {{contentReadMoreObj?.level_two_count>0?level2Name:''}}</h6>
                    <h6 v-if="contentReadMoreObj?.video_details !== null">
                        {{timeFormating(contentReadMoreObj?.video_details?.duration,contentReadMoreObj?.content_asset_type)}}
                    </h6>
                    <h6 v-if="contentReadMoreObj?.audio_details !== null">
                        {{timeFormating(contentReadMoreObj?.audio_details?.duration,contentReadMoreObj?.content_asset_type)}}
                    </h6>
                    <h6 class="sub-heading white-color"
                        v-else-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==1 && contentDetails?.playlist_content_list?.length>0">
                        {{contentDetails?.playlist_content_list?.length}} Movies </h6>
                    <h6 class="sub-heading white-color"
                        v-else-if="contentDetails.is_playlist == 1 && contentDetails?.content_asset_type==2 && contentDetails?.playlist_content_list?.length>0">
                        {{contentDetails?.playlist_content_list?.length}} Tracks </h6>
                    <span class="close-model" data-dismiss="modal">
                        <img :src="rootUrl +'img/modalCloseCross.png'" alt="popup" class="modalCloseCross" />
                    </span>
                </div>
                <div class="modal-body">
                    <p>{{contentReadMoreObj?.content_desc}}</p>
                </div>
            </div>
        </div>
    </div>
    <div id="muvi-content-purchase1" class="modal"/>

    </vd-component>
`,
    //    inheritAttrs: false
}

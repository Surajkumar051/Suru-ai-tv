let {
    getContentSettingsDetails,
    getContentCastList,
    getContentDetails,
    getChildDetails,
    isAuthorizedContent,
    getPlayerParentPermarlinkDetails,
    getVideoDetails,
    getLocation,
    categorizedPermalink,
    likeDislike,
    makeContentFavorite,
    getContentFavoriteStatus,
} = await import(window.importAssetJs('js/webservices.js'));
let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:like_favourite_share_content_seven}=await import(window.importLocalJs('widgets/like-favourite-share-content/like-favourite-share-content-seven.js'));
export default {
    name: "product_details_ten",
    components: {
        like_favourite_share_content_seven,
    },
    data() {
        return {
            contentCastList: [],
            contentDetails: {},
            isFetchReqd: false,
        };
    },
    mounted() {},
    methods: {
        getContentDetailsData(content_uuid, isPlaylist) {
            getContentDetails(content_uuid, isPlaylist).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.contentDetails =
                        res.data.data.contentList.content_list[0];
                }
            });
        },
        getCastcrewDetails(contentUuid) {
            getContentCastList(contentUuid).then((res) => {
                // JsLoadingOverlay.hide();
                if (
                    res.data.code == 200 &&
                    res.data.data !== null &&
                    res.data.data.contentList.content_list?.length > 0
                ) {
                    this.contentCastList =
                        res.data.data.contentList.content_list[0].cast_details;
                }
            });
        },
    },
    props: {
        contentObj: Object,
        contentUuid: "",
        isPlaylist: 0,
    },
    watch: {
        contentObj(contentObj) {
            this.contentDetails = contentObj;
            this.getCastcrewDetails(contentObj.content_uuid);
            this.isFetchReqd = true;
        },
        contentUuid(contentUuid) {
            console.log("pithan contentUuid--------" + contentUuid);
            this.getContentDetailsData(contentUuid, this.isPlayList);
            this.getCastcrewDetails(contentUuid);
        },
    },
    computed: {
        castListCommaSeperated() {
            let castNames = "";
            this.contentCastList.forEach((cast, index) => {
                if (castNames == "") {
                    castNames += cast.cast_name;
                } else {
                    castNames += ", " + cast.cast_name;
                }
            });

            return castNames;
        },
    },
    template: /*html*/ `
    
<vd-component class="vd product-details-ten" type="product-details-ten">
<div class="main-content movi ">
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12">
    <div class="trending-info mt-4 pt-0 pb-4">
        <div class="row">
            <div class="col-md-9 col-12  mb-auto">
            <div class="d-md-flex">
                <h3 vd-readonly="true" class="trending-text big-title text-uppercase mt-0 fadeInLeft animated">{{contentDetails.content_name}}</h3>
            </div>
        </div>
        </div>
        <!--- like favourite share component -->
        <like_favourite_share_content_seven :id="$attrs['id'] +'_like_favourite_share_content_seven_7'" :contentData="contentDetails" :likeReviewRatingsSettingsDataAvailable="isFetchReqd" 
         shareVideoText="Share this video" linkText="Link" socialText="Social"/>
        <!--- like favourite share component -->
        
        <p vd-readonly="true">{{contentDetails.content_desc}} </p>
          <p vd-readonly="true" v-if="contentCastList?.length"><span>Crew :</span> {{castListCommaSeperated}}   </p>
      </div>
    </div>
  </div>
</div>

</div>
</vd-component>`,
};

let { analyticsContentCount } = await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: 'content_views_one',
    //props: ['content_uuid'],
    props: {
        content_uuid: String,
        isPTagDesignRequired:Boolean
        },
        template: `<vd-component class="vd content-views-one vd-no-navigation" type="content-views-one">
                        <p v-if="isShow && isPTagDesignRequired">{{contentViews}}  {{i18n('Views')}}</p>
                        <span v-else-if="isShow && !isPTagDesignRequired">{{contentViews}}  {{i18n('Views')}}</span>
                     </vd-component>`,
    data() {
        return {
            contentViews: '',
            isShow: false
        }
    },
    components: {

    },
    beforeCreate() {

    },
    async created() {

    },
    beforeMount() {
        //
    },
    async mounted() {
        console.log(this.content_uuid, 'content_uuid')
        if (this.content_uuid == '') {
            throw "content_uuid is required";
        }
        let contentCountResult = await analyticsContentCount(this.content_uuid);
        this.contentViews = contentCountResult.data.data.analyticsContentCount['total_views'].toLocaleString('en-US');
        this.isShow = true;
    },
    methods: {
        i18n
    }
}

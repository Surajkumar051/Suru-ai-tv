let { analyticsContentCount } = await import(window.importAssetJs('js/webservices.js'));
export default {
    name: "content_views_two",
    props: ["content_uuid"],
    template: `<vd-component class="vd content-views-two vd-no-navigation" type="content-views-two"><i class="fas fa-eye views"></i><span v-if="isShow">{{contentViews}} Views</span></vd-component>`,
    data() {
        return {
            contentViews: "",
            isShow: false,
        };
    },
    components: {},
    beforeCreate() {},
    async created() {},
    beforeMount() {
        //
    },
    async mounted() {
        console.log(this.content_uuid, "content_uuid");
        if (this.content_uuid == "") {
            throw "content_uuid is required";
        }
        let contentCountResult = await analyticsContentCount(this.content_uuid);
        this.contentViews =
            contentCountResult.data.data.analyticsContentCount[
                "total_views"
            ].toLocaleString("en-US");
        this.isShow = true;
    },
    methods: {},
};

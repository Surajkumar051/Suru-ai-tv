let {
    registerUser,
    getUserDetails,
    isSubscriptionEnabled,
    getSubscriptionPlans,
    getEndUserRegdLoginSetting,
    getVdConfig,
    getCountryCodes,
    sendOtp,
    resendOtp,
    validateOtp,
    getProfileList,
    getMaturityRatingsList,
    getMaturitySettingStatus,
    toAddMultipleProfile,
    toEditMultipleProfile,
    toDeleteMultipleProfile,
    toGetMultipleProfileToken,
    toGetAvatarList
} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n }=await import(window.importAssetJs('js/i18n.js'));
let {
    getRootUrl,
    getAsthuDomainUrl
} = await import(window.importAssetJs('js/web-service-url.js'));
let {
    getUserGeoLocationFromCookies,
    setUserGeoLocationOnCookies,
} = await import(window.importAssetJs('js/main.js'));

export default {
    name: "multi_profile_one",

    data() {
        return {
          //language: getLocale(),
            isMobileSignin: true,
            input: {
                first_name: "",
                last_name: "",
                user_email: "",
                password: "",
                confpassword: "",
                username1: "",
                mobile_number:"",
                otpNumber1:"",
                otpNumber2:"",
                otpNumber3:"",
                otpNumber4:""
            },
            errors: {},
            country_details:[],
            mobile_field:false,
            selTypeIndex: "",
            isFormValid: false,
            emailFieldNotValidate: false,
            passwordFieldNotValidate: false,
            confirmPwdFieldNotValidate: false,
            nameFiledNotValidate: false,
            lastnameFiledNotValidate: false,
            showPassword: false,
            showConfPassword: false,
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            countryCode: "US",
            selectedCountry:"+91",
            selectCountry:"",
            otpSettingEnabled: false,
            muviAuthEmailOptSettingList : ['3','34','35'],
            muviAuthSettingType : '',
            //languageCode:getLocale(),
            datas: [ 
              'Hello',  
              'World',  
              'GeeksforGeeks' 
            ],
            getProfileList:[],
            maturityRatings:[],
            selectedMaturitySetting:"",
            selectedMaturitySettingAlt:"",
            maturityRatingSettingsStatus: true,
            avatarList:[],
          selectedImg:'',
          selectedImgUuid:'',
          addEditMultiProfileObj : {
              "profile_name": "",
              //"avatar": "",
              "avatar_uuid": "",
              "enduser_maturity_rating_uuid": "",
              "enduser_maturity_rating_min_age":0
          },
          username_field: false,
          username:"",
          selectedProfileUUid:'',
          //selectedMinAge:0,
          selectedMinAge: null
        }
    },
    computed: {
        username() {
            return this.username;
        },

    },
    watch: {
        username(value) {
            if (value != "" && !value.length) {
                this.errors.valid = false;
                this.username_field = true;
                this.errors.username = i18n("Name field is required");
            } else if (value != "" && (value.length < 2 || value.length > 30)) {
                this.errors.valid = false;
                this.username_field = true;
                this.errors.username =
                i18n("Name should be between 2 to 30 charaters");
            } else if (value != "" &&
                !value.match("^[A-Za-zÀ-ÿ0-9-' ]*$")
            ) {
                this.errors.valid = false;
                this.username_field = true;
                this.errors.username = i18n("Please enter a valid name.");
            } else {
                this.errors.username = null;
                this.username_field = false;

            }
        }

    },
    beforeMount() {
        JsLoadingOverlay.show();
        getEndUserRegdLoginSetting().then((res) => {
            if (res.data.code == 200 && res.data.data !== null) {
                const enableMultiProfile = parseInt(
                    res.data.data.sections[0].groups[0].nodes[2].node_value
                );
                const multiProfileLimit = parseInt(
                  res.data.data.sections[0].groups[0].nodes[3].node_value
                );
                var varDiff = false;
                if(localStorage.getItem('multiprofileIdClicked')){
                  const oneday = 60 * 60 * 24 * 1000 ;
                  var newDate = new Date();
                  var diff = newDate.getTime() - new Date(JSON.parse(localStorage.getItem('multiprofileIdClicked')).selectedDate).getTime();
                  varDiff = diff > oneday ? true :false;
                }
                if (enableMultiProfile == 1 && localStorage.getItem('end_user_access_token')) {

                    if(localStorage.getItem("multiprofileIdClicked")){
              
                      if(varDiff){
                        $('#manageProfile').modal('show');
                      }
                      if(localStorage.getItem("ManageProfileMenuClicked") === "true"){
                        $('#manageProfile').addClass('mp-edit');
                        $('#manageProfile').modal('show');
                        localStorage.setItem("ManageProfileMenuClicked","false");
                      }
                    }else{
                      if(localStorage.getItem("ManageProfileMenuClicked") === "true"){
                        $('#manageProfile').addClass('mp-edit');
                        $('#manageProfile').modal('show');
                        localStorage.setItem("ManageProfileMenuClicked","false");
                      }else{
                        $('#manageProfile').modal('show');
                      }
                      
                    }
                  
                    getMaturitySettingStatus().then((res) => {
                      if (res.data.code == 200 && res.data.data !== null) {
                        let maturityRatingSettingsStatus = false;
          
                        res.data.data.sections[0].groups.forEach((group) => {
                          group.nodes.forEach((node) => {
                            if (node.node_code === "maturity_rating") {
                              const enableMaturityRatingSettings = parseInt(node.node_value || "0");
                    
                              if (enableMaturityRatingSettings === 1) {
                                maturityRatingSettingsStatus = true;
                              }
                            }
                          });
                        });
                    
                        if (!maturityRatingSettingsStatus) {
                          this.maturityRatingSettingsStatus = false;
                        } else {
                          this.maturityRatingSettingsStatus = true;
                          this.selectDropdown();
                          }
                        }
                      }
                  );
                }
            }
        });
           
    },
    updated() {
      //Workarround fix for selectpicker in Citrine Template Multiprofile modals
      $("#mpmb-Profselects-alt, #mpmb-Profselects").selectpicker("refresh");
      $('.mp-mb-btn-cancel').off('click');
      $('.mp-mb-btn-cancel').on('click', function () {
        $('#manageProfileEdit, #manageProfileAdd').modal('hide');
      });
      //Fix for edit profile modal for Citine Template
      $('#mpmb_profinput_div_maturityRating_alt button').off('click');
      $('#mpmb_profinput_div_maturityRating_alt button').on('click', function () {
        $('#mpmb_profinput_div_maturityRating_alt .dropdown-menu').toggleClass('show');
      });
  
      $('#mpmb_profinput_div_maturityRating_alt .dropdown-item').off('click');
      $('#mpmb_profinput_div_maturityRating_alt .dropdown-item').on('click', function () {
        $('#mpmb_profinput_div_maturityRating_alt .dropdown-menu').removeClass('show');
      });
      //Fix for add profile modal for Citine Template
      $('#mpmb_profinput_div_maturityRating button').off('click');
      $('#mpmb_profinput_div_maturityRating button').on('click', function () {
        $('#mpmb_profinput_div_maturityRating .dropdown-menu').toggleClass('show');
      });
  
      $('#mpmb_profinput_div_maturityRating .dropdown-item').off('click');
      $('#mpmb_profinput_div_maturityRating .dropdown-item').on('click', function () {
        $('#mpmb_profinput_div_maturityRating .dropdown-menu').removeClass('show');
      });
    },
    async mounted() {

      getProfileList().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                //console.log(res.data.data.getProfileList,"res.data.data.getProfileList");
              if(res.data.data.getProfileList.length >= 1){

                this.getProfileList = res.data.data.getProfileList;
                //console.log(this.getProfileList,"res.data.data.getProfileList");
              }
            }
        });
        toGetAvatarList().then((res) => {
          if (res.status == 200) {
            if(res.data.data.avatartList.length >= 1){
              this.avatarList = res.data.data.avatartList;
              //console.log(this.avatarList,"res.data.data.avatarList");
              }
            }
        });
        // if(this.maturityRatingSettingsStatus){
        //   this.selectDropdown();  
        // }
      
        $(".mpmb-profile-add").click(function(){
          $('#manageProfile').modal('hide');
          setTimeout(() => {
            $("body").addClass('modal-open')
            $("body").css('padding-right','0');
            $('#manageProfileAdd').modal('show');
        }, 500);
      });
      $("#btn-done-manageProf").click(function(){
        $('#manageProfile').removeClass('mp-edit');
    });

      $("body").on('click', '#test', function () {
        $('#manageProfile').modal('hide');
        setTimeout(() => {
          $("body").addClass('modal-open')
          $("body").css('padding-right','0');
          $('#manageProfileEdit').modal('show');
      }, 500); 
    });

      $(".mpmbProf-selects").click(function(){
        setTimeout(() => {
          $("body").addClass('modal-open')
          $("body").css('padding-right','0');
          $('#manageProfileRestrict').modal('show');
      
      }, 500);
      });
      $(".open-editProfImg").click(function(){
        $('#manageProfileEdit').modal('hide');
        $("#btn-done-chooseProfImg").removeClass("from-addprof");
        $("#btn-done-chooseProfImg").addClass("from-editprof");
        setTimeout(() => {
          $("body").addClass('modal-open')
          $("body").css('padding-right','0');
          $('#manageProfile-chooseImg').modal('show');
      }, 500);
        
      })
      $(".open-addProfImg").click(function(){
        $('#manageProfileAdd').modal('hide');
        $("#btn-done-chooseProfImg").removeClass("from-editprof");
        $("#btn-done-chooseProfImg").addClass("from-addprof");
        setTimeout(() => {
          $("body").addClass('modal-open')
          $("body").css('padding-right','0');
          $('#manageProfile-chooseImg').modal('show');
      }, 500);
      })
      $("#btn-done-chooseProfImg").click(function(){
        $('#manageProfile-chooseImg').modal('hide');
        setTimeout(() => {
          $("body").addClass('modal-open')
          $("body").css('padding-right','0');
          if($(this).hasClass("from-editprof")){
            $('#manageProfileEdit').modal('show');
          }else{
            $('#manageProfileAdd').modal('show');
          }
      
      }, 500);
    });
    $(".open-addProfImg").click(function(){
      $('#manageProfileAdd').modal('hide');
      $("#btn-done-chooseProfImg").removeClass("from-editprof");
      $("#btn-done-chooseProfImg").addClass("from-addprof");
      setTimeout(() => {
        $("body").addClass('modal-open')
        $("body").css('padding-right','0');
        $('#manageProfile-chooseImg').modal('show');
    }, 500);
    });
    $(".open-editProfImg").click(function(){
      $('#manageProfileEdit').modal('hide');
      $("#btn-done-chooseProfImg").removeClass("from-addprof");
      $("#btn-done-chooseProfImg").addClass("from-editprof");
      setTimeout(() => {
        $("body").addClass('modal-open')
        $("body").css('padding-right','0');
        $('#manageProfile-chooseImg').modal('show');
    }, 500);
      
    })
    $(".open-addProfImg").click(function(){
      $('#manageProfileAdd').modal('hide');
      $("#btn-done-chooseProfImg").removeClass("from-editprof");
      $("#btn-done-chooseProfImg").addClass("from-addprof");
      setTimeout(() => {
        $("body").addClass('modal-open')
        $("body").css('padding-right','0');
        $('#manageProfile-chooseImg').modal('show');
    }, 500);
    })
    $("#btn-done-chooseProfImg").click(function(){
      $('#manageProfile-chooseImg').modal('hide');
      setTimeout(() => {
        $("body").addClass('modal-open')
        $("body").css('padding-right','0');
        if($(this).hasClass("from-editprof")){
          $('#manageProfileEdit').modal('show');
        }else{
          $('#manageProfileAdd').modal('show');
        }
   
    }, 500);
  });

  $(".mp-mb-btn-manage").click(function(){
    $('#manageProfile').addClass('mp-edit');
});
// $("#btn-done-editProf").click(function(){
  //   $('#manageProfileEdit').modal('hide');
  //   $('#manageProfile').addClass('mp-edit');
  //   setTimeout(() => {
    //     $("body").addClass('modal-open')
    //     $("body").css('padding-right','0');
    //     $('#manageProfile').modal('show');

// }, 500);
// });
$(".mp-mb-btn-dp").click(function(){
  $('#manageProfileEdit').modal('hide');
  setTimeout(() => {
    $("body").addClass('modal-open')
    $("body").css('padding-right','0');
    $('#manageProfileDelete').modal('show');

}, 500);
});
$("#cancel-deleteProf").click(function(){
  $('#manageProfileDelete').modal('hide');
  setTimeout(() => {
    $("body").addClass('modal-open')
    $("body").css('padding-right','0');
    $('#manageProfileEdit').modal('show');

}, 500);
});
$("#btn-deleteConfirm").click(function(){
  $('#manageProfileDelete').modal('hide');
  $('#manageProfile').removeClass('mp-edit');
  setTimeout(() => {
                $('#manageProfile').modal('show');
}, 500);
})

  

    },
    methods: {
        getRootUrl,
        i18n,
        getAsthuDomainUrl,
        selectDropdown(event){
            getMaturityRatingsList().then((res) => {
                if (res.data.code == 200) {
                    this.maturityRatings = res.data.data.maturityRatings;
                    //console.log(res.data.data.maturityRatings,"response");
                    //console.log(this.country_details[0].name,"this.country_details");
                    setTimeout(() => {
                        $("#mpmb-Profselects").selectpicker();
                        $("#mpmb-Profselects-alt").selectpicker();
                    }, 1700);
                }

                
            });
             
        },
        getSelectedAvatarImg(value, value1){
          this.selectedImg = value;
          this.selectedImgUuid = value1;
          const inputs = document.querySelectorAll(".selected");
          (document.querySelectorAll(".selected")).forEach((el) => el.classList.remove("selected"));
          $('#'+value1).parent().parent().addClass("selected");
        },
        getOtpForm(){
          if (!this.username.length) {
              this.errors.valid = false;
              this.errors.username = i18n("Fullname field is required");
              this.username_field = true;
              return;
          } else {
              this.errors.username = null;
              this.username_field = false;
          }
          this.addEditMultiProfileObj.avatar = this.selectedImg;
          //console.log(this.addEditMultiProfileObj.avatar);
        },
        setSelectedAvtarImg(){
          // this.addEditMultiProfileObj.avatar = this.selectedImg;
        this.addEditMultiProfileObj.avatar_uuid = this.selectedImgUuid;
          //console.log(this.addEditMultiProfileObj.avatar);
        },
        changeUserType(e){
          let newArray = this.maturityRatings.filter(function (el) {
            return el.maturity_rating_uuid == e;
        }
        );
        //console.log(newArray);
        if(newArray.length > 0){
        this.selectedMinAge = newArray[0].min_age;
        }else{
          this.selectedMinAge = null;
        }
        },
        getMultiProfileList(){
          getProfileList().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                //console.log(res.data.data.getProfileList,"res.data.data.getProfileList");
              if(res.data.data.getProfileList.length >= 1){

                this.getProfileList = res.data.data.getProfileList;
                //console.log(this.getProfileList,"res.data.data.getProfileList");
              }
            }
        });
        },
        addMultipleProfile(){
          if (!this.username.length) {
            this.errors.valid = false;
            this.errors.username = i18n("Fullname field is required");
            this.username_field = true;
            return;
          } else {
            this.errors.username = null;
            this.username_field = false;
          }
          // this.addEditMultiProfileObj.avatar = this.selectedImg;
          // if(this.addEditMultiProfileObj.avatar == "" || this.addEditMultiProfileObj.avatar == '' || this.addEditMultiProfileObj.avatar == null){
          //   //this.addEditMultiProfileObj.avatar = "https://d3jc3vjm4t7lis.cloudfront.net/defaultContent/15759717215def6b895e137039129908/3D28C83C85544F0D9517DD2E7C7EEDAA/Image/cast/no_image_people.png";
          //   this.addEditMultiProfileObj.avatar = "https://d3jc3vjm4t7lis.cloudfront.net/15759717215def6b895e137039129908/3D28C83C85544F0D9517DD2E7C7EEDAA/il/181B28F93AAC4A41A5860D8A58A4F50F/no-avatar_2_-1707375145969.png";
          // }
          // //alert(this.addEditMultiProfileObj.avatar);
          // console.log(this.addEditMultiProfileObj.avatar);
          this.addEditMultiProfileObj.avatar_uuid = this.selectedImgUuid;
          if(this.addEditMultiProfileObj.avatar_uuid == "" || this.addEditMultiProfileObj.avatar_uuid == '' || this.addEditMultiProfileObj.avatar_uuid == null){
            //this.addEditMultiProfileObj.avatar = "https://d3jc3vjm4t7lis.cloudfront.net/defaultContent/15759717215def6b895e137039129908/3D28C83C85544F0D9517DD2E7C7EEDAA/Image/cast/no_image_people.png";
            this.addEditMultiProfileObj.avatar_uuid = null;
          }
          //alert(this.addEditMultiProfileObj.avatar);
          //console.log(this.addEditMultiProfileObj.avatar_uuid);
          this.addEditMultiProfileObj.profile_name = this.username;
          this.addEditMultiProfileObj.enduser_maturity_rating_uuid = this.selectedMaturitySetting;
          this.addEditMultiProfileObj.enduser_maturity_rating_min_age = this.selectedMinAge;
          //console.log(this.addEditMultiProfileObj);
          toAddMultipleProfile(this.addEditMultiProfileObj)
          .then((res) => {
              if (res.data.code == 200 && res.data.status == "SUCCESS") {
                  Toast.fire({
                      icon: "success",
                      title: res.data.message,
                  });
                  $('#manageProfileAdd').modal('hide');
                  $('#manageProfile').addClass('mp-edit');
                  setTimeout(() => {
                    $("body").addClass('modal-open')
                    $("body").css('padding-right','0');
                    $('#manageProfile').modal('show');
                
                  }, 500);
                  setTimeout(() => {
                    $("#mpmb-Profselects").selectpicker("refresh");
                    $("#mpmb-Profselects").selectpicker();
                    $("#mpmb-Profselects-alt").selectpicker("refresh");
                    $("#mpmb-Profselects-alt").selectpicker();
                }, 1000);
            
                    // $(".get-otp").hide();
                    // $(".verify-otp").show();
                this.resetValues();
                this.getMultiProfileList(); 
              } else {
                  Toast.fire({
                      icon: "error",
                      title: res.data.status,
                      text: res.data.message,
                  });
              $('#manageProfileAdd').modal('hide');
              setTimeout(() => {
                    $("#mpmb-Profselects").selectpicker("refresh");
                    $("#mpmb-Profselects").selectpicker();
                    $("#mpmb-Profselects-alt").selectpicker("refresh");
                    $("#mpmb-Profselects-alt").selectpicker();
                }, 1000);
                  this.resetValues();
                  this.getMultiProfileList();
              }
          })
          .catch((err) => {
              Toast.fire({
                  icon: "error",
                  title: err.response.data.status,
                  text: err.response.data.message,
              });
              this.resetValues();
              this.getMultiProfileList();
          });
        },
        editMultipleProfile(){
          if (!this.username.length) {
            this.errors.valid = false;
            this.errors.username = i18n("Fullname field is required");
            this.username_field = true;
            return;
          } else {
            this.errors.username = null;
            this.username_field = false;
          }
          // this.addEditMultiProfileObj.avatar = this.selectedImg;
          // alert(this.addEditMultiProfileObj.avatar);
          // console.log(this.addEditMultiProfileObj.avatar);
          // this.addEditMultiProfileObj.profile_name = this.username;
          // this.addEditMultiProfileObj.maturity_rating_uuid = this.selectedMaturitySetting;
          let editToBe = {
            profile_name: this.username,
            //avatar: this.selectedImg,
            avatar_uuid: this.selectedImgUuid,
            enduser_maturity_rating_uuid: this.selectedMaturitySetting,
            enduser_maturity_rating_min_age: this.selectedMinAge,
            enduser_profile_uuid:this.selectedProfileUUid
        };
          //console.log(editToBe);
          toEditMultipleProfile(editToBe)
          .then((res) => {
              if (res.data.code == 200 && res.data.status == "SUCCESS") {
                  Toast.fire({
                      icon: "success",
                      title: res.data.message,
                  });
                    $('#manageProfileEdit').modal('hide');
                    $('#manageProfile').addClass('mp-edit');
                    setTimeout(() => {
                      $("body").addClass('modal-open')
                      $("body").css('padding-right','0');
                      $('#manageProfile').modal('show');
                  
                  }, 500);
                  setTimeout(() => {
                    $("#mpmb-Profselects").selectpicker("refresh");
                    $("#mpmb-Profselects").selectpicker();
                    $("#mpmb-Profselects-alt").selectpicker("refresh");
                    $("#mpmb-Profselects-alt").selectpicker();
                }, 1000);
            
                    // $(".get-otp").hide();
                    // $(".verify-otp").show();
                if(localStorage.getItem('multiprofileIdClicked') && JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid === editToBe.enduser_profile_uuid){
                  $(".profileImages").attr("src", this.selectedImg);
                  $("#userProfileName").text(editToBe.profile_name);
                  let payload = {
                    enduser_profile_uuid:editToBe.enduser_profile_uuid,
                    enduser_maturity_rating_uuid:editToBe.enduser_maturity_rating_uuid,
                    enduser_maturity_rating_min_age:editToBe.enduser_maturity_rating_min_age
                  };
                  // if(data.enduser_maturity_rating_min_age == null || data.enduser_maturity_rating_min_age == '' || data.enduser_maturity_rating_min_age==""){
                  //   payload['enduser_maturity_rating_min_age'] = null;
                  // }else{
                  //   payload['enduser_maturity_rating_min_age']=  data.enduser_maturity_rating_min_age;
          
                  // }
                  toGetMultipleProfileToken(payload)
                  .then((res) => {
                      if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        localStorage.setItem("end_user_access_token",res.data.data.access_token);
                      } else {
                          Toast.fire({
                              icon: "error",
                              title: res.data.status,
                              text: res.data.message,
                          });
                      }
                  })
                  .catch((err) => {
                      Toast.fire({
                          icon: "error",
                          title: err.response.data.status,
                          text: err.response.data.message,
                      });
                  });
                }
                this.resetValues();
                this.getMultiProfileList(); 
              } else {
                  Toast.fire({
                      icon: "error",
                      title: res.data.status,
                      text: res.data.message,
                  });
                  $('#manageProfileEdit').modal('hide');
                  this.resetValues();
                  this.getMultiProfileList();
              }
          })
          .catch((err) => {
              Toast.fire({
                  icon: "error",
                  title: err.response.data.status,
                  text: err.response.data.message,
              });
              this.resetValues();
              this.getMultiProfileList();
          });
        },
        deleteMultiProfile(){
          let deleteToBe = {
            enduser_profile_uuid:this.selectedProfileUUid
        };
          //console.log(deleteToBe);
          toDeleteMultipleProfile(deleteToBe)
          .then((res) => {
              if (res.data.message === "Profile deleted successfully.") {
                //if (res.data.code == 200 && res.data.status == "SUCCESS") {
                  Toast.fire({
                      icon: "success",
                      title: res.data.message,
                  });
                  setTimeout(() => {
                    $("#mpmb-Profselects").selectpicker("refresh");
                    $("#mpmb-Profselects").selectpicker();
                    $("#mpmb-Profselects-alt").selectpicker("refresh");
                    $("#mpmb-Profselects-alt").selectpicker();
                }, 1000);
            
                    // $(".get-otp").hide();
                    // $(".verify-otp").show();
                if(localStorage.getItem('multiprofileIdClicked') && deleteToBe.enduser_profile_uuid === JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid){
                  localStorage.removeItem("multiprofileIdClicked");
                  $('#closeButton').css("display","none");
                  //window.location.href = '/' + this.language;
                  //$(".profileImages").attr("src", this.getRootUrl() +'img/no-avatar.png');
                  //$("#profileImages").attr("src", this.getRootUrl() +'img/no-avatar.png');
                }
                this.resetValues();
                this.getMultiProfileList(); 
              } else {
                  Toast.fire({
                      icon: "error",
                      title: res.data.status,
                      text: res.data.message,
                  });
                  //this.resetValues();
                  this.getMultiProfileList();
              }
          })
          .catch((err) => {
              Toast.fire({
                  icon: "error",
                  title: err.response.data.status,
                  text: err.response.data.message,
              });
              this.resetValues();
              this.getMultiProfileList();
          });
        },              
        showEditModal(obj){
          this.getEditProfileData(obj);
          $('#manageProfile').modal('hide');
          
          setTimeout(() => {
            $("body").addClass('modal-open')
            $("body").css('padding-right','0');
            
            $('#manageProfileEdit').modal('show');
        }, 500); 
          // this.username = obj.profile_name;
          // this.selectedMaturitySettingAlt= obj.maturity_rating_uuid;
          // this.selectedImg = obj.maturity_rating_uuid;
          //this.selectedMaturitySettingAlt = getSelectedMaturityRatingEdit;
        },
        getEditProfileData(obj){
          this.username = obj.profile_name;
          this.selectedMaturitySettingAlt= obj.enduser_maturity_rating_uuid;
          this.selectedImg = obj.avatar;
          this.selectedImgUuid = obj.avatar_uuid;
          this.selectedProfileUUid=obj.enduser_profile_uuid;
          this.selectedMaturitySetting=obj.enduser_maturity_rating_uuid;
          this.selectedMinAge = obj.enduser_maturity_rating_min_age;
        },
        resetValues(){
          this.selectedImg ='';
          this.selectedImgUuid ='';
          this.username_field = false;
          this.username ='';
          this.selectedProfileUUid ='';
          this.selectedMaturitySetting ='';
          this.selectedMaturitySettingAlt ='';
          this.addEditMultiProfileObj.profile_name ='';
          //this.addEditMultiProfileObj.avatar ='';
          this.addEditMultiProfileObj.avatar_uuid ='';
          this.addEditMultiProfileObj.enduser_maturity_rating_uuid ='';
          this.addEditMultiProfileObj.enduser_maturity_rating_min_age = 0;
          //this.selectedMinAge =0;
          this.selectedMinAge = null;
          this.errors.username = '';
      },
      changeProfilePicName(e,data){
      if(e.target.nodeName == "IMG"){
        $('#closeButton').css("display","");
        var newDate = new Date();
        data.selectedDate = newDate;
        window.localStorage.setItem("multiprofileIdClicked",JSON.stringify(data));
        this.multiprofileClickedStatus = true;
        $(".profileImages").attr("src", data.avatar);
        $("#userProfileName").text(data.profile_name);
        //this.multiprofileClickedObj = data;
        let payload = {
          enduser_profile_uuid:data.enduser_profile_uuid,
          enduser_maturity_rating_uuid:data.enduser_maturity_rating_uuid
        };
        if(data.enduser_maturity_rating_min_age == null || data.enduser_maturity_rating_min_age == '' || data.enduser_maturity_rating_min_age==""){
          payload['enduser_maturity_rating_min_age'] = null;
        }else{
          payload['enduser_maturity_rating_min_age']=  data.enduser_maturity_rating_min_age;

        }        
        toGetMultipleProfileToken(payload)
        .then((res) => {
            if (res.data.code == 200 && res.data.status == "SUCCESS") {

              localStorage.setItem("end_user_access_token",res.data.data.access_token);
              $('#manageProfile').modal('hide');
            } else {
                Toast.fire({
                    icon: "error",
                    title: res.data.status,
                    text: res.data.message,
                });
                // this.resetValues();
                // this.getMultiProfileList();
            }
            if(localStorage.getItem('isHomePageRedirect')){
              localStorage.removeItem("isHomePageRedirect");
              window.location.href = "";
            }else{
              window.location.href = '/';
            }
        })
        .catch((err) => {
            Toast.fire({
                icon: "error",
                title: err.response.data.status,
                text: err.response.data.message,
            });
            // this.resetValues();
            // this.getMultiProfileList();
        });

          //window.location.href = '/' + this.language;
         // window.location.href = "/";
        }
      }   

        
    },
    template: `
<vd-component class="vd multi-profile-one" type="multi-profile-one">
<div id="manageProfile" class="modal fade manage-Profile" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-center">
    <div class="modal-content">
      <div class="modal-body mp-body">
        <div class="mp-mb-heading mp-wwText"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></div>
        <div class="mp-mb-heading mp-headingTxt"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></div>
        <div class="mp-mb-profiles">
          <div class="mpmb-profiles" v-for="data in getProfileList">
            <div class="mpmb-profile-img-div" @click="changeProfilePicName($event,data)">
              <img class="mpmb-profile-img" :src="data.avatar" style="height: 104px;object-fit: cover;">
              <span class="mpmb-profile-edit mpmb-profile-edit-fromFirstmodal hide" @click="showEditModal(data)">
                <svg width="104" height="104" viewBox="0 0 104 104" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_4083_26320)">
                  <path d="M57 43.0003C57.2626 42.7377 57.5744 42.5293 57.9176 42.3872C58.2608 42.245 58.6286 42.1719 59 42.1719C59.3714 42.1719 59.7392 42.245 60.0824 42.3872C60.4256 42.5293 60.7374 42.7377 61 43.0003C61.2626 43.2629 61.471 43.5747 61.6131 43.9179C61.7553 44.2611 61.8284 44.6289 61.8284 45.0003C61.8284 45.3717 61.7553 45.7395 61.6131 46.0827C61.471 46.4259 61.2626 46.7377 61 47.0003L47.5 60.5003L42 62.0003L43.5 56.5003L57 43.0003Z" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </g>
                  <defs>
                  <clipPath id="clip0_4083_26320">
                  <rect width="24" height="24" fill="white" transform="translate(40 40)"/>
                  </clipPath>
                  </defs>
                  </svg>                
              </span>
            </div>
            <div class="mpmb-profile-name">{{data.profile_name}}</div>
          </div>
          <!--<div class="mpmb-profiles">
            <div class="mpmb-profile-img-div">
              <img class="mpmb-profile-img" src="img/mp-2.png">
              <span class="mpmb-profile-edit mpmb-profile-edit-fromFirstmodal hide">
                <svg width="104" height="104" viewBox="0 0 104 104" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_4083_26320)">
                  <path d="M57 43.0003C57.2626 42.7377 57.5744 42.5293 57.9176 42.3872C58.2608 42.245 58.6286 42.1719 59 42.1719C59.3714 42.1719 59.7392 42.245 60.0824 42.3872C60.4256 42.5293 60.7374 42.7377 61 43.0003C61.2626 43.2629 61.471 43.5747 61.6131 43.9179C61.7553 44.2611 61.8284 44.6289 61.8284 45.0003C61.8284 45.3717 61.7553 45.7395 61.6131 46.0827C61.471 46.4259 61.2626 46.7377 61 47.0003L47.5 60.5003L42 62.0003L43.5 56.5003L57 43.0003Z" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </g>
                  <defs>
                  <clipPath id="clip0_4083_26320">
                  <rect width="24" height="24" fill="white" transform="translate(40 40)"/>
                  </clipPath>
                  </defs>
                  </svg>               
              </span>
            </div>
            <div class="mpmb-profile-name">Morgan</div>
          </div>-->
          <div class="mpmb-profiles">
            <div class="mpmb-profile-img-div">
              <span class="mpmb-profile-add">
                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M21.3359 28V25.3333C21.3359 23.9188 20.774 22.5623 19.7738 21.5621C18.7736 20.5619 17.4171 20 16.0026 20H6.66927C5.25478 20 3.89823 20.5619 2.89803 21.5621C1.89784 22.5623 1.33594 23.9188 1.33594 25.3333V28" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M11.3333 14.6667C14.2789 14.6667 16.6667 12.2789 16.6667 9.33333C16.6667 6.38781 14.2789 4 11.3333 4C8.38781 4 6 6.38781 6 9.33333C6 12.2789 8.38781 14.6667 11.3333 14.6667Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M26.6641 10.666V18.666" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M30.6641 14.666H22.6641" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>                              
              </span>
            </div>
            <div class="mpmb-profile-name"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></div>
          </div>
        </div>
        <div class="mp-mb-btn">
          <button class="mp-mb-btn-manage"><vd-component-param type="label26" v-html="i18n($attrs['label26'])"></vd-component-param></button>
          <button class="mp-mb-btn-done" id="btn-done-manageProf"><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Manage profile End Here-->
<!-- Add profile Start Here-->  
<div id="manageProfileAdd" class="modal fade edit-Profile" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-center">
    <form @submit.prevent action="" method="post" class="needs-validation" novalidate>
      <div class="modal-content">
        <div class="modal-body mp-body">
            <div class="mp-mb-heading mp-wwText"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></div>
            <div class="mp-mb-profiles">
                <div class="mpmb-profile-img-div">
                  <!--<span class="mpmb-profile-img-div-text text-center"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>-->
                  <span class="mpmb-profile-img-div-text text-center"></span>
                <img class="mpmb-profile-img" :src="selectedImg == '' ? getRootUrl() +'img/cpa-5.png' : selectedImg" @error="getRootUrl() +'img/cpa-5.png'" style="background-color: #00000047;">
                <span class="mpmb-profile-edit open-addProfImg">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 16 16" fill="none">
                    <g clip-path="url(#clip0_4234_16488)">
                      <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                      <clipPath id="clip0_4234_16488">
                        <rect width="16" height="16" fill="white"/>
                      </clipPath>
                    </defs>
                  </svg> <vd-component-param type="label30" v-html="i18n($attrs['label30'])"></vd-component-param>               
                </span>
              </div>
              <div class="mpmb-profile-input">
                <div class="mpmb-profinput-div">
                  <span class="mpmb-profinput-lbl"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></span>
                  <input class="mpmb-profinputs vd-component-attr form-control" name="username" vd-component-attr-placeholder="label8" :placeholder=i18n($attrs['label8']) 
                  vd-component-attr-title="label8" :title=i18n($attrs['label8']) v-model="username" :class="username_field ? 'is-invalid' : ''" >
                    <template v-if="errors.username">
                      <h3 class="invalid-feedback pb-2 validation-msg">{{ errors.username }}</h3>
                    </template>
                  </div>
                <div class="mpmb-profinput-div" id="mpmb_profinput_div_maturityRating" :style="{ 'display': maturityRatingSettingsStatus == true ? '' : 'none' }">
                  <span class="mpmb-profinput-lbl"><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></span>
                  <!--<select id="mpmb-Profselects" class="selectpicker w-100 mpmb-profselects" placeholder="Select">
                    <option value="0">All Maturity Ratings</option>
                    <option value="1" >No Restriction</option>
                    <option value="2" >5+ kids</option>
                    <option value="3" >7+ Older kids</option>
                    <option value="4" >13+ Teen</option>
                    <option value="5" >16+ Young Adults</option>
                    <option value="6" >18+ Adults</option>
                  </select>-->
                  <select class="selectpicker w-100 mpmb-profselects" id="mpmb-Profselects" v-model="selectedMaturitySetting" placeholder="Select" @change="changeUserType($event.target.value)">
                    <option v-for="(maturityRating,i) in maturityRatings" :key="i" :value="maturityRating.maturity_rating_uuid" :data-subtext=" maturityRating.name">{{maturityRating.maturity_rating_name}}</option> 
                    <option :value="">No Restriction</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="mp-mb-btn">
              <button class="mp-mb-btn-cancel" data-dismiss="modal" data-bs-dismiss="modal"><vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></button>
              <button class="mp-mb-btn-done" id="btn-done-addProf" @click="addMultipleProfile" :disabled="username_field"><vd-component-param type="label32" v-html="i18n($attrs['label32'])"></vd-component-param></button>
            </div>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Add profile End Here-->
<!-- Choose profile Image Start Here-->  
<div id="manageProfile-chooseImg" class="modal fade manage-Profile" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-center">
    <div class="modal-content">
      <div class="modal-body mp-body">
        <span class="close-model" data-dismiss="modal" data-bs-dismiss="modal">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15 5L5 15" stroke="#7F8286" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M5 5L15 15" stroke="#7F8286" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>            
        </span>
        <div class="mp-mb-heading mp-wwText"><vd-component-param type="label27" v-html="i18n($attrs['label27'])"></vd-component-param></div>
        <div class="mp-mb-profiles">
            <!--<div class="mpmb-profile-img-div selected">
              <div class="mpmb-pimg-div">
            <img class="mpmb-profile-img" src="img/mp-1.png">
          </div>
          </div>
          <div class="mpmb-profile-img-div">
            <div class="mpmb-pimg-div">
              <img class="mpmb-profile-img" src="img/mp-2.png">
            </div>
          </div>
          <div class="mpmb-profile-img-div">
            <div class="mpmb-pimg-div">
              <img class="mpmb-profile-img" src="img/mp-3.png">
            </div>
          </div>
          <div class="mpmb-profile-img-div">
            <div class="mpmb-pimg-div">
              <img class="mpmb-profile-img" src="img/mp-4.png">
            </div>
          </div>
          <div class="mpmb-profile-img-div">
            <div class="mpmb-pimg-div">
              <img class="mpmb-profile-img" src="img/mp-5.png">
            </div>
          </div>
          <div class="mpmb-profile-img-div">
            <div class="mpmb-pimg-div">
              <img class="mpmb-profile-img" src="img/mp-6.png">
            </div>
          </div>-->
          <div class="mpmb-profile-img-div" v-for="avatar in avatarList">
            <div class="mpmb-pimg-div" >
              <img class="mpmb-profile-img" :src="avatar.avatar_url" :id="avatar.avatar_uuid" @click="getSelectedAvatarImg(avatar.avatar_url,avatar.avatar_uuid)">
            </div>
          </div>
        </div>
        <div class="mp-mb-btn">
          <button class="mp-mb-btn-cancel mw-90" data-dismiss="modal" data-bs-dismiss="modal"><vd-component-param type="label29" v-html="i18n($attrs['label29'])"></vd-component-param></button>
          <button class="mp-mb-btn-done mw-90" id="btn-done-chooseProfImg" @click="setSelectedAvtarImg"><vd-component-param type="label28" v-html="i18n($attrs['label28'])"></vd-component-param></button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Choose profile Image End Here-->
<!-- Edit profile Start Here-->  
<div id="manageProfileEdit" class="modal fade edit-Profile" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-center">
    <form @submit.prevent action="" method="post" class="needs-validation" novalidate>
      <div class="modal-content">
        <div class="modal-body mp-body">
          <div class="mp-mb-heading mp-wwText"><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></div>
          <div class="mp-mb-profiles">
              <div class="mpmb-profile-img-div">
                <!--<span class="mpmb-profile-img-div-text text-center"><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></span>-->
                <span class="mpmb-profile-img-div-text text-center"></span>
              <img class="mpmb-profile-img" :src="selectedImg == '' ? getRootUrl() +'img/cpa-5.png' : selectedImg" @error="getRootUrl() +'img/cpa-5.png'" style="background-color: #00000047;">
              <span class="mpmb-profile-edit open-editProfImg">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 16 16" fill="none">
                  <g clip-path="url(#clip0_4234_16488)">
                    <path d="M11.3359 1.99955C11.511 1.82445 11.7189 1.68556 11.9477 1.5908C12.1765 1.49604 12.4216 1.44727 12.6693 1.44727C12.9169 1.44727 13.1621 1.49604 13.3909 1.5908C13.6196 1.68556 13.8275 1.82445 14.0026 1.99955C14.1777 2.17465 14.3166 2.38252 14.4114 2.61129C14.5061 2.84006 14.5549 3.08526 14.5549 3.33288C14.5549 3.58051 14.5061 3.82571 14.4114 4.05448C14.3166 4.28325 14.1777 4.49112 14.0026 4.66622L5.0026 13.6662L1.33594 14.6662L2.33594 10.9996L11.3359 1.99955Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"/>
                  </g>
                  <defs>
                    <clipPath id="clip0_4234_16488">
                      <rect width="16" height="16" fill="white"/>
                    </clipPath>
                  </defs>
                </svg> <vd-component-param type="label31" v-html="i18n($attrs['label31'])"></vd-component-param>               
              </span>
            </div>
            <div class="mpmb-profile-input">
              <div class="mpmb-profinput-div">
                <span class="mpmb-profinput-lbl"><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></span>
                <input class="mpmb-profinputs vd-component-attr form-control" name="username" v-model="username" vd-component-attr-placeholder="label16" :placeholder=i18n($attrs['label16']) 
                vd-component-attr-title="label16" :title=i18n($attrs['label16']) :class="username_field ? 'is-invalid' : ''" >
                  <template v-if="errors.username">
                    <h3 class="invalid-feedback pb-2 validation-msg">{{ errors.username }}</h3>
                  </template> 
              </div>
              <div class="mpmb-profinput-div mpmbProf-selects" id="mpmb_profinput_div_maturityRating_alt" :style="{ 'display': maturityRatingSettingsStatus == true ? '' : 'none' }">
                <span class="mpmb-profinput-lbl"><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></span>
                <!--<select id="mpmbProfselects" class="selectpicker w-100 mpmb-profselects pointer-none" placeholder="Select">
                  <option value="0" selected>All Maturity Ratings</option>
                  <option value="1" >No Restriction</option>
                  <option value="2" >5+ kids</option>
                  <option value="3" >7+ Older kids</option>
                  <option value="4" >13+ Teen</option>
                  <option value="5" >16+ Young Adults</option>
                  <option value="6" >18+ Adults</option>
                </select>-->
                <select class="selectpicker w-100 mpmb-profselects" id="mpmb-Profselects-alt" v-model="selectedMaturitySetting" placeholder="Select" @change="changeUserType($event.target.value)">
                  <option v-for="(maturityRating,i) in maturityRatings" :key="i" :value="maturityRating.maturity_rating_uuid" :data-subtext=" maturityRating.name" :selected=" selectedMaturitySetting === maturityRating.maturity_rating_uuid">{{maturityRating.maturity_rating_name}}</option> 
                  <option :value="" :selected="selectedMaturitySetting === ''" v-if="selectedMaturitySetting !== null">No Restriction</option>
                  <option :value=null :selected="selectedMaturitySetting == null" v-if="selectedMaturitySetting == null">No Restriction</option>
                </select>              
              </div>
            </div>
          </div>
          <div class="mp-mb-btn">
            <button class="mp-mb-btn-dp"><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></button>
            <button class="mp-mb-btn-cancel" data-dismiss="modal" data-bs-dismiss="modal"><vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param></button>
            <button class="mp-mb-btn-done" id="btn-done-editProf" @click="editMultipleProfile" :disabled="username_field"><vd-component-param type="label33" v-html="i18n($attrs['label33'])"></vd-component-param></button>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Edit profile End Here-->
<!-- Delete profile Start Here-->  
<div id="manageProfileDelete" class="modal fade edit-Profile" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-center">
    <div class="modal-content">
      <div class="modal-body mp-body">
        <!-- <div class="mp-mb-heading mp-wwText">Add Profile</div> -->
        <div class="mp-mb-profiles">
            <div class="mpmb-profile-img-div">
            <img class="mpmb-profile-img" :src="selectedImg == '' ? getRootUrl() +'img/cpa-5.png' : selectedImg" @error="getRootUrl() +'img/cpa-5.png'" style="background-color: #00000047;">
            <span class="mpmb-profile-edit">
              {{username}}               
            </span>
           </div>
           <div class="mpmb-profile-input">
            <div class="mpmb-profinput-div">
              <span class="mpmb-profinput-lbl del-prof-lbl"><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param></span>
             <p class="mpmb-para mt-1 pb-1"><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></p>
            </div>
          </div>
        </div>
        <div class="mp-mb-btn">
          <button class="mp-mb-btn-cancel mw-90" data-bs-dismiss="modal" data-dismiss="modal" id="cancel-deleteProf"><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param></button>
          <button class="mp-mb-btn-done mw-90" id="btn-deleteConfirm" @click="deleteMultiProfile"><vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param></button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Delete profile End Here-->
</vd-component>`,
};

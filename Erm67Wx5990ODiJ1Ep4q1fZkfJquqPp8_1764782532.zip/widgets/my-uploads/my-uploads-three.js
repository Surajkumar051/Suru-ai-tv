let { getAllContentDeatils,getUGCContent,deleteContent,getUgcSetting } = await import(window.importAssetJs('js/webservices.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
let {default:ugc_content_upload_one}=await import(window.importLocalJs('widgets/ugc-content-upload/ugc-content-upload-one.js'));
let { default: content_hover_two } = await import(window.importLocalJs('widgets/content-hover/content-hover-two.js'));
// let {getLocale}=await import(window.importAssetJs('js/web-service-url.js'));
const { defineAsyncComponent } = Vue;
export default {
  name: 'my_uploads_three',
  components: {
    ugc_content_upload_one,
    content_hover_two,
    content_purchase_one: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'))),
  },
  data() {
    return {
      isLogedIn: localStorage.getItem('isloggedin'),
      ugcContentList: [],
      minisContentList: [],
      ugcPage: 1,
      isNextPageCallReqdUgc: true,
      minisPage: 1,
      isNextPageCallReqdMinis: true,
      toBeDeletedContentId: "",
      content: {
        content_name: "",
      },
      toBeEditedContentId: "",
      reloadPop: 1,
      ugcSetting: {},
      // languageCode:getLocale()
    }
  },
  beforeMount() {


  },
  mounted() {
    scrollLoad = true; //@ER: 74207
    JsLoadingOverlay.hide();
    owlCarousal();
    this.getUgcSetting();
    //this.fetchUGCContents(false);
    // this.fetchMinisContents(false);
    this.loadMore();

  },
  methods: {
    i18n,
    getUgcSetting() {
      getUgcSetting().then((res) => {
        this.ugcSetting = res.data.data.ugcSetting;
        if (this.ugcSetting?.vod_access) {
          this.fetchUGCContents(false);
        } else if (this.ugcSetting?.mini_access) {
           // this.fetchMinisContents(false);
        }
      });
    },

    fetchUGCContents(onScroll) {
      if (this.isNextPageCallReqdUgc) {
        this.isNextPageCallReqdUgc = false,
          getUGCContent(1, this.ugcPage).then((res) => {
            if (!onScroll && res.data.status == 'SUCCESS' && res.data.code == 200 && (this.ugcContentList?.length == 0)) {
              this.ugcContentList = res.data.data.contentList.content_list;
            } else if (onScroll && res.data.status == 'SUCCESS' && res.data.code == 200) {
              this.ugcContentList.push(...res.data.data.contentList.content_list);
            } else if (!onScroll && res.data.status == 'SUCCESS' && res.data.code == 200) {
              this.ugcContentList.push(...res.data.data.contentList.content_list);
            }
            if (res.data.code == 200 && this.ugcContentList?.length < res.data.data.contentList.page_info.total_count) {
              this.isNextPageCallReqdUgc = true;
            }
          });
      }
    },

    fetchMinisContents(onScroll) {
      if (this.isNextPageCallReqdMinis) {
        this.isNextPageCallReqdMinis = false,
          getUGCContent(2, this.minisPage).then((res) => {
            if (!onScroll && res.data.status == 'SUCCESS' && res.data.code == 200 && (this.minisContentList?.length == 0)) {
              this.minisContentList = res.data.data.contentList.content_list;
            } else if (onScroll && res.data.status == 'SUCCESS' && res.data.code == 200) {
              this.minisContentList.push(...res.data.data.contentList.content_list);
            }
            else if (!onScroll && res.data.status == 'SUCCESS' && res.data.code == 200) {
              this.minisContentList.push(...res.data.data.contentList.content_list);
            }
            if (res.data.code == 200 && this.minisContentList?.length < res.data.data.contentList.page_info.total_count) {
              this.isNextPageCallReqdMinis = true;
            }
          });
      }
    },


    loadMore() {

      window.onscroll = () => {
        let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight + 20 >= document.documentElement.scrollHeight;
        if (bottomOfWindow && this.isNextPageCallReqdUgc && scrollLoad) {
          this.ugcPage++;
          this.fetchUGCContents(true);
        }
      }
    },

    deleteContentConfirmation(contentId) {
      this.toBeDeletedContentId = contentId
    },
    deleteContent() {
      deleteContent(this.toBeDeletedContentId).then((res) => {
        if (res.data.status == "SUCCESS") {
          this.toBeDeletedContentId = "";
          $(".modal-backdrop").hide();
          $('#deleteContentModal').hide();
          window.location.reload();
          Toast.fire({
            icon: 'success',
            text: i18n("Content deleted successfully."),

          });
        } else {
          Toast.fire({
            icon: 'error',
            text: i18n("Content delete failed."),

          });
        }
      });

    },
    edit(content_uuid) {
      this.toBeEditedContentId = content_uuid;
      //let ths = this;
      setTimeout(() => {
        $('#ugcContentEdit .modal').addClass('show');
        $('#ugcContentEdit .modal').css("display", "block");
      }, 300);
    },
    tabChange(section) {
      if (section == 'ugc') {
        if (this.ugcPage > 1 || (this.ugcPage == 1 && this.ugcContentList?.length > 0)) {
          this.ugcPage++;
        }
        this.isNextPageCallReqdUgc = true;
        this.fetchUGCContents(false);

      } else if (section == 'mini') {
        if (this.minisPage > 1 || (this.minisPage == 1 && this.minisContentList?.length > 0)) {
          this.minisPage++;
        }
        this.isNextPageCallReqdMinis = true;
        this.fetchMinisContents(false);
      }
    },

    reloadContentPopup() {
      this.toBeEditedContentId = "";
      ++this.reloadPop;
    }

  },




  template: `


    <vd-component class="vd my-uploads-three" type="my-uploads-three">
    <content_purchase_one  :id="$attrs['id'] +'_content_purchase_one_1'" />
    <!--Title start here-->
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <h1 class="dashboard-heading white-color mbottom-20 mb-32"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h1>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
            <ul class="upload-filter-options nav nav-tabs">
                <li v-if='ugcSetting?.vod_access' class="nav-item" @click="tabChange('ugc')">
                    <a class="nav-link active" id="ugc-tab" data-toggle="tab" href="#ugc" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></a>
                </li>
                <!--<li v-if='ugcSetting?.mini_access' class="nav-item" @click="tabChange('mini')" >
                    <a class="nav-link" id="minis-tab" data-toggle="tab" href="#minis" role="tab" aria-controls="home" aria-selected="true"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></a>
                </li>-->
            </ul>
        </div>
    </div>
    <!--Title End here-->
    <!--my uploads History start Here-->
    <div class="tab-content myuploads-history" id="myTabContent">
        <div class="tab-pane fade show active" id="ugc" role="tabpanel" aria-labelledby="ugc-tab">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 " v-if="ugcContentList?.length">
                    <!--Loop File Start Here-->
                    <div class="watch-history no-bg hover-show grid-hover" v-for="content in ugcContentList">
                        <div class="picture">
                            <div class="freeContent-tag" v-if="content?.is_free_content">
                                <span><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></span>
                            </div>
                            <img class="w-100" loading="lazy" v-if="content.posters.website !== null && content.posters.website[0].file_url !== ''" :src="content.posters.website[0].file_url" />
                            <img class="w-100" loading="lazy" v-if="content.posters.website === null  || content.posters.website[0].file_url === ''" :src="content.no_image_available_url" alt="no image"/>
																
                            <div class="video-duration"  v-if="content?.video_details?.encoding_status=='completed'">
                                <span>{{content?.video_details?.duration}}</span>
                            </div>
                            <!--Button Show on Hover start Here-->
                            <!--<div class="box-hover-button">
                                <a href="javascript:void(0);">
                                    <svg width="25" height="32" viewBox="0 0 25 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33594 2.83166C1.33594 2.0405 2.21118 1.56266 2.8767 1.99049L23.3608 15.1588C23.9731 15.5525 23.9731 16.4475 23.3608 16.8412L2.87669 30.0095C2.21118 30.4373 1.33594 29.9595 1.33594 29.1683V2.83166Z" fill="white" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </a>
                            </div>-->
                            <content_hover_two :id="$attrs['id'] +'_content_hover_two_2'" :content="content" 
                            :playNowBtnTxt="i18n($attrs['label9'])" 
                            :viewTrailerBtnTxt="i18n($attrs['label10'])" 
                            :playAllBtnTxt="i18n($attrs['label11'])" 
                            :watchNowBtnTxt="i18n($attrs['label9'])" 
                            :isLogedIn="isLogedIn" />
														
                            <!--Button Show on Hover End Here-->
                        </div>
                        <div class="data data-flex">
                            <div class="data-contents overflow-hidden">
                                <h2>
                                  <a v-if="content?.content_status==2 &&  content?.video_details?.encoding_status=='completed'" class="wh-data-a  truncate-text-regular" :href="'/player/'+content.content_permalink">{{content.content_name}}</a>
                                  <a v-else class="wh-data-a  truncate-text-regular" style="cursor: default;" >{{content.content_name}}</a>
                                </h2>
                                <p class="truncate-text lc-three">{{content.content_desc}}</p>
                                <span class="status-span">
                                    <svg  v-if="content.content_status==2" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 5.87827 0.842855 3.84344 2.34315 2.34315C3.84344 0.842855 5.87827 0 8 0C10.1217 0 12.1566 0.842855 13.6569 2.34315C15.1571 3.84344 16 5.87827 16 8C16 10.1217 15.1571 12.1566 13.6569 13.6569C12.1566 15.1571 10.1217 16 8 16C5.87827 16 3.84344 15.1571 2.34315 13.6569C0.842855 12.1566 0 10.1217 0 8ZM7.54347 11.424L12.1493 5.66613L11.3173 5.00053L7.38987 9.90827L4.608 7.5904L3.92533 8.4096L7.54347 11.4251V11.424Z" fill="#21A76F"></path>
                                    </svg>
                                    <svg v-else-if="content.content_status==1" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6.8566 2.57152L1.20993 11.9982C1.09351 12.1998 1.03191 12.4284 1.03126 12.6612C1.0306 12.894 1.09092 13.1229 1.20621 13.3252C1.3215 13.5275 1.48775 13.696 1.6884 13.8141C1.88906 13.9322 2.11713 13.9956 2.34993 13.9982H13.6433C13.8761 13.9956 14.1041 13.9322 14.3048 13.8141C14.5054 13.696 14.6717 13.5275 14.787 13.3252C14.9023 13.1229 14.9626 12.894 14.9619 12.6612C14.9613 12.4284 14.8997 12.1998 14.7833 11.9982L9.1366 2.57152C9.01775 2.37559 8.85041 2.2136 8.65073 2.10117C8.45104 1.98875 8.22575 1.92969 7.9966 1.92969C7.76744 1.92969 7.54215 1.98875 7.34247 2.10117C7.14278 2.2136 6.97544 2.37559 6.8566 2.57152Z" fill="#F5A700" stroke="#F5A700" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M8 4.66797V8.66797" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M8 11.332H8.00667" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    <svg  v-else-if="content.content_status==4" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6.8566 2.57152L1.20993 11.9982C1.09351 12.1998 1.03191 12.4284 1.03126 12.6612C1.0306 12.894 1.09092 13.1229 1.20621 13.3252C1.3215 13.5275 1.48775 13.696 1.6884 13.8141C1.88906 13.9322 2.11713 13.9956 2.34993 13.9982H13.6433C13.8761 13.9956 14.1041 13.9322 14.3048 13.8141C14.5054 13.696 14.6717 13.5275 14.787 13.3252C14.9023 13.1229 14.9626 12.894 14.9619 12.6612C14.9613 12.4284 14.8997 12.1998 14.7833 11.9982L9.1366 2.57152C9.01775 2.37559 8.85041 2.2136 8.65073 2.10117C8.45104 1.98875 8.22575 1.92969 7.9966 1.92969C7.76744 1.92969 7.54215 1.98875 7.34247 2.10117C7.14278 2.2136 6.97544 2.37559 6.8566 2.57152Z" fill="#E53935" stroke="#E53935" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 4.66797V8.66797" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 11.332H8.00667" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    <span class="status-text txt-published" v-if="content.content_status==2"><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>  
                                    <span class="status-text txt-pending" v-else-if="content.content_status==1"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></span>   
                                    <span class="status-text txt-rejected" v-else-if="content.content_status==4"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>                       
                                </span>
                            </div>
                            <div class="action-buttons">
                                <!--<button class="btns btn-share" v-if="content.content_status==2">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 5.33203C13.1046 5.33203 14 4.4366 14 3.33203C14 2.22746 13.1046 1.33203 12 1.33203C10.8954 1.33203 10 2.22746 10 3.33203C10 4.4366 10.8954 5.33203 12 5.33203Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M4 10C5.10457 10 6 9.10457 6 8C6 6.89543 5.10457 6 4 6C2.89543 6 2 6.89543 2 8C2 9.10457 2.89543 10 4 10Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M12 14.668C13.1046 14.668 14 13.7725 14 12.668C14 11.5634 13.1046 10.668 12 10.668C10.8954 10.668 10 11.5634 10 12.668C10 13.7725 10.8954 14.668 12 14.668Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M5.72656 9.00781L10.2799 11.6611" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M10.2732 4.33984L5.72656 6.99318" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>-->
                                <button class="btns btn-edit" @click="edit(content.content_uuid)" 
                                data-toggle="modal" data-target="#ugcContentEdit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 13.332H14" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M11 2.33218C11.2652 2.06697 11.6249 1.91797 12 1.91797C12.1857 1.91797 12.3696 1.95455 12.5412 2.02562C12.7128 2.09669 12.8687 2.20086 13 2.33218C13.1313 2.4635 13.2355 2.61941 13.3066 2.79099C13.3776 2.96257 13.4142 3.14647 13.4142 3.33218C13.4142 3.5179 13.3776 3.7018 13.3066 3.87338C13.2355 4.04496 13.1313 4.20086 13 4.33218L4.66667 12.6655L2 13.3322L2.66667 10.6655L11 2.33218Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>
                                <button class="btns btn-delete" @click="deleteContentConfirmation(content.content_uuid)" data-toggle="modal" data-target="#deleteContentModal">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2 4H3.33333H14" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M5.33594 3.9987V2.66536C5.33594 2.31174 5.47641 1.9726 5.72646 1.72256C5.97651 1.47251 6.31565 1.33203 6.66927 1.33203H9.33594C9.68956 1.33203 10.0287 1.47251 10.2787 1.72256C10.5288 1.9726 10.6693 2.31174 10.6693 2.66536V3.9987M12.6693 3.9987V13.332C12.6693 13.6857 12.5288 14.0248 12.2787 14.2748C12.0287 14.5249 11.6896 14.6654 11.3359 14.6654H4.66927C4.31565 14.6654 3.97651 14.5249 3.72646 14.2748C3.47641 14.0248 3.33594 13.6857 3.33594 13.332V3.9987H12.6693Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M6.66406 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M9.33594 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <!--Loop File End Here-->
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-else>
                    <div class="w-100 text-center white-color">
                        <h6><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="minis" role="tabpanel" aria-labelledby="minis-tab">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="minisContentList?.length">
                    <!--Loop File Start Here-->
                    <div class="watch-history no-bg hover-show grid-hover" v-for="content in minisContentList">
                        <div class="picture">
                        <img class="w-100" loading="lazy" v-if="content.posters.website !== null && content.posters.website[0].file_url !== ''" :src="content.posters.website[0].file_url" />
                        <img class="w-100" loading="lazy" v-if="content.posters.website === null  || content.posters.website[0].file_url === ''" :src="content.no_image_available_url" alt="no image"/>
                        
                            <div class="video-duration" v-if="content?.video_details?.encoding_status=='completed'">
                                <span>{{content?.video_details?.duration}}</span>
                            </div>
                            <!--Button Show on Hover start Here-->
                            <!--<div class="box-hover-button">
                                <a href="javascript:void(0);">
                                    <svg width="25" height="32" viewBox="0 0 25 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.33594 2.83166C1.33594 2.0405 2.21118 1.56266 2.8767 1.99049L23.3608 15.1588C23.9731 15.5525 23.9731 16.4475 23.3608 16.8412L2.87669 30.0095C2.21118 30.4373 1.33594 29.9595 1.33594 29.1683V2.83166Z" fill="white" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </a>
                            </div>-->
                            <content_hover_one :id="$attrs['id'] +'_content_hover_one_1'" :content="content" :playNowBtnTxt="i18n($attrs['label9'])" :viewTrailerBtnTxt="i18n($attrs['label10'])" :playAllBtnTxt="i18n($attrs['label11'])" :watchNowBtnTxt="i18n($attrs['label9'])" :isLogedIn="isLogedIn" />
														
                            <!--Button Show on Hover End Here-->
                        </div>
                        <div class="data data-flex">
                            <div class="data-contents overflow-hidden">
                                <h2>
                                <a v-if="content?.content_status==2 &&  content?.video_details?.encoding_status=='completed'" class="wh-data-a  truncate-text-regular" :href="'/player/'+content.content_permalink">{{content.content_name}}</a>
                                  <a v-else class="wh-data-a  truncate-text-regular" style="cursor: default;" >{{content.content_name}}</a>
                                </h2>
                                <p class="truncate-text lc-three">{{content.content_desc}}</p>
                                <span class="status-span">
                                    <svg  v-if="content.content_status==2" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 5.87827 0.842855 3.84344 2.34315 2.34315C3.84344 0.842855 5.87827 0 8 0C10.1217 0 12.1566 0.842855 13.6569 2.34315C15.1571 3.84344 16 5.87827 16 8C16 10.1217 15.1571 12.1566 13.6569 13.6569C12.1566 15.1571 10.1217 16 8 16C5.87827 16 3.84344 15.1571 2.34315 13.6569C0.842855 12.1566 0 10.1217 0 8ZM7.54347 11.424L12.1493 5.66613L11.3173 5.00053L7.38987 9.90827L4.608 7.5904L3.92533 8.4096L7.54347 11.4251V11.424Z" fill="#21A76F"></path>
                                    </svg>
                                    <svg v-else-if="content.content_status==1" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 8C0 5.87827 0.842855 3.84344 2.34315 2.34315C3.84344 0.842855 5.87827 0 8 0C10.1217 0 12.1566 0.842855 13.6569 2.34315C15.1571 3.84344 16 5.87827 16 8C16 10.1217 15.1571 12.1566 13.6569 13.6569C12.1566 15.1571 10.1217 16 8 16C5.87827 16 3.84344 15.1571 2.34315 13.6569C0.842855 12.1566 0 10.1217 0 8ZM7.54347 11.424L12.1493 5.66613L11.3173 5.00053L7.38987 9.90827L4.608 7.5904L3.92533 8.4096L7.54347 11.4251V11.424Z" fill="#21A76F"></path>
                                    </svg>
                                    <svg  v-else-if="content.content_status==4" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6.8566 2.57152L1.20993 11.9982C1.09351 12.1998 1.03191 12.4284 1.03126 12.6612C1.0306 12.894 1.09092 13.1229 1.20621 13.3252C1.3215 13.5275 1.48775 13.696 1.6884 13.8141C1.88906 13.9322 2.11713 13.9956 2.34993 13.9982H13.6433C13.8761 13.9956 14.1041 13.9322 14.3048 13.8141C14.5054 13.696 14.6717 13.5275 14.787 13.3252C14.9023 13.1229 14.9626 12.894 14.9619 12.6612C14.9613 12.4284 14.8997 12.1998 14.7833 11.9982L9.1366 2.57152C9.01775 2.37559 8.85041 2.2136 8.65073 2.10117C8.45104 1.98875 8.22575 1.92969 7.9966 1.92969C7.76744 1.92969 7.54215 1.98875 7.34247 2.10117C7.14278 2.2136 6.97544 2.37559 6.8566 2.57152Z" fill="#E53935" stroke="#E53935" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 4.66797V8.66797" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M8 11.332H8.00667" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    <span class="status-text txt-published" v-if="content.content_status==2"><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>  
                                    <span class="status-text txt-pending" v-else-if="content.content_status==1"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></span>   
                                    <span class="status-text txt-rejected" v-else-if="content.content_status==4"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>                       
                                </span>
                            </div>
                            <div class="action-buttons">
                                <!--<button class="btns btn-share" v-if="content.content_status==2">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 5.33203C13.1046 5.33203 14 4.4366 14 3.33203C14 2.22746 13.1046 1.33203 12 1.33203C10.8954 1.33203 10 2.22746 10 3.33203C10 4.4366 10.8954 5.33203 12 5.33203Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M4 10C5.10457 10 6 9.10457 6 8C6 6.89543 5.10457 6 4 6C2.89543 6 2 6.89543 2 8C2 9.10457 2.89543 10 4 10Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M12 14.668C13.1046 14.668 14 13.7725 14 12.668C14 11.5634 13.1046 10.668 12 10.668C10.8954 10.668 10 11.5634 10 12.668C10 13.7725 10.8954 14.668 12 14.668Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M5.72656 9.00781L10.2799 11.6611" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M10.2732 4.33984L5.72656 6.99318" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>-->
                                <button class="btns btn-edit" @click="edit(content.content_uuid)"  
                                data-toggle="modal" data-target="#ugcContentEdit">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8 13.332H14" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M11 2.33218C11.2652 2.06697 11.6249 1.91797 12 1.91797C12.1857 1.91797 12.3696 1.95455 12.5412 2.02562C12.7128 2.09669 12.8687 2.20086 13 2.33218C13.1313 2.4635 13.2355 2.61941 13.3066 2.79099C13.3776 2.96257 13.4142 3.14647 13.4142 3.33218C13.4142 3.5179 13.3776 3.7018 13.3066 3.87338C13.2355 4.04496 13.1313 4.20086 13 4.33218L4.66667 12.6655L2 13.3322L2.66667 10.6655L11 2.33218Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>
                                <button class="btns btn-delete" @click="deleteContentConfirmation(content.content_uuid)" data-toggle="modal" data-target="#deleteContentModal" >
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2 4H3.33333H14" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M5.33594 3.9987V2.66536C5.33594 2.31174 5.47641 1.9726 5.72646 1.72256C5.97651 1.47251 6.31565 1.33203 6.66927 1.33203H9.33594C9.68956 1.33203 10.0287 1.47251 10.2787 1.72256C10.5288 1.9726 10.6693 2.31174 10.6693 2.66536V3.9987M12.6693 3.9987V13.332C12.6693 13.6857 12.5288 14.0248 12.2787 14.2748C12.0287 14.5249 11.6896 14.6654 11.3359 14.6654H4.66927C4.31565 14.6654 3.97651 14.5249 3.72646 14.2748C3.47641 14.0248 3.33594 13.6857 3.33594 13.332V3.9987H12.6693Z" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M6.66406 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M9.33594 7.33203V11.332" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <!--Loop File End Here-->
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-else>
                    <div class="w-100 text-center white-color">
                        <h6><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h6>
                    </div>
                </div>
            </div>
        </div>
        
    </div>


    <div class="modal fade delete-massage" id="deleteContentModal" tabindex="-1" role="dialog" aria-labelledby="deleteCardModalLabel" style="padding-right: 15px;">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-body mt-2">
            <div class="d-flex align-items-start">
              <div class="svg wh-24 reset mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23Z" fill="#118BA6"></path>
                  <path d="M12 7V13" stroke="#F2F2F2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                  <path d="M12 17H12.01" stroke="#F2F2F2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
              </div>
              <section>
                <div class="title"><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></div>
                <p class="form-text mb-0 mt-2 pe-2"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></p>
              </section>
            </div>
          </div>
          <div class="modal-footer no-border">
            <button type="button" class="btn dismiss" data-dismiss="modal"><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></button>
            <button type="button" class="btn btnProceed"  id="proceed" @click="deleteContent()"><vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param></button>
          </div>
        </div>
      </div>
    </div>

    <ugc_content_upload_one id="ugcContentEdit" :contentId="toBeEditedContentId" :key="reloadPop" @closePop="reloadContentPopup"/>
    <!--my uploads History End Here-->
</vd-component>
`
};

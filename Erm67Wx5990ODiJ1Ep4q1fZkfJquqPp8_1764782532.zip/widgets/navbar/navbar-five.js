let { getEndUserRegdLoginSetting,
    getCategoryDetails,
    getUserDetails,
    getSearchListData,
    // getVdConfig,
    getUgcSettingStatus,
    getSearchListDataFromElastic,
    getAccountTokenDetails,
    fetchUserAndPartnersForSearch,
    getPartnerAndUserSettingDetails,
    getProfileList,
    toGetMultipleProfileToken,
    endUserLogOut } = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { delayCall } = await import(window.importLocalJs('widgets/navbar/search-util.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { default: ugc_content_upload_one } = await import(window.importLocalJs('widgets/ugc-content-upload/ugc-content-upload-one.js'));
let { default: multilingual_four } = await import(window.importLocalJs('widgets/multilingual/multilingual-four.js'));
const { mapState} = Vuex;

export default {
    name: "navbar_five",
    data() {
        return {
            rootUrl: getRootUrl(),
            
            categoryDetails: [],
            isLogin: Boolean,
            userProfile: String,
            userInfo: String,
            profilepic: false,
            searchValue: "",
            searchData: [],
            flag: Boolean,
            isRes: false,
            dropdown_toggle: "dropdown-toggle",
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            userConfig: null,
            newConfig: Boolean,
            ugcEnabled: false,
            reloadUGCPop: 1,
            activeClass: null,
            contentList: [],
            playlist: [],
            partnerList: [],
            endUserList: [],
            partnerFlag: Boolean,
            endUserFlag: Boolean,
            partnerEnabled: false,
            partnerProfileEnabled: false,
            ugcProfileEnabled: false,
            getProfileList: [],
            multiprofileClickedObj: {
                "profile_name": '',
                "enduser_profile_uuid": '',
                "avatar": ''
            },
            multiprofileClickedStatus: false,
            multiProfileIsEnable: false,
            selectedMultipleProfileUuid: '',
            scrollY: 0,
            svgElement:'<svg class=\"submenuClose\" width=\"16\" height=\"17\" viewBox=\"0 0 16 17\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M3.99023 6.5L7.99023 10.5L11.9902 6.5\" stroke=\"white\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg><svg class=\"submenuOpen\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"17\" viewBox=\"0 0 16 17\" fill=\"none\"><path d=\"M12 10.5L8 6.5L4 10.5\" stroke=\"#bf000a\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>'
                                     
        };
    },
    components: {
        ugc_content_upload_one,
        multilingual_four
    },
    computed: {
        ...mapState({
            logo_details: (state) => state.logo_details,
        }),   
        addClass() {
      return {
        inverted: this.scrollY > 60,
        
      };
    },   
    },

    async beforeCreate() {
        //if(!localStorage.getItem("userConfig")){
        const res = await getEndUserRegdLoginSetting();
        if (res.data.code == 200 && res.data.data !== null) {
            if (res.data.data.sections[0].groups[0].nodes[2].node_value == 1) {
                this.multiProfileIsEnable = true;
            }
            localStorage.setItem("userConfig", res.data.data.sections[0].groups[0].nodes[0].node_value);
            if (localStorage.getItem("userConfig") != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
            this.isLogin = localStorage.getItem("isloggedin");
            if (this.newConfig && this.isLogin === "true") {
                this.autoLogout();
            }
        } else {
            window.location.href = '/';
        }
        // }    
    },
beforeDestroy() {
    window.removeEventListener('scroll', this.callScroll);
  },
    mounted() {
        $('.si-searchicon').on('click', function () {
    $('.searchInput').addClass('si-open');
  });
  $('.si-right').on('click', function () {
    $('.searchInput').removeClass('si-open');
    setTimeout(function () {
        $('.searchInput #search-input').val('');
    }, 100);
  });

  $('#search-input').keypress(function (e) { 
    $("#subchild").show();
    // $(".si-right").show();
  });
  $('#search-input').focusout(function () {
    setTimeout(function () {
        $("#subchild").hide();
    }, 500);
    //   $(".si-right").hide();
  });
        window.addEventListener('scroll', this.callScroll);
        this.addEvent();
        if (window.location.pathname.toString().split("/").length > 3) {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[3];
        } else {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[2];
        }
        this.fetchUGCSettingStatus();
        this.searchItem = delayCall(this.searchItem);
        getCategoryDetails()
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    // res.data.data.assigned_categories.forEach((ele) => {
                    //     if (!ele.is_static) {
                    //         ele.is_static = "";
                    //     }
                    //     if (!ele.target) {
                    //         ele.target = "";
                    //     }
                    //     if (!ele.type) {
                    //         ele.type = "dynamic";
                    //     }
                    //     if (ele.sub_menu) {
                    //         ele.sub_menu.forEach((sub) => {
                    //             if (!sub.is_static) {
                    //                 sub.is_static = "";
                    //             }
                    //             if (!sub.target) {
                    //                 sub.target = "";
                    //             }
                    //             if (!sub.type) {
                    //                 sub.type = "dynamic";
                    //             }
                    //         });
                    //     }
                    // });
                    this.categoryDetails = res.data.data;
                }
            })
            .catch((ex) => {
                console.log(ex);
            });
        if (localStorage.getItem("isloggedin") !== undefined) {
            this.isLogin = localStorage.getItem("isloggedin");
            this.getUserMenu();
        }
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             //this.logo = res.data.data;
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });

        var intervalId = setInterval(() => {
            this.userConfig = localStorage.getItem("userConfig");
            if (this.userConfig != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
        }, 500);
        setTimeout(() => {
            clearInterval(intervalId);
        }, 2500);

        //Multiprofile
        getProfileList().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                if (res.data.data.getProfileList.length >= 1) {
                    // this.otpSettingEnabled = this.muviAuthEmailOptSettingList.includes(res.data.data.getUserDetails[0].muvi_auth_setting_type);
                    // console.log(this.otpSettingEnabled,"this.otpSettingEnabled");
                    // localStorage.setItem('adminId',res.data.data.getUserDetails[0].user_uuid);
                    // this.muviAuthSettingType = res.data.data.getUserDetails[0].muvi_auth_setting_type;
                    // this.muviAuthEmailOptSettingType = this.muviAuthEmailOptSettingList.includes(this.muviAuthSettingType);
                    this.getProfileList = res.data.data.getProfileList;
                    console.log(this.getProfileList, "res.data.data.getProfileList");
                }
            }
        });
        if (localStorage.getItem('multiprofileIdClicked')) {
            this.multiprofileClickedStatus = true;
        }
        this.multiprofileClickedObj = JSON.parse(localStorage.getItem('multiprofileIdClicked'));
        if (this.multiprofileClickedObj) {
            this.selectedMultipleProfileUuid = this.multiprofileClickedObj.enduser_profile_uuid;
        }
        //alert(this.multiprofileClickedObj.profile_name);    
        //Multiprofile
    },
    watch: {
        multiprofileClickedStatus(value) {
            //localStorage.name = value;
        }
    },
    methods: {
        hideSubmenuClick(){
            var $submenu = $(this).next('.vd_submenu_div');
            if ($submenu.hasClass('show') && !$(this).hasClass('show')) {
                $submenu.removeClass('show');
            } else {
                $('.vd_submenu_div').removeClass('show');
                $submenu.addClass('show');
                } 
            $(this).parent('.btn-navigation').toggleClass('activeClass');
        },
         callScroll() {
            this.scrollY = window.scrollY;
        },
        i18n,
        redirectCategory(link) {
            window.location.href = link;
        },
        getUserMenu() {
            if (localStorage.getItem("isloggedin") == "true") {
                this.userInfo = true;
                var userData = JSON.parse(localStorage.getItem("user"));
                this.userProfile = userData;
            } else {
                this.userInfo = false;
            }
        },
        goToMainjs: function () {
            localStorage.setItem(
                "content_uuid",
                "57bf2ddbea2049479522aceb87b324ec"
            );
        },
        getUserDetailsInfo() {
            getUserDetails().then((res) => {
                if (res.data && res.data.code == 200) {
                    this.userProfile = res.data.data.getUserDetails[0];
                    this.profilepic = true;
                }
            });
        },
        async searchItem() {
            if (this.searchValue !== "") {
                this.isRes = false;
                //let tokenData = await getAccountTokenDetails();

                // getSearchListDataFromElastic(this.searchValue,tokenData).then((res) => {
                //     this.isRes = true;
                //     if (
                //         res.data.code === 200 &&
                //         res.data.data.contents
                //     ) {
                //         this.flag = true;
                //         //this.searchData = res.data.data.contents;
                //         this.setSearchedData(res.data.data.contents);
                //     } else {
                //         this.flag = false;
                //     }
                // });

                getSearchListData(this.searchValue).then((res) => {
                    this.isRes = true;
                    if (
                        res.data.code === 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.flag = true;
                        //this.searchData =res.data.data.contentList.content_list;
                        this.setSearchedData(
                            res.data.data.contentList.content_list
                        );
                    } else {
                        this.flag = false;
                    }
                });
                if (this.partnerEnabled && this.partnerProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "partner",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getPartners.users_list
                        ) {
                            this.partnerFlag = true;
                            this.partnerList =
                                res.data.data.getPartners.users_list;
                        } else {
                            this.partnerFlag = false;
                            this.partnerList = [];
                        }
                    });
                }
                if (this.ugcEnabled && this.ugcProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "user",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getEndUserList.end_user_list
                        ) {
                            this.endUserFlag = true;
                            this.endUserList =
                                res.data.data.getEndUserList.end_user_list;
                        } else {
                            this.endUserFlag = false;
                            this.endUserList = [];
                        }
                    });
                }
            }
        },

        setSearchedData(searchDataList) {
            this.contentList = searchDataList.filter((element) => {
                return element.is_playlist == 0;
            });
            this.playlist = searchDataList.filter((element2) => {
                return element2.is_playlist == 1;
            });
            // let searchDataObjList = {};
            // searchDataObjList["contentList"] = this.contentList;
            // searchDataObjList["playlist"] = this.playlist;
            // this.$store.dispatch(GET_SEARCH_DATA,searchDataObjList);
        },
        //ER 101262
        viewSearchResultEpg(content_permalink,content_uuid) {
            localStorage.setItem("epg_content_uuid",content_uuid);
           window.location.href = "/epg-display-details/" + content_permalink;

        },//ER 101262

        viewContentlist(event) {
            if (event.keyCode === 13) {
                event.preventDefault();
                this.isRes = false;
                if (this.searchValue === undefined || this.searchValue == "") {
                    window.location ="/search-result/" + undefined;
                } else {
                    if (isAudioExists) {
                        getPageByAjax("/search-result/" + this.searchValue); //@ER: 74207
                    } else {
                        window.location.href =
                           "/search-result/" + this.searchValue;
                    }
                }
            }
        },
        viewSearchResult(data, isPlaylist) {
            if (isPlaylist == 1) {
                if (isAudioExists) {
                    getPageByAjax("/playlist/" + data); //@ER: 74207
                } else {
                    window.location.href = + "/playlist/" + data;
                }
            } else {
                //window.location.href = "/content/" + data;
                if (isAudioExists) {
                    getPageByAjax("/content/" + data); //@ER: 74207
                } else {
                    window.location.href = "/content/" + data;
                }
            }
        },
        viewSearchProfile(data, userType) {
            if (userType == "partner") {
                if (isAudioExists) {
                    getPageByAjax("/partner/" + data); //@ER: 74207
                } else {
                    window.location.href = "/partner/" + data;
                }
            } else if (userType == "user") {
                if (isAudioExists) {
                    getPageByAjax("/user/" + data); //@ER: 74207
                } else {
                    window.location.href = "/user/" + data;
                }
            }
        },
        // logout: function () {
            async logout() { 
                const res = await endUserLogOut();
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    window.onbeforeunload = null;
                    if (window.globalAudioPlayer && window.globalAudioPlayer.player_obj) {
                        document.getElementsByClassName("vjs-playlist")[0].remove();
                        window.globalAudioPlayer.player_obj.playlist([]);
                        window.globalAudioPlayer.player_obj.dispose();
                        delete window.globalAudioPlayer.player_obj;
                    }
                } else {
                    Toast.fire({
                        icon: "error",
                        title: res.data.status,
                        text: res.data.message,
                    });
                }   
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            //Multiple Profile window.location.href = "/";
            localStorage.removeItem("multiprofileIdClicked");
            //MultipleProfile
            $cookies.remove("token");
            $cookies.remove("isloggedin");
            this.userInfo = false;
            Toast.fire({
                icon: "success",
                title: "Signout Sucessfully",
            });
            window.location.href = '/' ;
        },
        navigateprofile: function () {
            window.localStorage.setItem("profile.currenttab", "profile_five");
            if (isAudioExists) {
                getPageByAjax("/profile"); //@ER: 74207
            } else {
                window.location.href = "/profile";
            }
        },
        //MultiProfile
        updateNameAndProfilePhoto: function (data) {
            // window.localStorage.setItem("multiprofileIdClicked.profile_name", data.profile_name);
            // window.localStorage.setItem("multiprofileIdClicked.profile_uuid", data.profile_uuid);
            // window.localStorage.setItem("multiprofileIdClicked.avatar", data.avatar);
            data.selectedDate = new Date();
            window.localStorage.setItem("multiprofileIdClicked", JSON.stringify(data));
            this.multiprofileClickedStatus = true;
            this.multiprofileClickedObj = data;
            this.selectedMultipleProfileUuid = this.multiprofileClickedObj.enduser_profile_uuid;
            let payload = {
                enduser_profile_uuid: data.enduser_profile_uuid,
                enduser_maturity_rating_uuid: data.enduser_maturity_rating_uuid
            };
            if (data.enduser_maturity_rating_min_age == null || data.enduser_maturity_rating_min_age == '' || data.enduser_maturity_rating_min_age == "") {
                payload['enduser_maturity_rating_min_age'] = null;
            } else {
                payload['enduser_maturity_rating_min_age'] = data.enduser_maturity_rating_min_age;

            }
            toGetMultipleProfileToken(payload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        localStorage.setItem("end_user_access_token", res.data.data.access_token);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
            $(".content-propertices").removeClass("cp-open");
            window.location.href = '/' ;
        },
        navigateTohome() {
            localStorage.setItem("ManageProfileMenuClicked", true);
            window.location.href = '/' ;
        },
        //MultiProfile
        fetchUGCSettingStatus() {
            getUgcSettingStatus().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "ugc") {
                                this.ugcEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                            if (element.node_code == "partner_portal") {
                                this.partnerEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    res.data.data.sections[0].groups[1].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_profile") {
                                this.ugcProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    //ER-101092 Start
                    res.data.data.sections[0].groups[2].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_regis_login") {
                                localStorage.setItem("freeContentLoginRequired", element.node_value && element.node_value == 1 ? true : false);
                            }
                        }
                    );
                    //ER-101092 End
                }
            });
            getPartnerAndUserSettingDetails().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "profile_page") {
                                this.partnerProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                }
            });
        },
        openAddContentPop() {
            setTimeout(() => {
                $("#ugcContentAdd .modal").addClass("show");
                $("#ugcContentAdd .modal").css("display", "block");
            }, 300);
        },
        openProfilePop() {
            $(".add-content").removeClass("callByAjax");
            if (localStorage.getItem('multiprofileIdClicked')) {
                this.selectedMultipleProfileUuid = JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
            }
            $(".content-propertices").addClass("cp-open");
            getProfileList().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                    if (res.data.data.getProfileList.length >= 1) {
                        this.getProfileList = res.data.data.getProfileList;
                        console.log(this.getProfileList, "res.data.data.getProfileList");
                        // if (localStorage.getItem('multiprofileIdClicked')) {
                        //     this.getProfileList = res.data.data.getProfileList.filter(function (el) {
                        //     return el.enduser_profile_uuid !== JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
                        // });
                        // console.log(this.getProfileList);
                        // }
                    }
                }
            });
        },
        closeProfilePop() {
            $(".content-propertices").removeClass("cp-open");
        },
        reloadUGCPopup() {
            ++this.reloadUGCPop;
        },
        addEvent() {
            window.onclick = (evt) => {
                this.isRes = false;
            };
        },
        // autoLogout: function () {
            async autoLogout(){    
                const resp = await endUserLogOut();
                if (resp.data.code == 200 && resp.data.status == "SUCCESS") {
                } else {
                    Toast.fire({
                        icon: "error",
                        title: resp.data.status,
                        text: resp.data.message,
                    });
                }
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            $cookies.remove("token");
            $cookies.remove("isloggedin");
            this.userInfo = false;
        },
        //106237-start
        removeRedirectAfterLogin() {
            if (window.localStorage.getItem("redirectAfterlogin") !== null) {
                window.localStorage.removeItem("redirectAfterlogin");
            }
        }
        //106237-end
    },
    template:
        /*html*/
        `    <vd-component class="vd navbar-five" type="navbar-five">
    <!--Header Section Start Here-->
<section :class="addClass" class="header" vd-node="header" vd-readonly="true" id="main-header">
    <div class="container-fluid plr-65">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <nav class="navbar navbar-expand-lg navbar-light flex-nowrap p-0 custom-navbar">
                     <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                      <svg class="openMenu-svg" width="22" height="18" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22 1H0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M22 9H0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M22 17H0" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>  
                        <svg class="closeMenu-svg" width="22" height="22" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M24 8L8 24" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                          <path d="M8 8L24 24" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                          </svg>                                                  
                    </button>
                    <a v-if="logo_details['logo']" class="navbar-brand callByAjax mr-42" href="/"><img
                            vd-node="logo" vd-readonly="true" :src="logo_details['logo']['src']"
                            :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']" /></a>
                    <a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax mr-42"
                        href="/"><img vd-node="logo" vd-readonly="true" :src="rootUrl+'img/garnetLogo.png'"
                            alt="Garnet" /></a>
                    <div class="collapse navbar-collapse justify-content-start" id="navbarNav">
                        <ul class="navbar-nav gap-32" vd-node="menu" vd-readonly="true">
                             <template v-if="categoryDetails.length > 5">
                                    <template v-for="data in categoryDetails.slice(0, 5)">
                                        <li class="nav-item phoenix-nav-dropdown garnet-nav-dropdown vd_sideheader_li"
                                            v-if="data.sub_menu != null && data.sub_menu.length > 0">
                                            <div class="btn-navigation toggle-focus-activety">
                                                <a v-if="data.type == 'web_address'"
                                                    class="nav-link pr-0 vd_sideheader_a callByAjax menuSubmenu hoverClass"
                                                    :id="data.id" :target="data.target" :href="data.permalink"
                                                    v-html="i18n(data.label)"
                                                    @click="activeClass= data.permalink"
                                                    :class="{activeClass:data.permalink == activeClass}">
                                                </a>
                                                <a v-if="data.type == 'page'"
                                                    class="nav-link pr-0 menuSubmenu vd_sideheader_a callByAjax hoverClass"
                                                    :id="data.id" :target="data.target"
                                                    :href="'/'+data.permalink" v-html="i18n(data.label)"
                                                    @click="activeClass= data.permalink"
                                                    :class="{activeClass:data.permalink == activeClass}">
                                                </a>
                                                <a v-if="data.type == 'category'"
                                                    class="nav-link pr-0 menuSubmenu vd_sideheader_a callByAjax hoverClass"
                                                    :id="data.id" :target="data.target"
                                                    :href="'/category/'+data.permalink"
                                                    v-html="i18n(data.label)"
                                                    @click="activeClass= data.permalink"
                                                    :class="{activeClass:data.permalink == activeClass}">
                                                </a>
                                                <svg @click="hideSubmenuClick()"  data-toggle="dropdown" aria-expanded="false" class=\"dropdown-toggle submenuClose\" width=\"16\" height=\"17\" viewBox=\"0 0 16 17\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M3.99023 6.5L7.99023 10.5L11.9902 6.5\" stroke=\"white\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>
                                                <svg class=\"submenuOpen\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"17\" viewBox=\"0 0 16 17\" fill=\"none\"><path  d=\"M12 10.5L8 6.5L4 10.5\" stroke=\"#bf000a\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>

                                                <div class="dropdown-menu garnetMenu vd_submenu_div">
                                                    <template v-for="subCat in data.sub_menu">
                                                        <div class="gmItems">
                                                            <a v-if="subCat.type == 'web_address'"
                                                                class=" vd_sideheader_a callByAjax hoverClass" :id="subCat.id"
                                                                :data-subcatID="subCat.label" :target="subCat.target"
                                                                :href="subCat.permalink" v-html=i18n(subCat.label)
                                                                @click="activeClass= subCat.permalink" 
                                                                :class="{activeClass:subCat.permalink == activeClass}">
                                                            </a>
                                                            <a v-if="subCat.type == 'page'"
                                                                class="vd_sideheader_a callByAjax hoverClass" :id="subCat.id"
                                                                :data-subcatID="subCat.label" :target="subCat.target"
                                                                :href="'/'+subCat.permalink"
                                                                v-html=i18n(subCat.label)
                                                                @click="activeClass= subCat.permalink" 
                                                                :class="{activeClass:subCat.permalink == activeClass}">
                                                            </a>
                                                            <a v-if="subCat.type == 'category'"
                                                                class="vd_sideheader_a callByAjax hoverClass" :id="subCat.id"
                                                                :data-subcatID="subCat.label" :target="subCat.target"
                                                                :href="'/category/'+subCat.permalink"
                                                                v-html=i18n(subCat.label)
                                                                @click="activeClass= subCat.permalink" 
                                                                :class="{activeClass:subCat.permalink == activeClass}">
                                                            </a>
                                                        </div>
                                                    </template>


                                                </div>
                                            </div>
                                        </li>
                                        <li v-else class="nav-item vd_sideheader_li">
                                            <a v-if="data.type == 'web_address'"
                                                class="nav-link vd_sideheader_a callByAjax hoverClass"
                                                @click="activeClass= data.permalink"
                                                :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                                :target="data.target" :href="data.permalink"
                                                v-html=i18n(data.label)></a>

                                            <a v-if="data.type == 'page'"
                                                class="nav-link vd_sideheader_a callByAjax hoverClass"
                                                @click="activeClass= data.permalink"
                                                :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                                :target="data.target" :href="'/'+data.permalink"
                                                v-html=i18n(data.label)></a>

                                            <a v-if="data.type == 'category'"
                                                class="nav-link vd_sideheader_a callByAjax hoverClass"
                                                @click="activeClass= data.permalink"
                                                :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                                :target="data.target" :href="'/category/'+data.permalink"
                                                v-html=i18n(data.label)></a>
                                        </li>
                                    </template>
                                    <li class="nav-item phoenix-nav-dropdown garnet-nav-dropdown vd_sideheader_li">
                                        <div class="btn-navigation toggle-focus-activety">
                                           <a class="nav-link pr-0 menuSubmenu dropdown-toggle more-btn hoverClass"   v-html=i18n('More')>More</a>
                                            <svg class="submenuClose" data-toggle="dropdown" aria-expanded="true" width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M3.99023 6.5L7.99023 10.5L11.9902 6.5" stroke="white" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                <svg class="submenuOpen" xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
                                                    <path d="M12 10.5L8 6.5L4 10.5" stroke="#bf000a" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            <div class="dropdown-menu garnetMenu vd_submenu_div more-div">
                                                <template v-for="data in categoryDetails.slice(5)">
                                                    <div class="gmItems">
                                                        <a v-if="data.type == 'web_address'"
                                                                    class="callByAjax hoverClass"
                                                                    :id="data.id" :target="data.target" 
                                                                   :href="data.permalink"
                                                                    v-html="i18n(data.label)"
                                                                    @click="activeClass= data.permalink"
                                                                    :class="{activeClass:activeClass === data.permalink}">

                                                        </a>

                                                        <a v-if="data.type == 'page'"
                                                                        class="callByAjax hoverClass"
                                                                        :id="data.id" :target="data.target"
                                                                        :href="'/'+data.permalink" 
                                                                        v-html="i18n(data.label)"
                                                                        @click="activeClass= data.permalink"
                                                                        :class="{activeClass:activeClass === data.permalink}">
                                                        </a>
                                                        <a v-if="data.type == 'category'"
                                                                    class="callByAjax hoverClass"
                                                                    :id="data.id" :target="data.target"
                                                                    :href="'/category/'+data.permalink"
                                                                    v-html="i18n(data.label)"
                                                                    @click="activeClass= data.permalink"
                                                                    :class="{activeClass:activeClass === data.permalink}">

                                                        </a>
                                                    </div>
                                                </template>
                                            </div>
                                        </div>
                                    </li>
                                </template>
                                <template v-else v-for="data in categoryDetails">
                                    <li class="nav-item phoenix-nav-dropdown garnet-nav-dropdown vd_sideheader_li"
                                        v-if="data.sub_menu != null && data.sub_menu.length > 0">
                                        <div class="btn-navigation toggle-focus-activety">
                                            <a v-if="data.type == 'web_address'"
                                                class="nav-link pr-0 vd_sideheader_a callByAjax menuSubmenu hoverClass"
                                                :id="data.id" :target="data.target" :href="data.permalink"
                                                v-html="i18n(data.label)"
                                                @click="activeClass= data.permalink"
                                                :class="{activeClass:data.permalink == activeClass}">
                                            </a>

                                            <a v-if="data.type == 'page'"
                                                class="nav-link pr-0 menuSubmenu dropdown-toggle vd_sideheader_a callByAjax hoverClass"
                                                :id="data.id" :target="data.target"
                                                :href="'/'+data.permalink" 
                                                v-html="i18n(data.label)"
                                                @click="activeClass= data.permalink"
                                                :class="{activeClass:data.permalink == activeClass}">
                                            </a>
                                            <a v-if="data.type == 'category'"
                                                class="nav-link pr-0 menuSubmenu dropdown-toggle vd_sideheader_a callByAjax hoverClass"
                                                :id="data.id" :target="data.target"
                                                :href="'/category/'+data.permalink" 
                                                v-html="i18n(data.label)"
                                                @click="activeClass= data.permalink"
                                                :class="{activeClass:data.permalink == activeClass}">

                                            </a>
                                            <svg @click="hideSubmenuClick()"  data-toggle="dropdown" aria-expanded="false" class=\"dropdown-toggle submenuClose\" width=\"16\" height=\"17\" viewBox=\"0 0 16 17\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M3.99023 6.5L7.99023 10.5L11.9902 6.5\" stroke=\"white\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>
                                            <svg class=\"submenuOpen\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"17\" viewBox=\"0 0 16 17\" fill=\"none\"><path  d=\"M12 10.5L8 6.5L4 10.5\" stroke=\"#bf000a\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>
                                            <div class="dropdown-menu garnetMenu vd_submenu_div">
                                                <template v-for="subCat in data.sub_menu">
                                                    <div class="gmItems">
                                                        <a v-if="subCat.type == 'web_address'"
                                                            class=" vd_sideheader_a callByAjax hoverClass" :id="subCat.id"
                                                            :data-subcatID="subCat.label" :target="subCat.target"
                                                            :href="subCat.permalink" v-html=i18n(subCat.label)
                                                            @click="activeClass= subCat.permalink" 
                                                            :class="{activeClass:subCat.permalink == activeClass}">
                                                        </a>
                                                        <a v-if="subCat.type == 'page'"
                                                            class="vd_sideheader_a callByAjax hoverClass" :id="subCat.id"
                                                            :data-subcatID="subCat.label" :target="subCat.target"
                                                            :href="'/'+subCat.permalink"
                                                            v-html=i18n(subCat.label)
                                                            @click="activeClass= subCat.permalink" 
                                                            :class="{activeClass:subCat.permalink == activeClass}">
                                                        </a>
                                                        <a v-if="subCat.type == 'category'"
                                                            class="vd_sideheader_a callByAjax hoverClass" :id="subCat.id"
                                                            :data-subcatID="subCat.label" :target="subCat.target"
                                                            :href="'/category/'+subCat.permalink"
                                                            v-html=i18n(subCat.label)
                                                            @click="activeClass= subCat.permalink" 
                                                            :class="{activeClass:subCat.permalink == activeClass}">
                                                        </a>
                                                    </div>
                                                </template>
                                            </div>
                                        </div>
                                    </li>
                                    <li v-else class="nav-item vd_sideheader_li">
                                        <a v-if="data.type == 'web_address'"
                                            class="nav-link vd_sideheader_a callByAjax hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                            :target="data.target" :href="data.permalink" v-html=i18n(data.label)></a>

                                        <a v-if="data.type == 'page'"
                                            class="nav-link vd_sideheader_a callByAjax hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                            :target="data.target" :href="'/'+data.permalink"
                                            v-html=i18n(data.label)></a>

                                        <a v-if="data.type == 'category'"
                                            class="nav-link vd_sideheader_a callByAjax hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                            :target="data.target" :href="'/category/'+data.permalink"
                                            v-html=i18n(data.label)></a>
                                    </li>
                                </template>
                            <li class="nav-item dropdown language-item show992" vd-node="styleLang" vd-readonly="true">
                                <multilingual_four :id="$attrs['id']+'_multilingual_four_1'" />
                            </li>
                            <li class="nav-item signup p-0 show992" class="signup-login-section"
                                v-if="!userInfo && !newConfig">
                                <a class="nav-link" vd-readonly="true" vd-node="styleOnly"
                                    :href="'/sign-in'" vd-readonly="true">
                                    <vd-component-param type="label6"
                                        v-html="i18n($attrs['label6'])"></vd-component-param>
                                </a>
                            </li>

                           
                        </ul>
                    </div>
                    <div class="rightSidemenu">
                        <ul class="navbar-nav align-items-center flex-row gap-24">
                            <li class="top-search-nav vd-form search-static">
                                <div class="searchInput">
                                    <div class="si-left">
                                        <span class="si-searchicon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                viewBox="0 0 24 24" fill="none">
                                                <path
                                                    d="M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z"
                                                    stroke="white" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                                <path d="M20.9999 20.9999L16.6499 16.6499" stroke="white"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                            <span class="sil-txt hide992">Search</span>
                                        </span>
                                        <input type="text" class="si-input search-content vd-component-attr"
                                            id="search-input" vd-readonly="true"
                                            v-model="searchValue" autocomplete="off"
                                            vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9'])
                                            vd-component-attr-title="label10" :title=i18n($attrs['label10'])
                                            aria-label="Search" id="searchInput" data-aut="srch_search"
                                            @input="searchItem()" @keydown="viewContentlist($event)">
                                    </div>
                                    <span class="si-right">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            viewBox="0 0 16 16" fill="none">
                                            <path d="M12 4L4 12" stroke="white" stroke-width="1.33"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M4 4L12 12" stroke="white" stroke-width="1.33"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </span>
                                </div>

                                <template v-if="searchValue && isRes" class="search search-navigation">
                                    <ul class="dropdown-menu w-100 srchPopup searchDropdown-cont"
                                        aria-labelledby="dropdownMenuButton1" v-if="flag && (contentList || playlist)"
                                        id="subchild">
                                        <template v-if="contentList && contentList.length">
                                            <li v-for="i in contentList">
		                                 <a v-if="i?.content_epg_details?.content_uuid" class="dropdown-item callByAjax"  @click="viewSearchResultEpg(i.content_permalink,i.content_epg_details?.content_uuid)"> {{i.content_name}} </a><!-- er 101262 -->

		                                 <a v-else class="dropdown-item callByAjax" @click="viewSearchResult(i.content_permalink,i.is_playlist)"> {{i.content_name}} </a>
		                            </li>
                                        </template>
                                        <template v-if="playlist && playlist.length">
                                            <li v-for="j in playlist">
                                                <a class="dropdown-item callByAjax"
                                                    @click="viewSearchResult(j.content_permalink,j.is_playlist)">
                                                    {{j.content_name}} </a>
                                            </li>
                                        </template>
                                        <template v-if="partnerList && partnerList.length">
                                            <li v-for="k in partnerList">
                                                <a class="dropdown-item callByAjax"
                                                    @click="viewSearchProfile(k.user_uuid, 'partner')"> {{k.name}} </a>
                                            </li>
                                        </template>
                                        <template v-if="endUserList && endUserList.length">
                                            <li v-for="m in endUserList">
                                                <a class="dropdown-item callByAjax"
                                                    @click="viewSearchProfile(m.end_user_uuid, 'user')"> {{m.name}} </a>
                                            </li>
                                        </template>
                                    </ul>
                                    <ul v-if="!flag" class="dropdown-menu w-100 srch-popup show">
                                        <li>
                                            <a class="dropdown-item callByAjax"><vd-component-param type="label4"
                                                    v-html="i18n($attrs['label4'])"></vd-component-param></a>
                                        </li>
                                    </ul>
                                </template>
                            </li>
                            <li class="nav-item dropdown language-item hide992" vd-node="styleLang" vd-readonly="true">
                            <multilingual_four :id="$attrs['id']+'_multilingual_four_1'" />
                            </li>
                            <li class="nav-item signup p-0 hide992" class="signup-login-section"
                                v-if="!userInfo && !newConfig">
                                <a class="nav-link" vd-readonly="true" vd-node="styleOnly"
                                    :href="'/sign-in'" vd-readonly="true">
                                    <vd-component-param type="label6"
                                        v-html="i18n($attrs['label6'])"></vd-component-param>
                                </a>
                            </li>
                            <!-- Add Content Button (Visible if ugcEnabled is true) -->
                        <li class="nav-item nav-icon" v-if="userInfo && userProfile">
                            <a v-if="ugcEnabled" @click="openAddContentPop()" class="d-flex align-items-center" data-toggle="modal">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13.5 11.25H10.5V8.25H9V11.25H6V12.75H9V15.75H10.5V12.75H13.5V11.25Z" fill="white"></path>
                                    <path d="M15.75 19.5H3C2.6023 19.4996 2.221 19.3414 1.93978 19.0602C1.65856 18.779 1.5004 18.3977 1.5 18V6C1.5004 5.6023 1.65856 5.221 1.93978 4.93978C2.221 4.65856 2.6023 4.5004 3 4.5H15.75C16.1477 4.5004 16.529 4.65856 16.8102 4.93978C17.0914 5.221 17.2496 5.6023 17.25 6V9.04275L21.3143 6.14025C21.4263 6.06023 21.5583 6.01262 21.6957 6.00265C21.833 5.99267 21.9705 6.02071 22.093 6.0837C22.2155 6.14668 22.3182 6.24217 22.39 6.35971C22.4618 6.47724 22.4999 6.61227 22.5 6.75V17.25C22.5 17.3878 22.4621 17.5229 22.3903 17.6406C22.3186 17.7582 22.2158 17.8538 22.0933 17.9169C21.9708 17.98 21.8333 18.0081 21.6959 17.9981C21.5584 17.9882 21.4264 17.9406 21.3143 17.8605L17.25 14.958V18C17.2496 18.3977 17.0914 18.779 16.8102 19.0602C16.529 19.3414 16.1477 19.4996 15.75 19.5ZM3 6V18.0007L15.75 18V13.5C15.75 13.3622 15.7879 13.2271 15.8597 13.1094C15.9314 12.9918 16.0342 12.8962 16.1567 12.8331C16.2792 12.77 16.4167 12.7419 16.5541 12.7519C16.6916 12.7618 16.8236 12.8094 16.9357 12.8895L21 15.792V8.208L16.9357 11.1105C16.8236 11.1906 16.6916 11.2382 16.5541 11.2481C16.4167 11.2581 16.2792 11.23 16.1567 11.1669C16.0342 11.1038 15.9314 11.0082 15.8597 10.8906C15.7879 10.7729 15.75 10.6378 15.75 10.5V6H3Z" fill="white"></path>
                                </svg>
                            </a>
                        </li>
                            <li class="nav-item phoenix-nav-dropdown userProfile-nav-dropdown" v-if="userInfo && userProfile">
                            <div class="btn-navigation toggle-focus-activety border-0">
                                <button @click="openProfilePop()" type="button" class="dropdown-toggle userProfileDropdown p-0" data-toggle="dropdown" aria-expanded="true">
                                    <!-- Display main profile image when multiple profiles are disabled or no profile is selected -->
                                    <img class="profileImages img-fluid"
                                        :src="(!multiProfileIsEnable || !multiprofileClickedObj)
                                            ? (userProfile.profile_image_url || rootUrl + 'img/no-avatar.png')
                                            : multiprofileClickedObj.avatar"
                                        alt="Profile Image" />
                                </button>

                                <div class="dropdown-menu garnetMenu position-absolute">
                                    <!-- Profile List for Multiple Profiles Enabled -->
                                    <div class="gmItems"
                                        v-if="multiProfileIsEnable && getProfileList.length >= 1"
                                        v-for="data in getProfileList.filter(data => data.enduser_profile_uuid !== selectedMultipleProfileUuid && data.enduser_profile_uuid !== userProfile.enduser_profile_uuid)"
                                        @click="updateNameAndProfilePhoto(data)">
                                        <a class="callByAjax">
                                            <span class="mplla-img">
                                                <img :src="data.avatar" alt="subProfile_image" width="32" height="32"/>
                                                {{ data.profile_name }}
                                            </span>
                                        </a>
                                    </div>

                                    <!-- Manage Profile Option for Multiple Profiles Enabled -->
                                    <div class="gmItems borderTop"
                                        v-if="multiProfileIsEnable && getProfileList.length >= 1"
                                        @click="navigateTohome()">
                                        <a class="callByAjax">Manage Profile</a>
                                    </div>

                                    <!-- Additional Options: My Profile, Logout -->
                                    <div class="gmItems borderTop">
                                        <a @click="navigateprofile()">
                                            <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                                        </a>
                                    </div>

                                    <div class="gmItems borderTop">
                                        <a @click="logout()">
                                            <vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <ugc_content_upload_one id="ugcContentAdd" :key="reloadUGCPop" @contentSaveConfirm="reloadUGCPopup" />
</section>
<!--Header Section End Here-->
     
  </vd-component>
    `,
};

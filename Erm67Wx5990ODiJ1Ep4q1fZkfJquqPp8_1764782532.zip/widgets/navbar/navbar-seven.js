let { getEndUserRegdLoginSetting,
    getCategoryDetails,
    getUserDetails,
    getSearchListData,
    // getVdConfig,
    getUgcSettingStatus,
    getSearchListDataFromElastic,
    getAccountTokenDetails,
    fetchUserAndPartnersForSearch,
    getPartnerAndUserSettingDetails,
    getProfileList,
    toGetMultipleProfileToken, endUserLogOut } = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { delayCall } = await import(window.importLocalJs('widgets/navbar/search-util.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { default: ugc_content_upload_one } = await import(window.importLocalJs('widgets/ugc-content-upload/ugc-content-upload-one.js'));
let { default: multilingual_three } = await import(window.importLocalJs('widgets/multilingual/multilingual-three.js'));

const { mapState } = Vuex;

export default {
    name: "navbar_seven",
    data() {
        return {
            showLeftnav: page_searchbar,
            rootUrl: getRootUrl(),
            categoryDetails: [],
            isLogin: Boolean,
            userProfile: String,
            userInfo: String,
            profilepic: false,
            searchValue: "",
            searchData: [],
            flag: Boolean,
            isRes: Boolean,
            dropdown_toggle: "dropdown-toggle",
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            userConfig: null,
            newConfig: Boolean,
            ugcEnabled: false,
            reloadUGCPop: 1,
            contentList: [],
            playlist: [],
            partnerList: [],
            endUserList: [],
            partnerFlag: Boolean,
            endUserFlag: Boolean,
            partnerEnabled: false,
            partnerProfileEnabled: false,
            ugcProfileEnabled: false,
            activeClass: null,
            getProfileList: [],
            multiprofileClickedObj: {
                "profile_name": '',
                "enduser_profile_uuid": '',
                "avatar": ''
            },
            multiprofileClickedStatus: false,
            multiProfileIsEnable: false,
            selectedMultipleProfileUuid:'',
            content_asset_type: 2
        };
    },
    components: {
        ugc_content_upload_one,
        multilingual_three
    },
    computed: {
        ...mapState({
            logo_details: (state) => state.logo_details,
        }),      
    },

    async beforeCreate() {
        const res = await getEndUserRegdLoginSetting();
        if (res.data.code == 200 && res.data.data !== null) {
            if (res.data.data.sections[0].groups[0].nodes[2].node_value == 1) {
                this.multiProfileIsEnable = true;
            }
            localStorage.setItem("userConfig", res.data.data.sections[0].groups[0].nodes[0].node_value);
            if (localStorage.getItem("userConfig") != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
            this.isLogin = localStorage.getItem("isloggedin");
            if (this.newConfig && this.isLogin === "true") {
                this.autoLogout();
            }
        } else {
            window.location.href = "/";
        }
    },

    mounted() {
        this.addEvent();
        this.fetchUGCSettingStatus();
        //hoverClass added to anchor tag menu
        if (window.location.pathname.toString().split("/")[2]) {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[2];
        } else {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[1];
        }

        //code updated for hovercalss vd menu settings ends here
        this.searchItem = delayCall(this.searchItem);
        getCategoryDetails()
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    // res.data.data.assigned_categories.forEach((ele) => {
                    //     if (!ele.is_static) {
                    //         ele.is_static = "";
                    //     }
                    //     if (!ele.target) {
                    //         ele.target = "";
                    //     }
                    //     if (!ele.type) {
                    //         ele.type = "category";
                    //     }
                    //     if (ele.sub_menu) {
                    //         ele.sub_menu.forEach((sub) => {
                    //             if (!sub.is_static) {
                    //                 sub.is_static = "";
                    //             }
                    //             if (!sub.target) {
                    //                 sub.target = "";
                    //             }
                    //             if (!sub.type) {
                    //                 sub.type = "category";
                    //             }
                    //         });
                    //     }
                    // });
                    this.categoryDetails = res.data.data;
                }
            })
            .catch((ex) => {
                console.log(ex);
            });
        if (localStorage.getItem("isloggedin") !== undefined) {
            this.isLogin = localStorage.getItem("isloggedin");
            this.getUserMenu();
        }
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });

        var intervalId = setInterval(() => {
            this.userConfig = localStorage.getItem("userConfig");
            if (this.userConfig != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
        }, 500);
        setTimeout(() => {
            clearInterval(intervalId);
        }, 2500);
        //Multiprofile
        getProfileList().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                //console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                if (res.data.data.getProfileList.length >= 1) {
                    
                    this.getProfileList = res.data.data.getProfileList;
                    //console.log(this.getProfileList, "res.data.data.getProfileList");
                }
            }
        });
        if (localStorage.getItem('multiprofileIdClicked')) {
            this.multiprofileClickedStatus = true;
        }
        this.multiprofileClickedObj = JSON.parse(localStorage.getItem('multiprofileIdClicked'));
        if(this.multiprofileClickedObj){
           this.selectedMultipleProfileUuid =  this.multiprofileClickedObj.enduser_profile_uuid;
        }
        //alert(this.multiprofileClickedObj.profile_name);    
        //Multiprofile
    },
    watch: {
        multiprofileClickedStatus(value) {
            //localStorage.name = value;
        }
    },
    methods: {
        i18n,
        redirectCategory(link) {
            window.location.href = link;
        },
        getUserMenu() {
            if (localStorage.getItem("isloggedin") == "true") {
                this.userInfo = true;
                var userData = JSON.parse(localStorage.getItem("user"));
                this.userProfile = userData;
            } else {
                this.userInfo = false;
            }
        },
        goToMainjs: function () {
            localStorage.setItem(
                "content_uuid",
                "57bf2ddbea2049479522aceb87b324ec"
            );
        },
        getUserDetailsInfo() {
            getUserDetails().then((res) => {
                if (res.data && res.data.code == 200) {
                    this.userProfile = res.data.data.getUserDetails[0];
                    this.profilepic = true;
                }
            });
        },
        async searchItem() {
            if (this.searchValue !== "") {
                this.isRes = false;
                getSearchListData(this.searchValue, this.content_asset_type).then((res) => {
                    this.isRes = true;
                    if (
                        res.data.code === 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.flag = true;
                        //this.searchData =res.data.data.contentList.content_list;
                        this.setSearchedData(
                            res.data.data.contentList.content_list
                        );
                    } else {
                        this.flag = false;
                    }
                });
                if (this.partnerEnabled && this.partnerProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "partner",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getPartners.users_list
                        ) {
                            this.partnerFlag = true;
                            this.partnerList =
                                res.data.data.getPartners.users_list;
                        } else {
                            this.partnerFlag = false;
                            this.partnerList = [];
                        }
                    });
                }
                if (this.ugcEnabled && this.ugcProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "user",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getEndUserList.end_user_list
                        ) {
                            this.endUserFlag = true;
                            this.endUserList =
                                res.data.data.getEndUserList.end_user_list;
                        } else {
                            this.endUserFlag = false;
                            this.endUserList = [];
                        }
                    });
                }
            }
        },

        setSearchedData(searchDataList) {
            this.contentList = searchDataList.filter((element) => {
                return element.is_playlist == 0;
            });
            this.playlist = searchDataList.filter((element2) => {
                return element2.is_playlist == 1;
            });
        },

        viewContentlist(event) {
            if (event.keyCode === 13) {
                event.preventDefault();
                this.isRes = false;
                if (this.searchValue === undefined || this.searchValue == "") {
                    window.location = "/search-result/" + undefined;
                } else {
                    if (isAudioExists) {
                        getPageByAjax("/search-result/" + this.searchValue); //@ER: 74207
                    } else {
                        window.location.href =
                            "/search-result/" + this.searchValue;
                    }
                }
            }
        },
        viewSearchResult(data, isPlaylist) {
            if (isPlaylist == 1) {
                if (isAudioExists) {
                    getPageByAjax("/playlist/" + data); //@ER: 74207
                } else {
                    window.location.href = "/playlist/" + data;
                }
            } else {
                if (isAudioExists) {
                    getPageByAjax("/content/" + data); //@ER: 74207
                } else {
                    window.location.href = "/content/" + data;
                }
            }
        },
        viewSearchProfile(data, userType) {
            if (userType == "partner") {
                if (isAudioExists) {
                    getPageByAjax("/partner/" + data); //@ER: 74207
                } else {
                    window.location.href = "/partner/" + data;
                }
            } else if (userType == "user") {
                if (isAudioExists) {
                    getPageByAjax("/user/" + data); //@ER: 74207
                } else {
                    window.location.href = "/user/" + data;
                }
            }
        },
        async logout() { 
            const res = await endUserLogOut();
            if (res.data.code == 200 && res.data.status == "SUCCESS") {
                window.onbeforeunload = null;
                if (window.globalAudioPlayer && window.globalAudioPlayer.player_obj) {
                    document.getElementsByClassName("vjs-playlist")[0].remove();
                    window.globalAudioPlayer.player_obj.playlist([]);
                    window.globalAudioPlayer.player_obj.dispose();
                    delete window.globalAudioPlayer.player_obj;
                }
            } else {
                Toast.fire({
                    icon: "error",
                    title: res.data.status,
                    text: res.data.message,
                });
            }           
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            //Multiple Profile
            localStorage.removeItem("multiprofileIdClicked");
            //MultipleProfile
            $cookies.remove("token");
            $cookies.remove("isloggedin");
            this.userInfo = false;
            Toast.fire({
                icon: "success",
                title: "Signout Sucessfully",
            });
            window.location.href = "/";
        },
        navigateprofile: function () {
            window.localStorage.setItem("profile.currenttab", "profile_seven");
            if (isAudioExists) {
                getPageByAjax("/profile"); //@ER: 74207
            } else {
                window.location.href = "/profile";
            }
        },
        //MultiProfile
        updateNameAndProfilePhoto: function (data) {
            // window.localStorage.setItem("multiprofileIdClicked.profile_name", data.profile_name);
            // window.localStorage.setItem("multiprofileIdClicked.profile_uuid", data.profile_uuid);
            // window.localStorage.setItem("multiprofileIdClicked.avatar", data.avatar);
            data.selectedDate = new Date();
            window.localStorage.setItem("multiprofileIdClicked", JSON.stringify(data));
            this.multiprofileClickedStatus = true;
            this.multiprofileClickedObj = data;
            this.selectedMultipleProfileUuid = this.multiprofileClickedObj.enduser_profile_uuid;
            let payload = {
                enduser_profile_uuid: data.enduser_profile_uuid,
                enduser_maturity_rating_uuid: data.enduser_maturity_rating_uuid
            };
            if(data.enduser_maturity_rating_min_age == null || data.enduser_maturity_rating_min_age == '' || data.enduser_maturity_rating_min_age==""){
                payload['enduser_maturity_rating_min_age'] = null;
            }else{
                payload['enduser_maturity_rating_min_age']=  data.enduser_maturity_rating_min_age;

            }
            toGetMultipleProfileToken(payload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        localStorage.setItem("end_user_access_token", res.data.data.access_token);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
            $(".content-propertices").removeClass("cp-open");
            //window.location.href = '/' + this.language;
            window.location.href = "/";
        },
        navigateTohome() {
            localStorage.setItem("ManageProfileMenuClicked", true);
            //window.location.href = '/' + this.language;
            window.location.href = "/";
        },
        //MultiProfile
        fetchUGCSettingStatus() {
            getUgcSettingStatus().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "ugc") {
                                this.ugcEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                            if (element.node_code == "partner_portal") {
                                this.partnerEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    res.data.data.sections[0].groups[1].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_profile") {
                                this.ugcProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    //ER-101092 Start
                    res.data.data.sections[0].groups[2].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_regis_login") {
                                localStorage.setItem("freeContentLoginRequired", element.node_value && element.node_value == 1 ? true : false);
                            }
                        }
                    );
                    //ER-101092 End
                }
            });
            getPartnerAndUserSettingDetails().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "profile_page") {
                                this.partnerProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                }
            });
        },
        openAddContentPop() {
            setTimeout(() => {
                $("#ugcContentAdd .modal").addClass("show");
                $("#ugcContentAdd .modal").css("display", "block");
            }, 300);
        },
        //toogle menu button searach starts here
        toggleMenu() {
            $('.leftside-bar').toggleClass('showmenu');
            $('.navbar-toggler').toggleClass('menu-active');
        },
        toggleSearch() {
            $('#search-field').toggleClass('form-active');
            $('#search-field input').focus();
        },
        //toggle menu
        openProfilePop() {
            if(localStorage.getItem('multiprofileIdClicked')){
                this.selectedMultipleProfileUuid = JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
            }
            $(".content-propertices").addClass("cp-open");
            getProfileList().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    //console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                    if (res.data.data.getProfileList.length >= 1) {
                        this.getProfileList = res.data.data.getProfileList;
                        //console.log(this.getProfileList, "res.data.data.getProfileList");
                            // if (localStorage.getItem('multiprofileIdClicked')) {
                                //     this.getProfileList = res.data.data.getProfileList.filter(function (el) {
                                //     return el.enduser_profile_uuid !== JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
                            // });
                            // console.log(this.getProfileList);
                            // }
                    }
                }
            });
        },
        closeProfilePop() {
            $(".content-propertices").removeClass("cp-open");
        },
        reloadUGCPopup() {
            ++this.reloadUGCPop;
        },
        addEvent() {
            window.onclick = (evt) => {
                this.isRes = false;
            };
        },
        async autoLogout(){    
            const resp = await endUserLogOut();
            if (resp.data.code == 200 && resp.data.status == "SUCCESS") {
            } else {
                Toast.fire({
                    icon: "error",
                    title: resp.data.status,
                    text: resp.data.message,
                });
            }        
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            $cookies.remove("token");
            $cookies.remove("isloggedin");
            this.userInfo = false;
        },
        //106237-start
        removeRedirectAfterLogin() {
            if (window.localStorage.getItem("redirectAfterlogin") !== null) {
                window.localStorage.removeItem("redirectAfterlogin");
            }
        }
        //106237-end
    },
    template: `
    <vd-component class="vd navbar-seven" type="navbar-seven">
        <div class="top-bar aboutNav" vd-node="header" vd-readonly="true" class="header">
            <div class="row no-gutters align-items-center justify-content-between">
                <div class="col-auto logoImage">
                    <a v-if="logo_details['logo']" class="navbar-brand callByAjax" href="/"><img vd-node="logo" vd-readonly="true" :src="logo_details['logo']['src']" :alt="logo_details['logo']['alt']" :style="logo_details['logo']['style']"/></a>
					<a v-else-if="logo_details['logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="logo" vd-readonly="true" :src="rootUrl+'img/logo.png'" alt="Symphony" /></a>
                </div>
                <div class="col-auto pl-0">
                    <div class="row no-gutters" v-if="showLeftnav">
                        <div class="col-auto">
                            <ul class="next-prev">
                                <li class="vd-no-navigation">
                                    <a  onclick="history.back()" class="callByAjax">
                                        <svg width="25" height="8" viewBox="0 0 25 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0.646447 3.64645C0.451184 3.84171 0.451184 4.15829 0.646447 4.35355L3.82843 7.53553C4.02369 7.7308 4.34027 7.7308 4.53553 7.53553C4.7308 7.34027 4.7308 7.02369 4.53553 6.82843L1.70711 4L4.53553 1.17157C4.7308 0.976311 4.7308 0.659728 4.53553 0.464466C4.34027 0.269204 4.02369 0.269204 3.82843 0.464466L0.646447 3.64645ZM1 4.5H25V3.5H1V4.5Z" fill="#7A7C7F"/>
                                        </svg>                            
                                    </a>
                                </li>
                                <li class="vd-no-navigation">
                                    <a onclick="history.forward()" class="callByAjax">
                                        <svg width="25" height="8" viewBox="0 0 25 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M24.3536 3.64645C24.5488 3.84171 24.5488 4.15829 24.3536 4.35355L21.1716 7.53553C20.9763 7.7308 20.6597 7.7308 20.4645 7.53553C20.2692 7.34027 20.2692 7.02369 20.4645 6.82843L23.2929 4L20.4645 1.17157C20.2692 0.976311 20.2692 0.659728 20.4645 0.464466C20.6597 0.269204 20.9763 0.269204 21.1716 0.464466L24.3536 3.64645ZM24 4.5H0V3.5H24V4.5Z" fill="#7A7C7F"/>
                                        </svg>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-auto">
                            <div class="search-box d-none d-md-block user-srch-input vd-form" >
                                <form class="form-inline">
                                    <input vd-readonly="true" type="search" class="form-control top-search-nav vd-component-attr" autocomplete="off" v-model="searchValue" vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9']) vd-component-attr-title="label10" :title=i18n($attrs['label10']) aria-label="Search" id="searchInput" data-aut="srch_search" @input="searchItem()" @keydown="viewContentlist($event)">
                                    <div class="form-icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M6.66853 1.83337C7.58193 1.83326 8.47666 2.09197 9.24905 2.57952C10.0214 3.06707 10.6399 3.7635 11.0327 4.58812C11.4255 5.41274 11.5766 6.33179 11.4685 7.23876C11.3604 8.14574 10.9975 9.00352 10.4219 9.71271L13.6885 12.9794C13.7782 13.0685 13.8308 13.1883 13.8358 13.3146C13.8407 13.4409 13.7976 13.5644 13.7151 13.6603C13.6326 13.7561 13.5169 13.8171 13.3913 13.831C13.2656 13.845 13.1393 13.8108 13.0379 13.7354L12.9819 13.6867L9.71453 10.42C9.11378 10.9075 8.40482 11.2435 7.64721 11.4001C6.88961 11.5566 6.1055 11.529 5.36078 11.3196C4.61606 11.1101 3.9325 10.725 3.36753 10.1965C2.80256 9.66806 2.37269 9.0117 2.11406 8.28261C1.85542 7.55351 1.77557 6.77299 1.88122 6.00663C1.98687 5.24028 2.27493 4.51047 2.72119 3.87856C3.16745 3.24664 3.75888 2.73108 4.44576 2.37519C5.13265 2.0193 5.89492 1.83349 6.66853 1.83337ZM6.66853 2.83337C6.16513 2.83337 5.66666 2.93253 5.20158 3.12517C4.7365 3.31781 4.31391 3.60017 3.95795 3.95613C3.602 4.31209 3.31963 4.73467 3.12699 5.19975C2.93435 5.66484 2.8352 6.16331 2.8352 6.66671C2.8352 7.17011 2.93435 7.66858 3.12699 8.13366C3.31963 8.59874 3.602 9.02132 3.95795 9.37728C4.31391 9.73324 4.7365 10.0156 5.20158 10.2082C5.66666 10.4009 6.16513 10.5 6.66853 10.5C7.68519 10.5 8.66022 10.0962 9.3791 9.37728C10.098 8.65839 10.5019 7.68337 10.5019 6.66671C10.5019 5.65004 10.098 4.67502 9.3791 3.95613C8.66022 3.23724 7.68519 2.83337 6.66853 2.83337Z" fill="#7A7C7F"/>
                                        </svg>                                
                                    </div>
                                </form>
                                <template v-if="searchValue && isRes" class="search search-navigation">
                                    <ul class="dropdown-menu w-100 srch-popup show" v-if="flag && (contentList || playlist)">
                                        <template v-if="contentList && contentList.length">
                                            <li class="srch-drop-title pb-4"><a class="dropdown-item" href="#">
                                            <vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param>
                                            </a></li>
                                            
                                            <li v-for="i in contentList">
                                                <a class="dropdown-item truncate-text lc-one callByAjax"  @click="viewSearchResult(i.content_permalink,i.is_playlist)"> {{i.content_name}} </a>
                                            </li>
                                        </template>

                                        <template v-if="playlist && playlist.length">
                                            
                                            <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                            <vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param>
                                            </a></li>
                                            
                                            <li v-for="j in playlist">
                                                <a class="dropdown-item truncate-text lc-one callByAjax"  @click="viewSearchResult(j.content_permalink,j.is_playlist)"> {{j.content_name}} </a>
                                            </li>
                                        </template>
                                        <template v-if="partnerList && partnerList.length">
                                            <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                            <vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                                            </a></li>
                                            <li v-for="k in partnerList">
                                                <a class="dropdown-item truncate-text lc-one callByAjax" @click="viewSearchProfile(k.user_uuid, 'partner')" > {{k.name}} </a>
                                            </li>
                                        </template>
                                        <template v-if="endUserList && endUserList.length">
                                            <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                            <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                                             </a></li>
                                            <li v-for="m in endUserList">
                                                <a class="dropdown-item truncate-text lc-one callByAjax" @click="viewSearchProfile(m.end_user_uuid, 'user')" > {{m.name}} </a>
                                            </li>
                                        </template>
                                    </ul>
                                    <ul v-if="!flag"  class="dropdown-menu w-100 srch-popup show" >
                                        <li>
                                        <a class="dropdown-item truncate-text lc-one callByAjax"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></a>
                                        </li>
                                    </ul>                
                                </template>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="row no-gutters align-items-center">
                        <div class="col-auto d-md-none">
                            <span  @click="toggleSearch()" class="nav-link d-flex align-items-center" id="search-btn">
                                <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M7.25 13.6984C10.5637 13.6984 13.25 10.9505 13.25 7.56087C13.25 4.17121 10.5637 1.42334 7.25 1.42334C3.93629 1.42334 1.25 4.17121 1.25 7.56087C1.25 10.9505 3.93629 13.6984 7.25 13.6984Z" stroke="#555578" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M14.7507 15.2328L11.4883 11.8955" stroke="#555578" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg> 
                                <form id="search-field" class="search-field1" action="">
                                    <input vd-readonly="true" v-model="searchValue" data-aut="srch_search" @input="searchItem()" @keydown="viewContentlist($event)" type="search" placeholder="Search" autocomplete="off" name="search" class="form-control" required="" value="">
                                   <template v-if="searchValue && isRes" class="search search-navigation">
                                        <ul class="dropdown-menu w-100 srch-popup show" v-if="flag && (contentList || playlist)">
                                            <template v-if="contentList && contentList.length">
                                                <li class="srch-drop-title pb-4"><a class="dropdown-item" href="#">
                                                <vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param>
                                                </a></li>
                                                
                                                <li v-for="i in contentList">
                                                    <a class="dropdown-item truncate-text lc-one callByAjax"  @click="viewSearchResult(i.content_permalink,i.is_playlist)"> {{i.content_name}} </a>
                                                </li>
                                            </template>

                                            <template v-if="playlist && playlist.length">
                                                
                                                <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                                <vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param>
                                                </a></li>
                                                
                                                <li v-for="j in playlist">
                                                    <a class="dropdown-item truncate-text lc-one callByAjax"  @click="viewSearchResult(j.content_permalink,j.is_playlist)"> {{j.content_name}} </a>
                                                </li>
                                            </template>
                                            <template v-if="partnerList && partnerList.length">
                                                <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                                <vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                                                </a></li>
                                                <li v-for="k in partnerList">
                                                    <a class="dropdown-item truncate-text lc-one callByAjax" @click="viewSearchProfile(k.user_uuid, 'partner')" > {{k.name}} </a>
                                                </li>
                                            </template>
                                            <template v-if="endUserList && endUserList.length">
                                                <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                                <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                                                </a></li>
                                                <li v-for="m in endUserList">
                                                    <a class="dropdown-item truncate-text lc-one callByAjax" @click="viewSearchProfile(m.end_user_uuid, 'user')" > {{m.name}} </a>
                                                </li>
                                            </template>
                                        </ul>
                                        <ul v-if="!flag"  class="dropdown-menu w-100 srch-popup show" >
                                            <li>
                                            <a class="dropdown-item truncate-text lc-one callByAjax"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></a>
                                            </li>
                                        </ul>   
                                    </template>
                                </form>
                            </span>
                        </div>
                        <div class="col-auto language-item">
                            <multilingual_three :id="$attrs['id']+'_multilingual_three_3'"/> 
                        </div>
                        <div class="col-auto language-item" v-if="userInfo && userProfile">
                            <a v-if="ugcEnabled" @click="openAddContentPop()" class="d-flex align-items-center" data-toggle="modal" data-target="#ugcContentAdd">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.5 11.25H10.5V8.25H9V11.25H6V12.75H9V15.75H10.5V12.75H13.5V11.25Z" fill="white"></path>
                                <path d="M15.75 19.5H3C2.6023 19.4996 2.221 19.3414 1.93978 19.0602C1.65856 18.779 1.5004 18.3977 1.5 18V6C1.5004 5.6023 1.65856 5.221 1.93978 4.93978C2.221 4.65856 2.6023 4.5004 3 4.5H15.75C16.1477 4.5004 16.529 4.65856 16.8102 4.93978C17.0914 5.221 17.2496 5.6023 17.25 6V9.04275L21.3143 6.14025C21.4263 6.06023 21.5583 6.01262 21.6957 6.00265C21.833 5.99267 21.9705 6.02071 22.093 6.0837C22.2155 6.14668 22.3182 6.24217 22.39 6.35971C22.4618 6.47724 22.4999 6.61227 22.5 6.75V17.25C22.5 17.3878 22.4621 17.5229 22.3903 17.6406C22.3186 17.7582 22.2158 17.8538 22.0933 17.9169C21.9708 17.98 21.8333 18.0081 21.6959 17.9981C21.5584 17.9882 21.4264 17.9406 21.3143 17.8605L17.25 14.958V18C17.2496 18.3977 17.0914 18.779 16.8102 19.0602C16.529 19.3414 16.1477 19.4996 15.75 19.5ZM3 6V18.0007L15.75 18V13.5C15.75 13.3622 15.7879 13.2271 15.8597 13.1094C15.9314 12.9918 16.0342 12.8962 16.1567 12.8331C16.2792 12.77 16.4167 12.7419 16.5541 12.7519C16.6916 12.7618 16.8236 12.8094 16.9357 12.8895L21 15.792V8.208L16.9357 11.1105C16.8236 11.1906 16.6916 11.2382 16.5541 11.2481C16.4167 11.2581 16.2792 11.23 16.1567 11.1669C16.0342 11.1038 15.9314 11.0082 15.8597 10.8906C15.7879 10.7729 15.75 10.6378 15.75 10.5V6H3Z" fill="white"></path>
                                </svg> 
                            </a>
                        </div>
                        <div class="col-auto" v-if="!userInfo && !newConfig">
                            <div class="form-inline my-2 my-lg-0 aboutNav top-bar-form pl-15">
                                <a class="sign-in" vd-readonly="true" vd-node="styleOnly" href="/sign-in" @click="removeRedirectAfterLogin()">
                                    <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                                </a>
                                <a class="sign-up" vd-readonly="true" vd-node="styleOnly" href="/sign-up" @click="removeRedirectAfterLogin()">
                                    <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                                </a>
                            </div>
                        </div>
                        <template v-if="userInfo && userProfile">
                        <div class="col-auto" vd-node="accountSetting">
                            <div class="dropdown">
                                <button @click="openProfilePop()" class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img class="profileImages profile-sm-image" v-if="userProfile.profile_image_url == '' && !multiprofileClickedObj"
                                        :src="rootUrl +'img/no-avatar.png'" alt="" />
                                    <img class="profileImages profile-sm-image" v-else-if="userProfile.profile_image_url !== '' && !multiprofileClickedObj"
                                        :src="userProfile.profile_image_url" alt="" />
                                    <img class="profileImages profile-sm-image" v-else
                                        :src="multiprofileClickedObj.avatar" alt="" />
                                    <span class="profileName" id="userProfileName" v-if="multiprofileClickedObj">{{multiprofileClickedObj.profile_name}}</span>
                                    <span class="profileName" id="userProfileName" v-else>{{userProfile.name.slice(0,12)}}</span>
                                </button>
                                <div class="dropdown-menu dropdownMenu" aria-labelledby="dropdownMenuButton" @click="closeProfilePop">
                                    <a class="dropdown-item callByAjax" v-if="getProfileList.length >= 1 && multiProfileIsEnable" v-for="data in getProfileList.filter(data => data.enduser_profile_uuid !== selectedMultipleProfileUuid)" @click="updateNameAndProfilePhoto(data)">
                                        <span class="mplla-img">
                                            <img :src="data.avatar" alt="subProfile_image"/>
                                            {{data.profile_name}}
                                        </span>
                                    </a>
                                    <a class="dropdown-item callByAjax" v-if="getProfileList.length >= 1 && multiProfileIsEnable" @click="navigateTohome()">Manage Profile</a>
                                  <a class="dropdown-item" @click="navigateprofile()"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></a>
                                  <a class="dropdown-item"  @click="logout()"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></a>
                                </div>
                            </div>
                        </div>
                         </template>
                        <div class="col-auto">
                            <button @click="toggleMenu()" class="navbar-toggler collapsed" type="button" >
                                <span></span>
                                <span></span>
                                <span></span>
                              </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </vd-component>
    `,
};

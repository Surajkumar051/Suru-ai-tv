let { getEndUserRegdLoginSetting,
    getCategoryDetails,
    getUserDetails,
    getSearchListData,
    // getVdConfig,
    getUgcSettingStatus,
    getSearchListDataFromElastic,
    getAccountTokenDetails,
    fetchUserAndPartnersForSearch,
    getPartnerAndUserSettingDetails,
    getFavouriteSettingStatus,
    getProfileList,
    toGetMultipleProfileToken, endUserLogOut } = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { delayCall } = await import(window.importLocalJs('widgets/navbar/search-util.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { default: ugc_content_upload_one } = await import(window.importLocalJs('widgets/ugc-content-upload/ugc-content-upload-one.js'));
let { default: multilingual_one } = await import(window.importLocalJs('widgets/multilingual/multilingual-one.js'));

const { mapState } = Vuex;

export default {
    name: "navbar_six",
    data() {
        return {
            rootUrl: getRootUrl(),
            categoryDetails: [],
            isLogin: Boolean,
            userProfile: String,
            userInfo: String,
            profilepic: false,
            searchValue: "",
            searchData: [],
            flag: Boolean,
            isRes: Boolean,
            dropdown_toggle: "dropdown-toggle",
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            userConfig: null,
            newConfig: Boolean,
            ugcEnabled: false,
            reloadUGCPop: 1,
            contentList: [],
            playlist: [],
            partnerList: [],
            endUserList: [],
            partnerFlag: Boolean,
            endUserFlag: Boolean,
            partnerEnabled: false,
            partnerProfileEnabled: false,
            ugcProfileEnabled: false,
            activeClass: null,
            getProfileList: [],
            multiprofileClickedObj: {
                "profile_name": '',
                "enduser_profile_uuid": '',
                "avatar": ''
            },
            multiprofileClickedStatus: false,
            multiProfileIsEnable: false,
            selectedMultipleProfileUuid:'',
            favouriteEnabled: false,
        };
    },
    components: {
        ugc_content_upload_one,
        multilingual_one
    },
    computed: {
        ...mapState({
            logo_details: (state) => state.logo_details,
        }),      
    },

    async beforeCreate() {
        const res = await getEndUserRegdLoginSetting();
        if (res.data.code == 200 && res.data.data !== null) {
            if (res.data.data.sections[0].groups[0].nodes[2].node_value == 1) {
                this.multiProfileIsEnable = true;
            }
            localStorage.setItem("userConfig", res.data.data.sections[0].groups[0].nodes[0].node_value);
            if (localStorage.getItem("userConfig") != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
            this.isLogin = localStorage.getItem("isloggedin");
            if (this.newConfig && this.isLogin === "true") {
                this.autoLogout();
            }
        } else {
            window.location.href = "/";
        }
    },

    mounted() {
        this.getFavouriteSettingStatus();
        this.addEvent();
        this.fetchUGCSettingStatus();
        //hoverClass added to anchor tag menu
        if (window.location.pathname.toString().split("/")[2]) {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[2];
        } else {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[1];
        }
        this.fetchUGCSettingStatus();

        //code updated for hovercalss vd menu settings ends here
        this.searchItem = delayCall(this.searchItem);
        getCategoryDetails()
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    // res.data.data.assigned_categories.forEach((ele) => {
                    //     if (!ele.is_static) {
                    //         ele.is_static = "";
                    //     }
                    //     if (!ele.target) {
                    //         ele.target = "";
                    //     }
                    //     if (!ele.type) {
                    //         ele.type = "category";
                    //     }
                    //     if (ele.sub_menu) {
                    //         ele.sub_menu.forEach((sub) => {
                    //             if (!sub.is_static) {
                    //                 sub.is_static = "";
                    //             }
                    //             if (!sub.target) {
                    //                 sub.target = "";
                    //             }
                    //             if (!sub.type) {
                    //                 sub.type = "category";
                    //             }
                    //         });
                    //     }
                    // });
                    this.categoryDetails = res.data.data;
                }
            })
            .catch((ex) => {
                console.log(ex);
            });
        if (localStorage.getItem("isloggedin") !== undefined) {
            this.isLogin = localStorage.getItem("isloggedin");
            this.getUserMenu();
        }
        // getVdConfig("logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             this.isLogoUpdated = true;
        //             this.logo_alt = res.data.data.alt;
        //             this.logo_src = res.data.data.src;
        //             this.logo_style = res.data.data.style;
        //         } else {
        //             this.isLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });

        var intervalId = setInterval(() => {
            this.userConfig = localStorage.getItem("userConfig");
            if (this.userConfig != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
        }, 500);
        setTimeout(() => {
            clearInterval(intervalId);
        }, 2500);
        //Multiprofile
        getProfileList().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                //console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                if (res.data.data.getProfileList.length >= 1) {
                    
                    this.getProfileList = res.data.data.getProfileList;
                    //console.log(this.getProfileList, "res.data.data.getProfileList");
                }
            }
        });
        if (localStorage.getItem('multiprofileIdClicked')) {
            this.multiprofileClickedStatus = true;
        }
        this.multiprofileClickedObj = JSON.parse(localStorage.getItem('multiprofileIdClicked'));
        if(this.multiprofileClickedObj){
           this.selectedMultipleProfileUuid =  this.multiprofileClickedObj.enduser_profile_uuid;
        }
        //alert(this.multiprofileClickedObj.profile_name);    
        //Multiprofile
    },
    watch: {
        multiprofileClickedStatus(value) {
            //localStorage.name = value;
        }
    },
    methods: {
        i18n,
        getFavouriteSettingStatus() {
            getFavouriteSettingStatus().then((resp) => {
                console.log(resp.data.data.contentSettings);
                if (
                    resp.data.code === 200 &&
                    resp.data.data.contentSettings.content_favourite_settings
                ) {
                    this.favouriteEnabled =
                        resp.data.data.contentSettings.content_favourite_settings.is_enabled;
                }
            });
        },
        redirectCategory(link) {
            window.location.href = link;
        },
        getUserMenu() {
            if (localStorage.getItem("isloggedin") == "true") {
                this.userInfo = true;
                var userData = JSON.parse(localStorage.getItem("user"));
                this.userProfile = userData;
            } else {
                this.userInfo = false;
            }
        },
        goToMainjs: function () {
            localStorage.setItem(
                "content_uuid",
                "57bf2ddbea2049479522aceb87b324ec"
            );
        },
        getUserDetailsInfo() {
            getUserDetails().then((res) => {
                if (res.data && res.data.code == 200) {
                    this.userProfile = res.data.data.getUserDetails[0];
                    this.profilepic = true;
                }
            });
        },
        async searchItem() {
            if (this.searchValue !== "") {
                this.isRes = false;
                getSearchListData(this.searchValue).then((res) => {
                    this.isRes = true;
                    if (
                        res.data.code === 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.flag = true;
                        //this.searchData =res.data.data.contentList.content_list;
                        this.setSearchedData(
                            res.data.data.contentList.content_list
                        );
                    } else {
                        this.flag = false;
                    }
                });
                if (this.partnerEnabled && this.partnerProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "partner",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getPartners.users_list
                        ) {
                            this.partnerFlag = true;
                            this.partnerList =
                                res.data.data.getPartners.users_list;
                        } else {
                            this.partnerFlag = false;
                            this.partnerList = [];
                        }
                    });
                }
                if (this.ugcEnabled && this.ugcProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "user",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getEndUserList.end_user_list
                        ) {
                            this.endUserFlag = true;
                            this.endUserList =
                                res.data.data.getEndUserList.end_user_list;
                        } else {
                            this.endUserFlag = false;
                            this.endUserList = [];
                        }
                    });
                }
            }
        },

        setSearchedData(searchDataList) {
            this.contentList = searchDataList.filter((element) => {
                return element.is_playlist == 0;
            });
            this.playlist = searchDataList.filter((element2) => {
                return element2.is_playlist == 1;
            });
        },

        viewContentlist(event) {
            if (event.keyCode === 13) {
                event.preventDefault();
                this.isRes = false;
                if (this.searchValue === undefined || this.searchValue == "") {
                    window.location = "/search-result/" + undefined;
                } else {
                    if (isAudioExists) {
                        getPageByAjax("/search-result/" + this.searchValue); //@ER: 74207
                    } else {
                        window.location.href =
                            "/search-result/" + this.searchValue;
                    }
                }
            }
        },
        viewSearchResult(data, isPlaylist) {
            if (isPlaylist == 1) {
                if (isAudioExists) {
                    getPageByAjax("/playlist/" + data); //@ER: 74207
                } else {
                    window.location.href = "/playlist/" + data;
                }
            } else {
                if (isAudioExists) {
                    getPageByAjax("/content/" + data); //@ER: 74207
                } else {
                    window.location.href = "/content/" + data;
                }
            }
        },
        viewSearchProfile(data, userType) {
            if (userType == "partner") {
                if (isAudioExists) {
                    getPageByAjax("/partner/" + data); //@ER: 74207
                } else {
                    window.location.href = "/partner/" + data;
                }
            } else if (userType == "user") {
                if (isAudioExists) {
                    getPageByAjax("/user/" + data); //@ER: 74207
                } else {
                    window.location.href = "/user/" + data;
                }
            }
        },
        async logout() { 
            const res = await endUserLogOut();
            if (res.data.code == 200 && res.data.status == "SUCCESS") {
                window.onbeforeunload = null;
                if (window.globalAudioPlayer && window.globalAudioPlayer.player_obj) {
                    document.getElementsByClassName("vjs-playlist")[0].remove();
                    window.globalAudioPlayer.player_obj.playlist([]);
                    window.globalAudioPlayer.player_obj.dispose();
                    delete window.globalAudioPlayer.player_obj;
                }
            } else {
                Toast.fire({
                    icon: "error",
                    title: res.data.status,
                    text: res.data.message,
                });
            }           
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            //Multiple Profile
            localStorage.removeItem("multiprofileIdClicked");
            //MultipleProfile
            $cookies.remove("token");
            $cookies.remove("isloggedin");

            this.userInfo = false;
            Toast.fire({
                icon: "success",
                title: "Signout Sucessfully",
            });
            window.location.href = "/";
        },
        navigateprofile: function () {
            window.localStorage.setItem("profile.currenttab", "profile_seven");
            if (isAudioExists) {
                getPageByAjax("/profile"); //@ER: 74207
            } else {
                window.location.href = "/profile";
            }
        },
        //MultiProfile
        updateNameAndProfilePhoto: function (data) {
            // window.localStorage.setItem("multiprofileIdClicked.profile_name", data.profile_name);
            // window.localStorage.setItem("multiprofileIdClicked.profile_uuid", data.profile_uuid);
            // window.localStorage.setItem("multiprofileIdClicked.avatar", data.avatar);
            data.selectedDate = new Date();
            window.localStorage.setItem("multiprofileIdClicked", JSON.stringify(data));
            this.multiprofileClickedStatus = true;
            this.multiprofileClickedObj = data;
            this.selectedMultipleProfileUuid = this.multiprofileClickedObj.enduser_profile_uuid;
            let payload = {
                enduser_profile_uuid: data.enduser_profile_uuid,
                enduser_maturity_rating_uuid: data.enduser_maturity_rating_uuid
            };
            if(data.enduser_maturity_rating_min_age == null || data.enduser_maturity_rating_min_age == '' || data.enduser_maturity_rating_min_age==""){
                payload['enduser_maturity_rating_min_age'] = null;
            }else{
                payload['enduser_maturity_rating_min_age']=  data.enduser_maturity_rating_min_age;

            }
            toGetMultipleProfileToken(payload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        localStorage.setItem("end_user_access_token", res.data.data.access_token);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
            $(".content-propertices").removeClass("cp-open");
            //window.location.href = '/' + this.language;
            window.location.href = "/";
        },
        navigateTohome() {
            localStorage.setItem("ManageProfileMenuClicked", true);
            //window.location.href = '/' + this.language;
            window.location.href = "/";
        },
        //MultiProfile
        fetchUGCSettingStatus() {
            getUgcSettingStatus().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "ugc") {
                                this.ugcEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                            if (element.node_code == "partner_portal") {
                                this.partnerEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    res.data.data.sections[0].groups[1].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_profile") {
                                this.ugcProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    //ER-101092 Start
                    res.data.data.sections[0].groups[2].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_regis_login") {
                                localStorage.setItem("freeContentLoginRequired", element.node_value && element.node_value == 1 ? true : false);
                            }
                        }
                    );
                    //ER-101092 End
                }
            });
            getPartnerAndUserSettingDetails().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "profile_page") {
                                this.partnerProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                }
            });
        },
        openAddContentPop() {
            setTimeout(() => {
                $("#ugcContentAdd .modal").addClass("show");
                $("#ugcContentAdd .modal").css("display", "block");
            }, 300);
        },
        //toogle menu button searach starts here
        toggleMenu() {
            //$('.navbar-toggler').on('click', function () {
            $('.leftside-bar').toggleClass('showmenu');
            $('.navbar-toggler').toggleClass('menu-active');
            //})
        },
        toggleSearch() {
            $('#search-field').toggleClass('form-active');
            $('#search-field input').focus();
        },
        //toggle menu button searach starts here
        openProfilePop() {
            if(localStorage.getItem('multiprofileIdClicked')){
                this.selectedMultipleProfileUuid = JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
            }
            $(".content-propertices").addClass("cp-open");
            getProfileList().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    //console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                    if (res.data.data.getProfileList.length >= 1) {
                        this.getProfileList = res.data.data.getProfileList;
                        //console.log(this.getProfileList, "res.data.data.getProfileList");
                            // if (localStorage.getItem('multiprofileIdClicked')) {
                                //     this.getProfileList = res.data.data.getProfileList.filter(function (el) {
                                //     return el.enduser_profile_uuid !== JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
                            // });
                            // console.log(this.getProfileList);
                            // }
                    }
                }
            });
        },
        closeProfilePop() {
            $(".content-propertices").removeClass("cp-open");
        },
        reloadUGCPopup() {
            ++this.reloadUGCPop;
        },
        addEvent() {
            window.onclick = (evt) => {
                this.isRes = false;
            };
        },
        toggleLeftMenu() {
            $('.submenu-toggle').toggleClass('open');
            $('.submenu').toggleClass('open');
        },
        toggleMoreMenu () {
            $('.moremenu-toggle').toggleClass('open');
            $('.moremenu').toggleClass('open');
        },
        async autoLogout(){    
            const resp = await endUserLogOut();
            if (resp.data.code == 200 && resp.data.status == "SUCCESS") {
            } else {
                Toast.fire({
                    icon: "error",
                    title: resp.data.status,
                    text: resp.data.message,
                });
            }        
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            $cookies.remove("token");
            $cookies.remove("isloggedin");

            this.userInfo = false;
        },
        //106237-start
        removeRedirectAfterLogin() {
            if (window.localStorage.getItem("redirectAfterlogin") !== null) {
                window.localStorage.removeItem("redirectAfterlogin");
            }
        }
        //106237-end
    },
    template: `
    <vd-component class="vd navbar-six" type="navbar-six">
         <div class="leftside-bar pt-36">
            <div class="links-wraper">
                <h4><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h4>
                <ul class="" vd-node="menu" vd-readonly="true">
                    <template v-if="categoryDetails.length > 5">
                        <template v-for="data in categoryDetails.slice(0, 5)">
                            <li class="vd_sideheader_li"
                                v-if="data.sub_menu != null && data.sub_menu.length > 0">
                                <div class="submenu-div vd_submenu_div">
                                    <a v-if="data.type == 'web_address'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax" 
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                        :id="data.id" :target="data.target"
                                        :href="data.permalink" v-html=i18n(data.label)></a>

                                    <a v-if="data.type == 'page'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax"
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                        :id="data.id" :target="data.target"
                                        :href="'/'+data.permalink" v-html=i18n(data.label)></a>

                                    <a v-if="data.type == 'category'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax"
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                        :id="data.id" :target="data.target"
                                        :href="'/category/'+data.permalink" v-html=i18n(data.label)></a>
                                    <span class="submenu-toggle-button open-submenu" @click="toggleLeftMenu()">
                                        <svg class="plus" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M4.33594 9.66927V5.66927H0.335938V4.33594H4.33594V0.335938H5.66927V4.33594H9.66927V5.66927H5.66927V9.66927H4.33594Z" fill="#5C5F62"/>
                                        </svg>
                                        <svg class="minus" width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M6.82653 7.77124L3.9981 4.94281L1.16967 7.77124L0.226865 6.82843L3.05529 4L0.226865 1.17157L1.16967 0.228764L3.9981 3.05719L6.82653 0.228763L7.76934 1.17157L4.94091 4L7.76934 6.82843L6.82653 7.77124Z" fill="#5C5F62"/>
                                        </svg>
                                    </span>    
                                </div>
                                <template v-for="subCat in data.sub_menu">
                                    <ul class="submenu">
                                        <li><a v-if="subCat.type == 'web_address'" class="vd_sideheader_a callByAjax" :id="subCat.id"
                                        :data-subcatID="subCat.label" :target="subCat.target"
                                        :href="subCat.permalink" v-html=i18n(subCat.label)></a></li>
                                        <li><a v-if="subCat.type == 'page'" class="vd_sideheader_a callByAjax" :id="subCat.id"
                                        :data-subcatID="subCat.label" :target="subCat.target"
                                        :href="'/'+subCat.permalink" v-html=i18n(subCat.label)></a></li>
                                        <li><a v-if="subCat.type == 'category'" class="vd_sideheader_a callByAjax" :id="subCat.id"
                                        :data-subcatID="subCat.label" :target="subCat.target"
                                        :href="'/category/'+subCat.permalink" v-html=i18n(subCat.label)></a></li>
                                    </ul>
                                </template>
                            </li>
                            <li v-else class="vd_sideheader_li">
                                <a v-if="data.type == 'web_address'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                    @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                    :href="data.permalink" v-html=i18n(data.label)></a>
                        
                                <a v-if="data.type == 'page'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                    @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                    :href="'/'+data.permalink" v-html=i18n(data.label)></a>
                        
                                <a v-if="data.type == 'category'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                    @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                    :href="'/category/'+data.permalink" v-html=i18n(data.label)></a>
                            </li>
                        </template>
                        <li class="vd_sideheader_li" > 
                    
                                    
                        
                                <a class="submenu-div vd_submenu_div more-btn hoverClass" @click="toggleMoreMenu()">
                        More
                                          <span class="submenu-toggle-button open-submenu moremenu-toggle">
                                        <svg class="plus" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M4.33594 9.66927V5.66927H0.335938V4.33594H4.33594V0.335938H5.66927V4.33594H9.66927V5.66927H5.66927V9.66927H4.33594Z" fill="#5C5F62"/>
                                        </svg>
                                        <svg class="minus" width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M6.82653 7.77124L3.9981 4.94281L1.16967 7.77124L0.226865 6.82843L3.05529 4L0.226865 1.17157L1.16967 0.228764L3.9981 3.05719L6.82653 0.228763L7.76934 1.17157L4.94091 4L7.76934 6.82843L6.82653 7.77124Z" fill="#5C5F62"/>
                                        </svg>
                                    </span> 
                                </a>
                                 <ul class="submenu moremenu">
                                 <template v-for="data in categoryDetails.slice(5)">
                                                        <a v-if="data.type == 'web_address'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax" 
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                        :id="data.id" :target="data.target"
                                        :href="data.permalink" v-html=i18n(data.label)></a>

                                    <a v-if="data.type == 'page'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax"
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                        :id="data.id" :target="data.target"
                                        :href="'/'+data.permalink" v-html=i18n(data.label)></a>

                                    <a v-if="data.type == 'category'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax"
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                        :id="data.id" :target="data.target"
                                        :href="'/category/'+data.permalink" v-html=i18n(data.label)></a>
                                        </template>
                                        </ul>
                                
                            </li>
                    </template>  
                    <template v-else>
                        <template v-for="data in categoryDetails">
                                <li class="vd_sideheader_li"
                                    v-if="data.sub_menu != null && data.sub_menu.length > 0">
                                    <div class="submenu-div vd_submenu_div">
                                        <a v-if="data.type == 'web_address'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax" 
                                            @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                            :id="data.id" :target="data.target"
                                            :href="data.permalink" v-html=i18n(data.label)></a>

                                        <a v-if="data.type == 'page'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax"
                                            @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                            :id="data.id" :target="data.target"
                                            :href="'/'+data.permalink" v-html=i18n(data.label)></a>

                                        <a v-if="data.type == 'category'" class="submenu-toggle hoverClass vd_sideheader_a callByAjax"
                                            @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}"
                                            :id="data.id" :target="data.target"
                                            :href="'/category/'+data.permalink" v-html=i18n(data.label)></a>
                                        <span class="submenu-toggle-button open-submenu" @click="toggleLeftMenu()">
                                            <svg class="plus" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M4.33594 9.66927V5.66927H0.335938V4.33594H4.33594V0.335938H5.66927V4.33594H9.66927V5.66927H5.66927V9.66927H4.33594Z" fill="#5C5F62"/>
                                            </svg>
                                            <svg class="minus" width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M6.82653 7.77124L3.9981 4.94281L1.16967 7.77124L0.226865 6.82843L3.05529 4L0.226865 1.17157L1.16967 0.228764L3.9981 3.05719L6.82653 0.228763L7.76934 1.17157L4.94091 4L7.76934 6.82843L6.82653 7.77124Z" fill="#5C5F62"/>
                                            </svg>
                                        </span>    
                                    </div>
                                    <template v-for="subCat in data.sub_menu">
                                        <ul class="submenu">
                                            <li><a v-if="subCat.type == 'web_address'" class="vd_sideheader_a callByAjax" :id="subCat.id"
                                            :data-subcatID="subCat.label" :target="subCat.target"
                                            :href="subCat.permalink" v-html=i18n(subCat.label)></a></li>
                                            <li><a v-if="subCat.type == 'page'" class="vd_sideheader_a callByAjax" :id="subCat.id"
                                            :data-subcatID="subCat.label" :target="subCat.target"
                                            :href="'/'+subCat.permalink" v-html=i18n(subCat.label)></a></li>
                                            <li><a v-if="subCat.type == 'category'" class="vd_sideheader_a callByAjax" :id="subCat.id"
                                            :data-subcatID="subCat.label" :target="subCat.target"
                                            :href="'/category/'+subCat.permalink" v-html=i18n(subCat.label)></a></li>
                                        </ul>
                                    </template>
                                </li>
                                <li v-else class="vd_sideheader_li">
                                    <a v-if="data.type == 'web_address'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                        :href="data.permalink" :data-url="data.permalink" v-html=i18n(data.label)></a>
                            
                                    <a v-if="data.type == 'page'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                        :href="'/'+data.permalink" :data-url="data.permalink" v-html=i18n(data.label)></a>
                            
                                    <a v-if="data.type == 'category'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                        @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                        :href="'/category/'+data.permalink" :data-url="data.permalink" v-html=i18n(data.label)></a>
                                </li>
                        </template>
                    </template>    
                </ul>
            </div>
            <div class="links-wraper" v-if="isLogin && favouriteEnabled">
                <h4><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h4>
                <ul>
                    <li>
                        <a href="/my-favorites" class="callByAjax">
                            Favourite Tracks
                        </a>
                    </li>
                </ul>
            </div>
            <form class="form-inline my-2 aboutNav left-panel-form" v-if="!userInfo && !newConfig">
              <a vd-node="styleOnly" vd-readonly="true" href="/sign-in" class="sign-in" type="submit" @click="removeRedirectAfterLogin()"><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></a>
              <a vd-node="styleOnly" vd-readonly="true" href="/sign-up" class="sign-up" type="submit" @click="removeRedirectAfterLogin()"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></a>
            </form>
            <div class="links-wraper my-profile-mobile">
                <template v-if="userInfo && userProfile">
                    <h4 class="user-avtar-heading"> 
                        <img class="profileImages img-fluid user-avtar-mobile" v-if="userProfile.profile_image_url == '' && !multiprofileClickedObj"
                            :src="rootUrl +'img/no-avatar.png'" alt="" />
                        <img class="profileImages img-fluid user-avtar-mobile" v-else-if="userProfile.profile_image_url !== '' && !multiprofileClickedObj"
                            :src="userProfile.profile_image_url" alt="" />
                        <img class="profileImages" v-else
                            :src="multiprofileClickedObj.avatar" alt="" />
                        <span class="profileName" id="userProfileName" v-if="multiprofileClickedObj">{{multiprofileClickedObj.profile_name}}</span>
                        <span class="profileName" id="userProfileName" v-else>{{userProfile.name.slice(0,12)}}</span>
                    </h4>
                    <ul>
                        <li v-if="getProfileList.length >= 1 && multiProfileIsEnable" v-for="data in getProfileList.filter(data => data.enduser_profile_uuid !== selectedMultipleProfileUuid)" @click="updateNameAndProfilePhoto(data)">
                            <a class="callByAjax">{{data.profile_name}}</a>
                        </li>
                        <li v-if="getProfileList.length >= 1 && multiProfileIsEnable" @click="navigateTohome()">
                            <a class="callByAjax">Manage Profile</a>
                        </li>
                        <li>
                            <a @click="navigateprofile()"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></a>
                        </li>
                        <li>
                            <a class="dropdown-item"  @click="logout()"><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></a>
                        </li>
                    </ul>
                <template>  
            </div>
        </div>
    </vd-component>
    `,
};

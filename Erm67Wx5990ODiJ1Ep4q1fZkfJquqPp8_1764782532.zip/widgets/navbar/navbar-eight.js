let { getEndUserRegdLoginSetting,
    getCategoryDetails,
    getUserDetails,
    getSearchListData,
    getVdConfig,
    getUgcSettingStatus,
    getSearchListDataFromElastic,
    getAccountTokenDetails,
    fetchUserAndPartnersForSearch,
    getPartnerAndUserSettingDetails,
    getProfileList,
    toGetMultipleProfileToken,
    getDocumentDetailsByContentUuid,
    isAuthorizedContent  } = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { delayCall } = await import(window.importLocalJs('widgets/navbar/search-util.js'));
let { getRootUrl, getLocale } = await import(window.importAssetJs('js/web-service-url.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { default: ugc_content_upload_one } = await import(window.importLocalJs('widgets/ugc-content-upload/ugc-content-upload-one.js'));
let { default: multilingual_two } = await import(window.importLocalJs('widgets/multilingual/multilingual-two.js'));
let {SET_CURRENT_CONTENT_SELECTION_DATA, TOGGLE_CONTENT_PURCHASE_MODAL, GET_END_USER_REGD_LOGIN_SETTING, PLAY_CONTENT,GET_PARTNER_AND_USER_PROFILE_SETTING}=await import(window.importAssetJs('js/configurations/actions.js'));

const { mapState } = Vuex;

export default {
    name: "navbar_eight",
    data() {
        return {
            rootUrl: getRootUrl(),
            categoryDetails: [],
            isLogin: Boolean,
            userProfile: String,
            userInfo: String,
            profilepic: false,
            searchValue: "",
            searchData: [],
            flag: Boolean,
            isRes: false,
            dropdown_toggle: "dropdown-toggle",
            logo_src: "",
            logo_alt: "",
            logo_style: "",
            isLogoUpdated: Boolean,
            userConfig: null,
            newConfig: Boolean,
            ugcEnabled: false,
            reloadUGCPop: 1,
            activeClass: null,
            contentList: [],
            playlist: [],
            partnerList: [],
            endUserList: [],
            partnerFlag: Boolean,
            endUserFlag: Boolean,
            partnerEnabled: false,
            partnerProfileEnabled: false,
            ugcProfileEnabled: false,
            getProfileList: [],
            multiprofileClickedObj: {
                "profile_name": '',
                "enduser_profile_uuid": '',
                "avatar": ''
            },
            multiprofileClickedStatus: false,
            multiProfileIsEnable: false,
            selectedMultipleProfileUuid:'',
            isRegdLogin: 1,
            isLogedIn: localStorage.getItem('isloggedin'),
	    multiprofileIdClicked: false
        };
    },
    components: {
        ugc_content_upload_one,
        multilingual_two
    },
    computed: {
        ...mapState({
            partner_and_enduser_profile_settings: (state) => state.partner_and_enduser_profile_settings,
            end_user_regd_login_setting: (state) => state.end_user_regd_login_setting,
        }),
    },
    async beforeCreate() {
        //if(!localStorage.getItem("userConfig")){
        const res = await getEndUserRegdLoginSetting();
        if (res.data.code == 200 && res.data.data !== null) {
            if (res.data.data.sections[0].groups[0].nodes[2].node_value == 1) {
                this.multiProfileIsEnable = true;
            }
            localStorage.setItem("userConfig", res.data.data.sections[0].groups[0].nodes[0].node_value);
            if (localStorage.getItem("userConfig") != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
            this.isLogin = localStorage.getItem("isloggedin");
            if (this.newConfig && this.isLogin === "true") {
                this.autoLogout();
            }
        } else {
            window.location.href = '/';
        }
        // }    
    },

    mounted() {
        if (localStorage.getItem('multiprofileIdClicked')) {
            this.multiprofileIdClicked = true
        } else {
            this.multiprofileIdClicked = false
        }
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.addEvent();
        if (window.location.pathname.toString().split("/").length > 3) {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[3];
        } else {
            this.activeClass = window.location.pathname
                .toString()
                .split("/")[2];
        }
        this.fetchUGCSettingStatus();
        this.searchItem = delayCall(this.searchItem);
        getCategoryDetails()
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    // res.data.data.assigned_categories.forEach((ele) => {
                    //     if (!ele.is_static) {
                    //         ele.is_static = "";
                    //     }
                    //     if (!ele.target) {
                    //         ele.target = "";
                    //     }
                    //     if (!ele.type) {
                    //         ele.type = "dynamic";
                    //     }
                    //     if (ele.sub_menu) {
                    //         ele.sub_menu.forEach((sub) => {
                    //             if (!sub.is_static) {
                    //                 sub.is_static = "";
                    //             }
                    //             if (!sub.target) {
                    //                 sub.target = "";
                    //             }
                    //             if (!sub.type) {
                    //                 sub.type = "dynamic";
                    //             }
                    //         });
                    //     }
                    // });
                    this.categoryDetails = res.data.data;
                }
            })
            .catch((ex) => {
                console.log(ex);
            });
        if (localStorage.getItem("isloggedin") !== undefined) {
            this.isLogin = localStorage.getItem("isloggedin");
            this.getUserMenu();
        }
        getVdConfig("logo")
            .then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    //this.logo = res.data.data;
                    this.isLogoUpdated = true;
                    this.logo_alt = res.data.data.alt;
                    this.logo_src = res.data.data.src;
                    this.logo_style = res.data.data.style;
                } else {
                    this.isLogoUpdated = false;
                }
            })
            .catch((ex) => {
                console.log(ex);
            });

        var intervalId = setInterval(() => {
            this.userConfig = localStorage.getItem("userConfig");
            if (this.userConfig != 1) {
                this.newConfig = true;
            } else {
                this.newConfig = false;
            }
        }, 500);
        setTimeout(() => {
            clearInterval(intervalId);
        }, 2500);

        //Multiprofile
        getProfileList().then((res) => {
            if (res.data.code === 200 && res.data.status == "SUCCESS") {
                console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                if (res.data.data.getProfileList.length >= 1) {
                    // this.otpSettingEnabled = this.muviAuthEmailOptSettingList.includes(res.data.data.getUserDetails[0].muvi_auth_setting_type);
                    // console.log(this.otpSettingEnabled,"this.otpSettingEnabled");
                    // localStorage.setItem('adminId',res.data.data.getUserDetails[0].user_uuid);
                    // this.muviAuthSettingType = res.data.data.getUserDetails[0].muvi_auth_setting_type;
                    // this.muviAuthEmailOptSettingType = this.muviAuthEmailOptSettingList.includes(this.muviAuthSettingType);
                    this.getProfileList = res.data.data.getProfileList;
                    console.log(this.getProfileList, "res.data.data.getProfileList");
                }
            }
        });
        if (localStorage.getItem('multiprofileIdClicked')) {
            this.multiprofileClickedStatus = true;
        }
        this.multiprofileClickedObj = JSON.parse(localStorage.getItem('multiprofileIdClicked'));
        if (this.multiprofileClickedObj) {
            this.selectedMultipleProfileUuid = this.multiprofileClickedObj.enduser_profile_uuid;
        }
        //alert(this.multiprofileClickedObj.profile_name);    
        //Multiprofile
    },
    watch: {
        multiprofileClickedStatus(value) {
            //localStorage.name = value;
        }
    },
    methods: {
        i18n,
        redirectCategory(link) {
            window.location.href = link;
        },
        getUserMenu() {
            if (localStorage.getItem("isloggedin") == "true") {
                this.userInfo = true;
                var userData = JSON.parse(localStorage.getItem("user"));
                this.userProfile = userData;
            } else {
                this.userInfo = false;
            }
        },
        goToMainjs: function () {
            localStorage.setItem(
                "content_uuid",
                "57bf2ddbea2049479522aceb87b324ec"
            );
        },
        getUserDetailsInfo() {
            getUserDetails().then((res) => {
                if (res.data && res.data.code == 200) {
                    this.userProfile = res.data.data.getUserDetails[0];
                    this.profilepic = true;
                }
            });
        },
        async searchItem() {
            if (this.searchValue !== "") {
                this.isRes = false;
                //let tokenData = await getAccountTokenDetails();

                // getSearchListDataFromElastic(this.searchValue,tokenData).then((res) => {
                //     this.isRes = true;
                //     if (
                //         res.data.code === 200 &&
                //         res.data.data.contents
                //     ) {
                //         this.flag = true;
                //         //this.searchData = res.data.data.contents;
                //         this.setSearchedData(res.data.data.contents);
                //     } else {
                //         this.flag = false;
                //     }
                // });

                getSearchListData(this.searchValue).then((res) => {
                    this.isRes = true;
                    if (
                        res.data.code === 200 &&
                        res.data.data.contentList.content_list
                    ) {
                        this.flag = true;
                        //this.searchData =res.data.data.contentList.content_list;
                        this.setSearchedData(
                            res.data.data.contentList.content_list
                        );
                    } else {
                        this.flag = false;
                    }
                });
                if (this.partnerEnabled && this.partnerProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "partner",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getPartners.users_list
                        ) {
                            this.partnerFlag = true;
                            this.partnerList =
                                res.data.data.getPartners.users_list;
                        } else {
                            this.partnerFlag = false;
                            this.partnerList = [];
                        }
                    });
                }
                if (this.ugcEnabled && this.ugcProfileEnabled) {
                    fetchUserAndPartnersForSearch(
                        this.searchValue,
                        "user",
                        1,
                        100
                    ).then((res) => {
                        this.isRes = true;
                        if (
                            res.data.code === 200 &&
                            res.data.data.getEndUserList.end_user_list
                        ) {
                            this.endUserFlag = true;
                            this.endUserList =
                                res.data.data.getEndUserList.end_user_list;
                        } else {
                            this.endUserFlag = false;
                            this.endUserList = [];
                        }
                    });
                }
            }
        },

        setSearchedData(searchDataList) {
            this.contentList = searchDataList.filter((element) => {
                return element.is_playlist == 0;
            });
            this.playlist = searchDataList.filter((element2) => {
                return element2.is_playlist == 1;
            });
            // let searchDataObjList = {};
            // searchDataObjList["contentList"] = this.contentList;
            // searchDataObjList["playlist"] = this.playlist;
            // this.$store.dispatch(GET_SEARCH_DATA,searchDataObjList);
        },

        viewContentlist(event) {
            if (event.keyCode === 13) {
                event.preventDefault();
                this.isRes = false;
                if (this.searchValue === undefined || this.searchValue == "") {
                    window.location = "/search-result/" + undefined;
                } else {
                    if (isAudioExists) {
                        getPageByAjax("/search-result/" + this.searchValue); //@ER: 74207
                    } else {
                        window.location.href =
                            "/search-result/" + this.searchValue;
                    }
                }
            }
        },
        viewSearchResult(data, isPlaylist) {
            if (isPlaylist == 1) {
                if (isAudioExists) {
                    getPageByAjax("/playlist/" + data); //@ER: 74207
                } else {
                    window.location.href = "/playlist/" + data;
                }
            } else {
                let contentObj = this.contentList.filter(tempContent => tempContent.content_permalink === data)[0];
          
                if(contentObj.content_asset_type == 6 && this.partner_and_enduser_profile_settings?.docDetailsPageDisabledSettings){
                    getDocumentDetailsByContentUuid(contentObj.content_uuid).then((res) => {
                        if (
                            res.data.code === 200 &&
                            res.data.data.contentList.content_list
                        ) {
                            contentObj =  res.data.data.contentList.content_list[0];
                            this.isAuthorized(contentObj);
                        }
                    });
                }else{
                    //window.location.href = "/content/" + data;
                    if (isAudioExists) {
                        getPageByAjax("/content/" + data); //@ER: 74207
                    } else {
                        window.location.href = "/content/" + data;
                    }
                }
            }
        },
        viewSearchProfile(data, userType) {
            if (userType == "partner") {
                if (isAudioExists) {
                    getPageByAjax("/partner/" + data); //@ER: 74207
                } else {
                    window.location.href = "/partner/" + data;
                }
            } else if (userType == "user") {
                if (isAudioExists) {
                    getPageByAjax("/user/" + data); //@ER: 74207
                } else {
                    window.location.href = "/user/" + data;
                }
            }
        },
        logout: function () {
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-107393
            //Multiple Profile window.location.href = "/";
            localStorage.removeItem("multiprofileIdClicked");
            //MultipleProfile
            $cookies.remove("token");
            $cookies.remove("isloggedin");
            this.userInfo = false;
            Toast.fire({
                icon: "success",
                title: "Signout Sucessfully",
            });
            window.location.href = '/';
        },
        navigateprofile: function () {
            window.localStorage.setItem("profile.currenttab", "profile_nine");
            if (isAudioExists) {
                getPageByAjax("/profile"); //@ER: 74207
            } else {
                window.location.href = "/profile";
            }
        },
        //MultiProfile
        updateNameAndProfilePhoto: function (data) {
            // window.localStorage.setItem("multiprofileIdClicked.profile_name", data.profile_name);
            // window.localStorage.setItem("multiprofileIdClicked.profile_uuid", data.profile_uuid);
            // window.localStorage.setItem("multiprofileIdClicked.avatar", data.avatar);
            data.selectedDate = new Date();
            window.localStorage.setItem("multiprofileIdClicked", JSON.stringify(data));
            this.multiprofileClickedStatus = true;
            this.multiprofileClickedObj = data;
            this.selectedMultipleProfileUuid = this.multiprofileClickedObj.enduser_profile_uuid;
            let payload = {
                enduser_profile_uuid: data.enduser_profile_uuid,
                enduser_maturity_rating_uuid: data.enduser_maturity_rating_uuid
            };
            if (data.enduser_maturity_rating_min_age == null || data.enduser_maturity_rating_min_age == '' || data.enduser_maturity_rating_min_age == "") {
                payload['enduser_maturity_rating_min_age'] = null;
            } else {
                payload['enduser_maturity_rating_min_age'] = data.enduser_maturity_rating_min_age;

            }
            toGetMultipleProfileToken(payload)
                .then((res) => {
                    if (res.data.code == 200 && res.data.status == "SUCCESS") {
                        localStorage.setItem("end_user_access_token", res.data.data.access_token);
                    } else {
                        Toast.fire({
                            icon: "error",
                            title: res.data.status,
                            text: res.data.message,
                        });
                    }
                })
                .catch((err) => {
                    Toast.fire({
                        icon: "error",
                        title: err.response.data.status,
                        text: err.response.data.message,
                    });
                });
            $(".content-propertices").removeClass("cp-open");
            window.location.href = '/';
        },
        navigateTohome() {
            localStorage.setItem("ManageProfileMenuClicked", true);
            window.location.href = '/';
        },
        //MultiProfile
        fetchUGCSettingStatus() {
            getUgcSettingStatus().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "ugc") {
                                this.ugcEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                            if (element.node_code == "partner_portal") {
                                this.partnerEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    res.data.data.sections[0].groups[1].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_profile") {
                                this.ugcProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                    //ER-101092 Start
                    res.data.data.sections[0].groups[2].nodes.forEach(
                        (element) => {
                            if (element.node_code == "user_regis_login") {
                                localStorage.setItem("freeContentLoginRequired", element.node_value && element.node_value == 1 ? true : false);
                            }
                        }
                    );
                    //ER-101092 End
                }
            });
            getPartnerAndUserSettingDetails().then((res) => {
                if (res.data.status == "SUCCESS" && res.data.code == 200) {
                    res.data.data.sections[0].groups[0].nodes.forEach(
                        (element) => {
                            if (element.node_code == "profile_page") {
                                this.partnerProfileEnabled =
                                    element.node_value &&
                                        element.node_value == 1
                                        ? true
                                        : false;
                            }
                        }
                    );
                }
            });
        },
        openAddContentPop() {
            setTimeout(() => {
                $("#ugcContentAdd .modal").addClass("show");
                $("#ugcContentAdd .modal").css("display", "block");
            }, 300);
        },
        openProfilePop() {
            if (localStorage.getItem('multiprofileIdClicked')) {
                this.selectedMultipleProfileUuid = JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
            }
            $(".content-propertices").addClass("cp-open");
            getProfileList().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    console.log(res.data.data.getProfileList, "res.data.data.getProfileList");
                    if (res.data.data.getProfileList.length >= 1) {
                        this.getProfileList = res.data.data.getProfileList;
                        console.log(this.getProfileList, "res.data.data.getProfileList");
                        // if (localStorage.getItem('multiprofileIdClicked')) {
                        //     this.getProfileList = res.data.data.getProfileList.filter(function (el) {
                        //     return el.enduser_profile_uuid !== JSON.parse(localStorage.getItem('multiprofileIdClicked')).enduser_profile_uuid;
                        // });
                        // console.log(this.getProfileList);
                        // }
                    }
                }
            });
        },
        closeProfilePop() {
            $(".content-propertices").removeClass("cp-open");
        },
        reloadUGCPopup() {
            ++this.reloadUGCPop;
        },
        addEvent() {
            window.onclick = (evt) => {
                this.isRes = false;
            };
        },
        autoLogout: function () {
            localStorage.removeItem("user");
            localStorage.removeItem("isloggedin");
            localStorage.removeItem("end_user_access_token");
            localStorage.removeItem("end_user_reload_token");
            localStorage.removeItem("audio_sleep_timer"); //ER-104522
            $cookies.remove("token");
            $cookies.remove("isloggedin");
            this.userInfo = false;
        },
        //106237-start
        removeRedirectAfterLogin() {
            if (window.localStorage.getItem("redirectAfterlogin") !== null) {
                window.localStorage.removeItem("redirectAfterlogin");
            }
        },
        //106237-end
        async isAuthorized(contentObj) {
            this.isRegdLogin = this.end_user_regd_login_setting.sections[0].groups[0].nodes[0].node_value ? 1 : 0;

            if (this.isRegdLogin === 0) {
                // window.location.href = value;
                window.open(contentObj?.document_details.file_url, '_blank');
            } else {
                if (!this.isLogedIn) {
                    let freeContentLoginRequired = JSON.parse(localStorage.getItem("freeContentLoginRequired"));
                    if (this.isFreeContent && !freeContentLoginRequired) {
                        // window.location.href = value;
                        window.open(contentObj?.document_details.file_url, '_blank');
                    } else {
                        // const redirectAfterLogin = window.localStorage.getItem("addOnContentPageUrl");
                        // if (redirectAfterLogin) {
                        //     window.localStorage.removeItem("addOnContentPageUrl");
                        //     window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                        // }
                        window.location.href = "/sign-in";
                        return false;
                    }
                } else {
                    const res = await isAuthorizedContent(contentObj.content_uuid );
                    if (res.data.code == 200) {
                        if (res.data.data.isAuthorized.is_content_authorized) {
                           this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                            // window.location.href = value;
                            window.open(contentObj?.document_details.file_url, '_blank');
                        } else {
                           this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                content_uuid: contentObj.content_uuid,
                                monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                            });
                           this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);//true
                        }
                    } else {
                        JsLoadingOverlay.hide();
                        Toast.fire({ icon: "error", title: res.data.message });
                    }
                }
            }

            return false;
        }
    },
    template: `
    <vd-component class="vd navbar-eight" type="navbar-eight">
        <div vd-node="header" vd-readonly="true" class="header header-wrapper header-new">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 navbar py-0">
						<a v-if="isLogoUpdated && logo_src" class="logo callByAjax" :href="'/'"><img vd-node="logo" vd-readonly="true" :src="logo_src" :alt="logo_alt" :style="logo_style"/></a>
						<a v-else-if="!isLogoUpdated" class="logo callByAjax" :href="'/'"><img vd-node="logo" vd-readonly="true" :src="rootUrl+'img/logo.png'" alt="Phoenix" /></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".nav-n-sign"
                            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="nav-n-sign collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                            <ul class="navbar-nav nav-menu" vd-node="menu" vd-readonly="true" style="padding:2px">
                                <template v-if="categoryDetails.length > 5">
                                <template v-for="data in categoryDetails.slice(0, 5)">
                                    <li class="nav-item dropdown phoenix-nav-dropdown vd_sideheader_li"
                                        v-if="data.sub_menu != null && data.sub_menu.length > 0">
                                        <div class="btn-navigation toggle-focus-activety hoverClass" @click="activeClass= data.permalink" :class="{activeClass:activeClass === data.permalink}">
											<a v-if="data.type == 'web_address'" class="nav-link pr-0 d-inline-block vd_sideheader_a callByAjax" 
												:id="data.id" :target="data.target"
												:href="data.permalink" v-html=i18n(data.label)></a>
											<a v-if="data.type == 'page'" class="nav-link pr-0 d-inline-block vd_sideheader_a callByAjax"
												:id="data.id" :target="data.target"
												:href="'/'+data.permalink" v-html=i18n(data.label)></a>
											<a v-if="data.type == 'category'" class="nav-link pr-0 d-inline-block vd_sideheader_a callByAjax"
												:id="data.id" :target="data.target"
												:href="'/category/'+data.permalink" v-html=i18n(data.label)></a>
                                            <span class="dropdown-toggle p-0" data-toggle="dropdown"
                                                aria-expanded="false" >
                                                <span class="sr-only">
                                                    <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                                                </span>
                                            </span>
                                            <div class="dropdown-menu vd_submenu_div">
                                                <ul>
                                                    <template v-for="subCat in data.sub_menu">
                                                        <li>
                                                            <a v-if="subCat.type == 'web_address'" class="dropdown-item vd_sideheader_a callByAjax" :id="subCat.id"
                                                                :data-subcatID="subCat.label" :target="subCat.target"
                                                                :href="subCat.permalink" v-html=i18n(subCat.label)>
                                                            </a>
                                                            <a v-if="subCat.type == 'page'" class="dropdown-item vd_sideheader_a callByAjax" :id="subCat.id"
                                                                :data-subcatID="subCat.label" :target="subCat.target"
                                                                :href="'/'+subCat.permalink" v-html=i18n(subCat.label)>
                                                            </a>
                                                            <a v-if="subCat.type == 'category'" class="dropdown-item vd_sideheader_a callByAjax" :id="subCat.id"
                                                                :data-subcatID="subCat.label" :target="subCat.target"
                                                                :href="'/category/'+subCat.permalink" v-html=i18n(subCat.label)>
                                                            </a>
                                                        </li>
                                                    </template>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li v-else class="nav-item vd_sideheader_li">
										<a v-if="data.type == 'web_address'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
                                            @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
                                            :href="data.permalink" v-html=i18n(data.label)></a>
							
										<a v-if="data.type == 'page'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
										    @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
											:href="'/'+data.permalink" v-html=i18n(data.label)></a>
							
										<a v-if="data.type == 'category'" class="nav-link vd_sideheader_a callByAjax hoverClass" 
										    @click="activeClass= data.permalink"  :class="{activeClass:activeClass === data.permalink}" :id="data.id" :target="data.target"
											:href="'/category/'+data.permalink" v-html=i18n(data.label)></a>
                                    </li>
                                </template>
                                <li class="nav-item dropdown phoenix-nav-dropdown vd_sideheader_li">
                                    <li class="nav-link dropdown-toggle p-0 more-btn hoverClass" data-toggle="dropdown"
                                        aria-expanded="false" >
                                        More
                                    </li>
                                    <div class="dropdown-menu vd_submenu_div more-div">
                                        <template v-for="data in categoryDetails.slice(5)">
                                            <li class="nav-item vd_sideheader_li">
                                                <a v-if="data.type == 'web_address'"
                                                    class="nav-link vd_sideheader_a callByAjax hoverClass"
                                                    @click="activeClass = data.permalink"
                                                    :class="{ activeClass: activeClass === data.permalink }"
                                                    :id="data.id" :target="data.target" :href="data.permalink"
                                                    v-html="i18n(data.label)"></a>
                                                <a v-if="data.type == 'page'"
                                                    class="nav-link vd_sideheader_a callByAjax hoverClass"
                                                    @click="activeClass = data.permalink"
                                                    :class="{ activeClass: activeClass === data.permalink }"
                                                    :id="data.id" :target="data.target"
                                                    :href="'/' + data.permalink"
                                                    v-html="i18n(data.label)"></a>
                                                <a v-if="data.type == 'category'"
                                                    class="nav-link vd_sideheader_a callByAjax hoverClass"
                                                    @click="activeClass = data.permalink"
                                                    :class="{ activeClass: activeClass === data.permalink }"
                                                    :id="data.id" :target="data.target"
                                                    :href="'/category/' + data.permalink"
                                                    v-html="i18n(data.label)"></a>
                                            </li>
                                        </template>
                                    </div>
                                    </li>
                            </template>
                            <template v-else>
                                <template v-for="data in categoryDetails">
                                    <li class="nav-item dropdown phoenix-nav-dropdown vd_sideheader_li"
                                        v-if="data.sub_menu != null && data.sub_menu.length > 0">
                                        <div class="btn-navigation toggle-focus-activety hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}">
                                            <a v-if="data.type == 'web_address'"
                                                class="nav-link pr-0 d-inline-block vd_sideheader_a callByAjax"
                                                :id="data.id" :target="data.target" :href="data.permalink"
                                                v-html=i18n(data.label)></a>

                                            <a v-if="data.type == 'page'"
                                                class="nav-link pr-0 d-inline-block vd_sideheader_a callByAjax"
                                                :id="data.id" :target="data.target"
                                                :href="'/'+data.permalink" v-html=i18n(data.label)></a>

                                            <a v-if="data.type == 'category'"
                                                class="nav-link pr-0 d-inline-block vd_sideheader_a callByAjax"
                                                :id="data.id" :target="data.target"
                                                :href="'/category/'+data.permalink"
                                                v-html=i18n(data.label)></a>

                                            <button type="button" class="dropdown-toggle p-0" data-toggle="dropdown"
                                                aria-expanded="false" >
                                                <span class="sr-only">
                                                    <vd-component-param type="label1"
                                                        v-html="i18n($attrs['label1'])"></vd-component-param>
                                                </span>
                                            </button>
                                            <div class="dropdown-menu vd_submenu_div">
                                                <template v-for="subCat in data.sub_menu">
                                                    <a v-if="subCat.type == 'web_address'"
                                                        class="dropdown-item vd_sideheader_a callByAjax hoverClass"
                                                        :id="subCat.id" :data-subcatID="subCat.label"
                                                        :target="subCat.target" :href="subCat.permalink"
                                                        v-html=i18n(subCat.label)></a>
                                                    <a v-if="subCat.type == 'page'"
                                                        class="dropdown-item vd_sideheader_a callByAjax hoverClass"
                                                        :id="subCat.id" :data-subcatID="subCat.label"
                                                        :target="subCat.target"
                                                        :href="'/'+subCat.permalink"
                                                        v-html=i18n(subCat.label)></a>
                                                    <a v-if="subCat.type == 'category'"
                                                        class="dropdown-item vd_sideheader_a callByAjax hoverClass"
                                                        :id="subCat.id" :data-subcatID="subCat.label"
                                                        :target="subCat.target"
                                                        :href="'/category/'+subCat.permalink"
                                                        v-html=i18n(subCat.label)></a>
                                                </template>
                                            </div>
                                        </div>
                                    </li>
                                    <li v-else class="nav-item vd_sideheader_li">
                                        <a v-if="data.type == 'web_address'"
                                            class="nav-link vd_sideheader_a callByAjax hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                            :target="data.target" :href="data.permalink"
                                            v-html=i18n(data.label)></a>

                                        <a v-if="data.type == 'page'"
                                            class="nav-link vd_sideheader_a callByAjax hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                            :target="data.target" :href="'/'+data.permalink"
                                            v-html=i18n(data.label)></a>

                                        <a v-if="data.type == 'category'"
                                            class="nav-link vd_sideheader_a callByAjax hoverClass"
                                            @click="activeClass= data.permalink"
                                            :class="{activeClass:activeClass === data.permalink}" :id="data.id"
                                            :target="data.target" :href="'/category/'+data.permalink"
                                            v-html=i18n(data.label)></a>
                                    </li>
                                </template>
                            </template>
                            </ul>
                        </div>
                    </div> 
                    <div class="col-lg-6 navbar2 nav-n-sign collapse">   
                        <div class="search-div top-search-nav top-search-nav user-srch-input vd-form">
                            <form class="form-inline">
                                <input class="form-control search-content vd-component-attr" vd-readonly="true" v-model="searchValue" type="search"
                                    autocomplete="off" vd-component-attr-placeholder="label9" :placeholder=i18n($attrs['label9']) vd-component-attr-title="label10" :title=i18n($attrs['label10']) aria-label="Search" id="searchInput"
                                    data-aut="srch_search" @input="searchItem()" @keydown="viewContentlist($event)">
                            </form>
                            <template v-if="searchValue && isRes" class="search search-navigation">
                                <ul class="dropdown-menu w-100 srch-popup show" v-if="flag && (contentList || playlist)">
                                    <template v-if="contentList && contentList.length">
                                        <li class="srch-drop-title">
                                            <span class="dropdown-item"><b>
                                                <vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></b>
                                            </span>
                                        </li>
                                        <li v-for="i in contentList"  class="text-capitalize">
                                            <a class="dropdown-item truncate-text lc-one callByAjax"  @click="viewSearchResult(i.content_permalink,i.is_playlist)"> {{i.content_name}} </a>
                                        </li>
                                    </template>
                                    <template v-if="playlist && playlist.length">
                                        <li class="srch-drop-title">
                                            <span class="dropdown-item"><b>
                                                <vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></b>
                                            </span>
                                        </li>
                                        <li v-for="j in playlist" class="text-capitalize">
                                            <a class="dropdown-item truncate-text lc-one callByAjax"  @click="viewSearchResult(j.content_permalink,j.is_playlist)"> {{j.content_name}} </a>
                                        </li>
                                    </template>
                                    <template v-if="partnerList && partnerList.length">
                                        <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                        <vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param>
                                        </a></li>
                                        <li v-for="k in partnerList">
                                            <a class="dropdown-item truncate-text lc-one callByAjax" @click="viewSearchProfile(k.user_uuid, 'partner')" > {{k.name}} </a>
                                        </li>
                                    </template>
                                    <template v-if="endUserList && endUserList.length">
                                        <li class="srch-drop-title pt-4 pb-4"><a class="dropdown-item" href="#"> 
                                        <vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param>
                                         </a></li>
                                        <li v-for="m in endUserList">
                                            <a class="dropdown-item truncate-text lc-one callByAjax" @click="viewSearchProfile(m.end_user_uuid, 'user')" > {{m.name}} </a>
                                        </li>
                                    </template>
                                </ul>
                                <ul v-if="!flag"  class="dropdown-menu w-100 srch-popup show" >
                                    <li>
                                    <a class="dropdown-item truncate-text lc-one callByAjax"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></a>
                                    </li>
                                </ul>
                            </template>
                        </div>
                        <multilingual_two :id="$attrs['id']+'_multilingual_two_2'"/>   
                    <template v-if="userInfo && userProfile">
                    <a v-if="ugcEnabled" @click="openAddContentPop()" class="pl-3 d-flex align-items-center" data-toggle="modal" data-target="#ugcContentAdd">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.5 11.25H10.5V8.25H9V11.25H6V12.75H9V15.75H10.5V12.75H13.5V11.25Z" fill="white"></path>
                        <path d="M15.75 19.5H3C2.6023 19.4996 2.221 19.3414 1.93978 19.0602C1.65856 18.779 1.5004 18.3977 1.5 18V6C1.5004 5.6023 1.65856 5.221 1.93978 4.93978C2.221 4.65856 2.6023 4.5004 3 4.5H15.75C16.1477 4.5004 16.529 4.65856 16.8102 4.93978C17.0914 5.221 17.2496 5.6023 17.25 6V9.04275L21.3143 6.14025C21.4263 6.06023 21.5583 6.01262 21.6957 6.00265C21.833 5.99267 21.9705 6.02071 22.093 6.0837C22.2155 6.14668 22.3182 6.24217 22.39 6.35971C22.4618 6.47724 22.4999 6.61227 22.5 6.75V17.25C22.5 17.3878 22.4621 17.5229 22.3903 17.6406C22.3186 17.7582 22.2158 17.8538 22.0933 17.9169C21.9708 17.98 21.8333 18.0081 21.6959 17.9981C21.5584 17.9882 21.4264 17.9406 21.3143 17.8605L17.25 14.958V18C17.2496 18.3977 17.0914 18.779 16.8102 19.0602C16.529 19.3414 16.1477 19.4996 15.75 19.5ZM3 6V18.0007L15.75 18V13.5C15.75 13.3622 15.7879 13.2271 15.8597 13.1094C15.9314 12.9918 16.0342 12.8962 16.1567 12.8331C16.2792 12.77 16.4167 12.7419 16.5541 12.7519C16.6916 12.7618 16.8236 12.8094 16.9357 12.8895L21 15.792V8.208L16.9357 11.1105C16.8236 11.1906 16.6916 11.2382 16.5541 11.2481C16.4167 11.2581 16.2792 11.23 16.1567 11.1669C16.0342 11.1038 15.9314 11.0082 15.8597 10.8906C15.7879 10.7729 15.75 10.6378 15.75 10.5V6H3Z" fill="#888888"></path>
                        </svg>
                    </a>
                    <div class="user-avater" vd-node="accountSetting">
                        <img class="profileImages" v-if="!multiProfileIsEnable && (userProfile.profile_image_url === '' || userProfile.profile_image_url === null)"
                        :src="rootUrl + 'img/no-avatar.png'" alt="No Avatar" />
                        <img class="profileImages" v-else-if="!multiProfileIsEnable && userProfile.profile_image_url !== ''"
                        :src="userProfile.profile_image_url" alt="User Profile Image" />
                        <img class="profileImages" v-else
                        :src="multiprofileClickedObj.avatar" alt="Multiple Profile Avatar" />
                        <div class="user-menu">
                        <ul>
                            <li v-if="getProfileList.length >= 1 && multiProfileIsEnable" 
                            v-for="data in getProfileList.filter(data => data.enduser_profile_uuid !== selectedMultipleProfileUuid)" 
                            @click="updateNameAndProfilePhoto(data)">
                            <a class="callByAjax">
                                <span class="mplla-img">
                                <img :src="data.avatar" alt="Sub Profile Image" />
                                {{ data.profile_name }}
                                </span>
                            </a>
                            </li>
                            <li v-if="getProfileList.length >= 1 && multiProfileIsEnable" @click="navigateTohome()">
                            <a class="callByAjax">Manage Profile</a>
                            </li>
                            <li @click="navigateprofile()">
                            <a class="callByAjax">
                                <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                            </a>
                            </li>
                            <li @click="logout()">
                            <a class="callByAjax">
                                <vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param>
                            </a>
                            </li>
                        </ul>
                        </div>
                    </div>
                    </template>

                        <div class="nav-n-sign collapse signup-login-section" v-if="!userInfo && !newConfig">
                            <div class="nav-item signup">
                                <a class="nav-link callByAjax" vd-readonly="true" vd-node="styleOnly" :href="'/sign-up'" vd-readonly="true">
                                    <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                                </a>
                            </div>
                            <div class="nav-item">
                                <a class="nav-link callByAjax" vd-readonly="true" vd-node="styleOnly" :href="'/sign-in'" vd-readonly="true">
                                    <vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ugc_content_upload_one  id="ugcContentAdd" :key="reloadUGCPop" @contentSaveConfirm="reloadUGCPopup"/>
        </div>
    </vd-component>

    `,
};
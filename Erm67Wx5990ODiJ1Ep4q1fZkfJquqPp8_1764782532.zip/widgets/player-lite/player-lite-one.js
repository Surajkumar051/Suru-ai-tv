let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {default:video_player_lite}=await import(window.importLocalJs('widgets/video-player-lite/video-player-lite-one.js'));
let {getContentAddonDetails,categorizedPermalink,getLicense } = await import(window.importAssetJs('js/webservices.js'));
let {SET_CURRENT_CONTENT_SELECTION_DATA, TOGGLE_CONTENT_PURCHASE_MODAL,GET_END_USER_REGD_LOGIN_SETTING}=await import(window.importAssetJs('js/configurations/actions.js'));

export default {
    name: "player_lite_one",
    template: `<vd-component class="vd player-lite-one" type="player-lite-one">
                <video_player_lite v-if="isPlayerDisplay" :id="$attrs['id'] +'_video_player_lite_1'" :playerConfig="playerConfig"/>
            </vd-component>`,
    data() {
        return {
            // root_url:getRootUrl(),
            isPlayerDisplay: false,
            playerConfig: '',
            contentPermalink:permalink,//window.location.pathname.toString().split("/")[2],
            addonUuid:addonuuid,//window.location.pathname.toString().split("/")[4],
            addon:{}
        }
    },
    components: {
        video_player_lite
    },
    created() {
        //
    },
    beforeMount() {
        //
    },
    mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        if (this.contentPermalink) {
            this.isFreeContent = false;//ER-101092
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if (content.permalink_type == "content" && content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.isFreeContent = res.data.data.contentList.content_list[findContentParentIndex].is_free_content;//ER-101092
                        this.getContentAddonDetails();


                    }
                }
            });
        }

        //CONFIG
        
    },
    methods: {
        getRootUrl,
            getContentAddonDetails() {
                getContentAddonDetails(this.contentParentUuid,this.addonUuid).then((res) => {
                    if (res.data.code == 200 && res.data.data !== null &&
                        res.data.data.addons.addons?.length>0) {
                        this.addon = res.data.data.addons.addons[0];
                        console.log("addonList---",this.addonList);
                         let playerTypeVal = "";
                         let videoSource = "";
                         if(this.addon.media_details.stream_format==1 || this.addon.media_details.stream_format==3){
                            playerTypeVal = "HLS";
                            videoSource = this.addon.media_details.hls_path;
                         } else if(this.addon.media_details.stream_format==2){
                            playerTypeVal = "dash";
                            videoSource = this.addon.media_details.mpeg_path;
                         } else{
                            playerTypeVal = "MP4";
                            videoSource = this.addon.media_details.file_url;
                         }   
                         if(this.addon.media_details.is_drm==0){
                            this.playerConfig = {
                                playerType: playerTypeVal,
                                videoSource: videoSource,
                                license: "",
                                poster: getRootUrl()+"/img/thumbnail-video.png",
                                playButtonTooltip: "Play",
                                drmType: "2",
                                certificateUri: "https://player-sdk.muvi.com/muvi_fairplay.cer",
                                is_drm:this.addon.media_details.is_drm,
                                isFreeContent: this.isFreeContent, //ER-101092
                                contentUuid:  this.contentParentUuid
                                // isplayBackRateVal: false,
                            };
                            this.isPlayerDisplay = true;
                        }else if(this.addon.media_details.is_drm==1){
                            getLicense(this.addon.media_details.content_key,this.addon.media_details.encryption_key).then((response) => {
                                if (response.data.code == 200 && response.data.data !== null){
                                this.playerConfig = {
                                    playerType: "drm",
                                    videoSource: {
                                        "hls": this.addon.media_details.hls_path,
                                        "dash": this.addon.media_details.mpeg_path
                                    },
                                    license: response.data.data.mediaLicenseTokens,
                                    poster: getRootUrl()+"/img/thumbnail-video.png",
                                    playButtonTooltip: "Play",
                                    drmType: "2",
                                    certificateUri: "https://player-sdk.muvi.com/muvi_fairplay.cer",
                                    is_drm:this.addon.media_details.is_drm,
                                    isFreeContent: this.isFreeContent, //ER-101092
                                    contentUuid:  this.contentParentUuid
                                    // isplayBackRateVal: false,
                                };
                                this.isPlayerDisplay = true;
                                console.log("pithan player", this.playerConfig);
                            }
                            });
                            }
                        }
                        
                    
                });
            }
        },
};

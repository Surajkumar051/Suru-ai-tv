let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "default_featureslist_eight",
    data() {
        return {
            isloggedin: localStorage.getItem('isloggedin')
        }
    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
    },
    // computed: {
    //     ...mapState({
    //         maturity_rating: (state) => state.maturity_rating,
    //     }),      
    // },
    template: `<vd-component class="vd default-featureslist-eight" type="default-featureslist-eight">
                    <template v-if="!isloggedin">
                        <div class="tutor-area border-bottom">
                            <div class="container">
                                <div class="row justify-content-between">
                                    <div class="col-md-5 col-lg-4 mt-lg-5 pt-lg-4">
                                        <div class="section-heading">
                                            <h2><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2>  
                                        </div>
                                        <p><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
                                        <ul class="tution-lists">
                                            <li><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></li>
                                            <li><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></li>
                                            <li><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></li>
                                            <li><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></li>
                                        </ul>
                                        <vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param>
                                    </div>
                                    <div class="col-md-7">
                                    <vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="insight-area border-bottom">
                            <div class="container">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-md-6 col-lg-5">
                                        <div class="section-heading">
                                            <h2><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></h2>  
                                        </div>
                                        <p><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></p>
                                        <vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param>
                                    </div>
                                    <div class="col-md-6 col-lg-7">
                                        <vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pick-area border-bottom">
                            <div class="container">
                                <div class="row justify-content-md-between justify-content-center align-items-center">
                                    <div class="col-md-6 col-lg-5">
                                        <div class="section-heading">
                                            <h2><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></h2>  
                                        </div>
                                        <p><vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param></p>
                                        <div class="app-download">
                                            <vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param>
                                            <vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param>
                                           
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-8">
                                        <vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </template>
                </vd-component>`,
            };

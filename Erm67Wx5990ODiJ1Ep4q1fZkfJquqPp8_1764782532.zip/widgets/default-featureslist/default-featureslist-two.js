let { getFeaturedSectionDataForHomePage,	makeContentFavorite,
	getContentFavoriteStatus,getContentSettingsDetails } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { default: content_hover_two } = await import(window.importLocalJs('widgets/content-hover/content-hover-two.js'));
let { default: audio_player_one } = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let { default: content_title_two } = await import(window.importLocalJs('widgets/content-title/content-title-two.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "default_featureslist_two",
    components: {
        content_hover_two,
        audio_player_one,
        content_title_two
    },
    data() {
        return {
            featureContentList: [],
            isLogedIn: localStorage.getItem('isloggedin'),
            pageNo:1,
            isNextPageCallReqd:true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true,
            userList:[],
			assignedArray: [],
            gutterSpace: null,
            isFavourite: 0,
            isFavouriteEnabled: false,
            // languageCode: getLocale(),
            
            contentPreorderStatusMap:  new Map(),
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        // console.log("mounted in default-featureslist1 page");
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
        this.getFeaturedSections(this.pageNo, false);
        this.getContentSettingsDetails();
        this.loadMore();

    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
				getContentSettingsDetails() {
					getContentSettingsDetails().then((res) => {
						if (res.data.code == 200) {
						 this.isFavouriteEnabled = (res.data.data.contentSettings.content_favourite_settings != null) ? res.data.data.contentSettings.content_favourite_settings ?.is_enabled : false;
					}
				});
			},
        getFeaturedSections(page, onScroll) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                    JsLoadingOverlay.show();
               
                getFeaturedSectionDataForHomePage(page).then((res) => {
                    JsLoadingOverlay.hide();
                    // if (res.data.code == 200 && res.data.data.featuredContentList) {
                    //     this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                    // }
                    if (!onScroll && res.data.code == 200 && res.data.data.featuredContentList) {
                        this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                        this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);
                    } else if (onScroll && res.data.code == 200 && res.data.data.featuredContentList?.featured_content_list?.length > 0) {
                        this.featureContentList.push(...res.data.data.featuredContentList.featured_content_list);
                        this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);
                    }

                    if (res.data.code == 200 && this.featureContentList?.length < res.data.data.featuredContentList.page_info.total_count) {
                        this.isNextPageCallReqd = true;
                    }

                });
            }
        },
        loadMore() {
            // window.onscroll = () => {
            //     //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //     let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight + 20 >= document.documentElement.scrollHeight;
            //     //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
            //         this.pageNo++;
            //         this.getFeaturedSections(this.pageNo, true);
            //     }
            // };
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                        this.getFeaturedSections(this.pageNo,true);
                }
            };
        },
        playAudioContent(content_detail) { //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        async getPartnerAndUserUuids(featuredSecList){
            let uuids = [];
            await featuredSecList.forEach((featuredSec) => {
                if(featuredSec?.section_content_list?.content_list){
                  contentHelper.getPartnerAndUserUuids(featuredSec?.section_content_list?.content_list,this.userList)
                  const contentUuids = featuredSec?.section_content_list?.content_list.map(item => item.content_uuid);
				  contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

                }
            });
        },
        reloadComponentAudio(content_detail) {
            this.playAudioContent(content_detail); //Er-101092
        },
				getFavoriteContents(page, onScroll) {
					if (this.isNextPageCallReqd) {
							(this.isNextPageCallReqd = false), JsLoadingOverlay.show();
							getFavoriteContents(page).then((res) => {
									JsLoadingOverlay.hide();
									if (
											!onScroll &&
											res.data.code == 200 &&
											res.data.data.favouriteContentList
													.content_favourite_list
									) {
											this.favoriteContents =
													res.data.data.favouriteContentList.content_favourite_list;
											let contents = [];
											this.favoriteContents.forEach(element => {
													contents.push(element.content_details);
											});    
											//contentHelper.getPartnerAndUserUuids(contents,this.userList);
									} else if (
											onScroll &&
											res.data.code == 200 &&
											res.data.data.favouriteContentList
													.content_favourite_list
									) {
											this.favoriteContents.push(
													...res.data.data.favouriteContentList
															.content_favourite_list
											);
											let contents = [];
											res.data.data.favouriteContentList
															.content_favourite_list.forEach(element => {
													contents.push(element.content_details);
											});    
										 // contentHelper.getPartnerAndUserUuids(contents,this.userList);
									}
									if (!onScroll && page == 1 && res.data.status == "FAILED") {
											this.favoriteContents = [];
									}

									if (
											res.data.code == 200 &&
											this.favoriteContents?.length <
													res.data.data.favouriteContentList.page_info
															.total_count
									) {
											this.isNextPageCallReqd = true;
									}
									if (
											this.favoriteContents == null ||
											this.favoriteContents?.length <= 0
									) {
											this.noRecordMsgShow = true;
									}
							});
					}
			},
			getContentFavouriteAction(contentUuid) {
				getContentFavoriteStatus(contentUuid).then((res) => {
						if (res.data.code == 200 && res.data.data !== null) {
								this.isFavourite = res.data.data.favouriteContentList.content_favourite_list[0].is_favourite;
						} else {
								this.isFavourite = 0;
						}
				});
		},
		favouriteEvent(contentDetails) {
				if (this.isLogedIn) {
						const param = {
								"app_token": ":app_token",
								"product_key": ":product_key",
								"store_key": ":store_key",
								"end_user_uuid": ":me",
								"content_uuid": contentDetails.content_uuid,
								"is_favourite": this.isFavourite == 0 ? 1 : 0,
						}
						makeContentFavorite(param).then((res) => {
								if (res.data.code == 200 && res.data.status == "SUCCESS") {
										this.getContentFavouriteAction(contentDetails.content_uuid);
								}
						})
				} else {
						window.location.href ="/sign-up";
				}
		}
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template: `
    <vd-component class="vd default-featureslist-two" type="default-featureslist-two">
        <template v-if="featureContentList " v-for="Data in featureContentList">
		    <section meta-key='meta-feature-list' vd-node="metaData" class="section-padding pt-0" v-if="Data.section_content_list !== null">
			    <div class="container-fluid">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-auto">
                            <h4 vd-readonly="true" class="heading-title" v-if="Data.section_content_list !== null">{{Data.feature_section_name}}
                        </div>
                        <div class="col-auto heading-view">
                            <span class="view-all" v-if="Data.section_content_list?.page_info?.total_count>6">
                                    <a class="callByAjax" :href="'/featured-contents/'+ Data.feature_section_uuid" ><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></a>
                                </span>
                        </div>
                        
                    </div>
				    <div class="row mt-4">
					    <div class="col-12">
						    <div class="raiden-product-slider">
							    <div class="owl-product owl-carousel owl-loaded owl-drag">
								    <template v-if="Data.section_content_list !== null" v-for="Data in Data.section_content_list.content_list">
									    <div class="item">
                                            <div class="product-slider-container">
                                                <div class="product-slider-image">
                                                <div class="freeContent-tag" v-if="Data?.is_free_content">
                                                    <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                                </div>
                                                <div class="mrContent-tag" v-if="Data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                                    <span>{{maturity_rating?.maturity_rating_list[Data?.maturity_rating]}}</span>
                                                </div>
                                                <div :class="(Data.content_asset_type == 2 && Data.is_playlist!=1)?'icons-apply-audio':'icons-apply'">
                                                    <img v-if="Data.content_asset_type == 1 && Data.is_playlist!=1" :src="rootUrl + 'img/video-icons.png'"/>
                                                    <img v-if="Data.content_asset_type == 2 && Data.is_playlist!=1" :src="rootUrl + 'img/audio-icon.png'"/>
                                                    <img v-if="Data.content_asset_type == 6 && Data.is_playlist!=1" :src="rootUrl + 'img/file-icon.png'"/>
                                                    <img v-if="Data.content_asset_type != 6 && Data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                                    <img v-if="Data.content_asset_type == 6 && Data.is_playlist==1" :src="rootUrl + 'img/file-icon.png'"/>
                                                </div>
                                                    <!-- <div class="icons-apply">
                                                        <img v-if="Data.content_asset_type == 1" :src="getRootUrl() + 'img/video-icons.png'"/>
                                                        <img v-if="Data.content_asset_type == 2" :src="getRootUrl() + 'img/audio-icon.png'"/>
                                                    </div> -->
                                                    <div class="product-like-option">
                                                        <div class="like like-heart" v-show="isFavouriteEnabled">
                                                            <div class="ulike ulike_is_not_liked">
                                                                <button vd-disable="true" @click="favouriteEvent(Data)" type="button" class="ulike_btn dislike-image"></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <img loading="lazy" v-if="Data.posters.website != null && Data.posters.website[0].file_url !== ''" :src="Data.posters.website[0].file_url" alt="Godzilla" class="mw-100"/>
                                                    <img loading="lazy" v-if="Data.posters.website == null || Data.posters.website[0].file_url === ''" :src="Data.no_image_available_url" alt="Godzilla" class="mw-100"/>
                                                    <content_hover_two :downloadBtnText="i18n($attrs['label7'])" :openBtnText="i18n($attrs['label8'])" :id="$attrs['id'] +'_content_hover_two_2'" 
                                                        :content="Data" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent" :preOrderBtnTxt  = "i18n($attrs['label9'])"  :contentPreorderStatusMap = "contentPreorderStatusMap"/>
                                                </div>
                                                <div class="gen-info-contain">
                                                    <div class="gen-movie-info">
                                                        <h3>
                                                            <content_title_two :id="$attrs['id'] +'_content_title_two_2'"  
                                                            :content="Data" :userList="userList" :assignedArray="assignedArray"/>
                                                        </h3>
                                                    </div>
                                                </div>
                                            </div>	
								        </div>
								    </template>
							    </div>
						    </div>
					    </div>
				    </div>
			    </div>
		    </section>
	    </template>
        <audio_player_one @reloadComponentAudio="reloadComponentAudio" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
    `,
};

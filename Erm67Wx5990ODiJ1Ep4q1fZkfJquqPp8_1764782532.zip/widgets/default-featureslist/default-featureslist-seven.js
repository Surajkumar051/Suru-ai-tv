let { getFeaturedSectionDataForHomePage } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl,getLocale } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_seven}=await import(window.importLocalJs('widgets/content-hover/content-hover-seven.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_six}=await import(window.importLocalJs('widgets/content-title/content-title-six.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "default_featureslist_seven",
    components: {
        content_hover_seven,
        audio_player_one,
        content_title_six,
        
    },
    data() {
        return {
            featureContentList: [],
            isLogedIn: localStorage.getItem('isloggedin'),
            pageNo:1,
            isNextPageCallReqd:true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true,
            userList:[],
			// assignedArray: [],
            gutterSpace: null,
            
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        // console.log("mounted in default-featureslist1 page");
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
        this.getFeaturedSections(this.pageNo,false);
        this.loadMore();

    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
        getFeaturedSections(page, onScroll) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                JsLoadingOverlay.show();
				//feature-list Meta data deiatils statrs here
				const metaKey='meta-feature-list';
				// getMetaData(metaKey).then((res) => {
				
				// 	this.gutterSpace=res.data.data["gutter-space"];
				// 	this.assignedArray=res.data.data.assigned; 
					
				// });
				//feature-list Meta data deiatils ends here
                getFeaturedSectionDataForHomePage(page).then((res) => {
                    JsLoadingOverlay.hide();
                    // if (res.data.code == 200 && res.data.data.featuredContentList) {
                    //     this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                    // }
                    if (!onScroll && res.data.code == 200 && res.data.data.featuredContentList) {
                            this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                            this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);   
                    } else if (onScroll && res.data.code == 200 && res.data.data.featuredContentList?.featured_content_list?.length>0) {
                            this.featureContentList.push(...res.data.data.featuredContentList.featured_content_list);
                            this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);   
                    }  

                    if(res.data.code == 200 &&  this.featureContentList?.length < res.data.data.featuredContentList.page_info.total_count){
                            this.isNextPageCallReqd = true;
                    }
                    
                });
            }
        },
        loadMore() {
            // window.onscroll = () => {
            //         //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //         let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight+20 >= document.documentElement.scrollHeight;
            //         //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //         if(bottomOfWindow && this.isNextPageCallReqd && scrollLoad){
            //                 this.pageNo++;
            //                 this.getFeaturedSections(this.pageNo,true);
            //         }
            // }
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                        this.getFeaturedSections(this.pageNo,true);
                }
            };
        },
        playAudioContent(content_detail) { //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        async getPartnerAndUserUuids(featuredSecList){
            let uuids = [];
            await featuredSecList.forEach((featuredSec) => {
                if(featuredSec?.section_content_list?.content_list){
                  contentHelper.getPartnerAndUserUuids(featuredSec?.section_content_list?.content_list,this.userList)
                }
            });
        },
        reloadComponentAudio(content_detail) {
            this.playAudioContent(content_detail); //Er-101092
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template: `
    <vd-component class="vd default-featureslist-seven" type="default-featureslist-seven">
	<template v-if="featureContentList " v-for="Data in featureContentList">
        <section vd-readonly="true" meta-key='meta-feature-list' vd-node="metaData" class="product-listing" v-if="Data.section_content_list !== null">

            <div class="slide-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6 text-left mb-4 mt-4">
                        <h2 vd-readonly="true" v-if="Data.section_content_list !== null">{{Data.feature_section_name}}</h2>
                        </div>
                        <span class="view-all mb-4 mt-4" v-if="Data.section_content_list?.page_info?.total_count>6">
                            <a class="callByAjax" :href="'/featured-contents/'+ Data.feature_section_uuid" ><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></a>
                        </span>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="owl-product-emerald slide-slider-full owl-carousel owl-theme">
                            <template v-if="Data.section_content_list !== null" v-for="Data in Data.section_content_list.content_list">
                                <div class="owl-items">
                                    <div class="slide-one">
                                        <div class="freeContent-tag" v-if="Data?.is_free_content">
                                            <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                        </div>
                                        <div class="mrContent-tag" v-if="Data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                            <span>{{maturity_rating?.maturity_rating_list[Data?.maturity_rating]}}</span>
                                        </div>
                                        <div :class="(Data.content_asset_type == 2 && Data.is_playlist!=1)?'icons-apply-audio':'icons-apply'" :class="(Data.content_asset_type == 6 && Data.is_playlist!=1)?'doc-img':''">
                                            <img v-if="Data.content_asset_type == 1 && Data.is_playlist!=1 && (Data.video_details == null || Data.video_details?.is_live_feed == false)" :src="rootUrl + 'img/video-icons.png'"/>
                                            <img v-if="Data.content_asset_type == 2 && Data.is_playlist!=1" :src="rootUrl + 'img/audio-icon.png'"/>
                                            <img v-if="Data.content_asset_type == 6 && Data.is_playlist!=1" :src="rootUrl + 'img/file-icon.png'"/>
                                            <img v-if="Data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                            <svg v-if = "Data.content_asset_type == 1 && Data.is_playlist!=1 && Data.video_details?.is_live_feed == true"
                                                xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                <path d="M12.2 4.33333C12.2 3.598 11.5721 3 10.8 3H2.4C1.6279 3 1 3.598 1 4.33333V11C1 11.7353 1.6279 12.3333 2.4 12.3333H10.8C11.5721 12.3333 12.2 11.7353 12.2 11V8.778L15 11V4.33333L12.2 6.55533V4.33333Z" fill="#7B8794"></path>
                                                <circle cx="6.64062" cy="7.65234" r="2.25" fill="white" fill-opacity="0.6"></circle>
                                            </svg>
                                        </div>
                                        <div class="slide-image">
                                            <content_hover_seven :downloadBtnText="i18n($attrs['label7'])" :openBtnText="i18n($attrs['label8'])" :id="$attrs['id'] +'_content_hover_seven_7'" 
                                            :content="Data" :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])" :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"/>
                                            <img loading="lazy" v-if="Data.posters.website != null && Data.posters.website[0].file_url !== ''" :src="Data.posters.website[0].file_url" alt="poster" class="mw-100"/>
                                            <img loading="lazy" v-if="Data.posters.website == null || Data.posters.website[0].file_url === ''" :src="Data.no_image_available_url" alt="poster" class="mw-100"/>
                                        </div>
                                        <div :class="(Data.content_asset_type == 2)?'icons-apply-audio':'icons-apply'">
                                            <img v-if="Data.content_asset_type == 1  && Data.is_playlist!=1" :src="rootUrl + 'img/video-icons.png'"/>
                                            <img v-if="Data.content_asset_type == 2  && Data.is_playlist!=1" :src="rootUrl + 'img/audio-icon.png'"/>
                                            <img v-if="Data.content_asset_type == 6 && Data.is_playlist!=1" :src="rootUrl + 'img/file-icon.png'"/>
                                            <img v-if="Data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                        </div>
                                        <div class="slide-content">
                                            <content_title_six :id="$attrs['id'] +'_content_title_six_6'"  
                                                :content="Data" :userList="userList"/>

                                            <!--<h2><a class="callByAjax" :href="'/content/'+ Data.content_permalink"><span v-if="Data.content_name">{{Data.content_name}}</span></a> <img :src="rootUrl + 'img/plus.png'" alt="icon"></h2>
                                            <p>Radhe is a singing prodigy determined to follow in the classical footsteps of his grandfather.</p>
                                            <span class="tag">2 h 20 min</span>
                                            <span class="tag">2020</span>
                                            <span class="tag"><b>HD</b></span>
                                            <span class="tag"><b>16+</b></span>-->
                                        </div>
                                    </div>
                                </div>
                            </template>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </template>
    <audio_player_one @reloadComponentAudio="reloadComponentAudio" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
    `,
};

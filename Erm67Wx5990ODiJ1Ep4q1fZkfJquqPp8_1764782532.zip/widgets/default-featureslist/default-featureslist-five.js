let { getFeaturedSectionDataForHomePage,getContentSettingsDetails} = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl ,getAssetUrl} = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_eight}=await import(window.importLocalJs('widgets/content-hover/content-hover-eight.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_eight}=await import(window.importLocalJs('widgets/content-title/content-title-eight.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { mapState, mapActions } = Vuex;

export default {
    name: "default_featureslist_five",
    components: {
        content_hover_eight,
        audio_player_one,
        content_title_eight
    },
    data() {
        return {
            featureContentList: [],
            isLogedIn: localStorage.getItem('isloggedin'),
            pageNo:1,
            isNextPageCallReqd:true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            assetUrl:getAssetUrl(),
            reloadOnUpdateLifeCycle: true,
            userList:[],
            assignedArray: [],
            gutterSpace: null,
            isFavComponent: true,
            isFavouriteEnabled: false,
            
            
        }
    },
     updated() {
     this.$nextTick(() => {
        owlCarousal(); 
        if (this.skipCarouselUpdate && this.scrollBeforeUpdate) {
            setTimeout(() => {
                this.restoreScrollPosition(this.scrollBeforeUpdate);
                this.scrollBeforeUpdate = 0;
                this.skipCarouselUpdate = false;
            }, 150); 
        } else {
            this.skipCarouselUpdate = false;
        }
     });
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        // console.log("mounted in default-featureslist1 page");
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
        this.getFeaturedSections(this.pageNo,false);
        this.loadMore();

                getContentSettingsDetails().then((res) => {
                    //console.log('res',res)
                if (res.data.code == 200) {
                    
                    this.isFavouriteEnabled =
                        res.data.data.contentSettings
                            .content_favourite_settings != null
                            ? res.data.data.contentSettings
                                  .content_favourite_settings?.is_enabled
                            : false;
                  
                }
            });

    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
        getAssetUrl,
        getFeaturedSections(page, onScroll) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                JsLoadingOverlay.show();
                getFeaturedSectionDataForHomePage(page).then((res) => {
                    JsLoadingOverlay.hide();
                    // if (res.data.code == 200 && res.data.data.featuredContentList) {
                    //     this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                    // }
										
										
                    if (!onScroll && res.data.code == 200 && res.data.data.featuredContentList) {
                            this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                            this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);   
                    } else if (onScroll && res.data.code == 200 && res.data.data.featuredContentList?.featured_content_list?.length>0) {
                            this.featureContentList.push(...res.data.data.featuredContentList.featured_content_list);
                            this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);   
                    }  

                    if(res.data.code == 200 &&  this.featureContentList?.length < res.data.data.featuredContentList.page_info.total_count){
                            this.isNextPageCallReqd = true;
                    }
                    
                });
            }
        },
        loadMore() {
            // $(document.body).ontouchmove=()=>{
            //     let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight+20 >= document.documentElement.scrollHeight;
            //     //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //     if(bottomOfWindow && this.isNextPageCallReqd && scrollLoad){
            //             this.pageNo++;
            //             this.getFeaturedSections(this.pageNo,true);
            //     }

            // }
            // window.onscroll = () => {
            //         //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //         let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight+20 >= document.documentElement.scrollHeight;
            //         //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //         if(bottomOfWindow && this.isNextPageCallReqd && scrollLoad){
            //                 this.pageNo++;
            //                 this.getFeaturedSections(this.pageNo,true);
            //         }
            // }
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                        this.getFeaturedSections(this.pageNo,true);
                }
            };
        },
        favouriteEvent(contentDetails) {
          const param = {
              app_token: ":app_token",
              product_key: ":product_key",
              store_key: ":store_key",
              end_user_uuid: ":me",
              content_uuid: contentDetails.content_uuid,
              is_favourite: 0, // only unfavorite is possible from this page
              profile_uuid:":profile_uuid"
          };
          makeContentFavorite(param).then((res) => {
              this.pageNo = 1;
              this.isNextPageCallReqd = true;
              // if (res.data.code == 200 && res.data.status == "SUCCESS") {
              //     this.getFavoriteContents(this.pageNo, false);
              // }
          });
      },
        playAudioContent(content_detail) { //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        async getPartnerAndUserUuids(featuredSecList){
            let uuids = [];
            await featuredSecList.forEach((featuredSec) => {
                if(featuredSec?.section_content_list?.content_list){
                  contentHelper.getPartnerAndUserUuids(featuredSec?.section_content_list?.content_list,this.userList)
                }
            });
        },
        reloadComponentAudio(content_detail) {
            this.playAudioContent(content_detail); //Er-101092
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    /*html*/
    template: `<vd-component class="vd default-featureslist-five" type="default-featureslist-five">
	<!--Top Series Section Start Here-->
	<template v-if="featureContentList " v-for="(Data,index) in featureContentList">
    <!--Top Movies Section Start Here-->
    <section class="product-listing p-0" :class="index == 0 ? 'mt-min300' : ''" vd-readonly="true"  v-if="Data.section_content_list !== null">
    <div class="container-fluid pl-65">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
          <div class="contect-listing">
            <div class="episode-heading">
            <h2 vd-node="styleOnly" vd-readonly="true" class="sub-heading white-color" v-if="Data.section_content_list !== null && Data.section_content_list?.content_list?.length>0">{{Data.feature_section_name}}</h2>
            <span vd-readonly="true" class="view-all" v-if="Data.section_content_list?.page_info?.total_count>6">
              <a class="callByAjax" :href="'/featured-contents/'+ Data.feature_section_uuid"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></a>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
                </svg>              
            </span>
            </div>
            <div class="owl-product-garnet owl-carousel owl-theme">
              <template v-if="Data.section_content_list !== null" v-for="Data in Data.section_content_list.content_list">
              <div class="item">    
              <a v-if="Data?.is_playlist==1" :href="'/playlist/'+Data.content_permalink" class="callByAjax">              
               <div class="picture">
               <div class="freeContent-tag" v-if="Data?.is_free_content">
                    <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
               </div>
               <div class="mrContent-tag" v-if="Data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                    <span>{{maturity_rating?.maturity_rating_list[Data?.maturity_rating]}}</span>
                </div>
              
                <img loading="lazy" v-if="Data.posters.website != null && Data.posters.website[0].file_url !== ''" :src="Data.posters.website[0].file_url" alt="Godzilla" class="mw-100"/>
                <img loading="lazy" v-if="Data.posters.website == null || Data.posters.website[0].file_url === ''" :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="Godzilla" class="mw-100"/>
                <div class="box-hover">                     
                   <!-- <a href="javascript:void(0);">Play Now</a>
                   <a href="javascript:void(0);">View Trailer</a>                      -->
                </div>
              </div>
               </a>
               <a v-else :href="'/content/'+Data.content_permalink" class="callByAjax">              
               <div class="picture">
               <div class="freeContent-tag" v-if="Data?.is_free_content">
                    <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
               </div>
               <div class="mrContent-tag" v-if="Data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                    <span>{{maturity_rating?.maturity_rating_list[Data?.maturity_rating]}}</span>
                </div>
              
                <img loading="lazy" v-if="Data.posters.website != null && Data.posters.website[0].file_url !== ''" :src="Data.posters.website[0].file_url" alt="Godzilla" class="mw-100"/>
                <img loading="lazy" v-if="Data.posters.website == null || Data.posters.website[0].file_url === ''" :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="Godzilla" class="mw-100"/>
                 <div class="box-hover">                     
                   <!-- <a href="javascript:void(0);">Play Now</a>
                   <a href="javascript:void(0);">View Trailer</a>                      -->
                </div>
              </div>
              </a>
               <div class="data">
               <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'"  
               :content="Data" :userList="userList" />
               <content_hover_eight :downloadBtnText="i18n($attrs['label7'])" :openBtnText="i18n($attrs['label8'])" :id="$attrs['id'] +'_content_hover_eight_1'" 
               :content="Data" :isFavouriteSettings="isFavouriteEnabled" :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])" :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent" />
               </div>                
              </div>  
              </template>     
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
   <!--TOp Movies Section End Here-->
	</template>
   <audio_player_one @reloadComponentAudio="reloadComponentAudio" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>`,
};

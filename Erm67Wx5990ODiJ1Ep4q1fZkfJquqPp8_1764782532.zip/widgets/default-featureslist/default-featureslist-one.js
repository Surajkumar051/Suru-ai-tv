let { getFeaturedSectionDataForHomePage } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl,getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS  } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "default_featureslist_one",
    components: {
        content_hover_one,
        audio_player_one,
        content_title_one
    },
    data() {
        return {
            featureContentList: [],
            isLogedIn: localStorage.getItem('isloggedin'),
            pageNo:1,
            isNextPageCallReqd:true,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle: true,
            userList:[],
            contentPreorderStatusMap:  new Map(),
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },

    mounted() {
        scrollLoad = true; //@ER: 74207
        // console.log("mounted in default-featureslist1 page");
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
        this.getFeaturedSections(this.pageNo,false);
        this.loadMore();

    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
        getFeaturedSections(page, onScroll) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false,
                JsLoadingOverlay.show();
                getFeaturedSectionDataForHomePage(page).then((res) => {
                    JsLoadingOverlay.hide();
                    // if (res.data.code == 200 && res.data.data.featuredContentList) {
                    //     this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                    // }
                    if (!onScroll && res.data.code == 200 && res.data.data.featuredContentList) {
                            this.featureContentList = res.data.data.featuredContentList.featured_content_list;
                            this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);   
                    } else if (onScroll && res.data.code == 200 && res.data.data.featuredContentList?.featured_content_list?.length>0) {
                            this.featureContentList.push(...res.data.data.featuredContentList.featured_content_list);
                            this.getPartnerAndUserUuids(res.data.data.featuredContentList.featured_content_list);   
                    }  

                    if(res.data.code == 200 &&  this.featureContentList?.length < res.data.data.featuredContentList.page_info.total_count){
                            this.isNextPageCallReqd = true;
                    }
                    
                });
            }
        },
        loadMore() {
            // window.onscroll = () => {
            //         //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
            //         let bottomOfWindow = document.documentElement.scrollTop + document.documentElement.clientHeight+20 >= document.documentElement.scrollHeight;
            //         //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
            //         if(bottomOfWindow && this.isNextPageCallReqd && scrollLoad){
            //                 this.pageNo++;
            //                 this.getFeaturedSections(this.pageNo,true);
            //         }
            // }
            window.onscroll = () => {
                const footerEle = document.getElementById('footer');
                const scrollStartPos = footerEle.getBoundingClientRect().top;
                const windowHeight = window.innerHeight;
                if (scrollStartPos <= windowHeight && this.isNextPageCallReqd && scrollLoad) {
                        this.pageNo++;
                        this.getFeaturedSections(this.pageNo,true);
                }
            };
        },
        playAudioContent(content_detail) { //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        async getPartnerAndUserUuids(featuredSecList){
            let uuids = [];
            await featuredSecList.forEach((featuredSec) => {
                if(featuredSec?.section_content_list?.content_list){
                  contentHelper.getPartnerAndUserUuids(featuredSec?.section_content_list?.content_list,this.userList)
                  const contentUuids = featuredSec?.section_content_list?.content_list.map(item => item.content_uuid);
				  contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

                }
            });
        },
        reloadComponentAudio(content_detail) {
            this.playAudioContent(content_detail); //Er-101092
        }
    },
    template: `
<vd-component class="vd default-featureslist-one" type="default-featureslist-one">
	<!--Top Series Section Start Here-->
	<template v-if="featureContentList " v-for="Data in featureContentList">
		<section class="product-listing" v-if="Data.section_content_list !== null">
			<div class="container-fluid">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
						<div class="contect-listing">
							<div class="episode-heading" >
								<h2 class="sub-heading white-color" v-if="Data.section_content_list !== null && Data.section_content_list?.content_list?.length>0">{{Data.feature_section_name}}</h2>
								<span class="view-all" v-if="Data.section_content_list?.page_info?.total_count>6">
									<a class="callByAjax" :href="'/featured-contents/'+ Data.feature_section_uuid" ><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></a>
								</span>
							</div>
							<div class="owl-product owl-carousel owl-theme">
								<template v-if="Data.section_content_list !== null" v-for="Data in Data.section_content_list.content_list">
									<div class="item">
										<div class="picture">
                                        <div class="freeContent-tag" v-if="Data?.is_free_content">
                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                     </div>
                                        <div class="mrContent-tag" v-if="Data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[Data?.maturity_rating]}}</span>
                                     </div>

                                     <div :class="(Data.content_asset_type == 2 && Data.is_playlist!=1)?'icons-apply-audio':'icons-apply'" :class="(Data.content_asset_type == 6 && Data.is_playlist!=1)?'doc-img':''">												
                                                <img v-if="Data.content_asset_type == 1 && Data.is_playlist!=1 && (Data.video_details == null || Data.video_details?.is_live_feed == false)" :src="rootUrl + 'img/video-icons.png'"/>
												<img v-if="Data.content_asset_type == 2 && Data.is_playlist!=1" :src="rootUrl + 'img/audio-icon.png'"/>
                                                <img v-if="Data.content_asset_type == 6 && Data.is_playlist!=1" :src="rootUrl + 'img/file-icon.png'"/>
                                                <img v-if="Data.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                                <svg v-if = "Data.content_asset_type == 1 && Data.is_playlist!=1 && Data.video_details?.is_live_feed == true"
                                                    xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                    <path d="M12.2 4.33333C12.2 3.598 11.5721 3 10.8 3H2.4C1.6279 3 1 3.598 1 4.33333V11C1 11.7353 1.6279 12.3333 2.4 12.3333H10.8C11.5721 12.3333 12.2 11.7353 12.2 11V8.778L15 11V4.33333L12.2 6.55533V4.33333Z" fill="#7B8794"></path>
                                                    <circle cx="6.64062" cy="7.65234" r="2.25" fill="white" fill-opacity="0.6"></circle>
                                                </svg>
											</div>
											<img loading="lazy" v-if="Data.posters.website != null && Data.posters.website[0].file_url !== ''" :src="Data.posters.website[0].file_url" alt="Godzilla" class="mw-100"/>
											<img loading="lazy" v-if="Data.posters.website == null || Data.posters.website[0].file_url === ''" :src="Data.no_image_available_url" alt="Godzilla" class="mw-100"/>
											<content_hover_one :id="$attrs['id'] +'_content_hover_one_1'" 
                                            :downloadBtnText="i18n($attrs['label7'])" :openBtnText="i18n($attrs['label8'])" :content="Data" :playNowBtnTxt="i18n($attrs['label1'])" :viewTrailerBtnTxt="i18n($attrs['label2'])" :playAllBtnTxt="i18n($attrs['label3'])" :watchNowBtnTxt="i18n($attrs['label4'])" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
                                            :preOrderBtnTxt  = "i18n($attrs['label9'])"
									        :contentPreorderStatusMap = "contentPreorderStatusMap"
/>
										</div>
										<content_title_one :id="$attrs['id'] +'_content_title_one_1'"  
                                        :content="Data" :userList="userList" />
                                        <!--<div class="data">
											<a class="callByAjax"  :href="'/content/'+ Data.content_permalink">
												<span v-if="Data.content_name">{{Data.content_name}}</span>
											</a>
										</div>-->
									</div>
								</template>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</template>
    <audio_player_one @reloadComponentAudio="reloadComponentAudio" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>
    `

}

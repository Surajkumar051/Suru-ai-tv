let {default:content_hover_four}=await import(window.importLocalJs('widgets/content-hover/content-hover-four.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let {GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
const ChildListThree = {
    name: "child_list_three",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        freeContentText: String,
    },
    components: {
        content_hover_four,
        audio_player_one,
        content_title_one
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            userList:[],
            assignedArray: [],
            gutterSpace:null,
            downloadBtnText:"",
            openBtnText:""
        };
    },
    watch: {
        optView(optView) {},
        "parentContent.child_content"(parentContent){
            contentHelper.getPartnerAndUserUuids(parentContent.child_content, this.userList);
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted(){
                this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
                this.$store.dispatch(GET_MATURITY_RATINGS);
        contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
    },
    created(){
        contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
    },

    methods: {
        i18n,
        playAudioContent(content_detail){ //ER-101092
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
    <vd-component class="vd child-list-three w-100" type="child-list-three">
        <div  class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="optView == 0">
        <div class="row" id="childListDiv" meta-key='meta-content-details' vd-node="metaData">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="(childObj,i) in parentContent.child_content">
                <div class="tiles grid-hover">
                    <div class="picture">
                        <div class="freeContent-tag" v-if="childObj?.is_free_content">
                            <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
                        </div>
                        <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                            <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                        </div>
                        <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="w-100"/>
                        <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="w-100"/>
                        <div class="box-hover">
                            <content_title_one :id="$attrs['id'] +'_content_title_one_1'" 
                                :content="childObj" :userList="userList" :assignedArray="assignedArray"/>
                                <!--<div class="data">
                                <a class="callByAjax" :href="'/content/'+childObj.content_permalink">
                                    <span vd-readonly="true">{{childObj.content_name}}</span>
                                </a>
                            </div>--> 
                            <!--Button Show on Hover start Here-->
                                           
                            <content_hover_four
                                :id="$attrs['id'] +'_content_hover_four_4'"
                                :content="childObj" 
                                :playNowBtnTxt="playNowBtnTxt"
                                :viewTrailerBtnTxt="viewTrailerBtnTxt"
                                :playAllBtnTxt="playAllBtnTxt"
                                :watchNowBtnTxt="watchNowBtnTxt"
                                :isLogedIn="isLogedIn"
                                @playAudioContent="playAudioContent"
                                :downloadBtnText="downloadBtnText"
                                :openBtnText="openBtnText"
                            />                  
                       
                        <!--Button Show on Hover end Here-->
                        </div> 
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <div id="childListDiv" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="optView == 1">
        <div class="season-list d-md-flex d-lg-flex d-xl-flex grid-hover list-hover" v-for="(childObj,i) in parentContent.child_content">
            <div class="number">
                <span vd-readonly="true">{{i+1}}</span>
            </div>
            <div class="row" style="width: 100%;">
             <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" >
                <div class="picture">
                <div class="freeContent-tag" v-if="childObj?.is_free_content">
                    <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
                </div>
                <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                     <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                  </div>
                <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="w-100"/>
                <img  loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="w-100"/>
                <!--Button Show on Hover start Here-->
                <div class="box-hover"> 
                    <content_hover_four 
                        :id="$attrs['id'] +'_content_hover_four_4'"
                        :content="childObj" 
                        :playNowBtnTxt="playNowBtnTxt"
                        :viewTrailerBtnTxt="viewTrailerBtnTxt"
                        :playAllBtnTxt="playAllBtnTxt"
                        :watchNowBtnTxt="watchNowBtnTxt"
                        :isLogedIn="isLogedIn"
                        @playAudioContent="playAudioContent"
                        :downloadBtnText="downloadBtnText"
                        :openBtnText="openBtnText"
                    />
                </div>    
                <!--Button Show on Hover end Here-->
            </div>
             </div>
             <div class="col-xs-12 col-sm-6 col-md-8 col-lg-10 col-xl-10" >
                <div class="content">
                <div class="heading">
                    <h3 vd-readonly="true" class="truncate-text lc-one">
                        <a :href="'/content/'+childObj?.content_permalink">
                            {{childObj?.content_name}}
                        </a>
                    </h3>

                </div>
                <div class="data" v-if="childObj?.content_desc?.length <= 500">
                    <p vd-readonly="true">{{childObj?.content_desc}}</p>
                </div>
                <div class="data" v-else>
                    <p vd-readonly="true">{{childObj?.content_desc?.substring(0,500)}} <a href="javascript:void(0);" @click="$emit('setDataReadMore',childObj)" data-toggle="modal" data-target="#readmoreDesc" v-if="childObj?.content_desc?.length > 500">{{i18n('..Read More')}}</a></p>
                </div>
            </div>
             </div>
            </div>
            
            
        </div>
    </div>
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent= "isFreeContent"/>
</vd-component>
      `,
};
export default ChildListThree;

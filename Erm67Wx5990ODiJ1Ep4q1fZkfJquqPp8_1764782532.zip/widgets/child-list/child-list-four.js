let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {
    multiHierarchy
} = await import(window.importAssetJs('js/webservices.js'));
let {GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
const ChildListFour = {
    name: "child_list_four",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        LogsArray:Object,
        quizes:Array,
        contentParentUuid:String,
        contentUUID:String,
        root_parent_uuid:String


    },
    emits: ["takeQuiz"],
    components: {
        content_hover_one,
        audio_player_one,
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            Myarray:[],
            multiHierarchyVal:"",
            downloadBtnText:"",
            openBtnText:""

        };
    },
    watch: {
        optView(optView) {},
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted() {
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.checkLogs();
        if(this.contentParentUuid){
            this.multiHierarchy(this.contentParentUuid)

        }
        
    },
    updated() {
        if($('#course_'+this.contentUUID).length > 0) {
            var parent = $('#course_'+this.contentUUID).data('parent-id');
            if($('#chapter_'+parent).hasClass('collapsed')) {
                $('#chapter_'+parent).trigger('click');
                $('#course_'+this.contentUUID).parent().parent().addClass('active-course');  
            } else {
                $('#course_'+this.contentUUID).parent().parent().addClass('active-course');
            }
        }
        
    },
    methods: {
        takeQuiz(quizes, content_id) {
            this.$emit("takeQuiz", quizes, content_id);
        },
        async multiHierarchy(content_uuid) {
            if (content_uuid) {
                var content_uuid = await multiHierarchy(content_uuid);
                if (content_uuid.data.code == 200) {
                    this.multiHierarchyVal=content_uuid.data.data;
                }
            }
        },
        checkLogs(){
            var arr =this.LogsArray;
            var Myarray=[];
            $.each(arr,function(index,obj){
                if(obj.content_uuid ){
                    Myarray.push(obj.content_uuid)
                }

            });
                    
            this.Myarray=Myarray;
            console.log('this.LogsArray',this.Myarray)

   
        },
        playAudioContent(content_detail){ //ER-101092
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        timeFormating(duration, contentType) {
            if (duration !== null && contentType === 1) {
                const vDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (vDuration.length <= 5) {
                    var videoDuration = vDuration
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration", videoDuration);
                } else {
                    videoDuration = vDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                    console.log("this.videoDuration else", videoDuration);
                }
                return videoDuration;
            }
            if (duration !== null && contentType === 2) {
                const aDuration = duration.replace(/^0(?:0:0?)?/, "");
                if (aDuration.length <= 5) {
                    var audioDuration = aDuration
                        .replace(":", "m ")
                        .concat("s");
                } else {
                    var audioDuration = aDuration
                        .replace(":", "h ")
                        .replace(":", "m ")
                        .concat("s");
                }
                return audioDuration;
            }
        },
    },

    template: `
    <div class="" v-for="(childObj,i) in parentContent.child_content">
    <div class="single-course course-box border-bottom row gx-3">
        <div class="col-auto">
        <input :data-parent-id = "parentContent.content_uuid" class="form-check-input course-complete" type="radio" :name="'courseOne'+childObj.content_uuid" :id="'course_'+childObj.content_uuid" disabled checked v-if="Myarray.includes(childObj.content_uuid)">
        <input :data-parent-id = "parentContent.content_uuid" class="form-check-input" type="radio" :name="'courseOne'+childObj.content_uuid" :id="'course_'+childObj.content_uuid" disabled="" v-else>
        </div>
        <div class="col">
            <a :href="'/player/'+childObj?.content_permalink+'/'+root_parent_uuid">
                <p vd-readonly="true">{{childObj?.content_name}}</p>
                <div class="d-flex align-items-center">
                    <button class="play-course">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9C16.4955 13.1403 13.1403 16.4955 9 16.5ZM3 9.129C3.03549 12.4299 5.73083 15.0822 9.0319 15.0645C12.333 15.0467 14.9997 12.3656 14.9997 9.0645C14.9997 5.76338 12.333 3.08233 9.0319 3.0645C5.73083 3.04684 3.03549 5.69907 3 9V9.129ZM7.5 12.375V5.625L12 9L7.5 12.375Z" fill="#555578"/>
                        </svg>                                              
                    </button>
                    <span vd-readonly="true" v-if="childObj?.video_details.duration">{{timeFormating(childObj?.video_details.duration,childObj?.content_asset_type)}}</span>
                </div>
            </a>
        </div>
    </div>

    <div class="single-course course-box border-bottom quiz-box" :id="'quizid_'+ quiz?.map_questionnaire_uuid"  v-if="quizes[i].mapped_questionnaire" v-for="(quiz,j) in quizes[i].mapped_questionnaire" :key="j" >
        <div class="row gx-3" @click="takeQuiz(quiz, childObj?.content_uuid)"  style="cursor: pointer;">
            <div class="col-auto">
                <input class="form-check-input question" type="radio" name="courseThree" id="courseThree" disabled="">
            </div>
            <div class="col">
                <p vd-readonly="true">{{quiz.title}}</p>
            </div>
        </div>
        </div>

</div>
 



<audio_player_one :root_url="$attrs['root_url']" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"  :isFreeContent= "isFreeContent"/>
      `,
};
export default ChildListFour;

let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let {GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let {
    getBaseUrl,
    getRootUrl,
} = await import(window.importAssetJs('js/web-service-url.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
const ChildListSeven = {
    name: "child_list_seven",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        freeContentText: String,
    },
    components: {
        content_hover_six,
        audio_player_one,
        content_title_one,
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            userList: [],
            assignedArray: [],
            gutterSpace:null,
            downloadBtnText:"",
            openBtnText:"",
            rootUrl: getRootUrl(),
            isSeeMoreClicked: false,
        };
    },
    updated() {
        owlCarousal();
    },
    watch: {
        optView(optView) {},

        "parentContent.child_content"(parentContent) {
            if (parentContent.child_content != undefined) {
                contentHelper.getPartnerAndUserUuids(
                    parentContent.child_content,
                    this.userList
                );
            }
            console.log(
                "parentContent.child_content watch",
                parentContent.child_content
            );
        },
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted() {
       
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        if (this.parentContent.child_content != undefined) {
            contentHelper.getPartnerAndUserUuids(
                this.parentContent.child_content,
                this.userList
            );
        }
    },
    created() {
        if (this.parentContent.child_content != undefined) {
            contentHelper.getPartnerAndUserUuids(
                this.parentContent.child_content,
                this.userList
            );
        }
    },

    methods: {
        i18n,
        seeMoreLessClicked(status) {
            this.isSeeMoreClicked = status;
        },
        timeFormating(duration) {
            let durationToShow = "";
            if (duration != undefined) {
                let timeElements = duration.split(":");
                if (timeElements.length == 3) {
                    durationToShow =
                        Number(Number(timeElements[0] * 60) + timeElements[1]) +
                        ":" +
                        timeElements[2];
                } else if (timeElements.length == 2) {
                    durationToShow = timeElements[0] + ":" + timeElements[1];
                }
            }
            return durationToShow;
        },
        playAudioContent(content_detail){ //ER-101092
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    template: `
    <vd-component class="vd child-list-seven w-100" type="child-list-seven">
        <div v-if="optView == 0">
        <div class="row" id="childListDiv" vd-readonly="true" meta-key='meta-content-details' vd-node="metaData">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5" v-for="(childObj,i) in parentContent.child_content">
                <div class="tiles grid-hover fs-tiles" :style="{'margin-right': this.gutterSpace,'margin-left': this.gutterSpace }">
                    <div class="picture">
                        <div class="freeContent-tag" v-if="childObj?.is_free_content">
                            <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
                        </div>
                        <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                            <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                        </div>
                        <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="w-216"/>
                        <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="w-216"/>
                        <!--Button Show on Hover start Here-->
                            <content_hover_six 
                                :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                :content="childObj" 
                                :playNowBtnTxt="playNowBtnTxt"
                                :viewTrailerBtnTxt="viewTrailerBtnTxt"
                                :playAllBtnTxt="playAllBtnTxt"
                                :watchNowBtnTxt="watchNowBtnTxt"
                                :isLogedIn="isLogedIn"
                                @playAudioContent="playAudioContent"
                                :downloadBtnText="downloadBtnText"
                                :openBtnText="openBtnText"
                            />
                        <!--Button Show on Hover end Here-->
                    </div>
                   <!-- <div class="data">
                        <a class="callByAjax" :href="'/content/'+childObj?.content_permalink">
                            <span>{{childObj?.content_name}}</span>
                        </a>
                    </div>-->
                    <content_title_one :id="$attrs['id'] +'_content_title_one_1'" 
                    :content="childObj" :userList="userList" :assignedArray="assignedArray"/>
                </div>
            </div>
        </div>
    </div>
        <div class="tracks pt-0">
        <div id="childListDiv" class="table-responsive" v-if="optView == 1">
            <table class="table mb-0">
                <colgroup>
                      <col class="one-table">
                      <col class="two-table">
                      <col class="three-table">
                      <col class="four-table">
                </colgroup>
                <tbody>
                    <tr>
                        <th>#</th>
                        <th class="pl-0">&nbsp;</th>
                        <th class="pl-0">{{i18n('Tracks')}}</th>
                        <th>L.</th>
                    </tr>
                    <template v-for="(childObj,i) in parentContent.child_content" :key="i">
                        <tr v-if="i<=5">
                            <td class="icon-col fw-500">
                                <div class="serials-no disable-in-vd">{{i+1}}</div>
                                <div class="symplay-icons">
                                    <!--Button Show on Hover start Here-->
                                    <content_hover_six 
                                        :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                        :content="childObj" 
                                        :playNowBtnTxt="playNowBtnTxt"
                                        :viewTrailerBtnTxt="viewTrailerBtnTxt"
                                        :playAllBtnTxt="playAllBtnTxt"
                                        :watchNowBtnTxt="watchNowBtnTxt"
                                        :isLogedIn="isLogedIn"
                                        @playAudioContent="playAudioContent"
                                        :downloadBtnText="downloadBtnText"
                                        :openBtnText="openBtnText"
                                    />
                                    <!--Button Show on Hover end Here-->
                                </div>
                            </td>
                            <td class="pl-0">
                            <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                            <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                         </div>
                                <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url"/>
                                <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url"/>
                            </td>
                            <td class="pl-0" vd-readonly="true"><a :href="'/content/'+childObj?.content_permalink">
                                {{childObj?.content_name}}
                            </a></td>
                            <td class="pl-0">{{timeFormating(childObj?.audio_details?.duration)}}</td>
                        </tr> 
                        <tr v-if="isSeeMoreClicked && i>5">
                            <td class="icon-col fw-500">
                                <div class="serials-no disable-in-vd">{{i+1}}</div>
                                <div class="symplay-icons">
                                    <!--Button Show on Hover start Here-->
                                    <content_hover_six 
                                        :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                        :content="childObj" 
                                        :playNowBtnTxt="playNowBtnTxt"
                                        :viewTrailerBtnTxt="viewTrailerBtnTxt"
                                        :playAllBtnTxt="playAllBtnTxt"
                                        :watchNowBtnTxt="watchNowBtnTxt"
                                        :isLogedIn="isLogedIn"
                                        @playAudioContent="playAudioContent"
                                        :downloadBtnText="downloadBtnText"
                                        :openBtnText="openBtnText"
                                    />
                                    <!--Button Show on Hover end Here-->
                                </div>
                            </td>
                            <td class="pl-0">
                            <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                            <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                         </div>
                                <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url"/>
                                <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url"/>
                            </td>
                            <td class="pl-0" vd-readonly="true"><a :href="'/content/'+childObj?.content_permalink">
                                {{childObj?.content_name}}
                            </a></td>
                            <td class="pl-0">{{timeFormating(childObj?.audio_details?.duration)}}</td>
                        </tr> 
                    </template>
                    <tr class="border-bottom-0">
                        <td colspan="4">
                            <a href="javascript:void(0);" class="view-all-button" v-if="parentContent?.child_content?.length>6 && !isSeeMoreClicked" @click="seeMoreLessClicked(true)">{{i18n('View more')}}</a>
                            <a href="javascript:void(0);" class="view-all-button" v-if="parentContent?.child_content?.length>6 && isSeeMoreClicked" @click="seeMoreLessClicked(false)">{{i18n('View less')}}</a>
                        </td>
                    </tr>
                </tbody>       
            </table>
        </div>
    </div>
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"  :isFreeContent= "isFreeContent"/>
</vd-component>
      `,
};
export default ChildListSeven;

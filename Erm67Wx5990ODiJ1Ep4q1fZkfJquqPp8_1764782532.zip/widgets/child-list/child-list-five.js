let {default:content_hover_nine}=await import(window.importLocalJs('widgets/content-hover/content-hover-nine.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_eight}=await import(window.importLocalJs('widgets/content-title/content-title-eight.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let {GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
const ChildListOne = {
    name: "child_list_five",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        freeContentText: String,
    },
    components: {
        content_hover_nine,
        audio_player_one,
        content_title_eight
    },
    

    data() {
      return {
          contentUuidAudio: "",
          resetAudioPlayer: Math.floor(Math.random() * 10000000),
          isAudioPlay: false,
          userList:[],
          contentPreorderStatusMap: new Map(),   
      };
  },
  watch: {
      optView(optView) {},
      "parentContent.child_content"(parentContent){
          contentHelper.getPartnerAndUserUuids(parentContent.child_content, this.userList);
          let contentUuids = parentContent.child_content.map(item => item.content_uuid);
          contentUuids.push(parentContent.content_uuid);
          if (parentContent.content_parent_uuid != null) {
              contentUuids.push(parentContent.content_parent_uuid);
          }

      contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

      }
  },
  mounted(){
      this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
      this.$store.dispatch(GET_MATURITY_RATINGS);
      contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
      let contentUuids = this.parentContent.child_content.map(item => item.content_uuid);
      contentUuids.push(this.parentContent.content_uuid);
      if (this.parentContent.content_parent_uuid != null) {
          contentUuids.push(this.parentContent.content_parent_uuid);
      }

  contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

  },
  created(){
      contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
      let contentUuids = this.parentContent.child_content.map(item => item.content_uuid);
      contentUuids.push(this.parentContent.content_uuid);
      if (this.parentContent.content_parent_uuid != null) {
          contentUuids.push(this.parentContent.content_parent_uuid);
      }

  contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

  },

  methods: {
      i18n,
      playAudioContent(content_detail){ //ER-101092
          this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
          this.isFreeContent = content_detail.is_free_content; //ER-101092
          this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
          this.isAudioPlay = true;
      }
  },
    template: /*html*/ `
    <vd-component class="vd child-list-five" type="child-list-five">
<div class="gliView-container" :class="optView == 0 ? 'gridView-active' : ''">
    <div class="row" vd-readonly="true" >
      <!--Loop Part Design Here-->
      
      <div class="col-6"  v-if="optView == 0" v-for="(childObj,i) in parentContent.child_content">
  <div class="glvc-main">
    <div class="glvcm-left">
      <div class="glvcml-hover">
        <div class="freeContent-tag" v-if="childObj?.is_free_content">
            <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
        </div>

                  <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="glvcmlh-img w-100 h-100"/>
            <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="glvcmlh-img w-100 h-100"/>	

            <content_hover_nine :id="$attrs['id'] +'_content_hover_nine_1'" 
            :content="childObj" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
            :downloadBtnText="downloadBtnText"
            :openBtnText="openBtnText" />

      </div>
    </div>
    <div class="glvcm-right">
      <div class="glvcmr-top">
        
        <div class="glvcmr-heading">
          <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'" 
            :content="childObj" :userList="userList"/>
        </div>
      </div>
      <!--<div class="glvcmr-bottom">
        <p class="glvcmrb-para">
          In the slums of Bhopal, a failed drug with disastrous side effects, S93R, finds its way into Mangu's family
        </p>
      </div>-->
    </div>
  </div>
</div>
      
      <div class="col-6"  v-if="optView == 1" v-for="(childObj,i) in parentContent.child_content" >
        <div class="glvc-main" >
        <div class="glvcm-left">
          <div class="glvcml-hover">
                  <div class="freeContent-tag" v-if="data?.is_free_content"><span><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span></div>    

            <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="glvcmlh-img w-100 h-100"/>
            <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="glvcmlh-img w-100 h-100"/>	
            <content_hover_nine :id="$attrs['id'] +'_content_hover_nine_1'" 
              :content="childObj" :isLogedIn="isLogedIn" @playAudioContent="playAudioContent"
              :downloadBtnText="downloadBtnText"
              :openBtnText="openBtnText" />
          <!--<div class="progressBar">
            <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="70"
            aria-valuemin="0" aria-valuemax="100" style="width:70%">
              <span class="sr-only">70% Complete</span>
            </div>
            </div>
          </div>-->
          </div>
        </div>
        <div class="glvcm-right">
          <div class="glvcmr-top">
          <!--<div class="glvcmr-heading">The Mandalorian 1</div>-->
          <div class="glvcmr-heading">
          
            <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'" 
        :content="childObj" :userList="userList" />
          </div>
          <!--  <span class="glvcmrsh-meta">S1 E1</span>
          <span class="glvcmrsh-meta">14 Jan 2022</span>
          <span class="glvcmrsh-meta">48m</span>-->
          </div>
          
          <div class="glvcmr-bottom" v-if="childObj?.content_desc?.length <= 120">
          <p vd-readonly="true" class="glvcmrb-para">{{childObj.content_desc}}</p>
          </div>
          <div v-else class="glvcmr-bottom" >
          <p vd-readonly="true" class="glvcmrb-para">{{childObj?.content_desc?.substring(0,120)}}</p> 
          <a href="javascript:void(0);" class="readMore-txt" @click="$emit('setDataReadMore',childObj)" data-toggle="modal" data-target="#readmoreDesc" v-if="childObj.content_desc?.length > 120">{{i18n('ReadMore')}}</a>
          </div>

        </div>
        </div>
      </div>
      <!--Loop Part Design End Here-->
    </div>
</div>

   
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"  :isFreeContent= "isFreeContent"/>
</vd-component>
      `,
};
export default ChildListOne;

let {default:content_hover_two}=await import(window.importLocalJs('widgets/content-hover/content-hover-two.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_two}=await import(window.importLocalJs('widgets/content-title/content-title-two.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let {GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
const ChildListTwo = {
    name: "child_list_two",
       props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        freeContentText: String,
        preOrderBtnTxt:"",
    },
    components: {
        content_hover_two,
        audio_player_one,
        content_title_two
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            userList:[],
			assignedArray: [],
            gutterSpace:null,
            downloadBtnText:"",
            openBtnText:"" ,
            contentPreorderStatusMap: new Map(),
        };
    },
    watch: {
        optView(optView) {},
        "parentContent.child_content"(parentContent){
            contentHelper.getPartnerAndUserUuids(parentContent.child_content, this.userList);
            const contentUuids = parentContent.child_content.map(item => item.content_uuid);
		    contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted(){
      
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
        const contentUuids = parentContent.child_content.map(item => item.content_uuid);
        contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

    },
    created(){
        contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
        const contentUuids = parentContent.child_content.map(item => item.content_uuid);
        contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

    },

    methods: {
        i18n,
        playAudioContent(content_detail){ //ER-101092
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
 <vd-component class="vd child-list-two w-100" type="child-list-two">    
    <div  class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mt-3" v-if="optView == 0">
      <div class="raiden-product-slider videoallseasion-grids">
       <div class="row" id="childListDiv" meta-key='meta-content-details' vd-node="metaData">
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3" v-for="(childObj,i) in parentContent.child_content">
         <div class="product-slider-container">
            <div class="product-slider-image">
                <div class="freeContent-tag" v-if="childObj?.is_free_content">
                    <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
                </div>
                <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                    <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                </div>
              	<img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" />
				<img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url"/>
              <!--Button Show on Hover start Here-->
                <content_hover_two 
                    :id="$attrs['id'] +'_content_hover_two_2'"
                    :content="childObj" 
                    :isLogedIn="isLogedIn"
                    @playAudioContent="playAudioContent"
                    :downloadBtnText="downloadBtnText"
                    :openBtnText="openBtnText"
                    :preOrderBtnTxt  = "preOrderBtnTxt"
					:contentPreorderStatusMap = "contentPreorderStatusMap"

                />
              <!--Button Show on Hover end Here-->
            </div>
            <div class="gen-info-contain">
                <div class="gen-movie-info">
                 <h3 vd-readonly="true">
                 <content_title_two :id="$attrs['id'] +'_content_title_two_2'" 
                    :content="childObj" :userList="userList" :assignedArray="assignedArray"/>
                 </h3>                 
                </div>
            </div>
         </div>
		</div>
	</div>
  </div>
</div>
<div id="childListDiv" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="optView == 1">
   <div class="raiden-product-slider videoallseasion-grids">
	<div class="season-list d-md-flex d-lg-flex d-xl-flex" v-for="(childObj,i) in parentContent.child_content">
		<div class="number disable-in-vd">
			<span>{{i+1}}</span>
		</div>
		<div class="picture">
         <div class="product-slider-container mb-0">
          <div class="product-slider-image mb-0">
            <div class="freeContent-tag" v-if="childObj?.is_free_content">
                <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
            </div>
            <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
            </div>
			<img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="w-100"/>
			<img  loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="w-100"/>
			<!--Button Show on Hover start Here-->
               <content_hover_two 
                    :id="$attrs['id'] +'_content_hover_two_2'"
                    :content="childObj" 
                    :isLogedIn="isLogedIn"
                    @playAudioContent="playAudioContent"
                    :downloadBtnText="downloadBtnText"
                    :openBtnText="openBtnText"
                    :preOrderBtnTxt  = "preOrderBtnTxt"
					:contentPreorderStatusMap = "contentPreorderStatusMap"

                />
            <!--Button Show on Hover end Here-->
          </div> 
         </div>             
		</div>
		<!--Button Show on Hover End Here-->
		<div class="content">
			<div class="heading">
				<h3 vd-readonly="true"><a class="callByAjax" :href="'/content/'+childObj?.content_permalink">{{childObj?.content_name}}</a></h3>
			</div>
			<div class="data" v-if="childObj?.content_desc?.length <= 500">
				<p vd-readonly="true" >{{childObj?.content_desc}}</p>
			</div>
            <div class="data" v-else>
				<p vd-readonly="true">{{childObj?.content_desc?.substring(0,500)}} <a class="callByAjax" href="javascript:void(0);" @click="$emit('setDataReadMore',childObj)" data-toggle="modal" data-target="#readmoreDesc" v-if="childObj.content_desc?.length > 500">{{i18n('..ReadMore')}}</a></p>
			</div>
		</div>
	</div>
  </div>  
</div>
<audio_player_one :root_url="$attrs['root_url']" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"  :isFreeContent= "isFreeContent"/>
</vd-component>
      `,
};
export default ChildListTwo;

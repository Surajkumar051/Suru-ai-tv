let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING ,GET_MATURITY_RATINGS} = await import(window.importAssetJs('js/configurations/actions.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
const ChildListOne = {
    name: "child_list_one",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        freeContentText: String,
        downloadBtnText:"",
        openBtnText:"",
        preOrderBtnTxt:"",

    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },

    components: {
        content_hover_one,
        audio_player_one,
        content_title_one
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            userList:[],
            contentPreorderStatusMap: new Map(),   
        };
    },
    watch: {
        optView(optView) {},
        "parentContent.child_content"(parentContent){
            contentHelper.getPartnerAndUserUuids(parentContent.child_content, this.userList);
            let contentUuids = parentContent.child_content.map(item => item.content_uuid);
            contentUuids.push(parentContent.content_uuid);
            if (parentContent.content_parent_uuid != null) {
                contentUuids.push(parentContent.content_parent_uuid);
            }

		    contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

        }
    },
    mounted(){
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
        let contentUuids = this.parentContent.child_content.map(item => item.content_uuid);
        contentUuids.push(this.parentContent.content_uuid);
        if (this.parentContent.content_parent_uuid != null) {
            contentUuids.push(this.parentContent.content_parent_uuid);
        }

		contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

    },
    created(){
        contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
        let contentUuids = this.parentContent.child_content.map(item => item.content_uuid);
        contentUuids.push(this.parentContent.content_uuid);
        if (this.parentContent.content_parent_uuid != null) {
            contentUuids.push(this.parentContent.content_parent_uuid);
        }

		contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

    },

    methods: {
        i18n,
        playAudioContent(content_detail){ //ER-101092
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },

    template: `
    <vd-component class="vd child-list-one w-100" type="child-list-one">
        <div  class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="optView == 0">
        <div class="row" id="childListDiv">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-2" v-for="(childObj,i) in parentContent.child_content">
                <div class="tiles grid-hover">
                    <div class="picture">
                    <div class="freeContent-tag" v-if="childObj?.is_free_content">
                    <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
                 </div>
                    <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                     <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                  </div>

                        <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="w-100"/>
                        <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="w-100"/>
                        <!--Button Show on Hover start Here-->
                            <content_hover_one
                                :id="$attrs['id'] +'_content_hover_one_1'"
                                :content="childObj" 
                                :playNowBtnTxt="playNowBtnTxt"
                                :viewTrailerBtnTxt="viewTrailerBtnTxt"
                                :playAllBtnTxt="playAllBtnTxt"
                                :watchNowBtnTxt="watchNowBtnTxt"
                                :isLogedIn="isLogedIn"
                                @playAudioContent="playAudioContent"
                                :downloadBtnText="downloadBtnText"
                                :openBtnText="openBtnText"
                                :preOrderBtnTxt  = "preOrderBtnTxt"
								:contentPreorderStatusMap = "contentPreorderStatusMap"
                                :parentContent = "parentContent"

                            />
                        <!--Button Show on Hover end Here-->
                    </div>
                   <!-- <div class="data">
                        <a class="callByAjax" :href="'/content/'+childObj.content_permalink">
                            <span>{{childObj.content_name}}</span>
                        </a>
                    </div>-->
                    <content_title_one :id="$attrs['id'] +'_content_title_one_1'" 
                    :content="childObj" :userList="userList"/>
                </div>
            </div>
        </div>
    </div>
    <div id="childListDiv" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="optView == 1">
        <div class="season-list d-md-flex d-lg-flex d-xl-flex grid-hover" v-for="(childObj,i) in parentContent.child_content">
            <div class="number disable-in-vd">
                <span>{{i+1}}</span>
            </div>
            <div class="picture">
            <div class="freeContent-tag" v-if="childObj?.is_free_content">
            <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
            </div>
            <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                     <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                  </div>

                <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="w-100"/>
                <img  loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="w-100"/>
                <!--Button Show on Hover start Here-->
                    <content_hover_one 
                        :id="$attrs['id'] +'_content_hover_one_1'"
                        :content="childObj" 
                        :playNowBtnTxt="playNowBtnTxt"
                        :viewTrailerBtnTxt="viewTrailerBtnTxt"
                        :playAllBtnTxt="playAllBtnTxt"
                        :watchNowBtnTxt="watchNowBtnTxt"
                        :isLogedIn="isLogedIn"
                        @playAudioContent="playAudioContent"
                        :downloadBtnText="downloadBtnText"
                        :openBtnText="openBtnText"
                        :preOrderBtnTxt  = "preOrderBtnTxt"
						:contentPreorderStatusMap = "contentPreorderStatusMap"
                        :parentContent = "parentContent"

                    />
                <!--Button Show on Hover end Here-->
                        
            </div>
            <!--Button Show on Hover End Here-->
            <div class="content">
                <div class="heading">
                <h3 vd-readonly="true" class="truncate-text lc-one">
				    <a :href="'/content/'+childObj?.content_permalink">
				        {{childObj?.content_name}}
				    </a>
                </h3>

                </div>
                <div class="data" v-if="childObj?.content_desc?.length <= 500">
                    <p vd-readonly="true">{{childObj?.content_desc}}</p>
                </div>
                <div class="data" v-else>
                    <p vd-readonly="true">{{childObj?.content_desc?.substring(0,500)}} <a href="javascript:void(0);" @click="$emit('setDataReadMore',childObj)" data-toggle="modal" data-target="#readmoreDesc" v-if="childObj?.content_desc?.length > 500">{{i18n('..ReadMore')}}</a></p>
                </div>
            </div>
        </div>
    </div>
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent= "isFreeContent"/>
</vd-component>
      `,
};
export default ChildListOne;

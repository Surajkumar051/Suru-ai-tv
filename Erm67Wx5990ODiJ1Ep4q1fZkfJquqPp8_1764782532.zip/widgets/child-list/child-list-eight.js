let {default:content_hover_seven}=await import(window.importLocalJs('widgets/content-hover/content-hover-seven.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_title_six}=await import(window.importLocalJs('widgets/content-title/content-title-six.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING } = await import(window.importAssetJs('js/configurations/actions.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
const ChildListEight = {
    name: "child_list_eight",
    props: {
        contentGroupDetails: Object,
        parentContent: Object,
        playNowBtnTxt: String,
        viewTrailerBtnTxt: String,
        playAllBtnTxt: String,
        watchNowBtnTxt: String,
        optView: 0,
        isLogedIn: Boolean,
        freeContentText: String,
        downloadBtnText:"",
        openBtnText:""
    },
    components: {
        content_hover_seven,
        audio_player_one,
        content_title_six
    },
    data() {
        return {
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            userList:[],
            assignedArray: [],
            gutterSpace:null,
        };
    },
    watch: {
        optView(optView) {},
                "parentContent.child_content"(parentContent){
                    contentHelper.getPartnerAndUserUuids(parentContent.child_content, this.userList);
            }
    },
        mounted(){

        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
            contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
        },
        created(){
                contentHelper.getPartnerAndUserUuids(this.parentContent.child_content, this.userList);
        },

    methods: {
        i18n,
        playAudioContent(content_detail){ //ER-101092
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },

    template: `
    <vd-component class="vd child-list-eight w-100" type="child-list-eight">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="row">
                    <div class="col-xs-12 col-6 col-sm-6 col-md-4 col-lg-3 col-xl-3" v-for="(childObj,i) in parentContent.child_content">
                        <div class="slide-one tiles grid-hover" :style="{'margin-right': this.gutterSpace,'margin-left': this.gutterSpace }">
                            <div class="slide-image picture">
                                    <div class="freeContent-tag" v-if="childObj?.is_free_content">
                                        <span><vd-component-param type="freeContentText" v-html="i18n(freeContentText)"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="childObj?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[childObj?.maturity_rating]}}</span>
                                    </div>
                                    <img loading="lazy" v-if="childObj.posters.website != null && childObj.posters.website[0].file_url !== ''" :src="childObj.posters.website[0].file_url" class="mw-100"/>
                                    <img loading="lazy" v-if="childObj.posters.website == null || childObj.posters.website[0].file_url === ''" :src="childObj.no_image_available_url" class="mw-100"/>
                                    <content_hover_seven
                                        :id="$attrs['id'] +'_content_hover_seven_7'"
                                        :content="childObj" 
                                        :playNowBtnTxt="playNowBtnTxt"
                                        :viewTrailerBtnTxt="viewTrailerBtnTxt"
                                        :playAllBtnTxt="playAllBtnTxt"
                                        :watchNowBtnTxt="watchNowBtnTxt"
                                        :isLogedIn="isLogedIn"
                                        @playAudioContent="playAudioContent"
                                        :downloadBtnText="downloadBtnText"
                                        :openBtnText="openBtnText"
                                    />
                            </div>
                            <div class="slide-content">
                                <content_title_six :id="$attrs['id'] +'_content_title_six_6'" 
                                    :content="childObj" :userList="userList" :assignedArray="assignedArray"/>
                            </div>        
                        </div>
                    </div>
                </div>
            </div>  
        </div>               

    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"  :isFreeContent= "isFreeContent"/>

    </vd-component>
`,
};
export default ChildListEight;
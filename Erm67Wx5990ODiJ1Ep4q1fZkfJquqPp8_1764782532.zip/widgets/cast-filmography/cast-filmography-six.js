let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {owlCarousal}=await import(window.importLocalJs('js/customcarousel.js'));

export default {
    name: "cast_filmography_six",
     data() {
        return {
            videoContentList: [],
            audioContentList: [],
			docContentList:[],
            isLogedIn: localStorage.getItem("isloggedin"),
			contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            userList: [],
            rootUrl: getRootUrl(),
        
        };
    },
    components: {
        content_hover_six,
        audio_player_one,
		content_title_one,
		content_purchase_five: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-five.js'))),
    },
		beforeCreate() {
			JsLoadingOverlay.show();
	 },
	 mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
		this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
		this.$store.dispatch(GET_MATURITY_RATINGS);
		JsLoadingOverlay.hide();
	},
     updated() {
        owlCarousal();
    },
    methods: {
		i18n,
		playAudioContent(content_detail){ //ER-101092
                    this.contentUuidAudio = content_detail.content_uuid;//ER-101092
                    this.isFreeContent = content_detail.is_free_content; //ER-101092
                    this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                    this.isAudioPlay = true;
                },
		reloadComponentAudio(content_detail){
                    this.playAudioContent(content_detail); //ER-101092
                }
	},
	computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    props: {
        cast: {},
    },
    watch: {
        cast(cast) {
            if (
                cast != null &&
                cast?.cast_content_list != null &&
                cast?.cast_content_list?.length > 0
            ) {
		contentHelper.getPartnerAndUserUuids(cast?.cast_content_list,this.userList);
                this.videoContentList = cast?.cast_content_list.filter(
                    function (con) {
                        return con.content_asset_type == 1;
                    }
                );
                this.audioContentList = cast?.cast_content_list.filter(
                    function (con) {
                        return con.content_asset_type == 2;
                    }
                );
				this.docContentList = cast?.cast_content_list.filter(
                    function (con) {
                        return con.content_asset_type == 6;
                    }
                );
            }
        },
    },

    template: `
    <vd-component type="cast-filmography-six" class="vd cast-filmography-six">
    <content_purchase_five  :id="$attrs['id'] +'_content_purchase_five_5'" />
    <section class="product-listing custom-prevNext-btn recommended-music pt-104">
	    <div class="container-fluid">
		    <div class="row">
			    <!-- <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 plr-88" v-if="videoContentList && videoContentList?.length>0">
				    <div class="contect-listing">
					    <h2 class="sub-heading white-color"><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></h2>
						<div class="owl-product owl-carousel owl-theme owl-loaded owl-drag" v-if="videoContentList && videoContentList?.length>0" >
							<div class="item" v-for="(content,i) in videoContentList" :key="i">
							    <div class="picture">
									<div class="freeContent-tag" v-if="content?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                    </div>
									<div class="mrContent-tag" v-if="content?.maturity_rating && maturity_rating?.maturity_rating_list != null">
										<span>{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
									</div>
								    <img loading="lazy" :src="(content?.posters?.website != null)?content?.posters?.website[0]?.file_url:content?.no_image_available_url" class="w-216"/>
									<div class="icons-apply">
								    <content_hover_six
									:id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
									:content="content"
									:playNowBtnTxt="$attrs['label1']"
									:viewTrailerBtnTxt="$attrs['label2']"
									:playAllBtnTxt="$attrs['label3']"
									:watchNowBtnTxt="$attrs['label1']"
									:isLogedIn="isLogedIn"
									@playAudioContent="playAudioContent"
									:downloadBtnText="i18n($attrs['label8'])"
									:openBtnText="i18n($attrs['label9'])"
									/>
									</div>
							    </div>
							  <content_title_one :id="$attrs['id'] +'_content_title_one_1'" 
							   :content="content" :userList="userList"/>
						    </div>
						</div>
				    </div>
			    </div> -->
			    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 plr-88" v-if="audioContentList && audioContentList?.length>0">
				    <div class="contect-listing">
					    <h2 class="sub-heading white-color"><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></h2>
						<div class="owl-product owl-carousel owl-theme owl-loaded owl-drag" v-if="audioContentList && audioContentList?.length>0">
							<div class="item" v-for="(content,i) in audioContentList" :key="i">
							    <div class="picture">
									<div class="freeContent-tag" v-if="content?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                    </div>
									<div class="mrContent-tag" v-if="content?.maturity_rating && maturity_rating?.maturity_rating_list != null">
										<span>{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
									</div>
								    <img :src="(content?.posters?.website != null)?content?.posters?.website[0]?.file_url:content?.no_image_available_url" class="w-216"/>
									<div class="icons-apply">
										<!--Button Show on Hover start Here-->
										<content_hover_six
										:id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
										:content="content"
										:playNowBtnTxt="$attrs['label1']"
										:viewTrailerBtnTxt="$attrs['label2']"
										:playAllBtnTxt="$attrs['label3']"
										:watchNowBtnTxt="$attrs['label1']"
										:isLogedIn="isLogedIn"
										@playAudioContent="playAudioContent"
										:downloadBtnText="i18n($attrs['label8'])"
										:openBtnText="i18n($attrs['label9'])"
										/>
										<!--Button Show on Hover End Here-->
									</div>
							    </div>
							    <!--<div class="data">
								    <a class="callByAjax" :href="'/content/'+content.content_permalink">
									    <span>{{content.content_name}}</span>
								    </a>
							    </div>-->
							    <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  :content="content" />
						    </div>
						</div>
				    </div>
			    </div>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="docContentList && docContentList?.length>0">
				    <div class="episode-heading">
					    <h3 class="sub-heading white-color"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h3>
				    </div>
			    </div>
			    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="docContentList && docContentList?.length>0">
				    <div class="row">
					    <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="(content,i) in docContentList" :key="i">
						    <div class="tiles grid-hover">
							    <div class="picture">
								<div class="freeContent-tag" v-if="content?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                    </div>
									
									<div class="mrContent-tag" v-if="content?.maturity_rating && maturity_rating?.maturity_rating_list != null">
									<span>{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
								 </div>
								    <img loading="lazy" :src="(content?.posters?.website != null)?content?.posters?.website[0]?.file_url:content?.no_image_available_url" class="w-100"/>
								    <!--Button Show on Hover start Here-->
								    <content_hover_one
									:id="$attrs['id'] +'_content_hover_one_1'"
									:content="content"
									:playNowBtnTxt="i18n($attrs['label1'])"
									:viewTrailerBtnTxt="i18n($attrs['label2'])"
									:playAllBtnTxt="i18n($attrs['label3'])"
									:watchNowBtnTxt="i18n($attrs['label1'])"
									:downloadBtnText="i18n($attrs['label8'])"
									:openBtnText="i18n($attrs['label9'])"
									:isLogedIn="isLogedIn"
									@playAudioContent="playAudioContent"
									/>
								    <!--Button Show on Hover End Here-->
							    </div>
							    <!--<div class="data">
								    <a class="callByAjax" :href="'/content/'+content.content_permalink">
									    <span>{{content.content_name}}</span>
								    </a>
							    </div>-->
							  <content_title_one :id="$attrs['id'] +'_content_title_one_1'" 
							   :content="content" :userList="userList"/>
						    </div>
					    </div>
				    </div>
			    </div>
		    </div>
	    </div>
    </section>
	<audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" @reloadComponentAudio="reloadComponentAudio" :isFreeContent="isFreeContent"/>
</vd-component>
    `,
};

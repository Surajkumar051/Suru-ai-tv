let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {GET_END_USER_REGD_LOGIN_SETTING,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

export default {
    name: "cast_filmography_three",
    data() {
        return {
            rootUrl: getRootUrl(),
            videoContentList: [],
            audioContentList: [],
            isLogedIn: localStorage.getItem("isloggedin"),
			contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
        };
    },
    components: {
        content_hover_one,
        audio_player_one,
    },
		beforeCreate() {
			JsLoadingOverlay.show();
	 },
     mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
		this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
		this.$store.dispatch(GET_MATURITY_RATINGS);
		JsLoadingOverlay.hide();
	},
    methods: {
        i18n,
		playAudioContent(content_detail){ //ER-101092
                    this.contentUuidAudio = content_detail.content_uuid;//ER-101092
                    this.isFreeContent = content_detail.is_free_content; //ER-101092
                    this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                    this.isAudioPlay = true;
                },
		
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    props: {
        cast: {},
    },
    watch: {
        cast(cast) {
            if (
                cast != null &&
                cast?.cast_content_list != null &&
                cast?.cast_content_list?.length > 0
            ) {
                this.videoContentList = cast?.cast_content_list.filter(
                    function (con) {
                        return con.content_asset_type == 1;
                    }
                );
                this.audioContentList = cast?.cast_content_list.filter(
                    function (con) {
                        return con.content_asset_type == 2;
                    }
                );
            }
        },
    },

    template:`
    <vd-component type="cast-filmography-three" class="vd cast-filmography-three">

    <div class="notification-area" v-if="videoContentList && videoContentList?.length>0">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="section-heading pb-0 pt-0">
                <h2><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></h2>  
            </div>
        </div>
        <div class="col-lg-11">
            <div class="wishlist-area no-slide border-bottom overflow-hidden pt-4 mt-2" v-if="videoContentList && videoContentList?.length>0">
                    <div class="row gx-4 gy-4" >
                        <div class="col-lg-4 col-md-6 col-sm-6"  v-for="(content,i) in videoContentList" :key="i">
                            <div class="single-wishlist">
                                <div class="image-preview">
                                    <div class="freeContent-tag" v-if="content?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="content?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
                                    </div>
                                <img loading="lazy" :src="(content?.posters?.website != null)?content?.posters?.website[0]?.file_url:content?.no_image_available_url" class="img-fluid"/>
                                </div>
                                <div class="whitelist-overlay">
                                    <div class="row justify-content-end gx-0 h-100">
                                        <div class="col-12 align-self-end px-0">
                                            <div class="row gx-0 justify-content-between align-items-center">
                                                <div class="col-12">
                                                    <span class="price d-none">$400.00</span>
                                                </div>
                                                <div class="col-12">
                                                    <div class="course-info">
                                                    {{content.content_name}}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row gx-0 justify-content-between align-items-center">
                                                <div class="col-auto">
                                                    <span class="rating d-none">
                                                        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"></path>
                                                        </svg>
                                                        4.5
                                                    </span>
                                                </div>
                                                <div class="col-auto">
                                                 
                                                     <a :href="'/content/'+content.content_permalink" class="details-btn callByAjax d-flex text-light mt-4">
                                                     View Detail
                                                     <div class="svg">
                                                         <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                             <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                                         </svg>
                                                     </div>
                                                 </a>
                                                 </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                     
                    </div>
                </div>

                <div class="wishlist-area no-slide border-bottom overflow-hidden pt-4 mt-2" v-if="audioContentList && audioContentList?.length>0">
                <vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param>
                    <div class="row gx-4 gy-4" >
                        <div class="col-lg-4 col-md-6 col-sm-6"  v-for="(content,i) in audioContentList" :key="i">
                            <div class="single-wishlist">
                                <div class="image-preview">
                                    <div class="freeContent-tag" v-if="content?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="content?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[content?.maturity_rating]}}</span>
                                    </div>
                                <img loading="lazy" :src="(content?.posters?.website != null)?content?.posters?.website[0]?.file_url:content?.no_image_available_url" class="img-fluid"/>
                                </div>
                                <div class="whitelist-overlay">
                                    <div class="row justify-content-end gx-0 h-100">
                                        <div class="col-12 align-self-end px-0">
                                            <div class="row gx-0 justify-content-between align-items-center">
                                                <div class="col-12">
                                                    <span class="price d-none">$400.00</span>
                                                </div>
                                                <div class="col-12">
                                                    <div class="course-info">
                                                    {{content.content_name}}
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row gx-0 justify-content-between align-items-center">
                                                <div class="col-auto">
                                                    <span class="rating d-none">
                                                        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"></path>
                                                        </svg>
                                                        4.5
                                                    </span>
                                                </div>
                                                <div class="col-auto">
                                                     
                           
                                                     <a :href="'/content/'+content.content_permalink" class="details-btn callByAjax d-flex text-light mt-4">
                                                         View Detail
                                                         <div class="svg">
                                                             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                 <path d="M15.7121 12L9.70111 5.98999L8.28711 7.40399L12.8871 12.004L8.28711 16.597L9.70111 18.011L15.7121 12Z" fill="white"/>
                                                             </svg>
                                                         </div>
                                                     </a>
                                                 </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                     
                    </div>
                </div>



            </div>
        </div>
    </div>
</div>
	<audio_player_one :root_url="rootUrl" :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>
    `,
};

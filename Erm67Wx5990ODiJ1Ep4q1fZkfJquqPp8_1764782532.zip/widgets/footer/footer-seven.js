let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
// let { getVdConfig }=await import(window.importAssetJs('js/webservices.js'));
const { mapState} = Vuex;

export default {
    name: 'footer_seven',
    data() {
        return {
					isFooterLogoUpdated: Boolean,
					footerlogo_alt:'',
					footerlogo_src:'',
					footerlogo_style:'',
					rootUrl: getRootUrl()
        }
    },
    methods: {
        i18n,
    },
    computed: {
        ...mapState({
            logo_details: (state) => state.logo_details,
        }),      
    },
    mounted() {
        // getVdConfig('footer-logo').then((res) => {
        //     if (res.data.code == 200 && res.data.data !== null) {
        //         //this.footerLogo = res.data.data;
		// 						this.isFooterLogoUpdated=true;
        //         this.footerlogo_alt=res.data.data.alt;
        //         this.footerlogo_src=res.data.data.src;
        //         this.footerlogo_style=res.data.data.style;

        //     }else{
		// 					this.isFooterLogoUpdated=false;
		// 				}
        // }).catch(ex => {
        //     console.log(ex);
        // });
    },
    template: `
    <vd-component class="vd footer-seven" type="footer-seven">

    <section class="footer-wrapper" vd-node="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-left">
                    <h4 class="mb-4"><vd-component-param type="label31" v-html="i18n($attrs['label31'])"></vd-component-param></h4>
                </div>
                <div class="col-sm-6 text-left">
                    <vd-component-param type="label32" v-html="i18n($attrs['label32'])"></vd-component-param>
                    <!--<a class="callByAjax" href="/">
                        <img vd-node="image" :src="rootUrl + 'img/google-playstore-icon.png'" alt="icon" class="icon-img">
                    </a> -->
                </div>
                <div class="col-sm-5 offset-sm-1 text-right">
                    <!-- <form action="#" class="mt-0">
                        <input type="email" :placeholder=i18n($attrs['label33']) vd-component-attr-placeholder="label33" vd-component-attr-title="label34" :title=i18n($attrs['label34'])>
                        <button vd-node="styleOnly"><vd-component-param type="label35" v-html="i18n($attrs['label35'])"></vd-component-param></button>
                    </form> -->
                </div>
                <div class="col-sm-12">
                    <div class="middle-footer">
                        <div class="row">
                            <div class="col-md-4 col-lg-2 col-sm-6 col-xs-6 md-mb25">
                                <h5><vd-component-param type="label27" v-html="i18n($attrs['label27'])"></vd-component-param></h5>
                                <ul>
                                    <li><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></li>
                                    <li><vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param></li>
                                    <li><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param></li>
                                    <li><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-lg-2 col-sm-6 col-xs-6 md-mb25">
                                <h5><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h5>
                                <ul>
                                    <li><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></li>
                                    <li><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></li>
                                    <li><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></li>
                                    <li><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-lg-2 col-sm-6 col-xs-6 md-mb25">
                                <h5><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h5>
                                <ul>
                                    <li><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></li>
                                    <li><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></li>
                                    <li><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></li>
                                    <li><vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-lg-2 col-sm-6 col-xs-6">
                                <h5><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></h5>
                                <ul>
                                    <li><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></li>
                                    <li><vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param></li>
                                    <li><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></li>
                                    <li><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-lg-2 col-sm-6 col-xs-6">
                                <h5><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></h5>
                                <ul>
                                    <li><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></li>
                                    <li><vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param></li>
                                    <li><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></li>
                                    <li><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param></li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-lg-2 col-sm-6 col-xs-6">
                                <h5 class="mb-3"><vd-component-param type="label28" v-html="i18n($attrs['label28'])"></vd-component-param></h5>
                                <p style="width: 100%;"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-12 lower-footer"></div>
                <div class="col-sm-6">
                    <p class="copyright-text"><vd-component-param type="label26" v-html="i18n($attrs['label26'])"></vd-component-param></p>
                </div>
                <div class="col-sm-6 text-right">
                    <p class="float-right copyright-text">
                        <vd-component-param type="label29" v-html="i18n($attrs['label29'])"></vd-component-param>&nbsp;
                        <vd-component-param type="label30" v-html="i18n($attrs['label30'])"></vd-component-param>
                    </p>
                </div>
            </div>
        </div>
    </section>

    </vd-component>
`
}
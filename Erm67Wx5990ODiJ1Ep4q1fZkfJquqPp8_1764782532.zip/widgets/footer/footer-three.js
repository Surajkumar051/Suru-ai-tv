let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: 'footer_three',
    data() {
        return {
            rootUrl: getRootUrl(),
        }
    },
    methods: {
        i18n,
    },
    template: `
    <vd-component class="vd footer-three" type="footer-three">
        <section class="footer" vd-node="footer">
           
            <div class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="footer-widgets">
                        <h3><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h3>
                        <ul>
                            <li><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></li>
                            <li><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></li>
                            <li><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></li>
                            <li><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></li>
                            <li><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></li>
                            <li><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-widgets">
                        <h3><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h3>
                        <ul>
                            <li><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></li>
                            <li><vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></li>
                            <li><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></li>
                            <li><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></li>
                            <li><vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param></li>
                            <li><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-widgets">
                        <h3><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></h3>
                        <ul>
                            <li><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></li>
                            <li><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></li>
                            <li><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-widgets">
                        <h3><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></h3>
                        <ul>
                        <li>
                            <vd-component-param type="label27" v-html="$attrs['label27']"></vd-component-param>
                        </li>
                        <li>
                            <vd-component-param type="label28" v-html="$attrs['label28']"></vd-component-param>
                        </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-auto">
                        <p>&copy; <vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param></p>
                        
                    </div>
                    <div class="col-md-3 col-auto">
                    <ul vd-node="socialIcon" id="socialIcon-1" vd-readonly="true">
                        <li><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></li>
                        <li><vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param></li>
                        <li><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param></li>
                        <li><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></li>
                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
            
        
        </section>
  
</vd-component>
    `
}
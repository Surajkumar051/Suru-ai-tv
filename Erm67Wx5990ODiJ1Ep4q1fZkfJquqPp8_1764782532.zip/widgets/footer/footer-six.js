let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
// let { getVdConfig }=await import(window.importAssetJs('js/webservices.js'));
const { mapState} = Vuex;

export default {
    name: "footer_six",
    data() {
        return {
            isFooterLogoUpdated: Boolean,
            footerlogo_alt: "",
            footerlogo_src: "",
            footerlogo_style: "",
            rootUrl: getRootUrl(),
        };
    },
    methods: {
        i18n,
    },
    computed: {
        ...mapState({
            logo_details: (state) => state.logo_details,
        }),      
    },
    mounted() {
        // getVdConfig("footer-logo")
        //     .then((res) => {
        //         if (res.data.code == 200 && res.data.data !== null) {
        //             //this.footerLogo = res.data.data;
        //             this.isFooterLogoUpdated = true;
        //             this.footerlogo_alt = res.data.data.alt;
        //             this.footerlogo_src = res.data.data.src;
        //             this.footerlogo_style = res.data.data.style;
        //         } else {
        //             this.isFooterLogoUpdated = false;
        //         }
        //     })
        //     .catch((ex) => {
        //         console.log(ex);
        //     });
    },
    template: `
    <vd-component class="vd footer-six" type="footer-six">
    <section class="footer" vd-node="footer" vd-readonly="true">
        <div class="container-fluid plr-64">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="boxes">
                                <h2><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></h2>
                                <ul>
                                    <li><vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param></li>
                                    <li><vd-component-param type="label4" v-html="i18n($attrs['label4'])"></vd-component-param></li>
                                    <li><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></li>
                                    <li><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="boxes">
                                <h2><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></h2>
                                <ul>
                                    <li><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></li>
                                    <li><vd-component-param type="label9" v-html="i18n($attrs['label9'])"></vd-component-param></li>
                                    <li><vd-component-param type="label10" v-html="i18n($attrs['label10'])"></vd-component-param></li>
                                    <li><vd-component-param type="label11" v-html="i18n($attrs['label11'])"></vd-component-param></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="boxes">
                                <h2><vd-component-param type="label12" v-html="i18n($attrs['label12'])"></vd-component-param></h2>
                                <ul>
                                    <li><vd-component-param type="label13" v-html="i18n($attrs['label13'])"></vd-component-param></li>
                                    <li><vd-component-param type="label14" v-html="i18n($attrs['label14'])"></vd-component-param></li>
                                    <li><vd-component-param type="label15" v-html="i18n($attrs['label15'])"></vd-component-param></li>
                                    <li><vd-component-param type="label16" v-html="i18n($attrs['label16'])"></vd-component-param></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                            <div class="boxes">
                                <h2><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></h2>
                                <ul>
                                    <li><vd-component-param type="label18" v-html="i18n($attrs['label18'])"></vd-component-param></li>
                                    <li><vd-component-param type="label19" v-html="i18n($attrs['label19'])"></vd-component-param></li>
                                    <li><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></li>
                                    <li><vd-component-param type="label21" v-html="i18n($attrs['label21'])"></vd-component-param></li>
                                </ul>
                            </div>
                        </div>
                    </div>    
                </div>
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                        <div class="boxes">
                            <a v-if="logo_details['footer-logo']" class="navbar-brand callByAjax" href="/"><img vd-node="footer-logo" vd-readonly="true" :src="logo_details['footer-logo']['src']" :alt="logo_details['footer-logo']['alt']" :style="logo_details['footer-logo']['style']" /></a>
                            <a v-else-if="logo_details['footer-logo']!=false" class="navbar-brand callByAjax" href="/"><img vd-node="footer-logo" vd-readonly="true" :src="rootUrl+'img/logo.png'" alt="MUVI" /></a>
                        </div>
                </div>     
            </div>
        </div>
        <!--Copyright Section Start Here-->
        <section class="copyright">
            <div class="container-fluid plr-64">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <ul vd-node="socialIcon" vd-readonly="true" id="socialIcon-1">
                        <li><vd-component-param type="label22" v-html="i18n($attrs['label22'])"></vd-component-param></li>
                        <li><vd-component-param type="label23" v-html="i18n($attrs['label23'])"></vd-component-param></li>
                        <li><vd-component-param type="label24" v-html="i18n($attrs['label24'])"></vd-component-param></li>
                        <li><vd-component-param type="label25" v-html="i18n($attrs['label25'])"></vd-component-param></li>
                        </ul>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                        <p><vd-component-param type="label26" v-html="i18n($attrs['label26'])"></vd-component-param></p>
                    </div>
                </div>
            </div>
        </section>
    </section>
</vd-component>
    `,
};

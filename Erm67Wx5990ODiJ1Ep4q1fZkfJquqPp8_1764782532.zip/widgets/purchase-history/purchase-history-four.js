let { purchaseHistory, viewInvoiceDetails } = await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));

export default {
    name: "purchase_history_four",
    props: {
        tab: String,
    },
    setup(props) {
        const tab = props.tab;
        return { tab };
    },
    data() {
        return {
            message: "",
            paymentHistoryList: [],
            hasPayment: false,
            invoiceHtml: "",
            apiResponse: {},
            show_device: "purchase_history_one",
        };
    },
    beforeCreate() {},
    beforeMount() {
        if(notLoggedinUser()){
            window.location.href = "/";
        }
    },
    mounted() {
        this.hasPayment = true;
        if (this.show_device == localStorage.getItem("profile.currenttab")) {
            // JsLoadingOverlay.show();
        }
        this.purchase_history();
    },
    updated() {
        if (this.paymentHistoryList.length) {
            this.hasPayment = true;
        }
    },
    methods: {
        i18n,
        getRootUrl,
        purchase_history: function () {
            purchaseHistory().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    // JsLoadingOverlay.hide();
                    this.apiResponse = res;
                    this.paymentHistoryList =
                        res.data.data.paymentHistory.payment_history_list;
                    this.isPayment = true;
                } else {
                    // JsLoadingOverlay.hide();
                    this.isPayment = false;
                    this.hasPayment = false;
                }
            });
        },
        viewInvoiceDetails(orderId) {
            viewInvoiceDetails(orderId).then((res) => {
                this.invoiceHtml = res.data.invoice_details;
                setTimeout(() => {
                    const printInvoice = window.open("", "", "");
                    printInvoice.document.write(
                        "<html><head><title>Invoice-" +
                            orderId +
                            "</title></head><body >"
                    );
                    printInvoice.document.write(this.invoiceHtml);
                    printInvoice.document.write("</body></html>");
                    printInvoice.document.close();
                    printInvoice.print();
                }, 1000);
            });
        },
    },
    template: /*html*/ `
    <vd-component class="vd purchase-history-four" type="purchase-history-four">
        <!--dashboard tiles Start Here-->
            <!--Title start here-->
                    <h5 class="mb-3 pb-3 a-border">
                        <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                    </h5>
            <!--Title End here-->
            <!--No Records Found start here-->
            <section class="no-result-found" v-if="paymentHistoryList.length == 0 && hasPayment == false">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="w-100 text-center">
                                <img :src="getRootUrl() +'img/no-result.gif'" alt="no result" class="mw-100" />
                                <h2>
                                    <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- No Records Found End Here-->
            <!--Table start Here-->
            <div id="content-page" class="content-page"  v-else>
                <div class="row">
                    <div class="iq-card">
                        <div class="iq-card-body">
                            <table class="table">
                                <tbody>
                                    <tr v-for="paymentHistory in paymentHistoryList" style="border-bottom: 0.063em solid rgba(82, 95, 129, 0.1);">
                                        <td>{{paymentHistory.item_name}}</td>
                                        <td>{{paymentHistory.transaction_date}} UTC</td>
                                        <td>
                                            <span>Order ID {{paymentHistory.order_uuid}}</span><br>
                                            <span>Transaction ID {{paymentHistory.transaction_uuid}}</span>
                                        </td>
                                        <td>
                                            <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                                            <a class="callByAjax" style="margin-left:15px;" href="javascript:void(0);" @click="viewInvoiceDetails(paymentHistory.order_uuid)">
                                            <i class="fa-solid fa-download"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--Table End Here-->
            
        <!--dashboard tiles End Here-->
    </vd-component>`,
};

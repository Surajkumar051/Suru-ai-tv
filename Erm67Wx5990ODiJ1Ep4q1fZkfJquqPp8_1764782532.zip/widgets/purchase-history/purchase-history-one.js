let { purchaseHistory, viewInvoiceDetails } = await import(window.importAssetJs('js/webservices.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
export default {
    name: 'purchase_history_one',
    props: {
        tab: String
    },
    setup(props) {
        const tab = props.tab;
        return { tab };
    },
    data() {
        return {
            message: '',
            paymentHistoryList: [],
            invoiceHtml: "",
            apiResponse: {},
            show_device: 'purchase_history_one',
        }
    },
    beforeCreate() {

    },
    beforeMount() {
        if (notLoggedinUser()) {
            window.location.href = "/";
        }
    },
    mounted() {
        if (this.show_device == localStorage.getItem('profile.currenttab')) {
            JsLoadingOverlay.show();
        }
        this.purchase_history();
    },
    methods: {
        i18n,
        purchase_history: function () {
            purchaseHistory().then((res) => {
                if (res.data.code === 200 && res.data.status == "SUCCESS") {
                    JsLoadingOverlay.hide();
                    this.apiResponse = res;
                    this.paymentHistoryList = res.data.data.paymentHistory.payment_history_list;
                    this.isPayment = true;
                } else {
                    JsLoadingOverlay.hide();
                    this.isPayment = false;
                }
            })
        },
        viewInvoiceDetails(orderId) {
            viewInvoiceDetails(orderId).then((res) => {
                this.invoiceHtml = res.data.invoice_details;
                setTimeout(() => {
                let printInvoice = window.open('', '', '');
                printInvoice.document.write('<html><head><title>Invoice-' + orderId + '</title></head><body >');
                printInvoice.document.write(this.invoiceHtml);
                printInvoice.document.write('</body></html>');
                printInvoice.document.close();
                printInvoice.print();
                }, 1000);
            })
        },

    },
    template: `
    <vd-component class="vd purchase-history-one" type="purchase-history-one">
        <!--dashboard tiles Start Here-->
        <div class="dashboard-tiles black-bg">
            <!--Title start here-->
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <h1 class="dashboard-heading white-color mbottom-20">
                        <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                    </h1>
                </div>
            </div>
            <!--Title End here-->
            <!--Table start Here-->
            <div class="row" v-if="paymentHistoryList.length != 0">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="purches-history">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr v-for="paymentHistory in paymentHistoryList">
                                        <td>{{paymentHistory.item_name}}</td>
                                        <td>{{paymentHistory.transaction_date}} UTC</td>
                                        <td>
                                            <span>Order ID {{paymentHistory.order_uuid}}</span><br>
                                            <span>Transaction ID {{paymentHistory.transaction_uuid}}</span>
                                        </td>
                                        <td>
                                            <vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param>
                                            <a class="callByAjax" href="javascript:void(0);" @click="viewInvoiceDetails(paymentHistory.order_uuid)">
                                                <i class="fas fa-download"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--Table End Here-->
            <!--No Records Found start here-->
            <section class="no-result-found" v-else>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                            <div class="w-100 text-center">
                                <img src="resources/views/phoenix/default/img/no-result.gif" alt="no result" class="mw-100" />
                                <h2>
                                    <vd-component-param type="label3" v-html="i18n($attrs['label3'])"></vd-component-param>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- No Records Found End Here-->
        </div>
        <!--dashboard tiles End Here-->
    </vd-component>`
};

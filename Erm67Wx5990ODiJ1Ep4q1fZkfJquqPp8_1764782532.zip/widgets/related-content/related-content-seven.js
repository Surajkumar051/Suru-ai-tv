let {
    getRelatedContent,
    categorizedPermalink,getContentSettingsDetails
} = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } =await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_eight} = await import(window.importLocalJs('widgets/content-hover/content-hover-eight.js'));
let {default:audio_player_one} = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_eight} = await import(window.importLocalJs('widgets/content-title/content-title-eight.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "related_content_seven",
    components: {
        content_hover_eight,
        audio_player_one,
        content_title_eight
    },
    data() {
        return {
            relatedContentListDetails: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            contentParentUuid: "",
            contentName: "",
            isNextPageCallReqd: true,
            pageNo: 1,
            isPlaylist:0,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
			isPlaylist:0,
            userList: [],
            isFavouriteEnabled: false,
            
        };
    },
    updated() {
        owlCarousal();
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
       
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if ((content.permalink_type == "content"  || content.is_playlist==1)
                                    && content.content_permalink == this.contentPermalink)
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;
                        this.contentName =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_name;
                        this.relatedcontentDetails(
                            this.contentParentUuid,
                            this.pageNo,
                            false
                            
                        );
                        this.isPlaylist = res.data.data.contentList.content_list[findContentParentIndex].is_playlist;
                    }
                }
            });
            this.loadMore();
        }
        getContentSettingsDetails().then((res) => {
            if (res.data.code == 200) {
                
                this.isFavouriteEnabled =
                    res.data.data.contentSettings
                        .content_favourite_settings != null
                        ? res.data.data.contentSettings
                              .content_favourite_settings?.is_enabled
                        : false;
              
            }
        });
        //         $(document).change(function (e) {
        //             let owl = $('.owl-carousel');
        //            // owl.owlCarousel();
        //             owl.owlCarousel({callbacks: true});
        //             owl.on('changed.owl.carousel', function(event) {
        //                 console.log("clicked");
        //             });
        // //             $('.contect-listing .owl-product .owl-nav .owl-next span').click(() => {
        // //                     console.log("clicked");
        // //                     //this.onNext();
        // //                 });
        // //             });
        // // let ths = this;
        // //             $(".owl-carousel").owlCarousel({
        // //                 afterInit : ths.onNext
        // //               });
        //        // });
        //         });
    },
    //     updated:function(ev){
    //         $(document).change(function (e) {
    //             let owl = $('.owl-carousel');
    //             owl.owlCarousel();
    //             owl.owlCarousel({callbacks: true});
    //             owl.on('next.owl.carousel', function(event) {
    //                 console.log("clicked");
    //             });
    // //             $('.contect-listing .owl-product .owl-nav .owl-next span').click(() => {
    // //                     console.log("clicked");
    // //                     //this.onNext();
    // //                 });
    // //             });
    // // let ths = this;
    // //             $(".owl-carousel").owlCarousel({
    // //                 afterInit : ths.onNext
    // //               });
    //        // });
    //         });
    //     },
    methods: {
		i18n,
        getRootUrl,
        relatedcontentDetails(contentPermalink, page, onScroll) {
            if (this.isNextPageCallReqd) {
                JsLoadingOverlay.show();
                (this.isNextPageCallReqd = false),
                    getRelatedContent(contentPermalink, page).then((res) => {
                        JsLoadingOverlay.hide();
                        // if (res.data.code == 200 && res.data.data.relatedContentList !== null) {
                        //     this.relatedContentListDetails = res.data.data.relatedContentList.related_content_list;

                        // }

                        if (
                            !onScroll &&
                            res.data.code == 200 &&
                            res.data.data.relatedContentList
                                .related_content_list
                        ) {
                            this.relatedContentListDetails =
                                res.data.data.relatedContentList.related_content_list;
                                this.relatedContentListDetails.forEach(relatedItem=>{
                                    contentHelper.getPartnerAndUserUuids(relatedItem.content_list,this.userList);
                                })
                        } else if (
                            onScroll &&
                            res.data.code == 200 &&
                            res.data.data.relatedContentList
                                .related_content_list
                        ) {
                            this.relatedContentListDetails.push(
                                ...res.data.data.relatedContentList
                                    .related_content_list
                            );
                            res.data.data.relatedContentList
                                    .related_content_list.forEach(relatedItem=>{
                                contentHelper.getPartnerAndUserUuids(relatedItem.content_list,this.userList);
                            })
                        }

                        if (
                            res.data.code == 200 &&
                            this.relatedContentListDetails?.length <
                                res.data.data.relatedContentList.page_info
                                    .total_count
                        ) {
                            this.isNextPageCallReqd = true;
                        }
                    });
            }
        },

        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd) {
                    this.pageNo++;
                    this.relatedcontentDetails(
                        this.contentParentUuid,
                        this.pageNo,
                        true,
                        
                    );
                }
            };
        },
        playAudioContent(contentUuid){
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: /*html*/ `
    
<vd-component class="vd related-content-seven" type="related-content-seven">
<!--Banner Section Start Here-->
<section class="category-heading-section" vd-readonly="true"
  v-if="relatedContentListDetails && relatedContentListDetails.length > 0">
  <div class="chs-div plr-65">
    <div class="chsd-heading" v-if="isPlaylist==0"> <vd-component-param type="label1"
        v-html="i18n($attrs['label1'])"></vd-component-param>
      "{{contentName}}"</div>
    <div class="chsd-heading" v-else-if="isPlaylist==0"> <vd-component-param type="label7"
        v-html="i18n($attrs['label7'])"></vd-component-param>
      "{{contentName}}"</div>
  </div>
</section>
<!--Banner Section End Here-->
<!--Top Movies Section Start Here-->
<section class="product-listing p-0" v-if="relatedContentListDetails && relatedContentListDetails.length > 0"
  vd-readonly="true">
  <div class="container-fluid pl-65">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="contect-listing">

          <div class="owl-product owl-carousel owl-theme">
            <div class="item" v-for="data in relatedContentListDetails">
              <a v-if="data?.is_playlist==1" :href="'/playlist/'+data.content_permalink" class="callByAjax">
                <div class="picture">
                  <div class="freeContent-tag" v-if="data?.is_free_content"><span><vd-component-param type="label8"
                        v-html="i18n($attrs['label8'])"></vd-component-param></span></div>
                 <img loading="lazy" class="mw-100"
                                        v-if="data.content_list[0].posters.website !== null && data.content_list[0].posters.website[0].file_url !== ''"
                                        :src="data.content_list[0].posters.website[0].file_url"
                                        :alt="data.content_list[0].posters.website[0].file_url" />
                                    <img loading="lazy" class="mw-100"
                                        v-if="data.content_list[0].posters.website === null  || data.content_list[0].posters.website[0].file_url === ''"
                                        :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                  <!--Button Show on Hover start Here-->
                  <div class="box-hover">
                    <!-- <a href="javascript:void(0);">Play Now</a>
                  <a href="javascript:void(0);">View Trailer</a>                      -->
                  </div>
                  <!--Button Show on Hover End Here-->
                </div>
              </a>
              <a v-else :href="'/content/'+data.content_permalink" class="callByAjax">
                <div class="picture">
                  <div class="freeContent-tag" v-if="data?.is_free_content"><span><vd-component-param type="label8"
                        v-html="i18n($attrs['label8'])"></vd-component-param></span></div>
                  <img loading="lazy" class="mw-100"
                                        v-if="data.content_list[0].posters.website !== null && data.content_list[0].posters.website[0].file_url !== ''"
                                        :src="data.content_list[0].posters.website[0].file_url"
                                        :alt="data.content_list[0].posters.website[0].file_url" />
                                    <img loading="lazy" class="mw-100"
                                        v-if="data.content_list[0].posters.website === null  || data.content_list[0].posters.website[0].file_url === ''"
                                        :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image" />
                  <div class="box-hover">
                    <!-- <a href="javascript:void(0);">Play Now</a>
                  <a href="javascript:void(0);">View Trailer</a>                      -->
                  </div>
                  <!--Button Show on Hover End Here-->
                </div>
                 </a>
                <div class="data">
                <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'"
                                        :content="data.content_list[0]" :userList="userList"
                                         />
                                    <content_hover_eight :id="$attrs['id'] +'_content_hover_eight_1'"
                                        :content="data.content_list[0]" 
                                        :isFavouriteSettings="isFavouriteEnabled"
                                        :playNowBtnTxt="i18n($attrs['label2'])"
                                        :viewTrailerBtnTxt="i18n($attrs['label4'])"
                                        :playAllBtnTxt="i18n($attrs['label5'])"
                                        :watchNowBtnTxt="i18n($attrs['label6'])" :isLogedIn="isLogedIn"
                                        @playAudioContent="playAudioContent" />
                                    <!--Button Show on Hover End Here-->
                </div>
             

            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
<!--TOp Movies Section End Here-->
<audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
</vd-component>`,
};

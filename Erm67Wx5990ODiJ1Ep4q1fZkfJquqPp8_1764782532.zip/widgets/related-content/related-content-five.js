let { getRelatedContent, categorizedPermalink, isAuthorizedContent, getVideoDetails, getLocation } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } =await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl, getRootUrl,getLocale } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_four} = await import(window.importLocalJs('widgets/content-hover/content-hover-four.js'));
let {default:audio_player_one} = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_one} = await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "related_content_five",
    components: {
        content_hover_four,
        audio_player_one,
        content_title_one
    },
    data() {
        return {
            relatedContentListDetails: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            videoDuration: '',
            audioDuration: '',
            nodatafound: false,
            isAuthorized: Boolean,
            audioUuid: String,
            uniqueId: '',
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: String,
            user_Info: JSON.parse(localStorage.getItem('user')), // Get user_uuid from  local storage 
            isLogedIn: localStorage.getItem('isloggedin'),
            contentParentUuid: '',
            stickyAudioData: String,
            removeJs: true,
            playBackRatesValue: [],
            isAuthorizedContent: Boolean,
            pageNo:-100,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            isPlaylist:0,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle : true,
            userList:[],
			assignedArray: [],
            gutterSpace: null,
            languageCode:getLocale
            
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted() {
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
              
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if ((content.permalink_type == "content" || content.is_playlist==1 )&& content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.isPlaylist = res.data.data.contentList.content_list[findContentParentIndex].is_playlist;
                        this.relatedcontentDetails(this.contentParentUuid,this.pageNo,);


                    }
                }
            });
        }
//         $(document).change(function (e) {
//             let owl = $('.owl-carousel');
//            // owl.owlCarousel();
//             owl.owlCarousel({callbacks: true});
//             owl.on('changed.owl.carousel', function(event) {
//                 console.log("clicked");
//             });
// //             $('.contect-listing .owl-product .owl-nav .owl-next span').click(() => {
// //                     console.log("clicked");
// //                     //this.onNext();
// //                 });
// //             });
// // let ths = this;
// //             $(".owl-carousel").owlCarousel({
// //                 afterInit : ths.onNext
// //               });
//        // });
//         });
        
    },
//     updated:function(ev){
//         $(document).change(function (e) {
//             let owl = $('.owl-carousel');
//             owl.owlCarousel();
//             owl.owlCarousel({callbacks: true});
//             owl.on('next.owl.carousel', function(event) {
//                 console.log("clicked");
//             });
// //             $('.contect-listing .owl-product .owl-nav .owl-next span').click(() => {
// //                     console.log("clicked");
// //                     //this.onNext();
// //                 });
// //             });
// // let ths = this;
// //             $(".owl-carousel").owlCarousel({
// //                 afterInit : ths.onNext
// //               });
//        // });
//         });
//     },
    methods: {
		i18n,
        // onNext(elem){
        //     console.log("clicked2222");
        //     // this.pageNo++;
        //     // this.relatedcontentDetails(this.contentParentUuid,this.pageNo);
        // },
        relatedcontentDetails(contentPermalink,page) {
            getRelatedContent(contentPermalink,page).then((res) => {
                if (res.data.code == 200 && res.data.data.relatedContentList !== null) {
                    this.relatedContentListDetails = res.data.data.relatedContentList.related_content_list;
                    this.relatedContentListDetails.forEach(relatedItem=>{
                        contentHelper.getPartnerAndUserUuids(relatedItem.content_list,this.userList);
                    })
                    this.relatedContentListDetails.forEach(ele => {
                        if (ele.content_list[0].video_details !== null) {
                            const vDuration = ele.content_list[0].video_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                        if (ele.content_list[0].audio_details !== null) {
                            const aDuration = ele.content_list[0].audio_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                    });
                    this.nodatafound = false;
                } else {
                    this.nodatafound = true;
                }

            });
        },
        playAudioContent(content_detail){ //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
<vd-component class="vd related-content-five" type="related-content-five">
    <section meta-key='meta-feature-list' vd-node="metaData" class="product-listing end-user" v-if="relatedContentListDetails && relatedContentListDetails.length > 0">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
					<div class="contect-listing">
                            <h2 vd-readonly="true" class="sub-heading white-color">
                                <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                                <a class="view-all-listing callByAjax" v-if="relatedContentListDetails?.length>6 && isPlaylist==0" :href="'/content/'+contentPermalink+'/related-contents'"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></a>
                                <a class="view-all-listing callByAjax" v-if="relatedContentListDetails?.length>6 && isPlaylist==1" :href="'/playlist/'+contentPermalink+'/related-playlist'"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param></a>
                            </h2>
						<div class="owl-product owl-carousel owl-theme">
							<div class="item" v-for="itemData of relatedContentListDetails">
								<div class="picture">
                                    <div class="freeContent-tag" v-if="itemData.content_list[0]?.is_free_content">
                                        <span><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="itemData.content_list[0]?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[itemData.content_list[0]?.maturity_rating]}}</span>
                                    </div>
                                    <div :class="(itemData.content_list[0].content_asset_type == 2 && itemData.content_list[0].is_playlist!=1)?'icons-apply-audio':'icons-apply'">
                                        <img v-if="isPlaylist==0 && itemData.content_list[0].content_asset_type == 1 && (itemData.content_list[0].video_details==null || itemData.content_list[0].video_details?.is_live_feed == false)" :src="rootUrl + 'img/video-icons.png'"/>
                                        <img v-if="isPlaylist==0 && itemData.content_list[0].content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'"/>
                                        <img v-if="isPlaylist==0 && itemData.content_list[0].content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                        <img v-if="isPlaylist==1 && itemData.content_list[0].content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                        <img v-if="isPlaylist==1 && itemData.content_list[0].content_asset_type != 6" :src="rootUrl + 'img/playlist-icon.png'"/>
                                        <svg v-if = "itemData.content_list[0].content_asset_type == 1 && itemData.content_list[0].is_playlist!=1 && itemData.content_list[0].video_details?.is_live_feed == true"
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <path d="M12.2 4.33333C12.2 3.598 11.5721 3 10.8 3H2.4C1.6279 3 1 3.598 1 4.33333V11C1 11.7353 1.6279 12.3333 2.4 12.3333H10.8C11.5721 12.3333 12.2 11.7353 12.2 11V8.778L15 11V4.33333L12.2 6.55533V4.33333Z" fill="#7B8794"></path>
                                            <circle cx="6.64062" cy="7.65234" r="2.25" fill="white" fill-opacity="0.6"></circle>
                                        </svg>
                                    </div>
									<img loading="lazy" v-if="itemData.content_list[0].posters.website != null && itemData.content_list[0].posters.website[0].file_url !== ''" :src="itemData.content_list[0].posters.website[0].file_url" alt="The Last Dance"/>
									<img loading="lazy" v-if="itemData.content_list[0].posters.website == null || itemData.content_list[0].posters.website[0].file_url === ''" :src="itemData.content_list[0].no_image_available_url" alt="The Last Dance"/>
									<!--Button Show on Hover start Here-->
                                    <div class="box-hover">
                                        <content_title_one :id="$attrs['id'] +'_content_title_one_1'"
                                            :content="itemData.content_list[0]" :userList="userList" :assignedArray="assignedArray"/>
                                        <!--<div class="data">
                                            <a class="callByAjax" v-if="isPlaylist==0" :href="'/content/'+itemData.content_list[0].content_permalink">
										        <span v-if="itemData.content_list[0].content_name">{{itemData.content_list[0].content_name}}</span>
									        </a>
                                            <a class="callByAjax" v-if="isPlaylist==1"  :href="'/playlist/'+itemData.content_list[0].content_permalink">
										        <span v-if="itemData.content_list[0].content_name">{{itemData.content_list[0].content_name}}</span>
									        </a>
                                            <p v-if="itemData.content_list[0].video_details !== null">{{videoDuration}}</p>
                                            <p v-if="itemData.content_list[0].audio_details !== null">{{audioDuration}}</p>
                                        </div>-->
                                        <content_hover_four 
                                            :id="$attrs['id'] +'_content_hover_four_4'"
                                                :content="itemData.content_list[0]" 
                                                :playNowBtnTxt="i18n($attrs['label3'])" 
                                                :viewTrailerBtnTxt="i18n($attrs['label4'])" 
                                                :playAllBtnTxt="i18n($attrs['label5'])" 
                                                :watchNowBtnTxt="i18n($attrs['label6'])" 
                                                :isLogedIn="isLogedIn"
                                                @playAudioContent="playAudioContent"
                                        />
                                    </div>
									<!--Button Show on Hover End Here-->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>`,
};

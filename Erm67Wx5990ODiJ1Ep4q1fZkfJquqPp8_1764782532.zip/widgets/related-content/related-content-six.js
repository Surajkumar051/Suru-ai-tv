let {
    getRelatedContent,
    categorizedPermalink
} = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } =await import(window.importAssetJs('js/customcarousel.js'));
let { getBaseUrl, getRootUrl,getLocale} = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_four} = await import(window.importLocalJs('widgets/content-hover/content-hover-four.js'));
let {default:audio_player_one} = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_one} = await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "related_content_six",
    components: {
        content_hover_four,
        audio_player_one,
        content_title_one
    },
    data() {
        return {
            relatedContentListDetails: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            user_Info: JSON.parse(localStorage.getItem("user")), // Get user_uuid from  local storage
            isLogedIn: localStorage.getItem("isloggedin"),
            contentParentUuid: "",
            contentName: "",
            isNextPageCallReqd: true,
            pageNo: 1,
            isPlaylist:0,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
			isPlaylist:0,
            userList: [],
            assignedArray: [],
            gutterSpace: null,
            //languageCode:getLocale
            
        };
    },
    updated() {
        owlCarousal();
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted() {
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
      
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if ((content.permalink_type == "content"  || content.is_playlist==1)
                                    && content.content_permalink == this.contentPermalink)
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;
                        this.contentName =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_name;
                        this.relatedcontentDetails(
                            this.contentParentUuid,
                            this.pageNo,
                            false,
                            
                        );
                        this.isPlaylist = res.data.data.contentList.content_list[findContentParentIndex].is_playlist;
                    }
                }
            });
            this.loadMore();
        }
        //         $(document).change(function (e) {
        //             let owl = $('.owl-carousel');
        //            // owl.owlCarousel();
        //             owl.owlCarousel({callbacks: true});
        //             owl.on('changed.owl.carousel', function(event) {
        //                 console.log("clicked");
        //             });
        // //             $('.contect-listing .owl-product .owl-nav .owl-next span').click(() => {
        // //                     console.log("clicked");
        // //                     //this.onNext();
        // //                 });
        // //             });
        // // let ths = this;
        // //             $(".owl-carousel").owlCarousel({
        // //                 afterInit : ths.onNext
        // //               });
        //        // });
        //         });
    },
    //     updated:function(ev){
    //         $(document).change(function (e) {
    //             let owl = $('.owl-carousel');
    //             owl.owlCarousel();
    //             owl.owlCarousel({callbacks: true});
    //             owl.on('next.owl.carousel', function(event) {
    //                 console.log("clicked");
    //             });
    // //             $('.contect-listing .owl-product .owl-nav .owl-next span').click(() => {
    // //                     console.log("clicked");
    // //                     //this.onNext();
    // //                 });
    // //             });
    // // let ths = this;
    // //             $(".owl-carousel").owlCarousel({
    // //                 afterInit : ths.onNext
    // //               });
    //        // });
    //         });
    //     },
    methods: {
		i18n,
        getRootUrl,
        relatedcontentDetails(contentPermalink, page, onScroll) {
            if (this.isNextPageCallReqd) {
                // JsLoadingOverlay.show();
                (this.isNextPageCallReqd = false),
                    getRelatedContent(contentPermalink, page).then((res) => {
                        // JsLoadingOverlay.hide();
                        // if (res.data.code == 200 && res.data.data.relatedContentList !== null) {
                        //     this.relatedContentListDetails = res.data.data.relatedContentList.related_content_list;

                        // }

                        if (
                            !onScroll &&
                            res.data.code == 200 &&
                            res.data.data.relatedContentList
                                .related_content_list
                        ) {
                            this.relatedContentListDetails =
                                res.data.data.relatedContentList.related_content_list;
                                this.relatedContentListDetails.forEach(relatedItem=>{
                                    contentHelper.getPartnerAndUserUuids(relatedItem.content_list,this.userList);
                                })
                        } else if (
                            onScroll &&
                            res.data.code == 200 &&
                            res.data.data.relatedContentList
                                .related_content_list
                        ) {
                            this.relatedContentListDetails.push(
                                ...res.data.data.relatedContentList
                                    .related_content_list
                            );
                            res.data.data.relatedContentList
                                    .related_content_list.forEach(relatedItem=>{
                                contentHelper.getPartnerAndUserUuids(relatedItem.content_list,this.userList);
                            })
                        }

                        if (
                            res.data.code == 200 &&
                            this.relatedContentListDetails?.length <
                                res.data.data.relatedContentList.page_info
                                    .total_count
                        ) {
                            this.isNextPageCallReqd = true;
                        }
                    });
            }
        },

        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd) {
                    this.pageNo++;
                    this.relatedcontentDetails(
                        this.contentParentUuid,
                        this.pageNo,
                        true,
                        
                    );
                }
            };
        },
        playAudioContent(contentUuid){
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
    <vd-component class="vd related-content-six" type="related-content-six">
        <section class="end-user" meta-key='meta-feature-list' vd-node="metaData" class="season-content" v-if="relatedContentListDetails && relatedContentListDetails.length > 0">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" >
                        <div class="episode-heading">
                            <h3 vd-readonly="true" v-if="isPlaylist==0" class="sub-heading white-color"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param> "{{contentName}}"</h3>
                            <h3 vd-readonly="true" v-else-if="isPlaylist==1" class="sub-heading white-color"><vd-component-param type="label7" v-html="i18n($attrs['label7'])"></vd-component-param> "{{contentName}}"</h3>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="row" id="categoryContentList">
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="data in relatedContentListDetails">
                                <div class="tiles grid-hover">
                                    <div class="picture">
                                        <div class="freeContent-tag" v-if="data.content_list[0]?.is_free_content">
                                            <span><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></span>
                                        </div>
                                        <div class="mrContent-tag" v-if="data.content_list[0]?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                            <span>{{maturity_rating?.maturity_rating_list[data.content_list[0]?.maturity_rating]}}</span>
                                        </div>
                                        <div class="icons-apply" :class="(data.content_list[0].content_asset_type == 2 && isPlaylist!=1)?'icons-apply-audio':'icons-apply'">
                                            <img v-if="isPlaylist==0 && data.content_list[0].content_asset_type == 1" :src="rootUrl + 'img/video-icons.png'"/>
                                            <img v-if="isPlaylist==0 && data.content_list[0].content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'"/>
                                            <img v-if="isPlaylist==0 && data.content_list[0].content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                            <img v-if="isPlaylist==1 && data.content_list[0].content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                            <img v-if="isPlaylist==1 && data.content_list[0].content_asset_type != 6" :src="rootUrl + 'img/playlist-icon.png'"/>
                                        </div>
                                        <img loading="lazy" class="w-100" v-if="data.content_list[0].posters.website !== null && data.content_list[0].posters.website[0].file_url !== ''" :src="data.content_list[0].posters.website[0].file_url" :alt="data.content_list[0].posters.website[0].file_url"/>
                                        <img loading="lazy" class="w-100" v-if="data.content_list[0].posters.website === null  || data.content_list[0].posters.website[0].file_url === ''" :src="data.content_list[0].no_image_available_url" alt="no image"/>
                                        <!--Button Show on Hover start Here-->
                                        <div class="box-hover"> 
                                            <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  
                                                :content="data.content_list[0]"  :userList="userList" :assignedArray="assignedArray"/>    
                                            <!--<div class="data">
                                                <a class="callByAjax" v-if="isPlaylist==0" :href="'/content/'+contentPermalink+'/related-contents'" @click="getContentId(data.content_list[0].content_uuid)">
                                                    <span v-if="data.content_list[0].content_name">{{data.content_list[0].content_name}} </span>
                                                </a>
                                                <a class="callByAjax" v-else-if="isPlaylist==1" :href="'/playlist/'+contentPermalink+'/related-playlist'" @click="getContentId(data.content_list[0].content_uuid)">
                                                    <span v-if="data.content_list[0].content_name">{{data.content_list[0].content_name}} </span>
                                                </a>        
                                            </div>-->                
                                            <content_hover_four 
                                                :id="$attrs['id'] +'_content_hover_four_4'"
                                                :content="data.content_list[0]" 
                                                :playNowBtnTxt="i18n($attrs['label2'])" 
                                                :viewTrailerBtnTxt="i18n($attrs['label4'])" 
                                                :playAllBtnTxt="i18n($attrs['label5'])" 
                                                :watchNowBtnTxt="i18n($attrs['label6'])"  
                                                :isLogedIn="isLogedIn"
                                                @playAudioContent="playAudioContent"
                                            />                 
                                        </div>
                                        <!--Button Show on Hover End Here-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
    </vd-component>
`,
};

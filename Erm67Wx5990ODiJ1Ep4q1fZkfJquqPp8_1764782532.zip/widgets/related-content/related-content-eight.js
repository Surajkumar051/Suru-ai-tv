let { getRelatedContent, categorizedPermalink, isAuthorizedContent, getVideoDetails, getLocation } = await import(window.importAssetJs('js/webservices.js'));
let { owlCarousal } =await import(window.importLocalJs('js/customcarousel.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_hover_six} = await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one} = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_title_one} = await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { GET_END_USER_REGD_LOGIN_SETTING, GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "related_content_eight",
    components: {
        content_hover_six,
        audio_player_one,
        content_title_one
    },
     data() {
        return {
            relatedContentListDetails: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            videoDuration: '',
            audioDuration: '',
            nodatafound: false,
            isAuthorized: Boolean,
            audioUuid: String,
            uniqueId: '',
            audioPlayControl: false,
            player: null,
            queueObj: null,
            enduserURL: null,
            addtoque: null,
            baseURL: null,
            ip: String,
            user_Info: JSON.parse(localStorage.getItem('user')), // Get user_uuid from  local storage 
            isLogedIn: localStorage.getItem('isloggedin'),
            contentParentUuid: '',
            stickyAudioData: String,
            removeJs: true,
            playBackRatesValue: [],
            isAuthorizedContent: Boolean,
            pageNo:-100,
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            isPlaylist:0,
            rootUrl: getRootUrl(),
            reloadOnUpdateLifeCycle : true,
            userList:[],
            assignedArray: [],
            gutterSpace: null,
            content_asset_type:2
        }
    },
    updated() {
        if (!this.reloadOnUpdateLifeCycle) {
            this.reloadOnUpdateLifeCycle = true;
        } else {
            owlCarousal();
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    mounted() {
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.baseURL = getBaseUrl();
               
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if ((content.permalink_type == "content" || content.is_playlist==1 )&& content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.isPlaylist = res.data.data.contentList.content_list[findContentParentIndex].is_playlist;
                        this.relatedcontentDetails(this.contentParentUuid,this.pageNo,this.content_asset_type);


                    }
                }
            });
        }
    },

    methods: {
        i18n,
        relatedcontentDetails(contentPermalink,page,content_asset_type) {
            getRelatedContent(contentPermalink,page,content_asset_type).then((res) => {
                if (res.data.code == 200 && res.data.data.relatedContentList !== null) {
                    this.relatedContentListDetails = res.data.data.relatedContentList.related_content_list;
                    this.relatedContentListDetails.forEach(relatedItem=>{
                        contentHelper.getPartnerAndUserUuids(relatedItem.content_list,this.userList);
                    })
                    this.relatedContentListDetails.forEach(ele => {
                        if (ele.content_list[0].video_details !== null) {
                            const vDuration = ele.content_list[0].video_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (vDuration.length <= 5) {
                                this.videoDuration = vDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.videoDuration = vDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                        if (ele.content_list[0].audio_details !== null) {
                            const aDuration = ele.content_list[0].audio_details.duration.replace(/^0(?:0:0?)?/, '');
                            if (aDuration.length <= 5) {
                                this.audioDuration = aDuration.replace(':', 'm ').concat('s');
                            } else {
                                this.audioDuration = aDuration.replace(':', 'h ').replace(':', 'm ').concat('s');
                            }
                        }
                    });
                    this.nodatafound = false;
                } else {
                    this.nodatafound = true;
                }

            });
        },
        playAudioContent(content_detail){ //ER-101092
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;//ER-101092;
            this.isFreeContent = content_detail.is_free_content; //ER-101092
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        }
    },
    template: `
    
<vd-component class="vd related-content-eight" type="related-content-eight">
    <section meta-key='meta-feature-list' vd-node="metaData" class="product-listing custom-prevNext-btn recommended-music end-user " v-if="relatedContentListDetails && relatedContentListDetails.length > 0">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 plr-88">
                    <div class="contect-listing">
                            <h2 vd-readonly="true" class="sub-heading white-color">
                                <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                            </h2>
						<div class="owl-product owl-carousel owl-theme owl-loaded owl-drag">
							<div class="item" v-for="itemData of relatedContentListDetails">
								<div class="picture">
                                    <div class="freeContent-tag" v-if="itemData.content_list[0]?.is_free_content">
                                        <span><vd-component-param type="label8" v-html="i18n($attrs['label8'])"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="itemData.content_list[0]?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[itemData.content_list[0]?.maturity_rating]}}</span>
                                    </div>
                                    <img class="w-216" loading="lazy" v-if="itemData.content_list[0].posters.website != null && itemData.content_list[0].posters.website[0].file_url !== ''" :src="itemData.content_list[0].posters.website[0].file_url" alt="The Last Dance"/>
                                    <img class="w-216" loading="lazy" v-if="itemData.content_list[0].posters.website == null || itemData.content_list[0].posters.website[0].file_url === ''" :src="itemData.content_list[0].no_image_available_url" alt="The Last Dance"/>
                                    <!--Button Show on Hover start Here-->
                                        <content_hover_six 
                                        :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                                    :content="itemData.content_list[0]" 
                                                    :playNowBtnTxt="i18n($attrs['label3'])" 
                                                    :viewTrailerBtnTxt="i18n($attrs['label4'])" 
                                                    :playAllBtnTxt="i18n($attrs['label5'])" 
                                                    :watchNowBtnTxt="i18n($attrs['label6'])" 
                                                    :isLogedIn="isLogedIn"
                                                    @playAudioContent="playAudioContent"
                                                    />
                                    <!--Button Show on Hover End Here-->
                                </div>
                                <!--<div class="data">
                                    <a class="callByAjax" v-if="isPlaylist==0" :href="'/content/'+itemData.content_list[0].content_permalink">
                                        <span v-if="itemData.content_list[0].content_name">{{itemData.content_list[0].content_name}}</span>
                                    </a>
                                    <a class="callByAjax" v-if="isPlaylist==1"  :href="'/playlist/'+itemData.content_list[0].content_permalink">
                                        <span v-if="itemData.content_list[0].content_name">{{itemData.content_list[0].content_name}}</span>
                                    </a>
                                </div>-->
                                <content_title_one :id="$attrs['id'] +'_content_title_one_1'"
                                  :content="itemData.content_list[0]" :userList="userList" :assignedArray="assignedArray"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :isFreeContent="isFreeContent"/>
</vd-component>`,
};

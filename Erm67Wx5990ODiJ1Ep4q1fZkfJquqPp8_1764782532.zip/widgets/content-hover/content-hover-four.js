let { TOGGLE_CONTENT_PURCHASE_MODAL, SET_CURRENT_CONTENT_SELECTION_DATA, GET_END_USER_REGD_LOGIN_SETTING, PLAY_CONTENT, SET_PLAY_CONTENT } = await import(window.importAssetJs('js/configurations/actions.js'));
let { getPlayerParentPermarlinkDetails, isAuthorizedContent, getContentParentUuid, logDownloadsToAnalytics  } = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "content_hover_four",
    template: `
    <vd-component type="content-hover-four" class="vd content-hover-four">
        <template
            v-if="(content.content_asset_uuid != null && content.content_asset_uuid != '' && content.content_asset_type == 1 &&
            content.video_details != null && 
            ((!content.video_details.is_feed && content.video_details.encoding_status =='completed' || content.video_details.encoding_status == null) || content.video_details.is_feed)) ||
            (content.content_trailer_uuid != null && content.content_trailer_uuid != '' && content.trailer_details != null &&
            content.trailer_details.file_url != null && content.trailer_details.file_url !='') || (content?.is_parent ==1 && content?.content_asset_type != 6)">
            <span class="playIconHover" 
                v-if="fromEnduserPlaylist && (content.content_asset_uuid != null && content.content_asset_uuid != '' && content.content_asset_type == 1 &&
                content.video_details != null && 
                ((!content.video_details.is_feed && content.video_details.encoding_status =='completed' || content.video_details.encoding_status == null) || content.video_details.is_feed))" @click="playContent(content)" style="cursor: pointer">
                <svg width="11" height="14" viewBox="0 0 11 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M1 2.40198C1 1.61081 1.87525 1.13297 2.54076 1.5608L9.6915 6.15771C10.3038 6.55134 10.3038 7.44643 9.6915 7.84006L2.54076 12.437C1.87524 12.8648 1 12.387 1 11.5958V2.40198Z"
                        fill="white" stroke="white" stroke-width="1.5"
                        stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </span>
            <button class="callByAjax" v-else-if="!fromEnduserPlaylist && (content.content_asset_uuid != null && content.content_asset_uuid != '' && content.content_asset_type == 1 &&
                content.video_details != null && 
                ((!content.video_details.is_feed && content.video_details.encoding_status =='completed' || content.video_details.encoding_status == null) || content.video_details.is_feed))"
                href="javascript:void(0);" @click="playContent(content)">
                {{watchNowBtnTxt}}
            </button>
            <button class="callByAjax" type="button" v-else-if="content?.is_parent == 1 && content.content_asset_type == 1" href="javascript:void(0);" @click="playContent(content)">
                {{playAllBtnTxt}}
            </button>
            <button class="callByAjax" v-if="content.content_trailer_uuid != null && content.content_trailer_uuid != '' && content.trailer_details != null &&
                content.trailer_details.file_url != null && content.trailer_details.file_url !=''"
                href="javascript:void(0);" @click="playTrailer(content.content_permalink)">
                {{viewTrailerBtnTxt}}
            </button>
        </template>
        <template v-if="(fromEnduserPlaylist || fromAdminPlaylist) && (content.content_asset_uuid != null  && content.content_asset_uuid != ''  && content.content_asset_type == 2 &&
            content.audio_details != null && 
            (content.audio_details.encoding_status =='completed' || content.audio_details.encoding_status == null))">
            <span class="playIconHover px-0" @click="playContent(content)" style="cursor: pointer">
                <svg width="11" height="14" viewBox="0 0 11 14" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M1 2.40198C1 1.61081 1.87525 1.13297 2.54076 1.5608L9.6915 6.15771C10.3038 6.55134 10.3038 7.44643 9.6915 7.84006L2.54076 12.437C1.87524 12.8648 1 12.387 1 11.5958V2.40198Z"
                        fill="white" stroke="white" stroke-width="1.5"
                        stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </span>
        </template>
        <template
            v-if="!fromEnduserPlaylist && !fromAdminPlaylist && (content.content_asset_uuid != null  && content.content_asset_uuid != ''  && content.content_asset_type == 2 &&
            content.audio_details != null && 
            (content.audio_details.encoding_status =='completed' || content.audio_details.encoding_status == null))">
            <button class="callByAjax" href="javascript:void(0);" @click="playContent(content)">
                {{playNowBtnTxt}}
            </button>
        </template>
        <template v-if="content?.is_parent == 1 && content.content_asset_type == 2">
            <button class="callByAjax" href="javascript:void(0);" @click="playContent(content)">
                {{playAllBtnTxt}}
            </button>
        </template>
        <template v-if="content.is_playlist == 1 && fromEnduserPlaylist">
            <button class="pa-btn" @click="playContent(content)">
                <span class="pa-icon d-flex">
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.91406 3.58167C2.91406 2.7905 3.78931 2.31266 4.45482 2.74049L9.77223 6.15882C10.3846 6.55246 10.3846 7.44754 9.77223 7.84118L4.45482 11.2595C3.78931 11.6873 2.91406 11.2095 2.91406 10.4183V3.58167Z"
                            fill="#E9E9E9" stroke="#E9E9E9" stroke-width="1.33"
                            stroke-linecap="round" stroke-linejoin="round">
                        </path>
                    </svg>
                </span>
                {{playAllBtnTxt}}
            </button>
        </template>
        <template v-if="content.is_playlist == 1 && content?.content_asset_type != 6">
            <button class="callByAjax" href="javascript:void(0);" @click="playContent(content)">
                {{playAllBtnTxt}}
            </button>
        </template>
        <template v-if="isAddOn && content?.media_type==1 && (content?.media_details?.encoding_status=='completed'  || content?.media_details?.is_feed)">
            <button class="callByAjax" href="javascript:void(0);" @click="playAddonContent(playAddonContentDetails,content)"> {{watchNowBtnTxt}}</button>
        </template>
        <template v-if="isAddOn && content?.media_type==2 && content?.media_details?.encoding_status=='completed'">
            <button class="callByAjax" href="javascript:void(0);" @click="playAddonContent(playAddonContentDetails,content)"> {{playNowBtnTxt}}</button>
        </template>
        <template v-if=" content?.is_playlist==0 && content?.content_asset_type == 6 && content?.content_asset_uuid !=''">
            <button class="callByAjax primary-button" @click="openDoc()">
                {{"Download"}} 
            </button>
        </template>
        <template v-if="content?.is_playlist==0 && content?.is_parent == 1 &&
            content?.content_asset_type == 6 ">
            <a :href="'/content/'+content?.content_permalink" class="callByAjax primary-button primary-button-a"  >
                {{"Open"}} 
            </a>
        </template>
        <template v-if=" content?.is_playlist==1 && content?.content_asset_type == 6">
            <a :href="'/playlist/'+content?.content_permalink" class="callByAjax primary-button primary-button-a" >
                {{"Open"}} 
            </a>
        </template>
    </vd-component>
    `,
    emits: ["playAudioContent", 'audioAddOnObject'],
    props: {
        content: Object,
        contentDetails: Object,//ER-90271
        playNowBtnTxt: "",
        viewTrailerBtnTxt: "",
        playAllBtnTxt: "",
        watchNowBtnTxt: "",
        isLogedIn: Boolean,
        isAddOn: Boolean,
        contentPermalinkAddon: "",
        fromEnduserPlaylist: Boolean,
        fromAdminPlaylist: Boolean,
        downloadBtnText:"",
        openBtnText:"",
        playAddonContentDetails: Object

    },
    data() {
        return {
            nestedContentplayBtnShow: Boolean,
            audioPlayControl: false,
            audioPlayControl: Boolean,
            audioUuid: String,
            contentParentUuid: "",
            playBackRatesValue: [],
            queueObj: null,
            monetizationMethods: [],
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            contentUuid: "",
            isLoggedIn: JSON.parse(localStorage.getItem("isloggedin")),
            getContentParentData: {},
            isRegdLogin: 1,
            recallVuexStateTime: 60, //In seconds
            loggingDocDownloads: {}
        };
    },
    computed: {
        ...mapState({
            end_user_regd_login_setting: (state) => state.end_user_regd_login_setting,
            play_content_detail: (state) => state.play_content_detail,
        }),
    },
    components: {
    },
    watch: {
        async play_content_detail(content_detail) {
            if (content_detail) {
                this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                    content: '',
                    monetization_methods: []
                });
                if (content_detail?.is_parent == 0 && content_detail?.is_playlist==0 && content_detail?.content_asset_type == 6 && content_detail?.content_asset_uuid !=''){
                    const res = await isAuthorizedContent(content_detail.content_uuid );
                    if (res.data.code == 200) {
                        if (res.data.data.isAuthorized.is_content_authorized) {
                            window.open(content_detail?.document_details?.file_url, '_blank');
                        } else {
                            this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                content_uuid: content_detail.content_uuid ,
                                monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                            });
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                        }
                    } else {
                        Toast.fire({ icon: "error", title: res.data.message });
                    }
                }else{
                    this.playContent(content_detail);
                }
            }
            this.$store.dispatch(PLAY_CONTENT,null);

        }
    },
    mounted() {
    },
    methods: {
        async  openDoc(){

            this.isRegdLogin = this.end_user_regd_login_setting.sections[0].groups[0].nodes[0].node_value ? 1 : 0;

            if (this.isRegdLogin === 0) {
                // window.location.href = value;
                window.open(this.content?.document_details?.file_url, '_blank');
            } else {
                if (!this.isLogedIn) {
                    let freeContentLoginRequired = JSON.parse(localStorage.getItem("freeContentLoginRequired"));
                    if (this.isFreeContent && !freeContentLoginRequired) {
                        // window.location.href = value;
                        window.open(this.content?.document_details?.file_url, '_blank');
                    } else {
                        const redirectAfterLogin = window.localStorage.getItem("addOnContentPageUrl");
                        if (redirectAfterLogin) {
                            window.localStorage.removeItem("addOnContentPageUrl");
                            window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                        }
                        window.location.href = "/sign-in";
                        return false;
                    }
                } else {
                    const res = await isAuthorizedContent(this.content.content_uuid );
                    if (res.data.code == 200) {
                        if (res.data.data.isAuthorized.is_content_authorized) {
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                            // window.location.href = value;
                            window.open(this.content?.document_details?.file_url, '_blank');
                        } else {
                            console.log("this.content?.document_details?.file_url",this.content?.document_details?.file_url)
                            this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                content_uuid: this.content.content_uuid ,
                                monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                            });
                            this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);//true
                        }
                    } else {
                        JsLoadingOverlay.hide();
                        Toast.fire({ icon: "error", title: res.data.message });
                    }
                }
            }

            this.loggingDocDownloads.body = {
                content_parent_uuid: this.content?.content_parent_uuid ? this.content?.content_parent_uuid: null,
                content_type: this.content?.content_asset_type,
                content_uuid: this.content?.content_uuid,
                content_name: this.content?.content_name,
                media_type: 3,
                content_created_by: this.content?.content_created_by,
                uploaded_user_type: this.content?.user_type
            }
            
            logDownloadsToAnalytics(this.loggingDocDownloads ).then( resp => {
            });

            return false;
     },
        async playContent(contentObj) {
            try {
                if(this.fromEnduserPlaylist && contentObj.is_playlist === 1 && contentObj.content_asset_type === 2){
                    //enduser audio playlist, store its url
                    let audioPlaylistUrl = window.location.origin + '/profile';
                    window.localStorage.setItem('audioPlaylistUrl', audioPlaylistUrl);
                }
                //103551-start
                if (!this.fromEnduserPlaylist && contentObj.is_playlist === 1 && contentObj.content_asset_type === 2) {
                    //audio playlist, store its url
                    let audioPlaylistUrl = window.location.origin + '/playlist/' + contentObj.content_permalink;
                    window.localStorage.setItem('audioPlaylistUrl', audioPlaylistUrl);
                }
                //103551-end
                //JsLoadingOverlay.show();
                if (contentObj.content_asset_type == 1) {
                    window.onbeforeunload = null;//@ER:74207 Disable isAudioPlaying
                    // console.log(this.end_user_regd_login_setting, 'end_user_regd_login_setting');
                    let lastDataTime = this.lastCalledDiff(this.end_user_regd_login_setting.last_called);
                    this.isRegdLogin = this.end_user_regd_login_setting.sections[0].groups[0].nodes[0].node_value ? 1 : 0;
                    // console.log(this.isRegdLogin,'this.isRegdLogin')
                    // console.log(lastDataTime, 'lastDataTime');
                    if (!lastDataTime) {
                        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
                    }

                    // PROMISE API CALL
                    let promiseAPi = [getContentParentUuid({ content_uuid: contentObj.content_uuid })];
                    if (this.isRegdLogin) {
                        promiseAPi.push(isAuthorizedContent(contentObj.content_uuid));
                    }
                    promiseAPi = await Promise.all(promiseAPi);
                    // console.log(promiseAPi, 'promiseAPi'); return;
                    // END PROMISE API CALL
                    this.getContentParentData = promiseAPi[0].data;
                    if (this.isRegdLogin === 0) {
                        this.getPlayerPermalink(contentObj);
                    } else {
                        if (!this.isLoggedIn) {
                            //ER-101092 Start
                            let freeContentLoginRequired = JSON.parse(localStorage.getItem("freeContentLoginRequired"));
                            if (contentObj.is_free_content && !freeContentLoginRequired) {
                                this.getPlayerPermalink(contentObj);
                            } else {
                                //106237-start
                                let redirectAfterLogin = window.location.origin;
                                if (this.fromEnduserPlaylist && contentObj.is_playlist === 1) {
                                    redirectAfterLogin = redirectAfterLogin + '/profile';
                                } else if (contentObj.is_playlist === 1) {
                                    redirectAfterLogin = redirectAfterLogin + '/playlist/' + contentObj.content_permalink;
                                } else {
                                    redirectAfterLogin = redirectAfterLogin + '/content/' + contentObj.content_permalink;
                                }
                                window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                                //106237-end
                                window.location.href = "/sign-in";
                                return false;
                            }
                            //ER-101092 End
                        } else {
                            if (promiseAPi[1].data.code == 200) {
                                let isAuthorizedRes = promiseAPi[1].data.data;
                                if (isAuthorizedRes.isAuthorized.is_content_authorized) {
                                    this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                                    this.getPlayerPermalink(contentObj);
                                } else {
                                    this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                        content_uuid: contentObj.content_uuid,
                                        monetization_methods: isAuthorizedRes.isAuthorized.monetization_details_list[0].monetization_methods
                                    });
                                    this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);//true
                                }
                            } else {
                                JsLoadingOverlay.hide();
                                Toast.fire({ icon: "error", title: promiseAPi[1].data.message });
                            }
                        }
                    }
                } else if (contentObj.content_asset_type == 2) { // check if audio content
                    this.$emit("playAudioContent", contentObj);//ER-101092
                }
            } catch (error) {
                console.log(error);
            }
        },

        lastCalledDiff(lastCalledTime) {
            let endDateTime = new Date();
            // console.log("lastCalledTime", lastCalledTime);
            // console.log("endDateTime", endDateTime);
            let seconds = (endDateTime.getTime() - lastCalledTime.getTime()) / 1000;
            // console.log("seconds", seconds);
            if (seconds < this.recallVuexStateTime) {
                return true;
            } else {
                return false;
            }
        },
        playTrailer(permalink) {
            window.onbeforeunload = null;//@ER:74207 Disable isAudioPlaying
            window.location.href = "/trailer/" + permalink;
        },
        /**
         * @purpose : GET PARENT PERMALINK DETAILS
         */
         async getPlayerPermalink(contentObj) {
            // console.log(contentObj, "contentObj");
            let childUuid = contentObj.content_uuid;
            let isParent = contentObj.is_parent;
            if (childUuid == this.getContentParentData.data.content_parent_uuid) {
                childUuid = null;
                isParent = 1;
            }
            const params = {
                "content_parent_uuid": this.getContentParentData.data.content_parent_uuid,
                "content_child_uuid": childUuid,
                "is_playlist": contentObj.is_playlist,
                "is_parent":isParent,
                "is_enduser_playlist": this.fromEnduserPlaylist
            };
            let permalinkResult = await getPlayerParentPermarlinkDetails(params);
            let permalinkData = permalinkResult.data.data;
            // console.log(permalinkData, 'permalinkData'); return;
            //REDIRECT TO LOCATION
            //ER-90271 Start
            if(this.fromEnduserPlaylist && this.contentDetails && this.contentDetails.is_playlist==1){
                this.redirectToLocation(
                    "player",
                    permalinkData.content_permalink,
                    "enduser-playlist",
                    this.contentDetails.content_permalink
                );
            } else if(this.contentDetails && this.contentDetails.is_playlist==1){
                this.redirectToLocation(
                    "player",
                    permalinkData.content_permalink,
                    "playlist",
                    this.contentDetails.content_permalink
                );
            } else if (this.fromEnduserPlaylist && contentObj.is_playlist == 1) {
                this.redirectToLocation(
                    "player",
                    permalinkData.content_permalink,
                    "enduser-playlist",
                    contentObj.content_permalink
                );
            } else if (contentObj.is_playlist == 1) { //ER-90271 End
                this.redirectToLocation(
                    "player",
                    permalinkData.content_permalink,
                    "playlist",
                    contentObj.content_permalink
                );
            } else {
                let contentUuid = (contentObj.is_parent == 1) ? contentObj.content_uuid : ""; // Parent Uuid
                if (contentObj.content_uuid != this.getContentParentData.data.content_parent_uuid) {
                    contentUuid = this.getContentParentData.data.content_parent_uuid;
                }
                this.redirectToLocation(
                    "player",
                    permalinkData.content_permalink
                );
            }
        },
        playAudioContent(contentObj) {
            this.$emit("playAudioContent", contentObj);//ER-101092
        },
        async  playAddonContent(contentObj,content) {
           
            
            if(!this.isLoggedIn){
                window.localStorage.setItem("addOnContentPageUrl", window.location.href);
                }
    
                try {
                   if (content.media_type == 1) {
    
                    window.onbeforeunload = null;
                    let lastDataTime = this.lastCalledDiff(this.end_user_regd_login_setting.last_called);
                    this.isRegdLogin = this.end_user_regd_login_setting.sections[0].groups[0].nodes[0].node_value ? 1 : 0;
                  
                    if (!lastDataTime) {
                        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING)
                    }
    
                    let promiseAPi = [getContentParentUuid({ content_uuid: contentObj.content_uuid })];
                    if (this.isRegdLogin) {
                        promiseAPi.push(isAuthorizedContent(contentObj.content_uuid));
                    }
                    promiseAPi = await Promise.all(promiseAPi);
                    this.getContentParentData = promiseAPi[0].data;
                    if (this.isRegdLogin === 0) {
                        window.location.href = "/content/" + this.contentPermalinkAddon + "/addon/" + content.addon_uuid;
                    } else {
                        if (!this.isLoggedIn) {
                            let freeContentLoginRequired = JSON.parse(localStorage.getItem("freeContentLoginRequired"));
                            if (contentObj.is_free_content && !freeContentLoginRequired) {
                                window.location.href = "/content/" + this.contentPermalinkAddon + "/addon/" + content.addon_uuid;
                            } else {
                                let redirectAfterLogin = window.location.origin + "/content/" + this.contentPermalinkAddon + "/addon/" + content.addon_uuid;
    
                                window.localStorage.setItem("redirectAfterlogin", redirectAfterLogin);
                                window.location.href = "/sign-in"; 
                                return false;
                            }
                        } else {
                            if (promiseAPi[1].data.code == 200) {
                                let isAuthorizedRes = promiseAPi[1].data.data;
                                if (isAuthorizedRes.isAuthorized.is_content_authorized) {
                                    this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                                    window.location.href = "/content/" + this.contentPermalinkAddon + "/addon/" + content.addon_uuid;
                                } else {
                                    this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                                        content_uuid: contentObj.content_uuid,
                                        monetization_methods: isAuthorizedRes.isAuthorized.monetization_details_list[0].monetization_methods
                                    });
                                    this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);//true
                                }
                            } else {
                                JsLoadingOverlay.hide();
                                Toast.fire({ icon: "error", title: promiseAPi[1].data.message });
                            }
                        }
                    }
                } else {
                    // For Audio Content
                    this.$emit("audioAddOnObject", content);
                }
                } catch (error) {
                    throw "playAddonContent=>" + error;
                }
        },

        /**
         * @purpose : REDIRECT TO LOCATION
         * @param {*} endPoint
         * @param {*} param
         */
        redirectToLocation: function (...params) {
            try {
                //CHECK THIRD PARAMETER
                let param2 = "";
                if (params[2]) {
                    param2 = `/${params[2]}`;
                }
                //CHECK FOURTH PARAMETER
                let param3 = "";
                if (params[3]) {
                    param3 = `/${params[3]}`;
                }
                //REDIRECT
                window.location.href = `/${params[0]}/${params[1]}${param2}${param3}`;
            } catch (error) {
                throw error;
            }
        }
    }
};

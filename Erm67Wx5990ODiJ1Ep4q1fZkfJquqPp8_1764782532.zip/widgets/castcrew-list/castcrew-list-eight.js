let {getContentCastList,
    categorizedPermalink}=await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {owlCarousal}=await import(window.importLocalJs('js/customcarousel.js'));

export default {
    name: "castcrew_list_eight",
    data() {
        return {
            contentCastList: [],
            contentPermalink: permalink, //window.location.pathname.toString().split("/")[2],
            contentParentUuid: "",
            contentName: "",
        };
    },
    updated() {
        owlCarousal();
    },
    beforeCreate() {},
    mounted() {
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    content.permalink_type == "content" &&
                                    content.content_permalink ==
                                        this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;
                        this.contentName =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_name;
                        this.getCastcrewDetails();
                    }
                }
            });
        }
    },
    methods: {
        i18n,
        getCastcrewDetails() {
            getContentCastList(this.contentParentUuid,2).then((res) => {
                // JsLoadingOverlay.hide();
                if (
                    res.data.code == 200 &&
                    res.data.data !== null &&
                    res.data.data.contentList.content_list?.length > 0
                ) {
                    this.contentCastList =
                        res.data.data.contentList.content_list[0].cast_details;
                }
            });
        },
    },
    template: `
<vd-component class="vd castcrew-list-eight" type="castcrew-list-eight">
	<!--Cast Section Start Here-->
	<section class="product-listing custom-prevNext-btn recommended-music mt-21" v-if="contentCastList !== null && contentCastList?.length">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 plr-88">
					<div class="contect-listing">
                        <h2 vd-readonly="true" class="sub-heading white-color" >
                            <vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param>
                        </h2>
                        <span class="view-all" v-if="contentCastList?.length>6">
                                <a class="callByAjax" :href="'/content/'+contentPermalink+'/casts'"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
                        </span>
						<div class="owl-product owl-carousel owl-theme owl-loaded owl-drag">
							<div class="item" v-for="data in contentCastList">
								<div class="picture">
									<img loading="lazy" v-if="data.cast_image_details !== null && data.cast_image_details.file_url !=='' || null" :src="data.cast_image_details.file_url" alt="Pedro Pascal" class="w-216"/>
									<img loading="lazy" v-if="data.cast_image_details === null || data.cast_image_details.file_url ==='' || null" :src="data.no_image_available_url" alt="Pedro Pascal" class="w-216"/>
								</div>
								<div class="data">
									<a class="callByAjax" :href="'/cast-details/'+data.cast_uuid">
										<span>{{data.cast_name}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</vd-component>`,
};

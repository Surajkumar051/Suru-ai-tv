let {getContentCastList,getContentAddonDetails,
  categorizedPermalink,getChildDetails}=await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { owlCarousal } = await import(window.importAssetJs('js/customcarousel.js'));
const { mapState, mapActions } = Vuex;
export default {
  name: "castcrew_list_seven",
  data() {
      return {
          contentCastList: [],
          contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
          contentParentUuid:"",
          contentName:"",
          childListData:[],
          addonList:[]
      }
  },
  beforeCreate() {

  },
  updated(){
    owlCarousal();

 
  },
  mounted() {

      if (this.contentPermalink) {
          categorizedPermalink(this.contentPermalink).then(res => {
              if (res.data.code == 200) {
                  let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                      if (content.permalink_type == "content" && content.content_permalink == this.contentPermalink) return true;
                      else return false;
                  })
                  if (findContentParentIndex > -1) {
                      this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                      this.contentName = res.data.data.contentList.content_list[findContentParentIndex].content_name;
                      this.getCastcrewDetails();
                       this.getChildDetails(this.contentParentUuid, 1, 5);


                  }
              }
          });

          getContentAddonDetails(this.contentParentUuid).then((res) => {
              if (res.data.code == 200 && res.data.data !== null &&
                  res.data.data.addons.addons?.length>0) {
                     // this.addonList=res.data
                  this.addonList = res.data.data.addons.addons;
                  //console.log("addonList---",this.addonList);
              }
          });
      }
     
     

  },
  methods: {
  i18n,
         getChildDetails(contentParentUuid, pageNo, perPage) {
          
          getChildDetails(contentParentUuid, pageNo, perPage).then((res) => {
              
              this.childListData= res.data.data.childList.child_list.child_content;
              // this.child_contentDetails = res.data.data.childList.child_list;
        
          });


      },
      getCastcrewDetails() {
                 
     
          getContentCastList(this.contentParentUuid).then((res) => {
              // JsLoadingOverlay.hide();
              if (res.data.code == 200 && res.data.data !== null &&
                  res.data.data.contentList.content_list?.length>0) {
                  this.contentCastList = res.data.data.contentList.content_list[0].cast_details;
              }
          });
      }
  },
  template: /*html*/ `
<vd-component class="vd castcrew-list-seven" type="castcrew-list-seven">
<!--Cast Section Start Here-->
<section class="product-listing cast-listing p-0"  :v-if="contentCastList?.length > 0">
 <div class="container-fluid pl-65">
   <div class="row">
     <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
       <div class="contect-listing">
         <div class="episode-heading" v-if="contentCastList?.length > 0">
         <h2 class="sub-heading white-color" vd-readonly="true"> <vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></h2>
         <span class="view-all" v-if="contentCastList?.length>6">
             <a class="text-primary iq-view-all callByAjax" :href="'/content/'+contentPermalink+'/casts'"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
           <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
             <path d="M2.66536 8.66536L10.7787 8.66536L7.05203 12.392L7.9987 13.332L13.332 7.9987L7.9987 2.66536L7.0587 3.60536L10.7787 7.33203L2.66536 7.33203L2.66536 8.66536Z" fill="#bf000a" stroke="#bf000a" stroke-width="0.2"/>
             </svg>              
         </span>
         </div>
         <div class="owl-product owl-carousel owl-theme cast-listing-carousel" v-if="contentCastList?.length > 0">
           <div class="item" v-for="data in contentCastList"> 
           <a class="callByAjax" :href="'/cast-details/'+data.cast_uuid">                 
            <div class="picture">
            <img loading="lazy" v-if="data.cast_image_details !== null && data.cast_image_details.file_url !=='' || null" :src="data.cast_image_details.file_url" alt="Pedro Pascal" class=""/>
          <img loading="lazy" v-if="data.cast_image_details === null || data.cast_image_details.file_url ==='' || null" :src="data.no_image_available_url" alt="Pedro Pascal" class=""/>
             </div>  
             </a>           
           </div>				 
         </div>
       </div>
     </div>
   </div>
 </div>
</section>
<!--cast Section End Here-->
</vd-component>`,
};

let {getContentCastList,
    categorizedPermalink}=await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
export default {
    name: "castcrew_list_three",
    data() {
        return {
            contentCastList: [],
            contentPermalink: permalink, //window.location.pathname.toString().split("/")[2],
            contentParentUuid: "",
            contentName: "",
        };
    },
    beforeCreate() {},
    mounted() {
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    content.permalink_type == "content" &&
                                    content.content_permalink ==
                                        this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;
                        this.contentName =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_name;
                        this.getCastcrewDetails();
                    }
                }
            });
        }
    },
    updated() {
        owlCarousal();
    },
    methods: {
        i18n,
        getCastcrewDetails() {
            getContentCastList(this.contentParentUuid).then((res) => {
                // JsLoadingOverlay.hide();
                if (
                    res.data.code == 200 &&
                    res.data.data !== null &&
                    res.data.data.contentList.content_list?.length > 0
                ) {
                    this.contentCastList =
                        res.data.data.contentList.content_list[0].cast_details;
                }
            });
        },
    },
    template: `
<vd-component class="vd castcrew-list-three" type="castcrew-list-three">
   <section class="section-padding" v-if="contentCastList !== null && contentCastList?.length">
     <div class="container-fluid">
        <div class="row justify-content-between align-items-center">
                <div class="col-auto">
                    <h4 vd-readonly="true" class="heading-title"><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></h4>                   
                </div>
                <div class="col-auto heading-view">
                    <span class="view-all" v-if="contentCastList?.length>6">
                        <a class="callByAjax" :href="'/content/'+contentPermalink+'/casts'"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
                    </span>
                </div>
        </div>
	    <div class="row mt-4">
          <div class="col-xl-12 col-lg-12 col-md-12">
             <div class="raiden-product-slider">
                <div class="owl-cast owl-carousel owl-loaded owl-drag">
                   <div class="item" v-for="data in contentCastList">
                        <div class="product-slider-container">
                           <div class="product-slider-image">
                            <img loading="lazy" v-if="data.cast_image_details !== null && data.cast_image_details.file_url !=='' || null" :src="data.cast_image_details.file_url" alt="Pedro Pascal" class="w-100"/>
			    <img loading="lazy" v-if="data.cast_image_details === null || data.cast_image_details.file_url ==='' || null" :src="data.no_image_available_url" alt="Pedro Pascal" class="w-100"/>
                           </div>
                          <div class="gen-info-contain">
                            <div class="gen-movie-info">
                                <h3>
                                  <a  class="callByAjax" :href="'/cast-details/'+data.cast_uuid">
                                  {{data.cast_name}}
				                 </a>
                                </h3>
                            </div>                                        
                          </div>
                        </div>
                   </div>
                </div>
             </div>
        </div>
  </div>
 </section>
</vd-component>
`,
};

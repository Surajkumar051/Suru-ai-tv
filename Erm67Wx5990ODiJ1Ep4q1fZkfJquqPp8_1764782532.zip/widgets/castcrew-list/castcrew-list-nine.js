let {getContentCastList,
    categorizedPermalink}=await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: 'castcrew_list_nine',
    data() {
        return {
            contentCastList: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            contentParentUuid:"",
            contentName:"",
        }
    },
    updated() {
        // owlCarousal();
    },
    beforeCreate() {

    },
    mounted() {

        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if (content.permalink_type == "content" && content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.contentName = res.data.data.contentList.content_list[findContentParentIndex].content_name;
                        this.getCastcrewDetails();


                    }
                }
            });
        }
        

    },
    methods: {
		i18n,
        getCastcrewDetails() {
            getContentCastList(this.contentParentUuid).then((res) => {
                JsLoadingOverlay.hide();
                if (res.data.code == 200 && res.data.data !== null &&
                    res.data.data.contentList.content_list?.length>0) {
                    this.contentCastList = res.data.data.contentList.content_list[0].cast_details;
                }
            });
        }
    },
    template: `
    <vd-component class="vd castcrew-list-nine" type="castcrew-list-nine">
    <div class="slide-wrapper" v-if="contentCastList !== null && contentCastList?.length">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6 text-left mb-4 mt-4">
                    <h2><vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param></h2>
                </div>
                <span class="view-all mb-4 mt-4" v-if="contentCastList?.length>6">
                    <a class="callByAjax" :href="'/content/'+contentPermalink+'/casts'"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
                </span>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="owl-cast-emerald team-slider-full owl-carousel owl-theme">
                        <div class="owl-items" v-for="data in contentCastList">
                            <a class="crew-wrap callByAjax" :href="'/cast-details/'+data.cast_uuid">
                                <img loading="lazy" v-if="data.cast_image_details !== null && data.cast_image_details.file_url !=='' || null" :src="data.cast_image_details.file_url" alt="Pedro Pascal" class="w-100"/>
                                <img loading="lazy" v-if="data.cast_image_details === null || data.cast_image_details.file_url ==='' || null" :src="data.no_image_available_url" alt="Pedro Pascal" class="w-100"/>
                                <span>{{data.cast_name}}</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </vd-component>

`
}
let {getContentCastList,
    categorizedPermalink}=await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name: "castcrew_list_six",
    data() {
        return {
            contentCastList: [],
            contentPermalink: permalink, //window.location.pathname.toString().split("/")[2],
            contentParentUuid: "",
            contentName: "",
        };
    },
    beforeCreate() {},
    mounted() {
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    content.permalink_type == "content" &&
                                    content.content_permalink ==
                                        this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;
                        this.contentName =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_name;
                        this.getCastcrewDetails();
                    }
                }
            });
        }
    },
    methods: {
        i18n,
        getCastcrewDetails() {
            getContentCastList(this.contentParentUuid).then((res) => {
                // JsLoadingOverlay.hide();
                if (
                    res.data.code == 200 &&
                    res.data.data !== null &&
                    res.data.data.contentList.content_list?.length > 0
                ) {
                    this.contentCastList =
                        res.data.data.contentList.content_list[0].cast_details;
                }
            });
        },
    },
    template: `
<vd-component class="vd castcrew-list-six" type="castcrew-list-six">
	<!--Cast Section Start Here-->
	<section class="cast" v-if="contentCastList !== null && contentCastList?.length">
		<div class="container-fluid">
			<div class="row accordianRow">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12"> 
                    <h2 vd-readonly="true" class="sub-heading accordionh2 white-color" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                        <vd-component-param type="label17" v-html="i18n($attrs['label17'])"></vd-component-param>
                        <a class="callByAjax view-all-listing" v-if="contentCastList?.length>6" :href="'/content/'+contentPermalink+'/casts'"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></a>
                    </h2>
                </div>
				<div id="collapseOne" class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 d-lg-flex d-xl-flex flex-wrap collapse show">
                    <div class="tiles" v-for="data in contentCastList">
                        <a class="callByAjax" :href="'/cast-details/'+data.cast_uuid">
                            <div class="picture">
                                <img v-if="data.cast_image_details !== null && data.cast_image_details.file_url !=='' || null" :src="data.cast_image_details.file_url" alt="Pedro Pascal" class="w-100"/>
								<img v-if="data.cast_image_details === null || data.cast_image_details.file_url ==='' || null" :src="data.no_image_available_url" alt="Pedro Pascal" class="w-100"/>
                            </div>
                            <div class="data">
                                <span>
                                  {{data.cast_name}}
                                </span>                  
                            </div>
                        </a>
                    </div>
				</div>
			</div>
		</div>
	</section>
</vd-component>`,
};

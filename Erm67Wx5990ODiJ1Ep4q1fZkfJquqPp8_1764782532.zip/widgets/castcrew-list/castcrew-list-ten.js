let {getContentCastList,
    categorizedPermalink}=await import(window.importAssetJs('js/webservices.js'));
export default {
    name: 'castcrew_list_ten',
    data() {
        return {
            contentCastList: [],
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            contentParentUuid:"",
        }
    },
    beforeCreate() {

    },
    mounted() {

        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if (content.permalink_type == "content" && content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.contentName = res.data.data.contentList.content_list[findContentParentIndex].content_name;
                        this.getCastcrewDetails();


                    }
                }
            });
        }
        

    },
    methods: {
        getCastcrewDetails() {
            getContentCastList(this.contentParentUuid).then((res) => {
                JsLoadingOverlay.hide();
                if (res.data.code == 200 && res.data.data !== null &&
                    res.data.data.contentList.content_list?.length>0) {
                    this.contentCastList = res.data.data.contentList.content_list[0].cast_details;
                }
            });
        }
    },
    template: `
    <vd-component class="vd castcrew-list-two" type="castcrew-list-two">
        <section class="product-listing" v-if="contentCastList !== null">
            <div class="slide-wrapper container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mb-4 mt-4">
                        <div class="episode-heading">
                            <h2 class="sub-heading white-color" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                <vd-component-param type="label17">{{ $attrs['label17'] }} "{{contentName}}"</vd-component-param>
                            </h2>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <template v-if="contentCastList.length ">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-2 col-xl-2" v-for="data in contentCastList">
                                    <div class="slide-one tiles grid-hover">
                                        <div class="slide-image picture">
                                            <img loading="lazy" v-if="data.cast_image_details !== null && data.cast_image_details.file_url !=='' || null" :src="data.cast_image_details.file_url" alt="Pedro Pascal" class="w-100"/>
                                            <img loading="lazy" v-if="data.cast_image_details === null || data.cast_image_details.file_url ==='' || null" :src="data.no_image_available_url" alt="Pedro Pascal" class="w-100"/>
                                        </div>
                                        <div class="slide-content data">
                                            <h2>
                                                <a class="callByAjax" :href="'/cast-details/'+data.cast_uuid">
                                                    <span>{{data.cast_name}}</span>
                                                </a>
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </section>
    </vd-component>
`
}
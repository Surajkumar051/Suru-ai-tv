let {getContentDetails, 
    categorizedPermalink, 
    getChildDetails,getContentSettingsDetails}=await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_eight}=await import(window.importLocalJs('widgets/content-hover/content-hover-five.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl,getAssetUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {default:content_title_eight}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let {GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS}=await import(window.importAssetJs('js/configurations/actions.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "child_details_three",
     components: {
        content_hover_eight,
        audio_player_one,
        content_title_eight,
		content_purchase_four: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-four.js'))),
    },
   data() {
        return {
            contentPermalink: permalink,//window.location.pathname.toString().split("/")[2],
            contentParentUuid: "",
            level0ContentName: "",
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            childDetail: {},
            pageNo: 1,
            perPage: 12,
            isNextLevel2PageExist: true,
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            assetUrl:getAssetUrl(),
            userList:[],
            isFavouriteEnabled: false,

        };
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },

    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    content.permalink_type == "content" &&
                                    content.content_permalink ==
                                        this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (findContentParentIndex > -1) {
                        let contentObj =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ];
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;

                        this.getChildDetails(
                            this.contentParentUuid,
                            this.pageNo,
                            this.perPage,
                            false
                        );
                    }
                }
            });
            this.loadMore();
        }
        getContentSettingsDetails().then((res) => {
        if (res.data.code == 200) {
            
            this.isFavouriteEnabled =
                res.data.data.contentSettings
                    .content_favourite_settings != null
                    ? res.data.data.contentSettings
                          .content_favourite_settings?.is_enabled
                    : false;
          
        }
    });
    },
    methods: {
        getRootUrl,
		i18n,
        getAssetUrl,
        getChildDetails(contentParentUuid, pageNo, perPage, onScroll) {
            this.isNextLevel2PageExist = false;
            getChildDetails(contentParentUuid, pageNo, perPage).then((res) => {
                if (
                    onScroll &&
                    res.data.data.childList.child_list.child_content != null
                ) {
                    this.isNextLevel2PageExist = true;
                    this.childDetail.child_content.push(
                        ...res.data.data.childList.child_list.child_content
                    );
                    contentHelper.getPartnerAndUserUuids(res.data.data.childList.child_list.child_content,this.userList)
                } else if (
                    !onScroll &&
                    res.data.data.childList.child_list.child_content != null
                ) {
                    this.isNextLevel2PageExist = true;
                    this.childDetail = res.data.data.childList.child_list;
                    if(res.data.data.childList.child_list){
                        contentHelper.getPartnerAndUserUuids(res.data.data.childList.child_list.child_content,this.userList)
                    }
                    getContentDetails(
                        this.childDetail.content_parent_uuid
                    ).then((res) => {
                        if (res.data.code == 200) {
                            this.level0ContentName =
                                res.data.data.contentList?.content_list[0]?.content_name;
                        }
                    });
                }
            });
        },

        loadMore() {
            let ths = this;
            window.onscroll = () => {
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                if (
                    bottomOfWindow &&
                    this.isNextLevel2PageExist &&
                    ths.childDetail?.no_of_child_content >
                        ths.childDetail?.child_content?.length && scrollLoad
                ) {
                    this.pageNo++;
                    this.getChildDetails(
                        this.contentParentUuid,
                        this.pageNo,
                        this.perPage,
                        true
                    );
                }
            };
        },
        playAudioContent(contentUuid) {
            this.contentUuidAudio = contentUuid;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        reloadComponentAudio(content_detail){
            this.playAudioContent(content_detail.content_uuid);
        }
    },
    template: /*html*/ `
    
<vd-component class="vd child-details-three" type="child-Details-three">
<content_purchase_four  :id="$attrs['id'] +'_content_purchase_four_4'" />
    <main class="site-main watchlist-contens" v-if="childDetail?.child_content && childDetail?.child_content.length > 0">
            <div class="container-fluid">
                            <div class="iq-main-header d-flex align-items-center justify-content-between mt-5 mt-lg-0" >
                                            <h4 vd-readonly="true" class="main-title"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param> {{level0ContentName}} : {{childDetail.content_name}}</h4>
                            </div>
                            
                            <ul class=" row list-inline  mb-0 iq-rtl-direction ">
                                    <li class="slide-item col-lg-3 col-md-4 col-6 mb-4" v-for="data in childDetail?.child_content">
                                            <div class="block-images position-relative  watchlist-first" >
                                                            <div class="freeContent-tag" v-if="data?.is_free_content">
                                                                <span><vd-component-param type="label5" v-html="i18n($attrs['label5'])"></vd-component-param></span>
                                                            </div>
                                                            <div class="mrContent-tag" v-if="data?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                                                <span>{{maturity_rating?.maturity_rating_list[data?.maturity_rating]}}</span>
                                                            </div>
                                                            <div class="img-box">
                                                                    <img loading="lazy" class="w-100" v-if="data.posters.website !== null && data.posters.website[0].file_url !== ''" :src="data.posters.website[0].file_url" :alt="data.posters.website[0].file_url"/>
                                                                    <img loading="lazy" class="w-100" v-if="data.posters.website === null  || data.posters.website[0].file_url === ''" :src="assetUrl + 'img/Garnet_Img/no_image.jpg'" alt="no image"/>
                                                                   
                                                            </div>
                                                    <div class="block-description">
                                                            <content_title_eight :id="$attrs['id'] +'_content_title_eight_1'"  
                                                            :content="data" :userList="userList" />        
                                                            <!--<div class="data">
                                                                    <a class="callByAjax" :href="'/content/'+data.content_permalink" @click="getContentId(data.content_uuid)">
                                                                            <span v-if="data.content_name">{{data.content_name}} </span>
                                                                    </a>
                                                            </div>-->
                                                             <!--Button Show on Hover start Here-->
                                                             <content_hover_eight :content="data" 
                                                             :isFavouriteSettings="isFavouriteEnabled"
                                                             :id="$attrs['id'] +'_content_hover_eight_5'"
                                                             :playNowBtnTxt="$attrs['label2']" 
                                                             :viewTrailerBtnTxt="$attrs['label4']" 
                                                             :playAllBtnTxt="$attrs['label5']" 
                                                             :watchNowBtnTxt="$attrs['label6']" 
                                                             :isLogedIn="isLogedIn"
                                                             @playAudioContent="playAudioContent"
                                                             downloadBtnText="i18n($attrs['label6'])"
                                                            :openBtnText="i18n($attrs['label7'])"
                                                         />
                                                         <!--Button Show on Hover End Here-->
                                                    </div>
                                            </div>
                                    </li>
                            </ul>
            </div>
            <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" @reloadComponentAudio="reloadComponentAudio" />
</vd-component>`,
};

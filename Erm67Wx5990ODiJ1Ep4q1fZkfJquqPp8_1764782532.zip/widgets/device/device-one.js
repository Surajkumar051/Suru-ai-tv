let {i18n}=await import(window.importAssetJs('js/i18n.js'));
export default {
    name : 'device_one',

    data() {
        return {
            noDevice: false,
            allDevices: []

        }
    },
    beforeMount() {
        //JsLoadingOverlay.show();
    },
    methods: {
		i18n,
    },
    template:`<vd-component type="device-one">
    <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
        <div class="my-profile-process" id="muvi-device-one">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <label class="dashboard-heading white-color mbottom-20"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></label>
                    <div class="deviece-control">
                    
                        <div class="manage-data" v-if="!noDevice">
                        <div class="top-icon">
                            <img v-if="device_type=='mobile'"
                                src="https://sampledesign.asthu.com/phoenix-template/images/mobile.png" alt="mobile" />
                            <img v-if="device_type == 'desktop'"
                                src="https://sampledesign.asthu.com/phoenix-template/images/laptop.png" alt="desktop" />
                        </div>
                            <h2>{{allDevices.device_info}}</h2>
                            <p>{{"Last Login Time:",allDevices.createddate}}</p>
                            <p>{{allDevices.os_version}}</p>
                            <p><a class="callByAjax">Deregister</a></p>
                        </div>
                    </div>
                    <div class="blank-card-info" v-if="noDevice">
                    <p><vd-component-param type="label2" v-html="i18n($attrs['label2'])"></vd-component-param></p>
                </div>
                </div>
            </div>
        </div>
    </div>
</vd-component>`
};
let {getSubCategories,getUgcMiniTemplate,getCategories,
  saveContent,generatePermalink,fetchContentForEdit,updateContent,
  getAwsBucketInfo,
  getUserInfo,
  getAwsTempCreds,
  saveAsset}=await import(window.importAssetJs('js/webservices.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let {Toast}=await import(window.importAssetJs('js/commontoast.js'));
export default {
    name: "ugc_content_upload_one",

    components: {
        
    },

    data() {
        return {
            rootUrl: getRootUrl(),
            contentTypeUGCMini:'UGC',
            templateDetails:{},
            categoryList:[],
            errors:"",
            subCategoryList:[],
            showSubcategory:false,
            content: {
                content_name: "",
                content_permalink: "",
                content_desc: "",
                content_category_uuid: "",
                content_asset_type: 1,
                content_asset_uuid: "",
                content_parent_uuid: null,
                store_key: ":store_key",
                app_token: ":app_token",
                product_key: ":product_key",
                is_parent: null,
                content_sub_category_uuid: "",
                content_template_uuid: "",
                user_type:"",
                content_created_by:"",
            },


            bucketDetails: null,
            bucketName: null,
            s3: null,
            accessKeyId:"",
            secretKey:"",
            sessionToken:"",
            unsignedFileUrl: null,
            drmFileUrl: null,
            s3pathStruct: null,
            folderKey: null,
            appToken: null,
            productKey: null,
            allowedExtensions: [
              ".mp4",
              ".wmv",
              ".mov",
              ".flv",
              ".vob",
              ".m4v",
              ".mkv",
              ".avi",
              ".3gp",
              ".mpg",
              ".mxf",
            ],
            eventName:"primaryVideo",
            fileName:"",
            fileUrl:"",
            reloadFileUrl:1,
            uploadProgress:false,
        };
    },
    beforeMount() {
        
    },
    mounted() {
        this.fetchUGCTemplate();
        this.fetchCategories();
       // this.getAwsBucketInfo();
        //this.getUserInfo();
        console.log("pithan---",this.contentId);
        
    },
    props: {
      contentId: String,
  },
watch:{
      contentId(contentId){
        console.log("pithan---5555",contentId);
        this.fetchEditContent(contentId);
      }
},
computed: {
  showFileName(){
    let maxChar = 30;
    let fileNameStr = "";
    fileNameStr += (this.fileName.length>maxChar) ? this.fileName.substring(0,maxChar)+"... "+this.fileName.substring(this.fileName.lastIndexOf('.'),this.fileName.length):this.fileName;
    return fileNameStr;
  },
  formattedExtensions() {
    return this.allowedExtensions
      .map(ext => ext.replace('.', '')).join(', ');
  },
},
methods: {
      
		i18n,
    fetchUGCTemplate(){
            getUgcMiniTemplate(this.content.content_asset_type,this.contentTypeUGCMini).then((res) => {
                    if(res.data.status == 'SUCCESS' && res.data.code==200 && res.data.data.templateList && res.data.data.templateList.length>0){
                            this.templateDetails = res.data.data.templateList[0];
                            this.content.content_template_uuid = this.templateDetails.template_uuid;
                    }
            });
    },
    fetchCategories(){
            getCategories().then((res) => {
                    const resp = res.data;
                    if (
                      resp.code === 200 &&
                      resp.data &&
                      resp.data.categoryList &&
                      resp.data.categoryList.category_list
                    ) {
                      this.categoryList = resp.data.categoryList.category_list;
                    }
            });
    },

    fetchSubCategories(){
            getSubCategories(this.content.content_category_uuid).then(
                    (res) => {
                      const resp = res.data;
                      if (
                        resp.code === 200 &&
                        resp.data &&
                        resp.data.categoryList &&
                        resp.data.categoryList.category_list
                      ) {
                        this.subCategoryList = resp.data.categoryList.category_list;
                        if(this.subCategoryList?.length > 0)
                          this.showSubcategory = true;
                      } else {
                        this.showSubcategory = false;
                        this.content.content_sub_category_uuid = "";
                      }
                    }
                  );
    },

    categorySelected(){
            if ("" != this.content.content_category_uuid) {
                    this.content.content_sub_category_uuid = "";
                    this.fetchSubCategories();
                  } else {
                    this.showSubcategory = false;
            }
    },
    submitUGCContent(){
      if(this.validateContentForm()){
            if(this.content?.content_permalink?.trim() != ""){
                    this.saveUGCContent(); 
            }else{
                    let contentDto = {
                            app_token: ":app_token",
                            product_key: ":product_key",
                            store_key: ":store_key",
                            content_name: this.content?.content_name.trim(),
                          };
                  
                          generatePermalink(contentDto).then((res) => {
                            const resp = res.data;
                            if (resp.code === 200 && resp.generated_permalink) {
                              this.content.content_permalink = resp.generated_permalink;
                              this.saveUGCContent(); 
                            }
                          });
            }
          }
            
    },
    saveUGCContent(){
      if(this.validateContentForm()){
        if(this.content.content_uuid === undefined || this.content.content_uuid === null || this.content.content_uuid === ""){
              saveContent(this.content).then((res) => {
                      const resp = res.data;
                      if (
                        resp.code === 200 &&
                        resp.data &&
                        resp.status &&
                        resp.status === "SUCCESS"
                      ) {
                              this.emitClose();
                              $(".modal-backdrop").hide();
                              $('.upload-content-popup').hide();
                              if(window.location.pathname.toString().indexOf('profile') != -1){
                                  window.location.reload();
                              }
                              Toast.fire({
                                      icon: 'success',
                                      text: i18n("Content Added Successfully."),
                                  });
                      }else{
                              Toast.fire({
                                      icon: 'error',
                                      text: i18n("Content creation failed."),
                                  });    
                      }
              });
            }else{
                  updateContent(this.content).then((res) => {
                    const resp = res.data;
                    if (
                      resp.code === 200 &&
                      resp.data &&
                      resp.status &&
                      resp.status === "SUCCESS"
                    ) {
                            $(".modal-backdrop").hide();
                            $('.upload-content-popup').hide();
                             if(window.location.pathname.toString().indexOf('profile') != -1){
                                  window.location.reload();
                              }
                            Toast.fire({
                                    icon: 'success',
                                    text: i18n("Content Updated Successfully."),
                                });
                    }else{
                            Toast.fire({
                                    icon: 'error',
                                    text: "Content update failed.",
                                });    
                    }
                });
            }
        }
    },
    generatePermalink(content_name) {
            if (content_name != undefined && content_name.trim() != "" ) {
              let contentDto = {
                app_token: ":app_token",
                product_key: ":product_key",
                store_key: ":store_key",
                content_name: content_name.trim(),
              };
      
              generatePermalink(contentDto).then((res) => {
                const resp = res.data;
                if (resp.code === 200 && resp.generated_permalink) {
                  this.content.content_permalink = resp.generated_permalink;
                }
              });
            }
    },
    fetchEditContent(contentUuid){
      fetchContentForEdit(contentUuid).then((res) => {
        const resp = res.data;
        if (resp.code === 200 && resp.data.contentList?.content_list?.length>0) {
          this.content = resp.data.contentList.content_list[0];
          this.fileName = resp.data.contentList.content_list[0].video_details?.file_name;
          this.fileUrl = resp.data.contentList.content_list[0].video_details?.file_url;
          console.log("pithan--------------",this.content);
          this.fetchSubCategories();
        }
      });

    },
    validateContentForm(){

      
      if(this.content.content_name.trim() === ''){
        this.errors= i18n("Title can not be blank");
        return false;
      }else if(this.content.content_name.trim().length>255){
        this.errors = i18n("Title can not be more than 255 character");
        return false;
      }else if(this.content.content_category_uuid === ''){
        this.errors = i18n("Category can not be blank");
        return false;
      }
      return true;
    },




//File Upload Related Code - Start
  async  getAwsBucketInfo() {
      let res = await getAwsTempCreds();
      let resp = res.data;
      if(resp.code === 200 && resp.status === "SUCCESS"){
        this.accessKeyId = resp.data.access_key_id;
        this.secretKey = resp.data.secret_key;
        this.sessionToken = resp.data.session_token;
      }
      if (this.bucketDetails === null || this.bucketName === null)
        await getAwsBucketInfo().then((response) => {
          if (response.data.status == "SUCCESS") {
            this.bucketDetails = response.data.data.getBucketInfo;
            this.bucketName = this.bucketDetails.bucket_detail.bucket_name;
            AWS.config.update({
              region: this.bucketDetails.bucket_detail.region_code,
              //accessKeyId: this.AWS_ACCESS_KEY,
            //  secretAccessKey: this.AWS_SECRET_KEY,
            });
            this.s3 = new AWS.S3({
              apiVersion: "2008-10-17",
              params: { Bucket: this.bucketName },
              accessKeyId: this.accessKeyId,
              secretAccessKey: this.secretKey,
              sessionToken: this.sessionToken
            });
            console.log(this.s3);
          }
        });
    },
    getAwsDetails(eventName) {
      let awsPathDetails = this.bucketDetails.assets_path_structure;
      let awsBucketDetails = this.bucketDetails.bucket_detail;
      this.unsignedFileUrl = awsBucketDetails.unsigned_cloudfront_url;
      this.drmFileUrl = awsBucketDetails.drm_cloudfront_url;
      this.bucketName = awsBucketDetails.bucket_name;
      let awsKeyName = "video-library";

      
      awsPathDetails
        .filter((awsPath) => awsPath.key_name === awsKeyName)
        .forEach((awsPath) => {
          this.s3pathStruct = awsPath.s3_path;
          this.folderKey = awsPath.folder_key;
        });
    },
    async getUserInfo() {
      if (this.appToken === null || this.productKey === null)
       await getUserInfo().then((response) => {
          this.appToken = response.data.data.app_token;
          this.productKey = response.data.data.product_key;
        });
    },
    validateFiles(files) {
      this.errors = "";
      files.some((file) => {
        if ( file.size > 5368709120) {
          this.errors = "File size is bigger than instructed, 5 GB  max.";
          this.files = [];
          return true;
        }
        
        let fileNameExt = file.name
          .substr(file.name.lastIndexOf("."))
          .toLowerCase();
        let fileTypeExt = file.type.substr(file.type.indexOf("/") + 1);
       
        if (
          (this.allowedExtensions.indexOf(fileNameExt) === -1 &&
            this.allowedExtensions.indexOf(fileNameExt.toUpperCase()) === -1) 
        ) {
          this.errors = i18n("Invalid file type. Select correct upload type.");
          this.files = [];
          return true;
        }
      });
      return this.errors.length > 1;
    },
    setAssetFileType(fileType, fileName) {
      let fileAssetType = fileType.substr(0, fileType.indexOf("/"));
      let fileExtention = "." + fileType.split("/").pop();
      let extFromName = fileName.substring(
        fileName.lastIndexOf("."),
        fileName.length
      );

      if (
        fileAssetType == "application" ||
        extFromName == ".webm" ||
        extFromName == ".mpeg" ||
        extFromName == ".m4b" ||
        extFromName == ".mxf" ||
        extFromName == ".flv" ||
        extFromName == ".vob" ||
        extFromName == ".m4p" ||
        extFromName == ".ogg" ||
        extFromName == ".dvf" ||
        extFromName == ".raw"
      ) {
        if (
          this.allowedExtensions.includes(extFromName) &&
          this.selectedMediaType == "Audio"
        ) {
          fileType = "audio";
          return fileType;
        } else if (
          this.allowedExtensions.includes(extFromName) &&
          this.selectedMediaType == "Video"
        ) {
          fileType = "video";
          return fileType;
        }
      } else {
        return;
      }
    },

    generateRandomUuid() {
      return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
        (
          c ^
          (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
        ).toString(16)
      );
    },

    async upload(event) {
      await this.getAwsBucketInfo();
      await this.getUserInfo();
      let fileId = Math.floor(Math.random() * 100) + 1;
      let modifiedEventName = null;
      if (event.target !== undefined) {
        this.files = [...event.target.files];
        modifiedEventName = this.eventName;
      } else {
        this.files = [...event];
        modifiedEventName = this.files[0].eventName;
      }

      if (this.validateFiles(this.files) || this.files.length == 0){
        return false;
      }
     

      this.getAwsDetails(modifiedEventName);

      this.files.forEach((file, index) => {
        let file_Type = file.type;
        file_Type = file_Type.substr(0, file_Type.indexOf("/"));
        
        const ths = this;
        this.file = file;
        let fileName = file.name;
        let dotPos = fileName.lastIndexOf(".");
        
        fileName =
          fileName.substr(0, dotPos).replace(".", "-") +
          "-" +
          new Date().getTime() +
          fileName.substr(dotPos);
        fileName = fileName
          .replace(/[^\w\s.-]+/g, "-")
          .replace(/\s+/g, "")
          .replace(/-{2,}/g, "-")
          .replace(/_/g, "-");

        let fileType = file.type;
        if (fileType.includes("application/pdf")) fileType = "document";
        else fileType = fileType.substr(0, fileType.indexOf("/"));

        let fileAssetType = this.setAssetFileType(file.type, fileName);
        
        if (fileAssetType != undefined) {
          fileType = fileAssetType;
        }

        

        let fileUuid = this.generateRandomUuid().replaceAll("-", "");
        let cUuid = this.generateRandomUuid().replaceAll("-", "");
        let s3Path = this.s3pathStruct
          .replace("{app-token}", this.appToken)
          .replace("{product-key}", this.productKey)
          .replace("{video_uuid}", fileUuid)
          .replace("{audio_uuid}", fileUuid)
          .replace("{image_uuid}", fileUuid)
          .replace("{content_uuid}", cUuid)
          .replace("{document_uuid}", fileUuid);
        let fileUrl =
          "https://" + this.unsignedFileUrl + "/" + s3Path + "/" + fileName;
        let mediaUrl =
          "https://" + this.drmFileUrl + "/" + s3Path + "/" + fileName;
        

        
        this.uploadProgress = true;
        var s3Instance = this.s3
          .upload(
            {
              Key: fileName,
              Body: file,
              Bucket: this.bucketName + "/" + this.folderKey + "/" + s3Path,
              ContentType: file.type,
            },
            (err, data) => {
              console.log(err, data);
              if (err) {
                if (err.code == "NetworkingError") {
                  console.log("Network Error Detected");
                  
                }

                // reject("error", err.message);
              } else {
                let uploadDto = {
                  app_token: ":app_token",
                  store_key: ":store_key",
                  user_uuid: ":me",
                  file_uuid: fileUuid,
                  file_name: fileName,
                  entity_tag: data.ETag,
                  content_type: file.type ? file.type : fileType,
                  file_type: fileType,
                  file_size: file.size,
                  file_url: fileUrl,
                  media_url: mediaUrl,
                  original_file_name : file.name
                };
                

               
                this.uploadProgress = false;
                saveAsset(uploadDto).then((resp) => {
                  if (resp.status === 200 && resp.data.code === 200) {
                    
                    ++this.reloadFileUrl;
                    let result = resp.data.data;
                    this.content.content_asset_uuid = result.file_uuid;
                    this.fileName = result.file_name;
                    
                    this.fileUrl = result.file_url;
                    
                    
                  }
                });
              }
            }
          )
          .on("httpUploadProgress", (progress) => {
            
            // this.$store.dispatch(MODULE_LAYOUT + UPLOAD_PROGRESS, {
            //   index,
            //   file_name: file.name,
            //   file_type: file_Type,
            //   file_uid: fileId,
            //   is_cancel: false,
            //   progress: parseInt(
            //     Math.round((progress.loaded / progress.total) * 100)
            //   ),
            // });
          });
        
      });
    },
    emitClose(){
      this.$emit("closePop");
      this.$emit("contentSaveConfirm");
    }

//File Upload Related Code - end

              
        
    },
    template: `

<vd-component class="vd ugc-content-upload-one" type="ugc-content-upload-one">
    <div  class="modal fade upload-content-popup addnew-card-popup" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style="padding-right: 16px;">
        <div class="modal-dialog modal-lg modal-dialog-centered mw-900">
            <div class="modal-content ucp-modal">
                <div class="modal-body">
                    <section class="add-new-card-section">
                        <h2 class="mb-24">{{i18n('Upload')}}</h2>
                        <div class="form-section">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pr-9">
                                    <!--<div class="form-d-flex">
                                        <label>Type</label>
                                        <select class="form-control">
                                          <option value="">Choose</option>
                                          <option value="">Choose</option>
                                        </select>
                                        </div>-->
                                    <div class="form-d-flex">
                                        <label>{{i18n('Title')}} <span class="mandatory-indicate">*</span> </label>
                                        <input type="text" name="" id="" class="form-control" :placeholder="i18n('Enter a name')" 
                                            v-model.trim="content.content_name" v-on:blur="generatePermalink($event.target.value)">
                                    </div>
                                    <div class="form-d-flex">
                                        <label>{{i18n('Category')}} <span class="mandatory-indicate">*</span></label>
                                        <select class="form-control" @change="categorySelected" v-model="content.content_category_uuid">
                                            <option value="">{{i18n('Choose')}}</option>
                                            <option v-for="category in categoryList" :value="category.category_uuid">
                                                {{category.category_name}}
                                            </option>
                                        </select>
                                    </div>
                                    <div class="form-d-flex" v-show="showSubcategory">
                                        <label>{{i18n('Sub Category')}}</label>
                                        <select class="form-control" aria-label="Default select example" placeholder="Choose" 
                                            v-model="content.content_sub_category_uuid">
                                            <option value="">{{i18n('Choose')}}</option>
                                            <option v-for="subCategory in subCategoryList" :value="subCategory.category_uuid">
                                                {{subCategory.category_name}}
                                            </option>
                                        </select>
                                    </div>
                                    <div class="form-d-flex">
                                        <label>{{i18n('Description')}}</label>
                                        <textarea class="form-control pt-3" v-model.trim="content.content_desc">                      </textarea>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pl-9 d-flex justify-content-end right-div">
                                    <div class="uploadBox hover-show" >
                                        <video  class="p-1" style="height:130px" v-if="fileUrl" v-show="!uploadProgress" :key="reloadFileUrl" >
                                        <source :src="fileUrl" type="video/mp4">
                                        </video>
                                        <div class="folder-svg" v-show="!uploadProgress"  >
                                            <svg  :title = "i18n('No file chosen')" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M14 10V12.6667C14 13.0203 13.8595 13.3594 13.6095 13.6095C13.3594 13.8595 13.0203 14 12.6667 14H3.33333C2.97971 14 2.64057 13.8595 2.39052 13.6095C2.14048 13.3594 2 13.0203 2 12.6667V10" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M11.3307 5.33333L7.9974 2L4.66406 5.33333" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M8 2V10" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </div>
                                        <div class="txt" v-if="!fileUrl" v-show="!uploadProgress">{{i18n('Upload Video')}}</div>
                                        <div class="txt" v-if="fileUrl" v-show="!uploadProgress">{{i18n('Change Video')}}</div>
                                        <input :accept="formattedExtensions" :title = "i18n('No file chosen')" type="file" class="form-control type-file"  v-show="!uploadProgress"
                                        @change="upload($event)"
                                        name="" id="">
                                        <div class="loaderSvg" v-show="uploadProgress">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 38 38" stroke="#0cb9f2">
                                                <g fill="none" fill-rule="evenodd">
                                                    <g transform="translate(1 1)" stroke-width="2">
                                                        <circle stroke-opacity=".5" cx="18" cy="18" r="18">
                                                        </circle>
                                                        <path d="M36 18c0-9.94-8.06-18-18-18">
                                                            <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="1s" repeatCount="indefinite">
                                                            </animateTransform>
                                                        </path>
                                                    </g>
                                                </g>
                                            </svg>
                                        </div>
                                        
                                        
                                    </div>
                                   
                                    <div class="div-afterupload">
                                        <!--<div class="info-span">
                                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M10.8031 5.99922C10.8031 3.34842 8.65393 1.19922 6.00313 1.19922C3.35232 1.19922 1.20312 3.34842 1.20312 5.99922C1.20312 8.65002 3.35232 10.7992 6.00313 10.7992C8.65393 10.7992 10.8031 8.65002 10.8031 5.99922ZM5.40313 7.79922C5.40313 8.13059 5.67175 8.39922 6.00313 8.39922C6.3345 8.39922 6.60313 8.13059 6.60313 7.79922V6.59922C6.60313 6.26785 6.3345 5.99922 6.00313 5.99922C5.67175 5.99922 5.40313 6.26785 5.40313 6.59922V7.79922ZM5.40313 4.19922C5.40313 4.53059 5.67175 4.79922 6.00313 4.79922C6.3345 4.79922 6.60313 4.53059 6.60313 4.19922C6.60313 3.86785 6.3345 3.59922 6.00313 3.59922C5.67175 3.59922 5.40313 3.86785 5.40313 4.19922Z" fill="#00A0AC"></path>
                                            </svg>
                                            <span class="span-recommend">Recommendations</span>                      
                                        </div>-->
                                        <div class="filename-div" v-if="fileName">
                                            <span class="fn-span">{{i18n('Filename')}}</span>
                                            <span class="fn-details truncate-text-regular" data-bs-tooltip="tooltip" data-bs-placement="top"  :data-bs-original-title="fileName" :title="fileName">{{showFileName}}</span>
                                        </div>

                                         <div class="filename-div mb-3 mt-3">
                                            <span class="fn-span">{{i18n('Supported files')}}</span>
                                            <span class="fn-details">{{formattedExtensions}}</span>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="mandatory-message" v-if="errors">
                              <p class="error-msg mb-1 mt-1">{{errors}}</p>
                            </div>
                            <div class="row">
                                <!--<div class="col-xs-9 col-sm-9 ">
                                  <p style="color:red" v-if="errors" >{{errors}}</p>
                                 </div>-->
                                <div class="col-xs-12 col-sm-12 d-flex justify-content-end w-100 footer-btn">
                                    <button type="button" class="btn" data-dismiss="modal" @click="emitClose()">{{i18n('Close')}}</button>
                                    <button type="submit" class="btn upload-btn" id="addtoclose" @click="submitUGCContent()">{{i18n('Upload')}}</button>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</vd-component>
    `,
};

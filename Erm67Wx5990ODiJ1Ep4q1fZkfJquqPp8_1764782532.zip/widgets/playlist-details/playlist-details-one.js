let { categorizedPermalink, getPlaylistDetailsForPlaylistPage, isAuthorizedContent} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { SET_CURRENT_CONTENT_SELECTION_DATA, TOGGLE_CONTENT_PURCHASE_MODAL,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: 'playlist_details_one',
    components: {
        audio_player_one,
        content_hover_one,
        content_title_one
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },

    data() {
        return {
            accessToken: localStorage.getItem("end_user_access_token") == null ? localStorage.getItem("access_token") : localStorage.getItem("end_user_access_token"),//108894
            contentPermalink: permalink, //window.location.pathname.toString().split("/")[2],
            contentParentUuid:"",
            contentDetails:Object,
            isSeeMoreClicked:false,
            contentUuidAudio: '',
            isAudioPlay: false,
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isLogedIn: localStorage.getItem('isloggedin'),
            rootUrl: getRootUrl(),
            userList:[],
            contentPreorderStatusMap:  new Map(),
        }
    },
    beforeCreate() {

    },
    mounted() {
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
				JsLoadingOverlay.show();
        if (this.contentPermalink) {
            categorizedPermalink(this.contentPermalink).then(res => {
                if (res.data.code == 200) {
                    let findContentParentIndex = res.data.data.contentList.content_list.findIndex((content) => {
                        if ((content.permalink_type == "content" || content.is_playlist==1 )&& content.content_permalink == this.contentPermalink) return true;
                        else return false;
                    })
                    if (findContentParentIndex > -1 && res.data.data.contentList.content_list[findContentParentIndex].is_playlist==1) {
                        this.contentParentUuid = res.data.data.contentList.content_list[findContentParentIndex].content_uuid;
                        this.getPlaylistDetails();
                    }
                } else {
                    window.location.href = "/404";
                }
            });
        }
    },
    methods: {
        i18n,
        getBaseUrl,
        getRootUrl,
        getPlaylistDetails() {
            getPlaylistDetailsForPlaylistPage(this.contentParentUuid).then((res) => {
                        if (res.data.code == 200 && res.data.data !== null &&
                                res.data.data.contentList.content_list?.length>0) {
                                this.contentDetails = res.data.data.contentList.content_list[0];
	contentHelper.getPartnerAndUserUuids(res.data.data.contentList.content_list[0].playlist_content_list,this.userList);
    const contentUuids = res.data.data.contentList.content_list[0].playlist_content_list.map(item => item.content_uuid);
            contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

	JsLoadingOverlay.hide();
                        }
            });
        },
        seeMoreLessClicked(status){
            this.isSeeMoreClicked = status;
        },
        async addToQueue(contentUuid){
            // JsLoadingOverlay.show();
            if (window.audioQueueObj && Object.keys(window.audioQueueObj).length > 0) {
                const res = await isAuthorizedContent(contentUuid);
                if (res.data.code == 200) {
                    if (res.data.data.isAuthorized.is_content_authorized) {
                        let unique_id = contentUuid;
                        let token = this.accessToken; // 108894
                        let queue_config = {};
                        let queue_header = {
                            Authorization:
                               "Bearer " + token,// 108894
                        };
                        let queue_body = {
                            unique_id: unique_id,
                            domain: this.enduserURL,
                        };
                        queue_config.add_to_queue_url =
                            getBaseUrl() + "player/add-to-queue";
                        queue_config.queue_header = queue_header;
                        queue_config.queue_body = queue_body;
                        window.audioQueueObj._loadIntoQueue(queue_config);
                    } else {
                        this.$store.dispatch(SET_CURRENT_CONTENT_SELECTION_DATA, {
                            content_uuid: contentUuid,
                            monetization_methods: res.data.data.isAuthorized.monetization_details_list[0].monetization_methods
                        });
                        this.$store.dispatch(TOGGLE_CONTENT_PURCHASE_MODAL, false);
                    }
                }
            } else {
                this.contentUuidAudio = contentUuid;
                this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                this.isAudioPlay = true;
            }
        },
        timeFormating(duration){
            let durationToShow = "";
            if(duration != undefined){
                let timeElements = duration.split(":");
                if(timeElements.length==3){
                    durationToShow = Number(Number(timeElements[0]*60)+timeElements[1])+":"+timeElements[2];

                }else if(timeElements.length==2){
                    durationToShow = timeElements[0]+":"+timeElements[1];
                }
            }
            return durationToShow;
        },
        playAudioContent(content_detail) {
            // console.log('content_detail', content_detail);
            // console.log('contentDetails-----------------', this.contentDetails);
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;
            this.isFreeContent = content_detail.is_free_content;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    template: `
    <vd-component class="vd playlist-details-one" type="playlist-details-one" >
    <section class="season-content pt-0" v-if="contentDetails.is_playlist==1 &&(contentDetails.content_asset_type==1 || contentDetails.content_asset_type==6)">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="episode-heading">
                        <h3 class="sub-heading white-color" v-if="contentDetails.content_asset_type==1 && contentDetails?.playlist_content_list?.length>0" >{{i18n('Start Watching')}}</h3>
                        <h3 class="sub-heading white-color" v-if="contentDetails.content_asset_type==6 && contentDetails?.playlist_content_list?.length>0">{{i18n('Documents')}}</h3>
                        <!--<span class="view-all">
                            <a href="javascript:void(0);" class="callByAjax">{{i18n('View All')}}</a>
                        </span>-->
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-2" v-for="trackContent in contentDetails?.playlist_content_list">
                            <div class="tiles grid-hover">
                                <div class="picture watch-status">
                                <div class="freeContent-tag" v-if="trackContent?.is_free_content">
                                <span><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></span>
                                   </div>
                                <div class="mrContent-tag" v-if="trackContent?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[trackContent?.maturity_rating]}}</span>
                                     </div>

                                    <!--Icon Aply Here-->
                                    <div :class="(trackContent.content_asset_type == 2)?'icons-apply-audio':'icons-apply'" :class="(trackContent.content_asset_type == 6 && trackContent.is_playlist!=1)?'doc-img':''">
                                        <img v-if="trackContent.content_asset_type == 1 && trackContent.video_details?.is_live_feed == false" :src="rootUrl + 'img/video-icons.png'" />
                                        <img v-if="trackContent.content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'"/>
                                        <img v-if="trackContent.content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                        <svg v-if = "trackContent.content_asset_type == 1 && trackContent.video_details?.is_live_feed == true"
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <path d="M12.2 4.33333C12.2 3.598 11.5721 3 10.8 3H2.4C1.6279 3 1 3.598 1 4.33333V11C1 11.7353 1.6279 12.3333 2.4 12.3333H10.8C11.5721 12.3333 12.2 11.7353 12.2 11V8.778L15 11V4.33333L12.2 6.55533V4.33333Z" fill="#7B8794"></path>
                                            <circle cx="6.64062" cy="7.65234" r="2.25" fill="white" fill-opacity="0.6"></circle>
                                        </svg>
                                    </div>
                                    <!--Icon Aply Here-->

                                    <img loading="lazy" class="w-100" v-if="trackContent.posters.website !== null && trackContent.posters.website[0].file_url !== ''" :src="trackContent.posters.website[0].file_url" />
                                    <img loading="lazy" class="w-100" v-if="trackContent.posters.website === null  || trackContent.posters.website[0].file_url === ''" :src="contentDetails.no_image_available_url" />
                                    <!--Button Show on Hover start Here-->
                                    <content_hover_one
                                        :id="$attrs['id'] +'_content_hover_one_1'"
                                        :content="trackContent"
                                        :contentDetails="contentDetails"
                                        :playNowBtnTxt="i18n($attrs['label3'])"
                                        :viewTrailerBtnTxt="i18n($attrs['label13'])"
                                        :playAllBtnTxt="i18n($attrs['label19'])"
                                        :watchNowBtnTxt="i18n($attrs['label3'])"
                                        :isLogedIn="isLogedIn"
                                        :downloadBtnText="i18n($attrs['label21'])"
                                        :openBtnText="i18n($attrs['label22'])"
                                        :preOrderBtnTxt  = "i18n($attrs['label23'])"
									    :contentPreorderStatusMap = "contentPreorderStatusMap"


									/>
                                    <!--Button Show on Hover End Here-->
                                    <!--Status Bar-->
                                    <!--<div class="status-bar">
                                        <div class="status-progress" style="width:20px;"/>
                                    </div>-->
                                    <!--Status Bar-->
                                </div>
                                <!--<div class="data">
                                    <a class="callByAjax" :href="'/content/'+trackContent.content_permalink">
                                        <span>{{trackContent.content_name}}</span>
                                    </a>
                                </div>-->
                                <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  :content="trackContent"
                                :userList="userList" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="tracks"  v-if="contentDetails.is_playlist==1 && contentDetails.content_asset_type==2">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                     <h2 class="sub-heading white-color mbottom-30" v-if="contentDetails?.playlist_content_list?.length>0">{{i18n("Tracks")}}</h2     
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="mplbb-scrollDiv table-responsive">
                        <table class="table">
                            <colgroup>
                                <col class="one"/>
                                <col class="two"/>
                                <col class="three"/>
                                <col class="four"/>
                                <col class="five"/>
                                <col class="six"/>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>{{i18n('Title')}}</th>
                                    <th></th>
                                    <th></th>
                                    <th>{{i18n('Duration')}}</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <template v-for="(trackContent,i) in contentDetails?.playlist_content_list" :key="i">
                                <tr  v-if="i<=5">
                                    <td>
                                        <div class="dsn-play-div">
                                            <span class="sn-digit px-0">
                                                {{i+1}}
                                            </span>
                                            <content_hover_one
                                                :id="$attrs['id'] +'_content_hover_one_1'"
                                                :content="trackContent"
                                                :contentDetails="contentDetails"
                                                :playNowBtnTxt="i18n($attrs['label3'])"
                                                :viewTrailerBtnTxt="i18n($attrs['label13'])"
                                                :playAllBtnTxt="i18n($attrs['label19'])"
                                                :watchNowBtnTxt="i18n($attrs['label3'])"
                                                :isLogedIn="isLogedIn"
                                                :downloadBtnText="i18n($attrs['label21'])"
                                                :openBtnText="i18n($attrs['label22'])"
                                                :preOrderBtnTxt  = "i18n($attrs['label23'])"
                                                :contentPreorderStatusMap = "contentPreorderStatusMap" 
                                                @playAudioContent="playAudioContent" 
                                                :fromAdminPlaylist="true"
                                            />
                                        </div>
                                    </td>
                                    <td>
                                        <img  loading="lazy" v-if="trackContent.posters.website !== null && trackContent.posters.website[0].file_url !== ''" :src="trackContent.posters.website[0].file_url" />
                                        <img  loading="lazy" v-if="trackContent.posters.website === null  || trackContent.posters.website[0].file_url === ''" :src="contentDetails.no_image_available_url" />

                                    </td>
                                    <td>
                                        {{trackContent.content_name}}
                                        <!--<p class="truncate-text lc-one">{{trackContent.content_name}}</p>-->
                                        <!--<span>John Coltrane</span>-->
                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        {{timeFormating(trackContent?.audio_details?.duration)}}
                                    </td>
                                    <td align="right">
                                        <div class="dropdown">
                                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"/>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <!--<a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-step-forward"/> Play Next </a>-->
                                                <a class="dropdown-item callByAjax" @click="addToQueue(trackContent.content_uuid)" href="javascript:void(0);">
                                                    <i class="fas fa-file-import"/>{{i18n('Add to Queue')}}</a>
                                                <!-- <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-plus"/>Add to Playlist</a>
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-share-alt"/> {{i18n('Share')}}</a>
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-download"/> Download</a>-->
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr  v-if="isSeeMoreClicked && i>5">
                                    <td>
                                        <div class="dsn-play-div">
                                            <span class="sn-digit px-0">
                                                {{i+1}}
                                            </span>
                                            <content_hover_one
                                                :id="$attrs['id'] +'_content_hover_one_1'"
                                                :content="trackContent"
                                                :contentDetails="contentDetails"
                                                :playNowBtnTxt="i18n($attrs['label3'])"
                                                :viewTrailerBtnTxt="i18n($attrs['label13'])"
                                                :playAllBtnTxt="i18n($attrs['label19'])"
                                                :watchNowBtnTxt="i18n($attrs['label3'])"
                                                :isLogedIn="isLogedIn"
                                                :downloadBtnText="i18n($attrs['label21'])"
                                                :openBtnText="i18n($attrs['label22'])"
                                                :preOrderBtnTxt  = "i18n($attrs['label23'])"
                                                :contentPreorderStatusMap = "contentPreorderStatusMap" 
                                                @playAudioContent="playAudioContent" 
                                                :fromAdminPlaylist="true"
                                            />
                                        </div>
                                    </td>
                                    <td>
                                        <img loading="lazy"  v-if="trackContent.posters.website !== null && trackContent.posters.website[0].file_url !== ''" :src="trackContent.posters.website[0].file_url" />
                                        <img loading="lazy" v-if="trackContent.posters.website === null  || trackContent.posters.website[0].file_url === ''" :src="contentDetails.no_image_available_url" />
                                    </td>
                                    <td>
                                        {{trackContent.content_name}}
                                        <!--<p class="truncate-text lc-one">{{trackContent.content_name}}</p>-->
                                        <!--<span>John Coltrane</span>-->
                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        {{timeFormating(trackContent?.audio_details?.duration)}}
                                    </td>
                                    <td align="right">
                                        <div class="dropdown">
                                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"/>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <!--<a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-step-forward"/> Play Next </a>-->
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);" @click="addToQueue(trackContent.content_uuid)">
                                                    <i class="fas fa-file-import"/>{{i18n('Add to Queue')}}</a>
                                                <!--<a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-plus"/>Add to Playlist</a>
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-share-alt"/> {{i18n('Share')}}</a>
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-download"/> Download</a>-->
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                </template>
                                <tr v-if="contentDetails?.playlist_content_list?.length>6 && !isSeeMoreClicked">
                                    <td>&nbsp;</td>
                                    <td colspan="5">
                                        <p class="pl-0">
                                            <a href="javascript:void(0);" @click="seeMoreLessClicked(true)" class="seemore callByAjax">{{i18n('See More')}}</a>
                                        </p>
                                    </td>
                                </tr>
                                <tr v-if="contentDetails?.playlist_content_list?.length>6 && isSeeMoreClicked">
                                    <td>&nbsp;</td>
                                    <td colspan="5">
                                        <p class="pl-0">
                                            <a href="javascript:void(0);" @click="seeMoreLessClicked(false)" class="seemore callByAjax">{{i18n('See Less')}}</a>
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" @queueEmit="setQueueEmit" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :playlistId="(contentUuidAudio !== contentDetails?.content_uuid) ? contentDetails.content_uuid : ''" />
</vd-component>`
}

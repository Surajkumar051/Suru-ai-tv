let { categorizedPermalink, getPlaylistDetailsForPlaylistPage, isAuthorizedContent} = await import(window.importAssetJs('js/webservices.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { getBaseUrl, getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { owlCarousal } = await import(window.importLocalJs('js/customcarousel.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { SET_CURRENT_CONTENT_SELECTION_DATA, TOGGLE_CONTENT_PURCHASE_MODAL,GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper = await import(window.importAssetJs('js/content-helper.js'));
const { mapState, mapActions } = Vuex;
export default {
    name: "playlist_details_five",
    components: {
        audio_player_one,
        content_hover_six,
        content_title_one,
    },
    data() {
        return {
            accessToken: localStorage.getItem("end_user_access_token") == null ? localStorage.getItem("access_token") : localStorage.getItem("end_user_access_token"),//108894
            contentPermalink: permalink, //window.location.pathname.toString().split("/")[2],
            contentParentUuid: "",
            contentDetails: Object,
            isSeeMoreClicked: false,
            contentUuidAudio: "",
            isAudioPlay: false,
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isLogedIn: localStorage.getItem("isloggedin"),
            rootUrl: getRootUrl(),
            userList: [],
            optNo: 0,
        };
    },
    watch: {
        optNo(optNo) {},
    },
    updated() {
        owlCarousal();
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    beforeCreate() {},
    mounted() {
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.optNo = 0;
        if (this.contentPermalink) {
					JsLoadingOverlay.show();
            categorizedPermalink(this.contentPermalink).then((res) => {
                if (res.data.code == 200) {
                    let findContentParentIndex =
                        res.data.data.contentList.content_list.findIndex(
                            (content) => {
                                if (
                                    (content.permalink_type == "content" ||
                                        content.is_playlist == 1) &&
                                    content.content_permalink ==
                                        this.contentPermalink
                                )
                                    return true;
                                else return false;
                            }
                        );
                    if (
                        findContentParentIndex > -1 &&
                        res.data.data.contentList.content_list[
                            findContentParentIndex
                        ].is_playlist == 1
                    ) {
                        this.contentParentUuid =
                            res.data.data.contentList.content_list[
                                findContentParentIndex
                            ].content_uuid;
                        this.getPlaylistDetails();
                    }
                } else {
                    window.location.href = "/404";
                }
            });
        }
    },
    methods: {
        getBaseUrl,
        getRootUrl,
        i18n,
        playAudioContent(content_detail) {
            // console.log('content_detail', content_detail);
            // console.log('contentDetails-----------------', this.contentDetails);
            this.reloadOnUpdateLifeCycle = false;
            this.contentUuidAudio = content_detail.content_uuid;
            this.isFreeContent = content_detail.is_free_content;
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        showGridListView(optNum) {
            this.optNo = optNum;
        },
        getPlaylistDetails() {
            getPlaylistDetailsForPlaylistPage(this.contentParentUuid).then(
                (res) => {
                    if (
                        res.data.code == 200 &&
                        res.data.data !== null &&
                        res.data.data.contentList.content_list?.length > 0
                    ) {
											JsLoadingOverlay.hide();
                        this.contentDetails =
                            res.data.data.contentList.content_list[0];
                        contentHelper.getPartnerAndUserUuids(
                            res.data.data.contentList.content_list[0]
                                .playlist_content_list,
                            this.userList
                        );
                    }
                }
            );
        },
        seeMoreLessClicked(status) {
            this.isSeeMoreClicked = status;
        },
        async addToQueue(contentUuid) {
            // JsLoadingOverlay.show();
            if (
                window.audioQueueObj &&
                Object.keys(window.audioQueueObj).length > 0
            ) {
                const res = await isAuthorizedContent(contentUuid);
                if (res.data.code == 200) {
                    if (res.data.data.isAuthorized.is_content_authorized) {
                        let unique_id = contentUuid;
                        let token = this.accessToken; // 108894
                        let queue_config = {};
                        let queue_header = {
                            Authorization:
                               "Bearer " + token,// 108894
                        };
                        let queue_body = {
                            unique_id: unique_id,
                            domain: this.enduserURL,
                        };
                        queue_config.add_to_queue_url =
                            getBaseUrl() + "player/add-to-queue";
                        queue_config.queue_header = queue_header;
                        queue_config.queue_body = queue_body;
                        window.audioQueueObj._loadIntoQueue(queue_config);
                    } else {
                        this.$store.dispatch(
                            SET_CURRENT_CONTENT_SELECTION_DATA,
                            {
                                content_uuid: this.contentUuid,
                                monetization_methods:
                                    res.data.data.isAuthorized
                                        .monetization_details_list[0]
                                        .monetization_methods,
                            }
                        );
                        this.$store.dispatch(
                            TOGGLE_CONTENT_PURCHASE_MODAL,
                            true
                        );
                    }
                }
            } else {
                this.contentUuidAudio = contentUuid;
                this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
                this.isAudioPlay = true;
            }
        },
        timeFormating(duration) {
            let durationToShow = "";
            if (duration != undefined) {
                let timeElements = duration.split(":");
                if (timeElements.length == 3) {
                    durationToShow =
                        Number(Number(timeElements[0] * 60) + timeElements[1]) +
                        ":" +
                        timeElements[2];
                } else if (timeElements.length == 2) {
                    durationToShow = timeElements[0] + ":" + timeElements[1];
                }
            }
            return durationToShow;
        },
    },
    template: `
    <vd-component class="vd playlist-details-five" type="playlist-details-five" >
    <section class="season-content list-grid-icon pt-0 m-top-44" v-if="contentDetails.is_playlist==1 && contentDetails.content_asset_type==2">
        <div class="container-fluid plr-88">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <div class="season-heading no-border">                
                <ul>
                    <li>
						<a v-bind:class="optNo == 0 ? 'active callByAjax': 'callByAjax'" @click="showGridListView(0)">
							<i vd-node='icon' class="fa fa-th-large"/>
						</a>
					</li>
					<li>
						<a v-bind:class="optNo == 1 ? 'active callByAjax': 'callByAjax'" @click="showGridListView(1)">
							<i vd-node='icon' class="fa fa-th-list"/>
						</a>
					</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
    </section>
    <template v-if="optNo == 0">
        <section class="product-listing custom-prevNext-btn recommended-music pt-0">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 plr-88">
                        <div class="contect-listing">
                            <h2 class="sub-heading white-color"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></h2>
                            <div class="owl-product owl-carousel owl-theme owl-loaded owl-drag">
                                <div class="item" v-for="(trackContent,i) in contentDetails?.playlist_content_list" :key="i">
                                    <div class="picture">
                                        <div class="freeContent-tag" v-if="trackContent?.is_free_content">
                                            <span><vd-component-param type="label20" v-html="i18n($attrs['label20'])"></vd-component-param></span>
                                        </div>
                                        <div class="mrContent-tag" v-if="trackContent?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                            <span>{{maturity_rating?.maturity_rating_list[trackContent?.maturity_rating]}}</span>
                                        </div>
                                        <content_hover_six
                                            :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                            :content="trackContent"
                                            :playNowBtnTxt="$attrs['label3']"
                                            :viewTrailerBtnTxt="$attrs['label13']"
                                            :playAllBtnTxt="$attrs['label19']"
                                            :watchNowBtnTxt="$attrs['label3']"
                                            :isLogedIn="isLogedIn"
                                            :downloadBtnText="i18n($attrs['label21'])"
                                            :openBtnText="i18n($attrs['label22'])"
                                            @playAudioContent="playAudioContent"
                                        /> 
                                        <img class="w-216" loading="lazy" v-if="trackContent.posters.website !== null && trackContent.posters.website[0].file_url !== ''" :src="trackContent.posters.website[0].file_url" />
                                        <img class="w-216" loading="lazy" v-if="trackContent.posters.website === null  || trackContent.posters.website[0].file_url === ''" :src="contentDetails.no_image_available_url" />   
                                    </div>
                                    <!--<div class="data">
                                        <a>
                                            <span>{{trackContent.content_name}}</span>
                                        </a>
                                    </div>-->
                                    <content_title_one :id="$attrs['id'] +'_content_title_one_1'"  :content="trackContent"
                                        :userList="userList" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>                            
    </template>

<template v-if="optNo == 1">
    <section class="season-content tracks pt-0 mb-10">
        <div class="container-fluid plr-88">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="table-responsive">
                        <table class="table">
                            <colgroup>
                                <col class="one-table"/>
                                <col class="two-table"/>
                                <col class="three-table"/>
                                <col class="four-table"/>
                               
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>#</th>
                                    <th class="pl-0 pr-9">&nbsp;</th>
                                    <th class="pl-0"><vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param></th>
                                    <th class="pl-0">&nbsp;</th>
                                    <th class="pr-35">L.</th>
                                </tr>
                            <template v-for="(trackContent,i) in contentDetails?.playlist_content_list" :key="i">
                                <tr  v-if="i<=5">
                                    <td class="icon-col fw-500">
                                        <div class="serials-no">{{i+1}}</div>
                                        <div class="symplay-icons">
                                            <content_hover_six
                                            :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                            :content="trackContent"
                                            :playNowBtnTxt="$attrs['label3']"
                                            :viewTrailerBtnTxt="$attrs['label13']"
                                            :playAllBtnTxt="$attrs['label19']"
                                            :watchNowBtnTxt="$attrs['label3']"
                                            :isLogedIn="isLogedIn"
                                            :downloadBtnText="i18n($attrs['label21'])"
                                            :openBtnText="i18n($attrs['label22'])"
                                            @playAudioContent="playAudioContent"
											:contentDetails="contentDetails"

                                            />
                                        </div>
                                    </td>
                                    <td class="pl-0 pr-9">
                                        <img  loading="lazy" v-if="trackContent.posters.website !== null && trackContent.posters.website[0].file_url !== ''" :src="trackContent.posters.website[0].file_url" />
                                        <img  loading="lazy" v-if="trackContent.posters.website === null  || trackContent.posters.website[0].file_url === ''" :src="contentDetails.no_image_available_url" />
                                    </td>
                                    <td class="pl-0">
                                        {{trackContent.content_name}}
                                    </td>
                                    
                                    
                                    <td align="right">
                                        <div class="dropdown">
                                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"/>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item callByAjax" @click="addToQueue(trackContent.content_uuid)" href="javascript:void(0);">
                                                    <i class="fas fa-file-import"/>{{i18n('Add to Queue')}}</a>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="pl-0">
                                        <p>{{timeFormating(trackContent?.audio_details?.duration)}}</p>
                                    </td>
                                </tr>
                                <tr  v-if="isSeeMoreClicked && i>5">
                                    <td class="icon-col fw-500">
                                        <div class="serials-no">{{i+1}}</div>
                                        <div class="symplay-icons">
                                            <content_hover_six
                                            :id="$attrs['id'] +'_content_hover_six_6'" :root_url="rootUrl"
                                            :content="trackContent"
                                            :playNowBtnTxt="$attrs['label3']"
                                            :viewTrailerBtnTxt="$attrs['label13']"
                                            :playAllBtnTxt="$attrs['label19']"
                                            :watchNowBtnTxt="$attrs['label3']"
                                            :isLogedIn="isLogedIn"
                                            :downloadBtnText="i18n($attrs['label21'])"
                                            :openBtnText="i18n($attrs['label22'])"
                                            @playAudioContent="playAudioContent" 
                                            :contentDetails="contentDetails" 
                                            />
                                        </div>
                                    </td>
                                    <td class="pl-0 pr-9">
                                        <img loading="lazy" v-if="trackContent.posters.website !== null && trackContent.posters.website[0].file_url !== ''" :src="trackContent.posters.website[0].file_url" />
                                        <img loading="lazy" v-if="trackContent.posters.website === null  || trackContent.posters.website[0].file_url === ''" :src="contentDetails.no_image_available_url" />
                                    </td>
                                    <td class="pl-0">
                                        <p>{{trackContent.content_name}}</p>
                                    </td>
                                    <td align="right">
                                        <div class="dropdown">
                                            <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-h"/>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <!--<a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-step-forward"/> Play Next </a>-->
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);" @click="addToQueue(trackContent.content_uuid)">
                                                    <i class="fas fa-file-import"/>{{i18n('Add to Queue')}}</a>
                                                <!--<a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-plus"/>Add to Playlist</a>
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-share-alt"/> Share</a>
                                                <a class="dropdown-item callByAjax" href="javascript:void(0);">
                                                    <i class="fas fa-download"/> Download</a>-->
                                            </div>
                                        </div>
                                    </td>
                                    <td class="pl-0">
                                        <p>{{timeFormating(trackContent?.audio_details?.duration)}}</p>
                                    </td>
                                </tr>
                            </template>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="product-listing custom-prevNext-btn recommended-music pt-0" >
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 plr-88">
                     <button class="see-all-btn" v-if="contentDetails?.playlist_content_list?.length>6 && !isSeeMoreClicked" @click="seeMoreLessClicked(true)">{{i18n('Show All')}}</button>
                     <button class="see-all-btn" v-if="contentDetails?.playlist_content_list?.length>6 && isSeeMoreClicked" @click="seeMoreLessClicked(false)"></button>
                </div>
            </div>
        </div>
    </section>
</template>    
    <audio_player_one :id="$attrs['id'] +'_audio_player_one_1'" @queueEmit="setQueueEmit" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" :playlistId="(contentUuidAudio !== contentDetails?.content_uuid) ? contentDetails.content_uuid : ''" />
</vd-component>`,
};

let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let { getBaseUrl,getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let {
        fetchPartnerDetails,fetchEndUserDetails
    } = await import(window.importAssetJs('js/webservices.js'));

export default {
name: "user_banner_one",
components: {
        
},
data() {
        return {
                rootUrl: getRootUrl(),
                //userUuid: permalink,
                //userType: user_type,
                userUuid: window.location.pathname.toString().split("/")[2],//permalink,
                userType: window.location.pathname.toString().split("/")[1],//user_type,
                
                userDetails:{},
            
        };
},
created() {
        
},

props: {
        
},

mounted() {
        if (this.userType == 'partner') {
                fetchPartnerDetails(this.userUuid).then((res) => {
                        if (res.data.code == 200 && res.data.data.getUserDetails && res.data.data.getUserDetails.length>0) {
                                this.userDetails = res.data.data.getUserDetails[0];
                             //   this.userDetails.created_date = moment( this.userDetails.created_date).format('DD MMMM YYYY');
                             // console.log("userdetails---",this.userDetails);
                        }
                });
        }else if(this.userType == 'user'){
          fetchEndUserDetails(this.userUuid).then((res) => {
            if (res.data.code == 200 && res.data.data.getAllTypeUser && res.data.data.getAllTypeUser.users_list.length>0) {
                    this.userDetails = res.data.data.getAllTypeUser.users_list[0];
                    
                        }

                });
        }
        
},
methods: {
        getBaseUrl,
        getRootUrl,
		i18n,
},
computed: {
        
},
watch: {
        
},
template: `
    <vd-component class="vd user-banner-one" type="user-banner-one">
    <section class="banner-section">
  <div class="container-fluid">
      <div class="row">          
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0 m-0">
        <div class="banner-content profile-banner-content">
        <div class="owl-banner owl-carousel owl-theme custom-banner-nocast owl-loaded owl-drag">
          <div class="owl-stage-outer">
            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1245px;">
              <div class="owl-item active" style="width: 1243.93px; margin-right: 1px;">
                <div class="item">
                  <img v-if="userDetails?.cover_image_url && userDetails?.cover_image_url!==''" :src="userDetails?.cover_image_url" alt="banner"/>
                  <img v-else :src="rootUrl +'img/profile-banner-bg.jpg'" alt="banner"/>
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
          </div>
          <div v-if="userDetails.name != undefined" class="col-xs-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 banner-text-left custom-vpd-mobile profile-banner-data">
            <div class="banner-data p-0">
              <div class="custom-vpd-box m-0 justify-content-start">
                <div class="profile-pic">
                  <img v-if="userDetails?.profile_image_url===''" src="https://d3jc3vjm4t7lis.cloudfront.net/defaultContent/15759717215def6b895e137039129908/3D28C83C85544F0D9517DD2E7C7EEDAA/Image/cast/no_image_people.png" alt="profile picture" style="border-radius: 50% !important;">
                  <img v-else :src="userDetails?.profile_image_url" alt="profile picture" style="border-radius: 50% !important;">
                
                </div>
                <div class="comment-data">           
                  <h1 class="main-heading white-color">{{userDetails.name}}</h1>
                  
                  
                    <!--<ul class="button p-0">
                      <li class="watch-now"><a href="javascript:void(0);" class="follow-btn">Follow</a> <span class="follower-txt">2523 Followers</span></li>
                    </ul>  -->                    
                   
                </div>
              </div>
            </div>
        </div>
      </div>
  </div>        
</section>
    </vd-component>`,
  
};
    
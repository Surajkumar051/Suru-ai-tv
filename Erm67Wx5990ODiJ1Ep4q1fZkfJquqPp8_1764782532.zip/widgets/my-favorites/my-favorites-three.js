let {
    getFavoriteContents,
    makeContentFavorite,
} = await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "my_favorites_three",

    components: {
        content_hover_one,
        audio_player_one,
    },
    data() {
        return {
            favoriteContents: [],
            pageNo: 1,
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            isLogedIn: localStorage.getItem("isloggedin"),
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            
        };
    },
    beforeMount() {
        if(notLoggedinUser()){
            window.location.href = "/";
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        // this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        // this.$store.dispatch(GET_MATURITY_RATINGS);
        this.loadMore();
        this.getFavoriteContents(this.pageNo, false);
    },
    methods: {
        i18n,
        getFavoriteContents(page, onScroll) {
            if (this.isNextPageCallReqd) {
                (this.isNextPageCallReqd = false), JsLoadingOverlay.show();
                getFavoriteContents(page).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.favouriteContentList
                            .content_favourite_list
                    ) {
                        this.favoriteContents =
                            res.data.data.favouriteContentList.content_favourite_list;
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.favouriteContentList
                            .content_favourite_list
                    ) {
                        this.favoriteContents.push(
                            ...res.data.data.favouriteContentList
                                .content_favourite_list
                        );
                    }
                    if (!onScroll && page == 1 && res.data.status == "FAILED") {
                        this.favoriteContents = [];
                    }

                    if (
                        res.data.code == 200 &&
                        this.favoriteContents?.length <
                            res.data.data.favouriteContentList.page_info
                                .total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.favoriteContents == null ||
                        this.favoriteContents?.length <= 0
                    ) {
                        this.noRecordMsgShow = true;
                    }
                });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getFavoriteContents(this.pageNo, true);
                }
            };
        },

        favouriteEvent(contentDetails) {
            const param = {
                app_token: ":app_token",
                product_key: ":product_key",
                store_key: ":store_key",
                end_user_uuid: ":me",
                content_uuid: contentDetails.content_uuid,
                is_favourite: 0, // only unfavorite is possible from this page
                profile_uuid:":profile_uuid"
            };
            makeContentFavorite(param).then((res) => {
                this.pageNo = 1;
                this.isNextPageCallReqd = true;
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    this.getFavoriteContents(this.pageNo, false);
                }
            });
        },
        playAudioContent(content_detail){
            this.contentUuidAudio = content_detail.content_uuid;//ER-107177
            this.isFreeContent = content_detail.is_free_content; //ER-107177
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template:`

<vd-component class="vd my-favourites-three season-content notification-area" type="my-favourites-three">
<div class="container-fluid max">
    <!--Headind Section Start Here-->
    <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" >
                    <h1 class="dashboard-heading white-color mbottom-20 mt-5">
                        <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                    </h1>
            </div>
    </div>
    <div class="row">
            <!--Loop Section Here-->
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-3" v-if="favoriteContents?.length" v-for="(content,i) in favoriteContents" :key="i">
            
            <div class="col-md-12">
                <div class="wishlist-area no-slide border-bottom overflow-hidden">
                        <div class="">
                            <div class="">
                                <div class="single-wishlist">
                                    <div class="image-preview">
                                    <div class="freeContent-tag" v-if="content.content_details?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="content?.content_details?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[content?.content_details?.maturity_rating]}}</span>
                                    </div>
                                    <div :class="(content.content_details.content_asset_type == 2 && content.content_details.is_playlist!=1)?'icons-apply-audio d-none':'icons-apply d-none'">
                                        <img v-if="content.content_details.is_playlist==0 && content.content_details.content_asset_type == 1" :src="rootUrl + 'img/video-icons.png'"/>
                                        <img v-if="content.content_details.is_playlist==0 && content.content_details.content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'"/>
                                        <img v-if="content.content_details.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                        <img v-if="content.content_details.is_playlist==0 && content.content_details.content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                    </div>
                                    <img loading="lazy" class="w-100" v-if="content.content_details.posters.website !== null && content.content_details.posters.website[0].file_url !== ''" :src="content.content_details.posters.website[0].file_url"/>
                                    <img loading="lazy" class="w-100" v-if="content.content_details.posters.website === null  || content.content_details.posters.website[0].file_url === ''" :src="content.content_details.no_image_available_url"/>
                                    </div>
                                    <div class="whitelist-overlay">
                                        <div class="row justify-content-end gx-0 h-100">
                                            <div class="col-6 align-self-start">
                                                <span class="d-block text-end">
                                                    <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M7.94668e-08 5.39995C-0.000248434 3.95029 0.582385 2.5614 1.61681 1.54578C2.65124 0.530159 4.05058 -0.026895 5.5 -4.93311e-05C7.21732 -0.00916934 8.85599 0.719125 10 1.99995C11.144 0.719125 12.7827 -0.00916934 14.5 -4.93311e-05C15.9494 -0.026895 17.3488 0.530159 18.3832 1.54578C19.4176 2.5614 20.0002 3.95029 20 5.39995C20 10.756 13.621 14.8 10 18C6.387 14.773 7.94668e-08 10.76 7.94668e-08 5.39995Z" fill="white"/>
                                                    </svg>                                                
                                                </span>
                                            </div>
                                            <div class="col-12 align-self-end px-0">
                                                <div class="row gx-0 justify-content-between align-items-center ">
                                                    <div class="col-12 d-none">
                                                        <span class="price">$400.00</span>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="course-info">
                                                            {{content.content_details.content_name}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row gx-0 justify-content-between align-items-center d-none">
                                                    <div class="col-auto">
                                                        <span class="rating">
                                                            <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M5.96831 1.90832C6.15173 1.53673 6.6816 1.53673 6.86502 1.90832L7.97419 4.15538C8.04696 4.3028 8.18756 4.40503 8.35023 4.42881L10.8314 4.79148C11.2414 4.8514 11.4048 5.35532 11.108 5.6444L9.31339 7.39234C9.19546 7.50721 9.14163 7.67277 9.16946 7.83504L9.59288 10.3038C9.66294 10.7123 9.23417 11.0238 8.86735 10.8309L6.64939 9.66447C6.5037 9.58785 6.32963 9.58785 6.18394 9.66447L3.96598 10.8309C3.59917 11.0238 3.17039 10.7123 3.24045 10.3038L3.66388 7.83504C3.69171 7.67277 3.63788 7.50721 3.51994 7.39234L1.72534 5.6444C1.42854 5.35532 1.59193 4.8514 2.00189 4.79148L4.4831 4.42881C4.64578 4.40503 4.78637 4.3028 4.85914 4.15538L5.96831 1.90832Z" fill="#FFC960"></path>
                                                            </svg>
                                                            4.5
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-auto">
                                                <a :href="'/content/'+content.content_details.content_permalink" class="details-btn callByAjax" style="color: #fdfdff;">
                                                    View Detail
                                                </a>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Loop Section Here-->
            <template v-else>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="noRecordMsgShow">
                            <div class="w-100 text-center white-color">
                                 <h4>{{i18n('You have not made any content favourite yet!')}}</h4>
                            </div>
                        </div>
            </template>
    </div>
    </div>
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio"/>
</vd-component>
    `,
};
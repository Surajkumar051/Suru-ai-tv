let {
    getFavoriteContents,
    makeContentFavorite,
} = await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_two}=await import(window.importLocalJs('widgets/content-hover/content-hover-two.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "my_favorites_two",
    components: {
        content_hover_two,
        audio_player_one,
        content_purchase_two: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-two.js'))),
        content_title_one,
    },
    data() {
        return {
            favoriteContents: [],
            pageNo: 1,
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            isLogedIn: localStorage.getItem("isloggedin"),
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            userList:[],
            isFavComponent: true,
            contentPreorderStatusMap:  new Map(),

        };
    },
    beforeMount() {
        if(notLoggedinUser()){
            window.location.href = "/";
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.loadMore();
        this.getFavoriteContents(this.pageNo, false);
    },
    methods: {
        i18n,
        getFavoriteContents(page, onScroll) {
            if (this.isNextPageCallReqd) {
                (this.isNextPageCallReqd = false), JsLoadingOverlay.show();
                getFavoriteContents(page).then((res) => {
                    JsLoadingOverlay.hide();
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.favouriteContentList
                            .content_favourite_list
                    ) {
                        this.favoriteContents =
                            res.data.data.favouriteContentList.content_favourite_list;
                        let contents = [];
                        this.favoriteContents.forEach(element => {
                            contents.push(element.content_details);
                        });
                        contentHelper.getPartnerAndUserUuids(contents,this.userList);
                        const contentUuids = contents.map(item => item.content_uuid);
				        contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.favouriteContentList
                            .content_favourite_list
                    ) {
                        this.favoriteContents.push(
                            ...res.data.data.favouriteContentList
                                .content_favourite_list
                        );
                        let contents = [];
                        res.data.data.favouriteContentList
                            .content_favourite_list.forEach(element => {
                                contents.push(element.content_details);
                            });
                        contentHelper.getPartnerAndUserUuids(contents,this.userList);
                        const contentUuids = contents.map(item => item.content_uuid);
				        contentHelper.getContentsPreorderStatus(contentUuids,this.contentPreorderStatusMap);

                    }
                    if (!onScroll && page == 1 && res.data.status == "FAILED") {
                        this.favoriteContents = [];
                    }

                    if (
                        res.data.code == 200 &&
                        this.favoriteContents?.length <
                        res.data.data.favouriteContentList.page_info
                            .total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.favoriteContents == null ||
                        this.favoriteContents?.length <= 0
                    ) {
                        this.noRecordMsgShow = true;
                    }
                });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                    document.documentElement.clientHeight +
                    20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getFavoriteContents(this.pageNo, true);
                }
            };
        },

        favouriteEvent(contentDetails) {
            const param = {
                app_token: ":app_token",
                product_key: ":product_key",
                store_key: ":store_key",
                end_user_uuid: ":me",
                content_uuid: contentDetails.content_uuid,
                is_favourite: 0, // only unfavorite is possible from this page
                profile_uuid:":profile_uuid"
            };
            makeContentFavorite(param).then((res) => {
                this.pageNo = 1;
                this.isNextPageCallReqd = true;
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    this.getFavoriteContents(this.pageNo, false);
                }
            });
        },
        playAudioContent(content_detail){
            this.contentUuidAudio = content_detail.content_uuid;//ER-107177
            this.isFreeContent = content_detail.is_free_content; //ER-107177
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        reloadComponentAudio(content_detail){
            this.playAudioContent(content_detail.content_uuid);
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),
    },
    template: `
        <vd-component class="vd my-favourites-two season-content" type="my-favourites-two">
            <content_purchase_two  :id="$attrs['id'] +'_content_purchase_two_2'" />
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" >
                        <h1 class="dashboard-heading white-color mbottom-20">
                            <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                        </h1>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="favoriteContents?.length"  >
                    <div class="raiden-product-slider videoallseasion-grids">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4" v-for="(content,i) in favoriteContents" :key="i">
                                <div class="product-slider-container" >
                                    <div class="product-slider-image">
                                        <div class="freeContent-tag" v-if="content.content_details?.is_free_content">
                                            <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                                        </div>
                                        <div class="mrContent-tag" v-if="content?.content_details?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                            <span>{{maturity_rating?.maturity_rating_list[content?.content_details?.maturity_rating]}}</span>
                                        </div>
                                        <div class="icons-apply"  :class="(content.content_details.content_asset_type == 2 && content.content_details.is_playlist!=1)?'icons-apply-audio':'icons-apply'">
                                            <img v-if="content.content_details.is_playlist==0 && content.content_details.content_asset_type == 1 && (content.content_details.video_details == null || content.content_details.video_details?.is_live_feed == false)" :src="rootUrl + 'img/video-icons.png'"/>
                                            <img v-if="content.content_details.is_playlist==0 && content.content_details.content_asset_type == 2" :src="rootUrl + 'img/audio-icon.png'"/>
                                            <img v-if="content.content_details.is_playlist==1" :src="rootUrl + 'img/playlist-icon.png'"/>
                                            <img v-if="content.content_details.is_playlist==0 && content.content_details.content_asset_type == 6" :src="rootUrl + 'img/file-icon.png'"/>
                                            <svg v-if = "content.content_details.is_playlist==0 && content.content_details.content_asset_type == 1 && content.content_details.video_details?.is_live_feed == true"
                                                xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                <path d="M12.2 4.33333C12.2 3.598 11.5721 3 10.8 3H2.4C1.6279 3 1 3.598 1 4.33333V11C1 11.7353 1.6279 12.3333 2.4 12.3333H10.8C11.5721 12.3333 12.2 11.7353 12.2 11V8.778L15 11V4.33333L12.2 6.55533V4.33333Z" fill="#7B8794"></path>
                                                <circle cx="6.64062" cy="7.65234" r="2.25" fill="white" fill-opacity="0.6"></circle>
                                            </svg>
                                        </div>
                                       
                                       <img loading="lazy" class="w-100" v-if="content.content_details.posters.website !== null && content.content_details.posters.website[0].file_url !== ''" :src="content.content_details.posters.website[0].file_url"/>
                                        <img loading="lazy" class="w-100" v-if="content.content_details.posters.website === null  || content.content_details.posters.website[0].file_url === ''" :src="content.content_details.no_image_available_url"/>
                                          <!--Button Show on Hover start Here-->
                                        <content_hover_two
                                            :id="$attrs['id'] +'_content_hover_two_2'" 
                                            :content="content.content_details" 
                                            :playNowBtnTxt="$attrs['label2']"
                                            :viewTrailerBtnTxt="$attrs['label3']"
                                            :playAllBtnTxt="$attrs['label4']"
                                            :watchNowBtnTxt="$attrs['label5']"
                                            :isLogedIn="isLogedIn"
                                            @playAudioContent="playAudioContent"
                                            :downloadBtnText="i18n($attrs['label7'])"
                                            :openBtnText="i18n($attrs['label8'])"
                                             :preOrderBtnTxt  = "i18n($attrs['label9'])"
									        :contentPreorderStatusMap = "contentPreorderStatusMap"

                                        />
                                        <div class="product-like-option">
                                            <div class="like like-heart">
                                                <div class="ulike ulike_is_not_liked">
                                                        <button type="button" class="ulike_btn dislike-image" @click="favouriteEvent(content.content_details)"></button>
                                                </div>
                                            </div>
                                        </div>    
                                    </div>
                                    <div class="gen-info-contain">
                                        <div class="gen-movie-info">
                                                <h3>
                                                    <a class="callByAjax" v-if="content.content_details?.is_playlist==0" :href="'/content/'+content.content_details.content_permalink" >
                                                        <span v-if="content.content_details?.content_name">{{content.content_details?.content_name}} </span>
                                                    </a>
                                                    <a class="callByAjax" v-else-if="content.content_details?.is_playlist==1" :href="'/playlist/'+content.content_details.content_permalink">
                                                        <span v-if="content.content_details?.content_name">{{content.content_details?.content_name}} </span>
                                                    </a>
                                                </h3>
                                                
                                        
                                        </div>
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
               <template v-else>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="noRecordMsgShow">
                        <div class="w-100 text-center white-color">
                             <h4>{{i18n('You have not made any content favourite yet!')}}</h4>
                        </div>
                    </div>
                </template> 
            </div>
            <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" @reloadComponentAudio="reloadComponentAudio"/>
        </vd-component>`,
};

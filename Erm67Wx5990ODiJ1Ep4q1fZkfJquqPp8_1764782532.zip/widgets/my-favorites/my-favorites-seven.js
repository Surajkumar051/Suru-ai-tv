let {
    getFavoriteContents,
    makeContentFavorite,
} = await import(window.importAssetJs('js/webservices.js'));
let { default: content_hover_seven } = await import(window.importLocalJs('widgets/content-hover/content-hover-seven.js'));
let { default: audio_player_one } = await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING, GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let { default: content_title_six } = await import(window.importLocalJs('widgets/content-title/content-title-six.js'));
let contentHelper = await import(window.importAssetJs('js/content-helper.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
export default {
    name: "my_favorites_seven",

    components: {
        content_hover_seven,
        audio_player_one,
        content_purchase_six: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-six.js'))),
        content_title_six,
    },
    data() {
        return {
            favoriteContents: [],
            pageNo: 1,
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            isLogedIn: localStorage.getItem("isloggedin"),
            contentUuidAudio: "",
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            userList: [],
            isFavComponent: true,


        };
    },
    beforeMount() {
        if (notLoggedinUser()) {
            window.location.href = "/";
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
        this.loadMore();
        this.getFavoriteContents(this.pageNo, false);
    },
    methods: {
        i18n,
        getRootUrl,
        getFavoriteContents(page, onScroll) {
            if (this.isNextPageCallReqd) {
                (this.isNextPageCallReqd = false),
                    // JsLoadingOverlay.show();
                    getFavoriteContents(page).then((res) => {
                        // JsLoadingOverlay.hide();
                        if (
                            !onScroll &&
                            res.data.code == 200 &&
                            res.data.data.favouriteContentList
                                .content_favourite_list
                        ) {
                            this.favoriteContents =
                                res.data.data.favouriteContentList.content_favourite_list;
                        } else if (
                            onScroll &&
                            res.data.code == 200 &&
                            res.data.data.favouriteContentList
                                .content_favourite_list
                        ) {
                            this.favoriteContents.push(
                                ...res.data.data.favouriteContentList
                                    .content_favourite_list
                            );
                        }
                        if (
                            !onScroll &&
                            page == 1 &&
                            res.data.status == "FAILED"
                        ) {
                            this.favoriteContents = [];
                        }

                        if (
                            res.data.code == 200 &&
                            this.favoriteContents?.length <
                            res.data.data.favouriteContentList.page_info
                                .total_count
                        ) {
                            this.isNextPageCallReqd = true;
                        }
                        if (
                            this.favoriteContents == null ||
                            this.favoriteContents?.length <= 0
                        ) {
                            this.noRecordMsgShow = true;
                        }
                    });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                    document.documentElement.clientHeight +
                    20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getFavoriteContents(this.pageNo, true);
                }
            };
        },

        favouriteEvent(contentDetails) {
            const param = {
                app_token: ":app_token",
                product_key: ":product_key",
                store_key: ":store_key",
                end_user_uuid: ":me",
                content_uuid: contentDetails.content_uuid,
                is_favourite: 0, // only unfavorite is possible from this page
                profile_uuid: ":profile_uuid"
            };
            makeContentFavorite(param).then((res) => {
                this.pageNo = 1;
                this.isNextPageCallReqd = true;
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    this.getFavoriteContents(this.pageNo, false);
                }
            });
        },
        playAudioContent(content_detail){
            this.contentUuidAudio = content_detail.content_uuid;//ER-107177
            this.isFreeContent = content_detail.is_free_content; //ER-107177
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        reloadComponentAudio(content_detail) {
            this.playAudioContent(content_detail); //ER-107177
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),
    },
    template: `
    <vd-component class="vd my-favourites-seven season-content" type="my-favourites-seven">
    <div class="dashboard-rightsection">
    <div class="page-nav page-nav2">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h2 class="mb-1">
                        <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                    </h2>
                </div>
            </div>
        </div>
    </div>

    <div class="slide-wrapper search-wrap-slide">
    <div class="container">
     
        <div class="row">

            <div class="col-md-4 col-lg-4 mb-3" v-if="favoriteContents?.length" v-for="(content,i) in favoriteContents" :key="i">
            
                <div class="slide-one">
                    <div class="slide-image">
                        <div class="freeContent-tag" v-if="content.content_details?.is_free_content">
                            <span><vd-component-param type="label6" v-html="i18n($attrs['label6'])"></vd-component-param></span>
                        </div>
                        <div class="mrContent-tag" v-if="content?.content_details?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                           <span>{{maturity_rating?.maturity_rating_list[content?.content_details?.maturity_rating]}}</span>
                        </div>
                        <img loading="lazy" class="img-fluid" v-if="content.content_details.posters.website !== null && content.content_details.posters.website[0].file_url !== ''" :src="content.content_details.posters.website[0].file_url"/>
                        <img loading="lazy" class="img-fluid" v-if="content.content_details.posters.website === null  || content.content_details.posters.website[0].file_url === ''" :src="content.content_details.no_image_available_url"/>
                        <content_hover_seven 
                            :id="$attrs['id'] +'_content_hover_seven_7'" 
                            :content="content.content_details" 
                            :playNowBtnTxt="i18n($attrs['label2'])"
                            :viewTrailerBtnTxt="i18n($attrs['label3'])"
                            :playAllBtnTxt="i18n($attrs['label4'])"
                            :watchNowBtnTxt="i18n($attrs['label5'])"
                            :isLogedIn="isLogedIn"
                            @playAudioContent="playAudioContent"
                            :downloadBtnText="i18n($attrs['label7'])"
                            :openBtnText="i18n($attrs['label8'])"
                        />
                    </div>
                    <div class="slide-content">
                        <content_title_six :id="$attrs['id'] +'_content_title_six_6'"  
                            :content="content.content_details" :userList="userList" :isFavouriteContent="isFavComponent"
                            @favourite="favouriteEvent"/>
                    </div>
                </div>

            </div>
            <div class="col-md-12 align-items-center justify-content-between mb-3" v-else>
                <div class="" v-if="noRecordMsgShow">
                    <div class="w-100 text-center">
                        <img :src="getRootUrl() +'img/no-result.gif'" alt="no result"
                            class="mw-100" />
                        <h2>
                            {{i18n('No Content Added yet !')}}
                        </h2>
                    </div>
                </div>
            </div>

        </div>

    </div>
    </div>
    </div>
    <content_purchase_six  :id="$attrs['id'] +'_content_purchase_six_6'" />
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" @reloadComponentAudio="reloadComponentAudio" :isFreeContent="isFreeContent"/>
    </vd-component>
    `,
};

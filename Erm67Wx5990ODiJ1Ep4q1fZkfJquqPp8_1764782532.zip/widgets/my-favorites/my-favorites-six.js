let { getFavoriteContents, makeContentFavorite } = await import(window.importAssetJs('js/webservices.js'));
let {default:content_hover_six}=await import(window.importLocalJs('widgets/content-hover/content-hover-six.js'));
let {default:audio_player_one}=await import(window.importLocalJs('widgets/audio-player/audio-player-one.js'));
let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getRootUrl}=await import(window.importAssetJs('js/web-service-url.js'));
let { notLoggedinUser } = await import(window.importAssetJs('js/main.js'));
let { GET_PARTNER_AND_USER_PROFILE_SETTING,GET_MATURITY_RATINGS } = await import(window.importAssetJs('js/configurations/actions.js'));
let {default:content_title_one}=await import(window.importLocalJs('widgets/content-title/content-title-one.js'));
let contentHelper=await import(window.importAssetJs('js/content-helper.js'));
const { defineAsyncComponent } = Vue;
const { mapState, mapActions } = Vuex;
let {owlCarousal}=await import(window.importAssetJs('js/customcarousel.js'));
export default {
    name: "my_favorites_six",

    components: {
        content_hover_six,
        audio_player_one,
        content_purchase_five: defineAsyncComponent(() => import(window.importLocalJs('widgets/content-purchase/content-purchase-five.js'))),
        content_title_one,
    },
    updated() {
        owlCarousal();
    },
    data() {
        return {
            favoriteContents: [],
            pageNo: 1,
            isNextPageCallReqd: true,
            noRecordMsgShow: false,
            isLogedIn: localStorage.getItem("isloggedin"),
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            rootUrl: getRootUrl(),
            userList:[],
            isFavComponent: true,
            content_asset_type:2
        };
    },
    beforeMount() {
        if(notLoggedinUser()){
            window.location.href = "/";
        }
    },
    mounted() {
        scrollLoad = true; //@ER: 74207
        this.loadMore();
        this.getFavoriteContents(this.pageNo, false, this.content_asset_type);
        this.$store.dispatch(GET_PARTNER_AND_USER_PROFILE_SETTING);
        this.$store.dispatch(GET_MATURITY_RATINGS);
    },
    // computed: {
    //     ...mapState({
    //         maturity_rating: (state) => state.maturity_rating,
    //     }),      
    // },
    methods: {
        i18n,
        getFavoriteContents(page, onScroll,contentAssettype) {
            if (this.isNextPageCallReqd) {
                this.isNextPageCallReqd = false
                getFavoriteContents(page,contentAssettype).then((res) => {
                    if (
                        !onScroll &&
                        res.data.code == 200 &&
                        res.data.data.favouriteContentList
                            .content_favourite_list
                    ) {
                        this.favoriteContents =
                            res.data.data.favouriteContentList.content_favourite_list;
                        let contents = [];
                        this.favoriteContents.forEach(element => {
                            contents.push(element.content_details);
                        });    
                        contentHelper.getPartnerAndUserUuids(contents,this.userList);
                    } else if (
                        onScroll &&
                        res.data.code == 200 &&
                        res.data.data.favouriteContentList
                            .content_favourite_list
                    ) {
                        this.favoriteContents.push(
                            ...res.data.data.favouriteContentList
                                .content_favourite_list
                        );
                        let contents = [];
                        res.data.data.favouriteContentList
                                .content_favourite_list.forEach(element => {
                            contents.push(element.content_details);
                        });    
                        contentHelper.getPartnerAndUserUuids(contents,this.userList);
                    }
                    if (!onScroll && page == 1 && res.data.status == "FAILED") {
                        this.favoriteContents = [];
                    }

                    if (
                        res.data.code == 200 &&
                        this.favoriteContents?.length <
                            res.data.data.favouriteContentList.page_info
                                .total_count
                    ) {
                        this.isNextPageCallReqd = true;
                    }
                    if (
                        this.favoriteContents == null ||
                        this.favoriteContents?.length <= 0
                    ) {
                        this.noRecordMsgShow = true;
                    }
                });
            }
        },
        loadMore() {
            window.onscroll = () => {
                //  let bottomOfChildDiv = $('#categoryContentList').height() < document.documentElement.scrollTop;
                let bottomOfWindow =
                    document.documentElement.scrollTop +
                        document.documentElement.clientHeight +
                        20 >=
                    document.documentElement.scrollHeight;
                //console.log((document.documentElement.scrollTop + document.documentElement.clientHeight)+"----"+document.documentElement.scrollHeight+"----"+bottomOfWindow+'-----'+this.isNextPageCallReqd);
                if (bottomOfWindow && this.isNextPageCallReqd && scrollLoad) {
                    this.pageNo++;
                    this.getFavoriteContents(this.pageNo, true,this.content_asset_type);
                }
            };
        },

        favouriteEvent(contentDetails) {
            const param = {
                app_token: ":app_token",
                product_key: ":product_key",
                store_key: ":store_key",
                end_user_uuid: ":me",
                content_uuid: contentDetails.content_uuid,
                is_favourite: 0, // only unfavorite is possible from this page
                profile_uuid:":profile_uuid"
            };
            makeContentFavorite(param).then((res) => {
                this.pageNo = 1;
                this.isNextPageCallReqd = true;
                if (res.data.code == 200 && res.data.status == "SUCCESS") {
                    this.getFavoriteContents(this.pageNo, false,this.content_asset_type);
                }
            });
        },
        playAudioContent(content_detail){
            this.contentUuidAudio = content_detail.content_uuid;//ER-107177
            this.isFreeContent = content_detail.is_free_content; //ER-107177
            this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            this.isAudioPlay = true;
        },
        reloadComponentAudio(content_detail){
            this.playAudioContent(content_detail); //ER-107177
        }
    },
    computed: {
        ...mapState({
            maturity_rating: (state) => state.maturity_rating,
        }),      
    },
    template: `

<vd-component class="vd my-favourites-six season-content" type="my-favourites-six">
    <content_purchase_five  :id="$attrs['id'] +'_content_purchase_five_5'" />
    <!--Headind Section Start Here-->
    <section class="season-content">
        <div class="container-fluid plr-88">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="episode-heading pb-40">
                        <h3 class="sub-heading white-color separate-page-heading">
                            <vd-component-param type="label1" v-html="i18n($attrs['label1'])"></vd-component-param>
                        </h3>
                    </div>
                </div>    
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 box-5" v-if="favoriteContents?.length" v-for="(content,i) in favoriteContents" :key="i">
                            <div class="tiles grid-hover fs-tiles">
                                <div class="picture">
                                    <div class="freeContent-tag" v-if="content.content_details?.is_free_content">
                                        <span><vd-component-param type="label6" v-html="i18n('Free')"></vd-component-param></span>
                                    </div>
                                    <div class="mrContent-tag" v-if="content?.content_details?.maturity_rating && maturity_rating?.maturity_rating_list != null">
                                        <span>{{maturity_rating?.maturity_rating_list[content?.content_details?.maturity_rating]}}</span>
                                    </div>
                                    <img loading="lazy" class="w-100" v-if="content.content_details.posters.website !== null && content.content_details.posters.website[0].file_url !== ''" :src="content.content_details.posters.website[0].file_url"/>
                                    <img loading="lazy" class="w-100" v-if="content.content_details.posters.website === null  || content.content_details.posters.website[0].file_url === ''" :src="content.content_details.no_image_available_url"/>
                                        <!--Button Show on Hover start Here-->
                                        <content_hover_six
                                            :id="$attrs['id'] +'_content_hover_six_6'" 
                                            :content="content.content_details"
                                            :playNowBtnTxt="i18n($attrs['label2'])"
                                            :viewTrailerBtnTxt="i18n($attrs['label3'])"
                                            :playAllBtnTxt="i18n($attrs['label4'])"
                                            :watchNowBtnTxt="i18n($attrs['label5'])"
                                            :isLogedIn="isLogedIn"
                                            @playAudioContent="playAudioContent"
                                            :downloadBtnText="i18n($attrs['label7'])"
                                            :openBtnText="i18n($attrs['label8'])"
                                        />
                                </div>
                                <div class="data">
                                    <a class="callByAjax data-a" v-if="content.content_details?.is_playlist==0" :href="'/content/'+content.content_details.content_permalink" >
                                            <span v-if="content.content_details?.content_name">{{content.content_details?.content_name}} </span>
                                    </a>
                                    <a class="callByAjax data-a" v-else-if="content.content_details?.is_playlist==1" :href="'/playlist/'+content.content_details.content_permalink">
                                            <span v-if="content.content_details?.content_name">{{content.content_details?.content_name}} </span>
                                    </a>
                                    <button class="fav-heart-btn" @click="favouriteEvent(content.content_details)">
                                        <i class="fa fa-heart fav-heart-icon liked"></i>
                                    </button>
                                </div>
                            </div>
                        </div>   
                        <template v-else>
                            <div v-else class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" v-if="noRecordMsgShow">
                                <div class="w-100 text-center white-color">
                                    <h4>{{i18n('You have not made any content favourite yet!')}}</h4>
                                </div>
                            </div>
                        </template>
                    </div> 
                </div>
            </div>
        </div>
    </section>    
    <audio_player_one  :id="$attrs['id'] +'_audio_player_one_1'" :key="resetAudioPlayer" :contentUuid="contentUuidAudio" v-if="isAudioPlay && contentUuidAudio" @reloadComponentAudio="reloadComponentAudio" :isFreeContent="isFreeContent"/>
</vd-component>
    `,
};

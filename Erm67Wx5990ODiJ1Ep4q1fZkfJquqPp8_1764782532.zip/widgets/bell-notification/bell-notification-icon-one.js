let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let { getConfigValue, getBellNotifications, readNotification } = await import(window.importAssetJs('js/webservices.js'));

export default {
    name: "bell_notification_icon_one",
    data() {
        return {
            is_enable_notification: false,
            notification_lists: [],
            unread_count: 0,
        }
    },
    props: {
        is_login: Boolean,
        label15: String,
        label16: String,
        label17: String,
    },
    methods: {
        i18n,
        openNP() {
            $(".overlay-np").addClass('open');
            $("#NotificationPanel").addClass('open');
            $("body").addClass('overflow-hidden');
            getBellNotifications().then((response) => {
                if (response?.data?.code == 200) {
                    this.notification_lists = response?.data?.data;
                    this.unread_count = response?.data?.total_unreads;
                    if (this.unread_count > 0) {
                        $('.notiCount').show();
                    }
                }
            })
        },
        closeNP() {
            $(".overlay-np").removeClass('open');
            $("#NotificationPanel").removeClass('open');
            $("body").removeClass('overflow-hidden');
        },
        formatHistory(timestamp) {
            var currentDateInTimezone = new Date();
            var currentDate = new Date(currentDateInTimezone.getUTCFullYear(), currentDateInTimezone.getUTCMonth(), currentDateInTimezone.getUTCDate(), currentDateInTimezone.getUTCHours(), currentDateInTimezone.getUTCMinutes(), currentDateInTimezone.getUTCSeconds());
            var historyDate = new Date(timestamp);
            var timeDifference = currentDate.getTime() - historyDate.getTime();
            var seconds = Math.floor(timeDifference / 1000);
            var minutes = Math.floor(seconds / 60);
            var hours = Math.floor(minutes / 60);
            var days = Math.floor(hours / 24);

            if (days > 0) {
                return days + (days === 1 ? " day ago" : " days ago");
            } else if (hours > 0) {
                return hours + (hours === 1 ? " hour ago" : " hours ago");
            } else if (minutes > 0) {
                return minutes + (minutes === 1 ? " minute ago" : " minutes ago");
            } else {
                return seconds + (seconds === 1 ? " second ago" : " seconds ago");
            }
        },
        readMessage(data) {
            if (data?.read_status) {
                if (data?.deep_link && Object.keys(data?.deep_link)?.length > 0) {
                    if (data?.deep_link?.is_playlist == 1) {
                        window.location.href = "/playlist/" + data?.deep_link?.content_permalink;
                        //ER 109149 start
                    } else if (data?.deep_link?.custom_url) {
                        let url = data?.deep_link?.custom_url || '';
                        if (url && !url.startsWith('https://')) {
                            url = 'https://' + url;
                        }
                        // Open the URL in a new tab
                        this.openNP();
                        window.open(url, '_blank');
                    } else {
                        //ER 109149 end   
                        window.location.href = "/content/" + data?.deep_link?.content_permalink;
                    }
                } else {
                    window.location.href = "/";
                }
            } else {
                const id = data.sent_push_notification_uuid;
                readNotification({
                    "push_notification_uuid": id,
                    "status": 1
                }).then((response) => {
                    $("#" + id).addClass("read");
                    this.unread_count = this.unread_count - 1;
                    if (data?.deep_link && Object.keys(data?.deep_link)?.length > 0) {
                        if (data?.deep_link?.is_playlist == 1) {
                            window.location.href = "/playlist/" + data?.deep_link?.content_permalink;
                            //ER 109149 start
                        } else if (data?.deep_link?.custom_url) {
                            let url = data?.deep_link?.custom_url || '';
                            if (url && !url.startsWith('https://')) {
                                url = 'https://' + url;
                            }
                            // Open the URL in a new tab
                            this.openNP();
                            window.open(url, '_blank');
                        } else {
                            //ER 109149 end    
                            window.location.href = "/content/" + data?.deep_link?.content_permalink;
                        }
                    } else {
                        window.location.href = "/";
                    }
                });
            }
        },
        goto(page) {
            window.location.href = page;
        }
    },
    async mounted() {
        if (this.is_login) {
            let notificationConfig = await getConfigValue({ "query": "{sections(code:\"notification_settings\"){section_uuid,code,comment,label,sequence,groups{group_uuid,code,comment,label,sequence,nodes(app_token:\":app_token\", product_key: \":product_key\", store_key: \":store_key\"){node_uuid,sequence,section_code,group_code,node_type,node_label,node_placeholder,node_code,node_value,node_comment,parent,options {option_uuid,config_node_uuid,option_value,option_label,sequence}}}}}" });
            if (notificationConfig?.data?.code == 200) {
                let is_enable = notificationConfig?.data?.data?.sections[0]?.groups[0]?.nodes[0]?.node_value
                this.is_enable_notification = (is_enable == '1') ? true : false;
            }
            if (this.is_enable_notification) {
                let notificationList = await getBellNotifications();
                if (notificationList?.data?.code == 200) {
                    this.notification_lists = notificationList?.data?.data;
                    this.unread_count = notificationList?.data?.total_unreads;
                }
            }
        }

    },
    template: `
    <vd-component class="vd" class="vd bell-notification-iocn-one" type="bell-notification-icon-one"  v-if="is_login && is_enable_notification" >
        <div class="nav-item">
            <a href="javascript:void(0)" class="d-flex align-items-center h-100 messageNotification position-relative cursor" @click="openNP">
                <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 8.25C18 6.6587 17.3679 5.13258 16.2426 4.00736C15.1174 2.88214 13.5913 2.25 12 2.25C10.4087 2.25 8.88258 2.88214 7.75736 4.00736C6.63214 5.13258 6 6.6587 6 8.25C6 15.25 3 17.25 3 17.25H21C21 17.25 18 15.25 18 8.25Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M13.7334 21.25C13.5576 21.5531 13.3053 21.8047 13.0017 21.9795C12.698 22.1544 12.3538 22.2465 12.0034 22.2465C11.6531 22.2465 11.3088 22.1544 11.0052 21.9795C10.7016 21.8047 10.4492 21.5531 10.2734 21.25" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span class="notiCount top-0" v-if="unread_count">{{unread_count}}</span>                                       
            </a>
            <div id="NotificationPanel" class="notification-panel" >
                <div class="np-header">
                    <div class="nph-text">
                        <vd-component-param type="label15" v-html="i18n(label15)"></vd-component-param>
                    </div>
                    <div class="nph-close">
                    <a href="javascript:void(0)" class="closeNP" @click="closeNP">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 4L4 12" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M4 4L12 12" stroke="white" stroke-width="1.33" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </a>
                    </div>
                </div>
                <div class="np-body" v-if="notification_lists.length">
                    <template v-for="data in notification_lists">
                        <div class="npb-lc" v-if="data.image && data.deep_link && !data.deep_link?.custom_url" @click="readMessage(data)">
                            <div class="npblc-mainContent">
                                <div class="npblc-img">
                                    <img class="npblci-img img-fluid" :src="data.image">
                                </div>
                                <div class="npblc-text">
                                    <div class="npblct-top" :id="data.sent_push_notification_uuid" :class="{'read' : (data.read_status == 1)}">
                                        <div class="npblctt-one">{{data.push_title}}</div>
                                        <div class="npblctt-two">{{data.push_content}}</div>
                                    </div>
                                    <div class="npblct-bottom">
                                        {{formatHistory(data.created_at)}}
                                    </div>
                                </div>
                            </div>
                            <div class="npblc-hoverContent" :style="'background-image: url('+data.image+');'">
                                <div class="npblchc-wn">
                                    <a v-if="data?.deep_link?.is_playlist" :href="'/playlist/'+data.deep_link.content_permalink"  class="watchNow">{{i18n('Watch Now')}}</a>
                                    <a v-else :href="'/content/'+data.deep_link.content_permalink"  class="watchNow">{{i18n('Watch Now')}}</a>
                                </div>
                            </div>
                        </div>
                        <div class="npb-lc" v-else-if="data.image && (!data.deep_link || data.deep_link?.custom_url)">
                            <div class="npblc-mainContent" @click="readMessage(data)">
                                <div class="npblc-img">
                                    <img class="npblci-img img-fluid" :src="data.image">
                                </div>
                                <div class="npblc-text">
                                    <div class="npblct-top" :id="data.sent_push_notification_uuid" :class="{'read' : (data.read_status == 1)}">
                                        <div class="npblctt-one">{{data.push_title}}</div>
                                        <div class="npblctt-two">{{data.push_content}}</div>
                                    </div>
                                    <div class="npblct-bottom">
                                        {{formatHistory(data.created_at)}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="npb-lc" v-else>
                            <div class="npblc-mainContent" @click="readMessage(data)">
                                <div class="npblc-text">
                                    <div class="npblct-top" :id="data.sent_push_notification_uuid" :class="{'read' : (data.read_status == 1)}">
                                        <div class="npblctt-one">{{data.push_title}}</div>
                                        <div class="npblctt-two">{{data.push_content}}</div>
                                    </div>
                                    <div class="npblct-bottom">
                                        {{formatHistory(data.created_at)}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="npb-hr">
                    </template>
                </div>
                <div class="np-footer" v-if="notification_lists.length">
                    <div class="npf-left">
                    </div>
                    <div class="npf-right">
                    <button class="primary-button update-btn" @click="goto('/notifications')">
                        <vd-component-param type="label16" v-html="i18n(label16)"></vd-component-param>
                    </button>
                    </div>
                </div>

                <div class="no-notifications" v-else>
                    <div class="nn-div">
                    <span class="nnd-svg">
                        <svg width="64" height="66" viewBox="0 0 64 66" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M48 22.3359C48 18.0925 46.3143 14.0228 43.3137 11.0222C40.3131 8.02165 36.2435 6.33594 32 6.33594C27.7565 6.33594 23.6869 8.02165 20.6863 11.0222C17.6857 14.0228 16 18.0925 16 22.3359C16 41.0026 8 46.3359 8 46.3359H56C56 46.3359 48 41.0026 48 22.3359Z"
                            stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path
                            d="M36.6095 57C36.1406 57.8082 35.4677 58.4791 34.6581 58.9454C33.8484 59.4118 32.9305 59.6572 31.9961 59.6572C31.0618 59.6572 30.1439 59.4118 29.3342 58.9454C28.5246 58.4791 27.8516 57.8082 27.3828 57"
                            stroke="#118BA6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M9 1L54 65" stroke="#118BA6" stroke-width="2" stroke-linecap="round" />
                        </svg>
                    </span>
                    <span class="nnd-text"><vd-component-param type="label17" v-html="i18n(label17)"></vd-component-param></span>
                    </div>
                </div>
            </div> 
        </div>  
    </vd-component>`,
};

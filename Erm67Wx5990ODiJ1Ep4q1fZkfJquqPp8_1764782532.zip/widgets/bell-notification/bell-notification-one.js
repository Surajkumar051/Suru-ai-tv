let {i18n}=await import(window.importAssetJs('js/i18n.js'));
let {getBellNotifications,readNotification } = await import(window.importAssetJs('js/webservices.js'));
// let { getBaseUrl } = await import(window.importAssetJs('js/web-service-url.js'));
export default {
    name: "bell_notification_one",
    data() {
        return {
            is_enable_notification:false,
            notification_lists :[],
            unread_count:0,
            current_page:1,
            totalPages:1,
            notification_lists:[],
            total_records:0,
            unread_count:0,
            previous_url:"",
            isLoggedIn:null,
            paginationHtml:"",

        }
    },
    methods: {
        i18n,
        generatePagination(currentPage, totalPages) {
            const maxPagesToShow = 2;
            // Left arrow
           let paginationHtml =  `
                    <a class="${currentPage == 1 ?"nsdp nsdp-leftarrow":"nsdp nsdp-leftarrow hasMoreLeft"}">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.22 12.7179C8.07931 12.5774 8.00018 12.3867 8 12.1879V11.8079C8.0023 11.6095 8.08112 11.4196 8.22 11.2779L13.36 6.1479C13.4539 6.05324 13.5817 6 13.715 6C13.8483 6 13.9761 6.05324 14.07 6.1479L14.78 6.8579C14.8741 6.95006 14.9271 7.07621 14.9271 7.2079C14.9271 7.33959 14.8741 7.46574 14.78 7.5579L10.33 11.9979L14.78 16.4379C14.8747 16.5318 14.9279 16.6596 14.9279 16.7929C14.9279 16.9262 14.8747 17.054 14.78 17.1479L14.07 17.8479C13.9761 17.9426 13.8483 17.9958 13.715 17.9958C13.5817 17.9958 13.4539 17.9426 13.36 17.8479L8.22 12.7179Z" fill="#BCBCBC"></path>
                        </svg>
                    </a>
           `;
            // Page numbers
            const startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
            const endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
            if (startPage > 1) {
                paginationHtml+=`
                    <a class="nsdp nsdp-pn">1</a>
                `;
            }
        
            if (startPage > 2) {
                paginationHtml+=`
                    <span class="nsdp nsdp-dots">...</span>
                `;
            }
        
            for (let i = startPage; i <= endPage; i++) {
                paginationHtml+=`
                    <a class="${ i === currentPage ? 'nsdp nsdp-pn pn-active' : 'nsdp nsdp-pn'}">${i}</a>
                `;
            }
        
            if (endPage < totalPages - 1) {
                paginationHtml+=`
                    <span class="nsdp nsdp-dots">...</span>
                `;
            }
        
            if (endPage < totalPages) {
                paginationHtml+=`
                    <a class="nsdp nsdp-pn">${totalPages}</a>
                `;
            }   
            // Right arrow
            paginationHtml+=`
                    <a class="${currentPage == totalPages ?"nsdp nsdp-rightarrow":"nsdp nsdp-rightarrow hasMoreRight"}">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.78 12.7179C15.9207 12.5774 15.9998 12.3867 16 12.1879V11.8079C15.9977 11.6095 15.9189 11.4196 15.78 11.2779L10.64 6.1479C10.5461 6.05324 10.4183 6 10.285 6C10.1517 6 10.0239 6.05324 9.93 6.1479L9.22 6.8579C9.12594 6.95006 9.07293 7.07621 9.07293 7.2079C9.07293 7.33959 9.12594 7.46574 9.22 7.5579L13.67 11.9979L9.22 16.4379C9.12534 16.5318 9.0721 16.6596 9.0721 16.7929C9.0721 16.9262 9.12534 17.054 9.22 17.1479L9.93 17.8479C10.0239 17.9426 10.1517 17.9958 10.285 17.9958C10.4183 17.9958 10.5461 17.9426 10.64 17.8479L15.78 12.7179Z" fill="#BCBCBC"></path>
                        </svg>
                    </a>
                `;
            return paginationHtml;
        },
        leftArrow(){
            if (this.current_page>1) {
                this.current_page = this.current_page-1;
                this.getNotifications(this.current_page); 
            }
        },
        rightArrow(){
            if (this.current_page<this.totalPages) {
                this.current_page = this.current_page+1; 
                this.getNotifications(this.current_page);
            }
        },
        onPageClick(page){
            this.current_page = page;
            this.getNotifications(this.current_page);
        },
        formatHistory(timestamp) {
            var currentDateInTimezone = new Date();
            var currentDate = new Date(currentDateInTimezone.getUTCFullYear(), currentDateInTimezone.getUTCMonth(), currentDateInTimezone.getUTCDate(), currentDateInTimezone.getUTCHours(), currentDateInTimezone.getUTCMinutes(), currentDateInTimezone.getUTCSeconds());
            var historyDate = new Date(timestamp);
            var timeDifference = currentDate.getTime() - historyDate.getTime();
            var seconds = Math.floor(timeDifference / 1000);
            var minutes = Math.floor(seconds / 60);
            var hours = Math.floor(minutes / 60);
            var days = Math.floor(hours / 24);

            if (days > 0) {
                return days + (days === 1 ? " day ago" : " days ago");
            } else if (hours > 0) {
                return hours + (hours === 1 ? " hour ago" : " hours ago");
            } else if (minutes > 0) {
                return minutes + (minutes === 1 ? " minute ago" : " minutes ago");
            } else {
                return seconds + (seconds === 1 ? " second ago" : " seconds ago");
            }
        },
        formatDate(timestamp) {
            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const date = new Date(timestamp);
        
            const day = date.getDate();
            const month = months[date.getMonth()];
            const year = date.getFullYear();
            // Get time components
            let hours = date.getHours();
            const minutes = date.getMinutes();
            const ampm = hours >= 12 ? "PM" : "AM";       
            // Convert hours to 12-hour format
            hours = hours % 12;
            hours = hours ? hours : 12; // Handle midnight    
            // Construct the formatted date and time string
            const formattedDate = `${day} ${month} ${year}, ${hours}:${minutes < 10 ? '0' + minutes : minutes} ${ampm}`;          
            return formattedDate;
        },
        async getNotifications(page){
            let notificationList = await getBellNotifications(page);
            if (notificationList?.data?.code == 200) {
                this.totalPages =  notificationList?.data?.total_pages;
                this.current_page_no =  notificationList?.data?.current_page_no;
                this.notification_lists = notificationList?.data?.data; 
                this.unread_count = notificationList?.data?.total_unreads;
                this.total_records = notificationList?.data?.total_records;
                if (this.totalPages>1) {
                    this.paginationHtml = this.generatePagination(this.current_page,this.totalPages);
                }
            }
        },
        readMessage(data){
            if (data?.read_status) {
                if (data?.deep_link && Object.keys(data?.deep_link)?.length>0) {
                    if (data?.deep_link?.is_playlist == 1) {
                        window.location.href = "/playlist/"+data?.deep_link?.content_permalink;
                    //ER 109149 start
                    }else if(data?.deep_link?.custom_url){
                        let url = data?.deep_link?.custom_url || '';
                        if (url && !url.startsWith('https://')) {
                            url = 'https://' + url;
                        }
                        // Open the URL in a new tab
                        window.open(url, '_blank');
                    }else{
                    //ER 109149 end
                        window.location.href ="/content/"+data?.deep_link?.content_permalink;
                    }
                }else{
                    window.location.href ="/";
                }         
            }else{
                const id  = data.sent_push_notification_uuid;
                readNotification({
                    "push_notification_uuid":id,
                    "status":1
                }).then((response)=>{
                    $("#"+id+"_listing").addClass("read");
                    this.unread_count = this.unread_count - 1;
                    if (data?.deep_link && Object.keys(data?.deep_link)?.length>0) {
                        if (data?.deep_link?.is_playlist == 1) {
                            window.location.href = "/playlist/"+data?.deep_link?.content_permalink;
                        //ER 109149 start
                        }else if(data?.deep_link?.custom_url){
                            let url = data?.deep_link?.custom_url || '';
                            if (url && !url.startsWith('https://')) {
                                url = 'https://' + url;
                            }
                            // Open the URL in a new tab
                            window.open(url, '_blank');
                        }else{
                        //ER 109149 end
                            window.location.href ="/content/"+data?.deep_link?.content_permalink;
                        }
                    }else{
                        window.location.href ="/";
                    }
                });
            }
        }
    },
    created(){

    },
    async beforeMount() {
        this.isLoggedIn = localStorage.getItem('isloggedin');
        if(!this.isLoggedIn){
            window.location.href = '/'
        }
    },
    async mounted() {
        this.isLoggedIn = localStorage.getItem('isloggedin');
        if (this.isLoggedIn) {
            window.app = this;
            await this.getNotifications(this.current_page);
            $(document).on("click", ".nsdp-leftarrow", function () {
                window.app.leftArrow(); 
            });
            $(document).on("click", ".nsdp-rightarrow", function () {
                window.app.rightArrow(); 
            });
            $(document).on("click", ".nsdp-pn", function (e) {
                window.app.onPageClick(parseInt($(e.target).text())); 
            });
            this.previous_url = document.referrer;
        }else{
            window.location.href = "/"
        }
    },
    template: `
    <vd-component class="vd">
    <section class="notification-section" v-if="isLoggedIn">
        <div class="ns-div">
        <div class="nsd-header">
            <a class="nsdh-svg" :href="previous_url">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                d="M14.5026 25.7341L5.7026 16.9341C5.56927 16.8008 5.4746 16.6563 5.4186 16.5008C5.36349 16.3452 5.33594 16.1785 5.33594 16.0008C5.33594 15.823 5.36349 15.6563 5.4186 15.5008C5.4746 15.3452 5.56927 15.2008 5.7026 15.0674L14.5026 6.26743C14.747 6.02298 15.0524 5.89498 15.4186 5.88343C15.7857 5.87276 16.1026 6.00076 16.3693 6.26743C16.6359 6.51187 16.775 6.81721 16.7866 7.18343C16.7973 7.55054 16.6693 7.86743 16.4026 8.13409L9.86927 14.6674H24.7693C25.147 14.6674 25.4639 14.795 25.7199 15.0501C25.975 15.3061 26.1026 15.623 26.1026 16.0008C26.1026 16.3785 25.975 16.695 25.7199 16.9501C25.4639 17.2061 25.147 17.3341 24.7693 17.3341H9.86927L16.4026 23.8674C16.647 24.1119 16.775 24.423 16.7866 24.8008C16.7973 25.1785 16.6693 25.4896 16.4026 25.7341C16.1582 26.0008 15.847 26.1341 15.4693 26.1341C15.0915 26.1341 14.7693 26.0008 14.5026 25.7341Z"
                fill="#7B8794" />
            </svg>
            </a>
            <div class="nsdh-ht">
            <span class="nsdhht-text">{{i18n('Notifications')}}</span>
            <span class="nsdhht-ncount" v-if="unread_count">({{unread_count}})</span>
            </div>
        </div>
        <div class="nsd-body" v-if="notification_lists.length">
        <template v-for="data in notification_lists" >
            <hr class="npb-hr">
            <div class="npb-lc" v-if="data.image && (!data.deep_link || data.deep_link?.custom_url)">
            <div class="npblc-mainContent" @click="readMessage(data)">
                <div class="npblc-img">
                <img class="npblci-img img-fluid" :src="data.image" >
                </div>
                <div class="npblc-text">
                <div class="npblct-top" :id="data.sent_push_notification_uuid+'_listing'" :class="{'read' : (data.read_status == 1)}">
                    <div class="npblctt-one">
                    <span class="npblctto-left">{{data.push_title}}</span>
                    <span class="npblctto-time">{{formatHistory(data.created_at)}}</span>
                    <span class="npblctto-time npblctto-datetime">{{formatDate(data.created_at)}} (UTC)</span>
                    </div>
                    <div class="npblctt-two">
                    {{data.push_content}}
                    </div>
                </div>
                </div>
            </div>
            </div>
            <div class="npb-lc" v-else-if="data.image && data.deep_link && !data.deep_link?.custom_url">
            <div class="npblc-mainContent" @click="readMessage(data)">
                <div class="npblc-img">
                <img class="npblci-img img-fluid" :src="data.image">
                </div>
                <div class="npblc-text">
                <div class="npblct-top" :id="data.sent_push_notification_uuid+'_listing'" :class="{'read' : (data.read_status == 1)}">
                    <div class="npblctt-one">
                    <span class="npblctto-left">{{data.push_title}}</span>
                    <span class="npblctto-time">{{formatHistory(data.created_at)}}</span>
                    <span class="npblctto-time npblctto-datetime">{{formatDate(data.created_at)}} (UTC)</span>
                    </div>
                    <div class="npblctt-two">
                    {{data.push_content}}
                    </div>
                </div>
                <div class="npblct-bottom">
                    <a :href="'/content/'+data.deep_link.content_permalink" class="watchNow">{{i18n('Watch Now')}}</a>
                </div>
                </div>
            </div>
            </div>
            <div class="npb-lc" v-else>
            <div class="npblc-mainContent" @click="readMessage(data)">
                <div class="npblc-text">
                <div class="npblct-top" :id="data.sent_push_notification_uuid+'_listing'" :class="{'read' : (data.read_status == 1)}">
                    <div class="npblctt-one">
                    <span class="npblctto-left">{{data.push_title}}</span>
                    <span class="npblctto-time">{{formatHistory(data.created_at)}}</span>
                    <span class="npblctto-time npblctto-datetime">{{formatDate(data.created_at)}} (UTC)</span>
                    </div>
                    <div class="npblctt-two">
                    {{data.push_content}}
                    </div>
                </div>
                </div>
            </div>
            </div>
            </template>
        </div>
        <div class="nsd-footer nsd-pagination" id="nsd-pagination" v-if="totalPages>1 && total_records>1" v-html="paginationHtml">
    
        </div>
        </div>
    </section>
    </vd-component>`,
};

let { TooltipDirective } = await import(window.importAssetJs('js/directives/tooltip.directive.js'));
let {
    editEnduserPlaylist,
    getEnduserPlaylistDetails,
    removeContentFromPlaylist
} = await import(window.importAssetJs('js/webservices.js'));
let { getRootUrl } = await import(window.importAssetJs('js/web-service-url.js'));
let { Toast } = await import(window.importAssetJs('js/commontoast.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));
let {default:content_hover_one}=await import(window.importLocalJs('widgets/content-hover/content-hover-one.js'));
let {default:watch_now_one}=await import(window.importLocalJs('widgets/watch-now/watch-now-one.js'));

const { mapState, mapGetters } = Vuex;

export default {
    name: 'playlist_enduser_details_one',
    components: {
        content_hover_one,
        watch_now_one
    },
    template: `
    <vd-component class="vd playlist-enduser-details-one" type="playlist-enduser-details-one">
        <section class="mp-listing p-0">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 mpl-contents p-0">
                        <div class="mpl-top">
                            <h1 class="mplt-heading">
                                <span class="span-backarrow" @click="backToList">
                                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M14.5026 25.7341L5.7026 16.9341C5.56927 16.8008 5.4746 16.6563 5.4186 16.5008C5.36349 16.3452 5.33594 16.1785 5.33594 16.0008C5.33594 15.823 5.36349 15.6563 5.4186 15.5008C5.4746 15.3452 5.56927 15.2008 5.7026 15.0674L14.5026 6.26743C14.747 6.02298 15.0524 5.89498 15.4186 5.88343C15.7857 5.87276 16.1026 6.00076 16.3693 6.26743C16.6359 6.51187 16.775 6.81721 16.7866 7.18343C16.7973 7.55054 16.6693 7.86743 16.4026 8.13409L9.86927 14.6674H24.7693C25.147 14.6674 25.4639 14.795 25.7199 15.0501C25.975 15.3061 26.1026 15.623 26.1026 16.0008C26.1026 16.3785 25.975 16.695 25.7199 16.9501C25.4639 17.2061 25.147 17.3341 24.7693 17.3341H9.86927L16.4026 23.8674C16.647 24.1119 16.775 24.423 16.7866 24.8008C16.7973 25.1785 16.6693 25.4896 16.4026 25.7341C16.1582 26.0008 15.847 26.1341 15.4693 26.1341C15.0915 26.1341 14.7693 26.0008 14.5026 25.7341Z"
                                            fill="#7B8794" />
                                    </svg>
                                </span>
                                {{i18n('My Playlists')}}
                            </h1>
                        </div>
                        <div class="mpl-bottom">
                            <div class="mplb-top">
                                <div class="myplaylist-items">
                                    <div class="picture">
                                        <a href="javascript:void(0)" class="h-100" style="cursor:text;">
                                            <img :src="playlist_thumbnail" alt="playlist" class="w-100 h-100" v-if="playlist_thumbnail" />
                                            <span class="playlist-type-icon d-flex" v-else>
                                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path 
                                                        d="M20 8H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                    <path 
                                                        d="M17.3333 13.332H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                    <path 
                                                        d="M12 18.668H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                    <path 
                                                        d="M10.6667 24H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                    <path 
                                                        d="M22.6641 22.0013V16.668V10.668" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                    <path
                                                        d="M19.3333 25.3346C21.1743 25.3346 22.6667 23.8423 22.6667 22.0013C22.6667 20.1604 21.1743 18.668 19.3333 18.668C17.4924 18.668 16 20.1604 16 22.0013C16 23.8423 17.4924 25.3346 19.3333 25.3346Z"
                                                        stroke="white" stroke-width="1.5"></path>
                                                    <path 
                                                        d="M27.9974 16.0013C25.0519 16.0013 22.6641 13.6134 22.6641 10.668" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                    <div :class="['mpi-data', hideMpiData ? 'd-none' : '']">
                                        <div class="data-contents">
                                            <h2 class="mp-heading">
                                                {{ formatText(playlist_name) }}
                                            </h2>
                                            <div class="createDateTrack">
                                                <span class="cd-date">
                                                    {{ formatDate(playlist_created_date) }}
                                                </span>
                                                <span class="cdt-divide">|</span>
                                                <span class="cdt-track">
                                                    {{ playlist_size }} {{ playlist_type === 1 ? 'Video(s)' : 'Audio(s)' }}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="actionbuttons">
                                            <div class="playAll">
                                                <!--<content_hover_one 
                                                    v-if="playlist_size"
                                                    :id="$attrs['id'] +'_content_hover_one_1'"
                                                    :content="playlist_details?.content_list?.[0]"
                                                    :playNowBtnTxt="i18n($attrs['label1'])"
                                                    :playAllBtnTxt="playAllBtnTxt"
                                                    :watchNowBtnTxt="i18n($attrs['label4'])"
                                                    :isLogedIn="isLogedIn" 
                                                    :fromEnduserPlaylist="true"
                                                    @playAudioContent="playAudioContent"
                                                />-->
                                                <watch_now_one 
                                                    v-if="playlist_size" 
                                                    :fromEnduserPlaylist="true" 
                                                    :playerRequiredObj="playerRequiredObj"
                                                    :id="$attrs['id'] +'_watch_now_one_1'" 
                                                    @playAudioContent="playAudioContent" @player_permalink_data="playerPermalinkDataEmitted" 
                                                    ref="$watchNowRef"
                                                />
                                                <button class="pa-btn disabled" v-else>
                                                    <span class="pa-icon d-flex">
                                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M2.91406 3.58167C2.91406 2.7905 3.78931 2.31266 4.45482 2.74049L9.77223 6.15882C10.3846 6.55246 10.3846 7.44754 9.77223 7.84118L4.45482 11.2595C3.78931 11.6873 2.91406 11.2095 2.91406 10.4183V3.58167Z"
                                                                fill="#E9E9E9" stroke="#E9E9E9" stroke-width="1.33"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </span>
                                                    Play All
                                                </button>
                                            </div>
                                            <div class="ed-btns" id="showStartOver" v-if="permalinkDataEmitted?.show_play_btn && permalinkDataEmitted?.button_text === 'Resume'">
                                                <a class="btns" href="javascript:void(0);" @click="triggerWatchNow" data-toggle="tooltip" data-placement="top" data-original-title="Start Over" :title="i18n('Start Over')">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M2 3.99219V9.99219H8" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                        <path d="M4.51 14.9907C5.15839 16.831 6.38734 18.4109 8.01166 19.492C9.63598 20.5732 11.5677 21.0973 13.5157 20.9851C15.4637 20.873 17.3226 20.1308 18.8121 18.8704C20.3017 17.61 21.3413 15.8996 21.7742 13.997C22.2072 12.0944 22.0101 10.1026 21.2126 8.32177C20.4152 6.54091 19.0605 5.06747 17.3528 4.12344C15.6451 3.17941 13.6769 2.81593 11.7447 3.08779C9.81245 3.35964 8.02091 4.25209 6.64 5.63067L2 9.99067" stroke="white" stroke-opacity="0.64" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>                              
                                                </a>
                                            </div>
                                            <div class="ed-btns">
                                                <button class="btns btnEdit" id="editPlaylistListing" @click="editClicked">
                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M11.5909 1.58492C11.7763 1.39948 11.9964 1.25238 12.2387 1.15201C12.481 1.05165 12.7407 1 13.003 1C13.2652 1 13.5249 1.05165 13.7672 1.15201C14.0095 1.25238 14.2296 1.39948 14.4151 1.58492C14.6005 1.77036 14.7476 1.99051 14.848 2.2328C14.9483 2.47509 15 2.73478 15 2.99703C15 3.25928 14.9483 3.51897 14.848 3.76126C14.7476 4.00355 14.6005 4.2237 14.4151 4.40914L4.88331 13.9409L1 15L2.05909 11.1167L11.5909 1.58492Z"
                                                            stroke="white" stroke-opacity="0.64" stroke-width="1.5"
                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </button>
                                                <button class="btns btnDelete" data-toggle="modal"
                                                    @click="openDeletePlaylistModal">
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M2.25 4.5H3.75H15.75" stroke="white" stroke-opacity="0.64"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                        <path
                                                            d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72065 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5"
                                                            stroke="white" stroke-opacity="0.64" stroke-width="1.5"
                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M7.5 8.25V12.75" stroke="white" stroke-opacity="0.64"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                        <path d="M10.5 8.25V12.75" stroke="white" stroke-opacity="0.64"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div :class="['mpi-Editdata', hideMpiEditData ? 'd-none' : '']">
                                        <div class="data-contents">
                                            <div class="mpied-inputDiv">
                                                <input type="text" :value="playlist_name" ref="plName" :class="['editPlName-input', invalidPlaylistName ? 'is-invalid' : '']">
                                            </div>
                                            <div class="invalid-feedback" ref="plNameError">{{errors.playlist_name}}</div>
                                            <div class="createDateTrack">
                                                <span class="cd-date">{{ formatDate(playlist_created_date) }}</span>
                                                <span class="cdt-divide">|</span>
                                                <span class="cdt-track">{{ playlist_size }} {{ playlist_type === 1 ? 'Video(s)' : 'Audio(s)' }}</span>
                                            </div>
                                        </div>
                                        <div class="actionbuttons">
                                            <div class="ed-btns">
                                                <button class="btns btnCancelEditpl" id="editPlaylistCancel" @click="editCancelClicked">
                                                    {{i18n('Cancel')}}
                                                </button>
                                                <button class="btns btnSaveEditpl" @click="saveEditClicked">
                                                    {{i18n('Save')}}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mplb-bottom">
                                <div :class="['table-options', hideCheckAll ? 'd-none' : '']">
                                    <div class="d-flex align-items-center" style="min-width: 800px;padding-top: 2px;">
                                        <div :class="['track-delete', plist_contents?.length ? '' : 'd-none']" @click="openDeleteContentModal()">
                                            Delete All
                                        </div>
                                        <div class="trackAllSelect d-none">
                                            <p class="mb-0">All 17 Tracks on this page are selected.</p>
                                        </div>
                                        <div class="trackAllinfo">
                                            <a href="javascript:void(0)" class="info-link ms-4">
                                                {{ plist_contents?.length }} content(s) selected out of {{ playlist_size }}
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="mplbb-scrollDiv table-responsive">
                                    <table class="table" style="min-width: 800px;">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <div :class="['checkbox-button', hideCheckAll ? 'd-none' : '']">
                                                        <input type="checkbox" @click="checkAll()" v-model="isCheckAll" id="checkboxplay"  class="chkAll">
                                                        <label for="checkboxplay" class="checkbox-label blue"></label>
                                                    </div>
                                                </th>
                                                <th>
                                                    {{i18n('Title')}}
                                                </th>
                                                <th>
                                                    {{i18n('Added on')}}
                                                </th>
                                                <th>
                                                    {{i18n('Duration')}}
                                                </th>
                                                <th>

                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody class="droppable-area1">
                                            <tr v-if="!playlist_size && !isLoading">
                                                <td colspan="5" class="p-2">{{i18n('No data available')}}</td>
                                            </tr>
                                            <template v-else> 
                                                <tr class="draggable-item" v-for="(item, index) in playlist_content_list" :key="item.content_uuid">
                                                    <td>
                                                        <div :class="['checkBoxDel', hideCheckAll ? 'd-none' : '']">
                                                            <div class="checkbox-button">
                                                                <input type="checkbox" :id="'chk_single'+item.content_uuid"  class="playlist-check" :value="item.content_uuid" v-model="plist_contents" @change="updateCheckall()">
                                                                <label :for="'chk_single'+item.content_uuid" class="checkbox-label blue"></label>
                                                            </div>
                                                        </div>
                                                        <div :class="['dragSN', hideCheckAll ? '' : 'd-none']">
                                                            <div class="dsn-div">
                                                                <span class="dragIcon-span d-none">
                                                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M5.33073 8.66536C5.69892 8.66536 5.9974 8.36689 5.9974 7.9987C5.9974 7.63051 5.69892 7.33203 5.33073 7.33203C4.96254 7.33203 4.66406 7.63051 4.66406 7.9987C4.66406 8.36689 4.96254 8.66536 5.33073 8.66536Z"
                                                                            stroke="white" stroke-opacity="0.64"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path
                                                                            d="M5.33073 4.0013C5.69892 4.0013 5.9974 3.70283 5.9974 3.33464C5.9974 2.96645 5.69892 2.66797 5.33073 2.66797C4.96254 2.66797 4.66406 2.96645 4.66406 3.33464C4.66406 3.70283 4.96254 4.0013 5.33073 4.0013Z"
                                                                            stroke="white" stroke-opacity="0.64"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path
                                                                            d="M5.33073 13.3333C5.69892 13.3333 5.9974 13.0349 5.9974 12.6667C5.9974 12.2985 5.69892 12 5.33073 12C4.96254 12 4.66406 12.2985 4.66406 12.6667C4.66406 13.0349 4.96254 13.3333 5.33073 13.3333Z"
                                                                            stroke="white" stroke-opacity="0.64"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path
                                                                            d="M11.3307 13.3333C11.6989 13.3333 11.9974 13.0349 11.9974 12.6667C11.9974 12.2985 11.6989 12 11.3307 12C10.9625 12 10.6641 12.2985 10.6641 12.6667C10.6641 13.0349 10.9625 13.3333 11.3307 13.3333Z"
                                                                            stroke="white" stroke-opacity="0.64"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path
                                                                            d="M11.3307 4.0013C11.6989 4.0013 11.9974 3.70283 11.9974 3.33464C11.9974 2.96645 11.6989 2.66797 11.3307 2.66797C10.9625 2.66797 10.6641 2.96645 10.6641 3.33464C10.6641 3.70283 10.9625 4.0013 11.3307 4.0013Z"
                                                                            stroke="white" stroke-opacity="0.64"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                        <path
                                                                            d="M11.3307 8.66536C11.6989 8.66536 11.9974 8.36689 11.9974 7.9987C11.9974 7.63051 11.6989 7.33203 11.3307 7.33203C10.9625 7.33203 10.6641 7.63051 10.6641 7.9987C10.6641 8.36689 10.9625 8.66536 11.3307 8.66536Z"
                                                                            stroke="white" stroke-opacity="0.64"
                                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                            <div class="dsn-play-div">
                                                                <span class="sn-digit">
                                                                    {{index+1}}
                                                                </span>
                                                                <content_hover_one  
                                                                    :id="$attrs['id'] +'_content_hover_one_1_'+index"
                                                                    :content="item" 
                                                                    :contentDetails="playlist_details?.content_list?.[0]"
                                                                    :playNowBtnTxt="'Play Aud'"
                                                                    :viewTrailerBtnTxt="i18n($attrs['label2'])"
                                                                    :playAllBtnTxt="'Play All'"
                                                                    :watchNowBtnTxt="'Play Vid'"
                                                                    :isLogedIn="isLogedIn" 
                                                                    :fromEnduserPlaylist="true"
                                                                    @playAudioContent="playAudioContent"
                                                                />
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="td-playlistData">
                                                            <div class="trackPic">
                                                                <img class="img-fluid" :src="item?.posters?.website?.[0]?.file_url" v-if="item?.posters?.website?.[0]?.file_url">
                                                                <span class="" v-else>
                                                                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path 
                                                                            d="M20 8H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                                        <path 
                                                                            d="M17.3333 13.332H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                                        <path 
                                                                            d="M12 18.668H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                                        <path 
                                                                            d="M10.6667 24H4" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                                        <path 
                                                                            d="M22.6641 22.0013V16.668V10.668" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                                        <path
                                                                            d="M19.3333 25.3346C21.1743 25.3346 22.6667 23.8423 22.6667 22.0013C22.6667 20.1604 21.1743 18.668 19.3333 18.668C17.4924 18.668 16 20.1604 16 22.0013C16 23.8423 17.4924 25.3346 19.3333 25.3346Z"
                                                                            stroke="white" stroke-width="1.5"></path>
                                                                        <path 
                                                                            d="M27.9974 16.0013C25.0519 16.0013 22.6641 13.6134 22.6641 10.668" stroke="white" stroke-width="1.5" stroke-linecap="round"></path>
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                            <div class="data-contents">
                                                                <h2 class="mp-heading">
                                                                    {{ formatText(item.content_name) }}
                                                                </h2>
                                                                <div class="trackPara">
                                                                    {{ formatText(item.content_desc) }}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>{{ formatContentMappedDate(item.playlist_created_date) }}</td>
                                                    <td>{{ item?.video_details?.duration ? item?.video_details?.duration : item?.audio_details?.duration ? item?.audio_details?.duration : '' }}</td>
                                                    <td>
                                                        <button :class="['btns btnDelete hoverShow', hideSingleDelete ? 'd-none' : '']"  data-toggle="modal"
                                                        @click="openDeleteContentModal(item.content_uuid)">
                                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M2.25 4.5H3.75H15.75" stroke="white"
                                                                    stroke-opacity="0.64" stroke-width="1.5"
                                                                    stroke-linecap="round" stroke-linejoin="round" />
                                                                <path
                                                                    d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72065 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5"
                                                                    stroke="white" stroke-opacity="0.64" stroke-width="1.5"
                                                                    stroke-linecap="round" stroke-linejoin="round" />
                                                                <path d="M7.5 8.25V12.75" stroke="white" stroke-opacity="0.64"
                                                                    stroke-width="1.5" stroke-linecap="round"
                                                                    stroke-linejoin="round" />
                                                                <path d="M10.5 8.25V12.75" stroke="white" stroke-opacity="0.64"
                                                                    stroke-width="1.5" stroke-linecap="round"
                                                                    stroke-linejoin="round" />
                                                            </svg>
                                                        </button>
                                                    </td>
                                                </tr>
                                            </template>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="playlistItems pt-3" v-if="playlist_size > playlist_content_list?.length">
                                    <div class="plic-left">
                                        <button class="loadMore" @click="loadMoreContents">
                                            <span class="pa-icon d-flex">
                                                <img src=${rootUrl}img/playlist-icon.png style="width: 14px;">                           
                                            </span>
                                                {{i18n('Load More')}}
                                        </button>
                                    </div>
                                </div>
                                <div class="playlistItems pt-3" v-else-if="playlist_content_list?.length > 5">
                                    <span class="pa-icon d-flex white-color samll-content">
                                        {{i18n('No more contents to show')}}!                         
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--delete playlist start Here-->
        <div class="modal fade delete-playlist-modal p-0" id="deletePlaylistContent" tabindex="-1" role="dialog" aria-labelledby="deletePlaylistContent" aria-hidden="true" ref="del_cont_modal_el">
            <div class="modal-dialog modal-dialog-centered justify-content-center" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="dplm-mb-contents">
                            <div class="dplmmbc-delIcon">
                                <span class="delicon-span">
                                    <svg width="42" height="42" viewBox="0 0 42 42" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.25 10.5H8.75H36.75" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path
                                            d="M33.25 10.5V35C33.25 35.9283 32.8813 36.8185 32.2249 37.4749C31.5685 38.1313 30.6783 38.5 29.75 38.5H12.25C11.3217 38.5 10.4315 38.1313 9.77513 37.4749C9.11875 36.8185 8.75 35.9283 8.75 35V10.5M14 10.5V7C14 6.07174 14.3688 5.1815 15.0251 4.52513C15.6815 3.86875 16.5717 3.5 17.5 3.5H24.5C25.4283 3.5 26.3185 3.86875 26.9749 4.52513C27.6313 5.1815 28 6.07174 28 7V10.5"
                                            stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M17.5 19.25V29.75" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M24.5 19.25V29.75" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </span>
                            </div>
                            <div class="dplmmbc-delMessage">
                                <span class="delMessage-heading">{{i18n("Remove from Playlist")}}</span>
                                <span class="delMessage-para" v-if="plist_contents?.length > 1">{{i18n("Are you sure you want to delete all the selected contents?")}}</span>
                                <span class="delMessage-para" v-else-if="plist_contents?.length">{{i18n("Are you sure you want to delete the selected content?")}}</span>
                                <span class="delMessage-para" v-else>{{i18n("Are you sure you want to delete this content?")}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer no-border">
                        <button type="button" class="btn dismiss" data-dismiss="modal">{{i18n('Cancel')}}</button>
                        <button type="button" class="btn btnProceed" id="proceedDelPl" @click="deletePlaylistContent">{{i18n('Proceed')}}</button>
                    </div>
                </div>
            </div>
        </div>
        <!--delete playlist End Here-->
    </vd-component>
    `,
    props: {
        playlistId: String,
        playAllBtnTxt: String
    },
    directives: {
        tooltip: TooltipDirective
    },
    data() {
        return {
            permalinkDataEmitted: null,
            hideSingleDelete: false,
            playerRequiredObj: {},
            contentUuidAudio: '',
            resetAudioPlayer: Math.floor(Math.random() * 10000000),
            isAudioPlay: false,
            reloadOnUpdateLifeCycle: true,
            pageNo: 1,
            playlist_details: null,
            playlist_content_list: [],
            isLoading: true,
            playlist_size: 0,
            playlist_type: 0,
            playlist_name: '',
            playlist_created_date: '',
            playlist_thumbnail: '',
            playlistContId: '',
            isJsLoader: false,
            hideMpiData: false,
            hideMpiEditData: true,
            isCheckAll: false,
            plist_contents: [],
            selected_contents: "",
            hideCheckAll: true,
            // playlistId: '',
            isLogedIn: JSON.parse(localStorage.getItem("isloggedin")),
            contentDetails: { 
                content_asset_type: 0,
                content_uuid: '',
                playlist_uuid: '',
                isListing: false
            },
            selectedIndex: 0,
            rootUrl: getRootUrl(),
            errors: {},
            isReset:false,
            invalidPlaylistName: false,
        }
    },
    computed: {
        ...mapState({
            current_content_uuid: state => state.current_content_uuid,
            store_content_type: (state) => state.store_content_type,
            enduser_playlist: (state) => state.enduser_playlist,
            show_enduser_playlist_modal: state => state.show_enduser_playlist_modal
        }),
        // 87419 Raj
        ...mapGetters({
            will_show_apply_promocode: 'is_promotion_enabled',
            //is_third_party_gateway: 'is_third_party_gateway',
        }),
    },
    watch: {
        show_enduser_playlist_modal(cv) {
            console.log('cv', cv);
            if (cv) {
                setTimeout(() => {
                    $('#addPlaylist').modal('show');
                    $('.modal-backdrop').css('z-index', 'initial');
                }, 100);
            } else {
                $('#addPlaylist').modal('hide');
            }
        },
    },
    async beforeMount() {
        if (localStorage.getItem('isloggedin')) {

        }
    },
    async mounted() {
        if (this.isLogedIn) {
            $('[data-toggle="tooltip"]').tooltip();
            await this.getMyPlaylistDetails();
        } else {
            window.location.href = "/sign-up";
        }
    },
    methods: {
        i18n,
        getRootUrl,
        backToList(){
            this.$emit('show-list', true);
        },
        formatContentMappedDate(inputDate) {
            const local = moment.utc(inputDate).local();
            return moment(local).fromNow();
            // let startTime = moment(new Date()); //todays date
            // let end = moment(inputDate); // another date

            // let duration = moment.duration(end.diff(startTime));
            // let hours = duration.asHours();
            // console.log(hours)
            // return hours;
        },
        formatDate(inputDate) {
            const local = moment.utc(inputDate).local();
            const dstr = moment(local).format('Do MMMM, YYYY');
            // console.log('Created on '+dstr);
            return 'Created on '+dstr;
        },
        formatText(inputText) {
            return inputText.length > 30 ? inputText.substring(0, 30) + '..' : inputText;
        },
        checkAll() {
            this.isCheckAll = !this.isCheckAll;
            this.plist_contents = [];
            if(this.isCheckAll){ // Check all
                this.hideSingleDelete = true;
                for (const key in this.playlist_content_list) {
                    console.log('item', this.playlist_content_list[key]);
                    this.plist_contents.push(this.playlist_content_list[key].content_uuid);
                }
            } else {
                this.hideSingleDelete = false;
            }
        },
        updateCheckall() {
            console.log('updateCheckall', this.plist_contents?.length);
            if(this.plist_contents?.length) {
                this.hideSingleDelete = true;
            } else {
                this.hideSingleDelete = false;
            }
            if(this.plist_contents?.length == this.playlist_content_list?.length){
                this.isCheckAll = true;
            } else {
                this.isCheckAll = false;
            }
        },      
        editClicked() {
            console.log(this.playlistId);
            this.hideMpiData = true;
            this.hideMpiEditData = false;
            this.hideCheckAll = false;
        },
        editCancelClicked() {
            this.hideSingleDelete = false;
            this.hideMpiData = false;
            this.hideMpiEditData = true;
            this.isCheckAll = false;
            this.hideCheckAll = true;
            this.plist_contents = [];
        },
        validatePlaylistName(value) {
            // console.log('validate text value', value);
            if (!value.length) {
                this.errors.playlist_name = i18n("The Playlist Name field is required.");
                this.invalidPlaylistName = true;
            } else if (!value.match(/^[a-z\d\s]+$/i)) {
                this.invalidPlaylistName = true;
                this.errors.playlist_name = i18n("The Playlist Name field must contains only alphanumeric.");
            } else if (value.length < 3 || value.length > 50) {
                this.errors.playlist_name = i18n("The Playlist Name should be between 3 to 50 charaters.");
                this.invalidPlaylistName = true;
            } else {
                this.errors.playlist_name = null;
                this.invalidPlaylistName = false;
            }
        },
        async saveEditClicked() {
            console.clear();
            console.log(this.playlist_name);
            console.log(this.$refs.plName.value);
            
            if(this.playlist_name === this.$refs.plName.value) {
                Toast.fire({
                    icon: "info",
                    title: "Validation Failed",
                    text: 'No changes made in the playlist name to save'
                });
                return false;
            }
            this.validatePlaylistName(this.$refs.plName.value);
            if (this.errors.playlist_name) {
                console.log('Validate Failed');
                this.$refs.plNameError.style.display = "block";
                return false;
            }
            JsLoader.show();
            try {
                const postedData = {
                    "playlist_name": this.$refs.plName.value,
                    "playlist_type": this.playlist_type,
                    "account_type": 2,
                    "playlist_uuid": this.playlistId
                };
                // console.log('ref', this.$refs.plName.value);
                console.log('postedData', postedData);
                // return false;
                const edit_resp = await editEnduserPlaylist(postedData);
                // console.log(edit_resp);
                if (edit_resp?.data?.code === 200 && edit_resp?.data?.status === "SUCCESS") {
                    this.hideSingleDelete = false;
                    this.playlist_name = postedData.playlist_name;
                    console.log('this.playlist_name', this.playlist_name);
                    this.hideMpiData = false;
                    this.hideMpiEditData = true;
                    this.isCheckAll = false;
                    this.hideCheckAll = true;
                    this.plist_contents = [];

                    Toast.fire({
                        icon: "success",
                        title: "Success",
                        text: 'Playlist updated successfully'
                    });
                } else {
                    Toast.fire({
                        icon: "error",
                        title: "Error",
                        text: edit_resp?.data?.message
                    });
                }
            } catch (error) {
                console.error("Something went wrong!", error.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: error.message,
                });
            }
            JsLoader.hide();
        },
        async getMyPlaylistDetails() {
            !this.isJsLoader ? JsLoader.show() : '';
            try {
                const reqData = {
                    content_uuid: this.playlistId,
                    page: this.pageNo
                };
                const resp = await getEnduserPlaylistDetails(reqData);
                console.log('playlist_details', resp);
                if (resp?.data?.code === 200 && resp?.data?.status === "SUCCESS") {
                    this.playlist_details = resp.data.data.contentList;
                    this.setPlayerObj(this.playlist_details.content_list[0]);
                    this.playlist_content_list = resp.data.data.contentList?.content_list[0]?.playlist_content_list;

                    this.playlist_size = this.playlist_details.content_list[0].playlist_size;
                    this.playlist_type = this.playlist_details.content_list[0].content_asset_type;
                    this.playlist_name = this.playlist_details.content_list[0].content_name;
                    this.playlist_created_date = this.playlist_details.content_list[0].content_created_date;
                    this.playlist_thumbnail = this.playlist_details.content_list[0]?.playlist_content_list?.[0]?.posters?.website?.[0]?.file_url;
                } else {
                    Toast.fire({
                        icon: "error",
                        title: "Error",
                        text: resp?.data?.message
                    });
                }
            } catch (error) {
                console.error("Something went wrong!", error.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: error.message,
                });
            }
            this.isLoading = false;
            JsLoader.hide();
        },
        setPlayerObj(contentObj) {
            this.playerRequiredObj = {
                contentUuid: contentObj.content_uuid,
                isPlayList: contentObj.is_playlist,
                contentPermalink: contentObj.content_permalink,
                contentAssetType: contentObj.content_asset_type,
                isParent: contentObj.is_parent,
                isFreeContent: contentObj.is_free_content
            };
            console.clear();
            console.log('playerRequiredObj', this.playerRequiredObj);
        },
        async loadMoreContents() {
            console.log('loadmore called');
            console.log('this.pageNo', this.pageNo);
            console.log('this.playlist_details', this.playlist_details);
            console.log(this.playlist_details?.content_list?.length);
            console.log('total', this.playlist_size);
            this.pageNo++;
            await this.loadPlaylistContents();
        },
        async loadPlaylistContents() {
            !this.isJsLoader ? JsLoader.show() : '';
            try {
                const reqData = {
                    content_uuid: this.playlistId,
                    page: this.pageNo
                };
                const resp = await getEnduserPlaylistDetails(reqData);
                console.log('playlist_details', resp);
                if (resp?.data?.code === 200 && resp?.data?.status === "SUCCESS") {
                    if(resp?.data?.data?.contentList) {
                        // console.log('Existing List', this.playlist_content_list);
                        // console.log('New List', resp.data.data.contentList?.content_list[0]?.playlist_content_list);
                        this.playlist_content_list.push(...resp.data.data.contentList?.content_list[0]?.playlist_content_list);
                        // console.log('After Push', this.playlist_content_list);
                    }
                } else {
                    Toast.fire({
                        icon: "error",
                        title: "Error",
                        text: resp?.data?.message,
                    });
                }
            } catch (error) {
                console.error("Something went wrong!", error.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: error.message,
                });
            }
            this.isLoading = false;
            JsLoader.hide();
        },
        openDeletePlaylistModal() {
            console.log('details page', this.playlistId);
            console.log('details page', this.playlist_name);
            this.$emit('click-delete-playlist', {plId: this.playlistId, plName: this.playlist_name});
        },
        openDeleteContentModal(contId = '') {
            console.log('contId', contId);
            this.playlistContId = contId ? contId : '';
            console.log('this.playlistContId', this.playlistContId);
            console.log('this.plist_contents', this.plist_contents);
            jQuery(this.$refs.del_cont_modal_el).modal('show');
        },
        async deletePlaylistContent() {
            jQuery(this.$refs.del_cont_modal_el).modal('hide');
            JsLoader.show();
            try {
                const removePayload = {
                    "playlist_items": this.playlistContId ? [this.playlistContId] : this.plist_contents,
                    "playlist_uuid": this.playlistId,
                    "account_type": 2
                }
                console.log('removePayload', removePayload);
                // return false;
                let delResponse = await removeContentFromPlaylist(removePayload);
                if (delResponse?.data?.code == 200 && delResponse?.data?.status === "SUCCESS") {
                    this.isJsLoader = true;
                    this.playlistContId = '';
                    this.plist_contents = [];
                    Toast.fire({ 
                        icon: "success",
                        title: "Success",
                        text: delResponse.data.message 
                    });
                    this.pageNo = 1;
                    await this.getMyPlaylistDetails();
                } else {
                    Toast.fire({ 
                        icon: "error", 
                        title: "Error", 
                        text: delResponse?.data?.message 
                    });
                }
            } catch(err) {
                console.error("Something went wrong!", err.message);
                Toast.fire({
                    icon: "info",
                    title: 'Something went wrong!',
                    text: err.message,
                });
            }
            JsLoader.hide();
        },
        playAudioContent(content_detail) {//ER-101092
            console.log('content_detail', content_detail);
            this.$emit('playAudioContent', content_detail);
            // this.reloadOnUpdateLifeCycle = false;
            // this.contentUuidAudio = content_detail.content_uuid;//ER-101092
            // this.isFreeContent = content_detail.is_free_content; //ER-101092
            // this.resetAudioPlayer = Math.floor(Math.random() * 10000000);
            // this.isAudioPlay = true;
        },
        playerPermalinkDataEmitted(data) {
            this.permalinkDataEmitted = data;
        },
        triggerWatchNow() {
            this.$refs.$watchNowRef.getContentDetails('1');
        }
    }
}

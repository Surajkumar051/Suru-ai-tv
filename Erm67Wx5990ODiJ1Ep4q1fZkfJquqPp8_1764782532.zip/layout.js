let {default:navbar_one}=await import(window.importLocalJs('widgets/navbar/navbar-one.js'));
let {default:footer_one}=await import(window.importLocalJs('widgets/footer/footer-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
let { GET_LOGO_DETAILS}=await import(window.importAssetJs('js/configurations/actions.js'));
// let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));


const app1 = Vue.createApp({
    data() {
        return {
            isPpvmodel: localStorage.getItem("hidemodel"),
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
    components: {
        navbar_one: navbar_one
        // content_purchase_one: content_purchase_one
    },
    beforeMount() {
        this.$store.dispatch(GET_LOGO_DETAILS);      
    },
});
app1.use(vuexStore);
app1.mount("#navbar");

const app2 = Vue.createApp({
    components: {
       footer_one:footer_one
    }
});
app2.use(vuexStore);
app2.mount("#footer");



let {default:cookie_one} = await import(window.importLocalJs('widgets/cookie/cookie-one.js'));
const app3 = Vue.createApp({
    components: {
        cookie_one:cookie_one
    }
});
setTimeout(() => {
    app3.mount("#cookieDiv");
}, 2000);
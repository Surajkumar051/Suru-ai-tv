<?php echo @$global_script; ?>

<link rel="preload"
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'"
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap">
</noscript>

<link rel="preload" href="https://asset.muvi.com/visual-designer/cdn/font-awesome/css/all.min.css" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="https://asset.muvi.com/visual-designer/cdn/font-awesome/css/all.min.css">
</noscript>

<link rel="preload" href="<?php echo $asseturl; ?>css/bootstrap.min.css?v=<?php echo $assetCacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="<?php echo $asseturl; ?>css/bootstrap.min.css?v=<?php echo $assetCacheVersion; ?>">
</noscript>

<link rel="preload" href="<?php echo $template_default_url; ?>css/common.css?v=<?php echo $cacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="<?php echo $template_default_url; ?>css/common.css?v=<?php echo $cacheVersion; ?>">
</noscript>

<link rel="preload" href="<?php echo $template_default_url; ?>css/style.css?v=<?php echo $cacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="<?php echo $template_default_url; ?>css/style.css?v=<?php echo $cacheVersion; ?>">
</noscript>

<link rel="preload" href="<?php echo $asseturl; ?>css/vdglobalstyle.css?v=<?php echo $assetCacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="<?php echo $asseturl; ?>css/vdglobalstyle.css?v=<?php echo $assetCacheVersion; ?>">
</noscript>

<link rel="preload" href="<?php echo $rootUrl; ?>/css/cropper.css?v=<?php echo $cacheVersion; ?>" as="style" onload="this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="<?php echo $rootUrl; ?>/css/cropper.css?v=<?php echo $cacheVersion; ?>">
</noscript>

<link rel="preload" href="<?php echo $asseturl; ?>css/owl.carousel.min.css?v=<?php echo $assetCacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="<?php echo $asseturl; ?>css/owl.carousel.min.css?v=<?php echo $assetCacheVersion; ?>">
</noscript>

<link rel="preload" href="<?php echo $asseturl; ?>css/owl.theme.default.min.css?v=<?php echo $assetCacheVersion; ?>" as="style"
    onload="this.onload=null;this.rel='stylesheet'">
<noscript>
    <link rel="'stylesheet'" href="<?php echo $asseturl; ?>css/owl.theme.default.min.css?v=<?php echo $assetCacheVersion; ?>">
</noscript>

<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css" as="style"
    onload="this.onload=null;this.rel='stylesheet'" integrity="sha512-ARJR74swou2y0Q2V9k0GbzQ/5vJ2RBSoCWokg4zkfM29Fb3vZEQyv0iWBMW/yvKgyHSR/7D64pFMmU8nYmbRkg==" crossorigin="anonymous" referrerpolicy="no-referrer">
<noscript>
    <link rel="'stylesheet'" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/css/bootstrap-select.min.css" integrity="sha512-ARJR74swou2y0Q2V9k0GbzQ/5vJ2RBSoCWokg4zkfM29Fb3vZEQyv0iWBMW/yvKgyHSR/7D64pFMmU8nYmbRkg==" crossorigin="anonymous" referrerpolicy="no-referrer">
</noscript>

<script>
    var vdCTAInit = 0;
</script>

<script src="<?php echo $asseturl; ?>js/vue/vue-cookies.js"></script>
<script defer src="<?php echo $asseturl; ?>js/sweetalert2.all.min.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/js-loading-overlay.min.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/common-loader.js?v=<?php echo $assetCacheVersion; ?>" ></script>
<script defer src="<?php echo $asseturl; ?>js/axios.min.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/popper.min.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/bootstrap.min.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script src="<?php echo $asseturl; ?>js/vue/vue.global.prod.js"></script>
<script src="<?php echo $asseturl; ?>js/vue/vuex.global.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/vue-demi"></script>
<script defer src="https://cdn.jsdelivr.net/npm/@vuelidate/core"></script>
<script defer src="https://cdn.jsdelivr.net/npm/@vuelidate/validators"></script>
<script defer src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script defer src="<?php echo $asseturl; ?>js/owl.carousel.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/main.js?v=<?php echo $assetCacheVersion; ?>" type="module"></script>
<script defer id="custom_js" src="<?php echo $rootUrl; ?>js/custom.js?v=<?php echo $cacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/lodash.min.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/aws-s3-sdk.js?v=<?php echo $assetCacheVersion; ?>"></script>
<script defer src="<?php echo $asseturl; ?>js/i18n.js?v=<?php echo $assetCacheVersion; ?>" type="module"></script>
<script defer src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.18/js/bootstrap-select.min.js"></script>
<?php 
//@ER: 74207 start. ajax.v1.js script added
if (isset($isAudioExists) && $isAudioExists == true) { 
?>
    <script defer id="ajaxScript" src="<?php echo $asseturl; ?>js/ajax.v1.js?v=<?php echo $assetCacheVersion; ?>" type="text/javascript"></script>
<?php } ?>
var components={};
const app = Vue.createApp({
    components: components,
    mounted() {
            setTimeout(() => {
                JsLoadingOverlay.hide();
            }, 2000)
        },
    methods: {
        
        
    }
    });
app.mount("#app");
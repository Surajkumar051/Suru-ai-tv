<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<div id="app">  
        <section  class="geoblock-section" >
            <img  vd-node="image" src="<?php echo $asset_cdn_url; ?>geoblock1.png" >   
            <div class="geoblock-textDIv">
                <h2 class="nsatxt">Not in Service Area</h2>
                <p class="nsatxtp">Sorry this site is currently not available in your location</p>
            </div>   
        </section>
</div>  
<script src="<?php echo $rootUrl; ?>pages/geo-restriction/geo-restriction.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

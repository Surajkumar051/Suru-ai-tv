<div id="app">
    <div>
        <player_one
            label1="Share"
            label2="Share this video"
            label3="Link"
            label4="Social"
            label5="Crew"
            id="player_player_one_1" />
    </div>
    <div>
        <reviewrating_one
            label1="Ratings & Review"
            label2="Add a review"
            label3="Ratings"
            label4="Review"
            label5="Post Review"
            label6="Data Exists"
            id="player_reviewrating_one_1" />
    </div>
</div>

<script src="<?php echo $rootUrl; ?>pages/player/player.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

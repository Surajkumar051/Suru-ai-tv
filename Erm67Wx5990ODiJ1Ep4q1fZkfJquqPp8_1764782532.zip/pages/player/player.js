let {default:player_one}=await import(window.importLocalJs('widgets/player/player-one.js'));
let {default:reviewrating_one}=await import(window.importLocalJs('widgets/reviewrating/reviewrating-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components = {
        player_one: player_one,
        reviewrating_one: reviewrating_one
    }
const app = Vue.createApp({
    components: components
});
app.use(vuexStore);
app.mount("#app");

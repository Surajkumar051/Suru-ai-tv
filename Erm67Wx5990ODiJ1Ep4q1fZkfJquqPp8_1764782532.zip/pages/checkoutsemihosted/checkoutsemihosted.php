<!--Checkout page 1 start Here-->
<div id="app">
    <div id="iyzipay-checkout-form" class="responsive"></div> <!--ER-120069-->
    <!-- Toast start here -->
    <div class="toastCustom" role="alert" aria-live="assertive" aria-atomic="true" style="width: 400px;">
        <div class="toastCustom-header">
            <strong class="mr-auto">{{i18n('Please do not close this page after successful payment. Page will redirect automatically')}}</strong>
            <button type="button" class="ml-2 mb-1 closeToast" data-dismiss="toast" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <!-- Toast ends here -->
</div>
<script src="<?php echo $rootUrl; ?>pages/checkoutsemihosted/checkoutsemihosted.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

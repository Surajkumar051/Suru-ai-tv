let { i18n } = await import(window.importAssetJs('js/i18n.js'));

var components = {};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            subscription_page_response: '',
            gateway_code: ''
        };
    },
    mounted() {
        this.gateway_code = window.location.pathname.toString().split("/")[2];
        if(this.gateway_code === "iyzico"){ //ER-120069
            this.readIndexDb();
        }
         document.getElementsByClassName('toastCustom')[0].classList.add('show');
    },
    methods: {
        i18n,
        openIndexDb() {
            return new Promise((resolve, reject) => {
              const request = indexedDB.open("MuviDB", 1);

              request.onupgradeneeded = function (event) {
                const db = event.target.result;
                db.createObjectStore("checkoutFormContent", { keyPath: "id" }); // Create object store
              };

              request.onsuccess = function () {
                resolve(request.result); // Return the opened database
              };

              request.onerror = function () {
                reject("Failed to open IndexedDB");
              };
            });
          },
        async readIndexDb() {
            const db = await this.openIndexDb();
            const tx = db.transaction("checkoutFormContent", "readonly");
            const store = tx.objectStore("checkoutFormContent");

            const data = store.get("iyzicoResopnse");

            data.onsuccess = () => {
                //console.log("Data read:", data.result?.value);
                this.loadIyzicoScripts(data.result?.value);
            };
            data.onerror = () => console.error("Read failed");
        },
        async loadIyzicoScripts(subscription_link) { //ER-120069
            try {
                
                // Parse the HTML string into a document
                const parser = new DOMParser();
                const doc = parser.parseFromString(subscription_link, 'text/html');

                // Extract and inject each script
                doc.querySelectorAll('script').forEach(originalScript => {
                  const newScript = document.createElement('script');
                  if (originalScript.src) {
                    newScript.src = originalScript.src;
                  } else {
                    newScript.textContent = originalScript.textContent;
                  }
                  document.body.appendChild(newScript);
                });

              } catch (error) {
                console.error('Failed to load Iyzico script:', error);
              }
        }
    }
});
app.mount("#app");

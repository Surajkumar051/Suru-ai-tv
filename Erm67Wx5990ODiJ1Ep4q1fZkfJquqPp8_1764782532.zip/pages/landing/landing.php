<mvuivd-myapp>
<div id="muvi-landing1">
        <section class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand callByAjax" href="/"><img src="<?php echo $rootUrl; ?>img/logo.png" alt="MUVI1" /></a>
                            <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button> -->

                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <!--Banner Section Start Here-->
        <section class="banner-section video-homepage-banner">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="page-heading">
                            <h1>Unrivalled Video Streaming Experience</h1>
                            <p>Experience astonishing video quality and player experience with Phenoix by Muvi. Craete
                                audio steamig service
                                for a wider variety of contents starting from audio streaming to podcasts in mutiple
                                language across multiple paltforms</p>
                            <ul>
                                <li><a href="register" class="active callByAjax">Sign Up</a></li>
                                <li><a href="about" class="callByAjax">Learn More</a></li>
                            </ul>
                        </div>
                        card
                    </div>
                </div>
                <template v-if="contentTitle && !noDatafound">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div class="tabviews  banner-tabs w-100">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item" v-for="(itemData,index) in contentTitle">
                                        <a class="nav-link callByAjax" data-toggle="tab" :href="'#'+itemData.feature_section_name" role="tab" aria-controls="home" aria-selected="true" @click="tabChange(itemData.feature_section_name)">{{itemData.feature_section_name}}</a>
                                    </li>
                                </ul>

                                <div class="tab-content w-100" id="myTabContent" v-for="(itemData,index) in contentTitle">
                                    <div class="tab-pane fade show " v-bind:class="isActive==''?(index==0?'active':'') :  isActive == itemData.feature_section_name ? 'active': ''" :id="itemData.feature_section_name" role="tabpanel" aria-labelledby="home-tab">

                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                                <div class="video-home-slider product-listing" class="">
                                                    <div class="owl-newreleases owl-carousel owl-theme">
                                                        <div class="item" v-for="Data in itemData.section_content_list.content_list">
                                                            <div class="tiles">
                                                                <div class="picture">

                                                                    <img v-if="Data.posters.website != null && Data.posters.website[0].file_url !== ''" :src="Data.posters.website[0].file_url" alt="Godzilla" class="mw-100">
                                                                    <img v-if="Data.posters.website == null || Data.posters.website[0].file_url === ''" :src="Data.no_image_available_url" alt="Godzilla" class="mw-100">
                                                                    <!--Button Show on Hover start Here-->
                                                                    <div class="box-hover" v-if="Data.content_asset_uuid != ''">
                                                                        <a class="callByAjax" v-if="Data.content_level == 0 && Data.content_asset_type == 2 " href="javascript:void(0);">Play Now</a>
                                                                        <a class="callByAjax" v-if="Data.content_level == 0 && Data.content_asset_type == 1 " href="javascript:void(0);">Play Now</a>
                                                                        <a class="callByAjax" v-if="(Data.content_trailer_uuid !== null && Data.content_trailer_uuid !== '') && Data.content_asset_type == 1 " href="javascript:void(0);">View Trailer</a>

                                                                    </div>
                                                                    <!--Button Show on Hover End Here-->

                                                                </div>



                                                                <div class="data">
                                                                    <a class="callByAjax" href="javascript:void(0);">
                                                                        <span>{{Data.content_name}}</span></a>
                                                                    <a class="callByAjax" href="javascript:void(0);">
                                                                        <p>Various Artists</p>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
        </section>
        <!--Banner Section End Here-->
        <!--Why Phoeni Start Here-->
        <section class="why-phoeni">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <h2>Why Phoenix</h2>
                        <p>Et eu qui cillum tempor amet quis et anim commodo minim. Minim elit culpa magna enim
                            <br />nostrud adipisicing elit exercitation.
                            Voluptate laboris laborum proident minim est enim voluptate.
                        </p>
                        <ul>
                            <li>12K+ <span>Artists & Production House</span></li>
                            <li>100k+ <span>Movies</span></li>
                            <li>25k+ <span>Web Series Episodes</span></li>
                            <li>300K + <span>Viewers</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!--Why Phoeni End Here-->
        <!--Feature Packed to Delight the Viewers start Here-->
        <section class="homepage-feature">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-2 order-sm-2 order-md-1 order-lg-1">
                        <div class="pictures">
                           <img src="<?php echo $rootUrl; ?>img/space-race-1.png" alt="space race" class="mw-100" />
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-1 order-sm-1 order-md-2 order-lg-2">
                        <div class="data">
                            <h2>Feature Packed to Delight the Viewers</h2>
                            <p>Et eu qui cillum tempor amet quis et anim commodo minim.
                                Minim elit culpa magna enim nostrud adipisicing elit exercitation.
                                Voluptate laboris laborum proident minim est enim voluptate.
                                Ex ad mollit labore id ullamco et veniam est labore aliquip dolor culpa.</p>
                            <ul>
                                <li><span><i class="fas fa-chevron-right"></i></span> Pariatur qui laborum labore qui
                                    commodo </li>
                                <li><span><i class="fas fa-chevron-right"></i></span> magna duis nisi ad quis nostrud do
                                    aute elit.</li>
                                <li><span><i class="fas fa-chevron-right"></i></span> proident minim est enim voluptate
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="data">
                            <h2>True Immersive Viewing Experience</h2>
                            <p>Et eu qui cillum tempor amet quis et anim commodo minim.
                                Minim elit culpa magna enim nostrud adipisicing elit exercitation.
                                Voluptate laboris laborum proident minim est enim voluptate.
                                Ex ad mollit labore id ullamco et veniam est labore aliquip dolor culpa.</p>
                            <ul>
                                <li><span><i class="fas fa-chevron-right"></i></span> Pariatur qui laborum labore qui
                                    commodo </li>
                                <li><span><i class="fas fa-chevron-right"></i></span> magna duis nisi ad quis nostrud do
                                    aute elit.</li>
                                <li><span><i class="fas fa-chevron-right"></i></span> proident minim est enim voluptate
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                        <div class="pictures mt-50">
                        <img src="<?php echo $rootUrl; ?>img/space-race-2.png" alt="space race" class="mw-100" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feature Packed to Delight the Viewers End Here-->

    </div>
</mvuivd-myapp>
<?php 
    $planWidgetPath=file_exists($custWidgetPath."myplan/myplan-one.php")?$custWidgetPath:$widgetPath;
    include  $planWidgetPath."myplan/myplan-one.php";
     ?>
<script src="<?php echo $rootUrl; ?>js/landing-one.js" type="module"></script>



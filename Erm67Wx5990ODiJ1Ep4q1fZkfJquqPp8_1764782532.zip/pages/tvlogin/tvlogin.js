let {default:codebase_tv_login_one}=await import(window.importLocalJs('widgets/codebase-tv-login/codebase-tv-login-one.js'));
var components= { codebase_tv_login_one: codebase_tv_login_one };

JsLoader.show();
let isloggedIn = localStorage.getItem("isloggedin");
if(!isloggedIn){
    JsLoader.show();
    window.location.href = "/sign-in";
}else{
    JsLoader.hide();
    const app = Vue.createApp({
        components: components
    });
    app.mount("#app");
}
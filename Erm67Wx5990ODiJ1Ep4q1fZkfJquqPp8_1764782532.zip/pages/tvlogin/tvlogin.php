<div id="app">
    <codebase_tv_login_one 
        label1="Hi" 
        label2="Enter the code displayed on your TV" 
        label3="Connect"
        label4="Congratulations !"
        label5="Connected to TV successfully!"
        label6="Now you can close this tab"
    />
</div>
<script src="<?php echo $rootUrl; ?>pages/tvlogin/tvlogin.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
<script src="<?php echo $asseturl; ?>js/loader-helper.js"></script>
<script src="<?php echo $asseturl; ?>js/loader.js" type="module"></script>
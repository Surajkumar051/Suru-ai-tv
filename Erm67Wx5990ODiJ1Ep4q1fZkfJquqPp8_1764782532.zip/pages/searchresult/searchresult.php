<div id="app">
    <div>
        <searchlistdetails_one
            id="searchresult_search_list_one_1" 
            label1="Search Results for"
            label2="Play"
            label3="Play"
            label4="No Result found !"
            label5="Watch Trailer"
            label6="Play All"
            label7="Play"
            label8="Videos"
            label9="Audios"
            label10="Series"
            label11="Playlist"
            label12="UGC"
            label13="Minis"
            label14="Result showing for"
            label15="No Record Found"
            label16="Creators"
            label17="Content Partners"
            label18="Free"
            label19="Documents"
            label20="Download"
            label21="Open"
            label22="Pre-order"
        />
    </div>
    <div>
        <content_purchase_one 
            id="searchresult_content_purchase_one_1" 
        />
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/searchresult/searchresult.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

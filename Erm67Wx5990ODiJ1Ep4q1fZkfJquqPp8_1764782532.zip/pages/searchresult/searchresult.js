let {default:searchlistdetails_one}=await import(window.importLocalJs('widgets/searchlistdetails/searchlistdetails-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components= {
    searchlistdetails_one: searchlistdetails_one,
    content_purchase_one: content_purchase_one
};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
});
app.use(vuexStore);
app.mount("#app");

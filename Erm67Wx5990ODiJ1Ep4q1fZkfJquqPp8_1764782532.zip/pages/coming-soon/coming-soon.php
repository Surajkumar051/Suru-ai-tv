<div id="app">  
   <div>
      <coming_soon_one 
      id="coming-soon_coming_soon_1"
      label1="Coming Soon"
      label2="We can't wait to share what we have in store with you. Get ready to embark on an incredible journey with us."
      label3='<a vd-name="facebook" href="https://www.facebook.com/muvidotcom" rel="noopener noreferrer external" class=""><i class="fab fa-facebook-f"></i></a>'
      label4='<a vd-name="twitter" href="https://twitter.com/muvi" rel="noopener noreferrer external" class=""><i class="fa-brands fa-x-twitter"></i></a>'
      label5='<a vd-name="instagram" href="https://www.instagram.com/muvi_com/" rel="noopener noreferrer external" class=""><i class="fab fa-instagram"></i></a>'
      label6='<a vd-name="youtube" href="https://www.youtube.com/c/MuviLLC" rel="noopener noreferrer external" class=""><i class="fab fa-youtube"></i></a>'
      label7='&copy; 2023 Muvi LLC, All Rights Reserved.' />
   </div>
</div>  
<script src="<?php echo $rootUrl; ?>pages/coming-soon/coming-soon.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

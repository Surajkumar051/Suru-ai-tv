let {default:coming_soon_one}=await import(window.importLocalJs('widgets/coming-soon/coming-soon-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components= { coming_soon_one: coming_soon_one };
const app = Vue.createApp({
    components: components,
    mounted() {
        JsLoadingOverlay.hide();
    },

});
app.use(vuexStore);
app.mount("#app");
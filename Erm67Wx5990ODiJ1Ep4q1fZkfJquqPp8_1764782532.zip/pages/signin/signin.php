<div id="app">
    <login_one 
        id="login_one_sign-in_1"
        label1="Login to your account" 
        label2="Login with your email" 
        label3="Remember me"
				label4='<a href="/password-recovery" vd-node="styleOnly" class=""> Forgot Password? </a>'
        label5="Login"
        label6=" "
        label7='<a vd-node="link" href="/sign-up" class=""><span class="mr-10"><img src="<?php echo $asset_cdn_url; ?>left-arrow-icon.png" al="left"></span> Back to Sign Up </a>' 
        label8="willie.jennings@example.com" 
        label9="******" 
        label10="" 
        label11=""
        label12="Enter mobile number"
        label13="Next"
        label14="Didn't receive OTP?"
        label15="Resend"
        label16="Verify & Login"
        label17="Login to your account"
        label18="Login to your account"
        label19=" "
        label20='<a vd-node="link" href="/sign-up" class=""><span class="mr-10"><img src="<?php echo $asset_cdn_url; ?>left-arrow-icon.png" al="left"></span> Back to Sign Up </a>'
        label21=" "
        label22='<a vd-node="link" href="/sign-up" class=""><span class="mr-10"><img src="<?php echo $asset_cdn_url; ?>left-arrow-icon.png" al="left"></span> Back to Sign Up </a>'
        label23="Enter mobile number"
        label24='Don’t have an account?<a vd-node="link" href="/sign-up" class=""> Click here</a> to' 
        label25="create an account"
        label26='Don’t have an account?<a vd-node="link" href="/sign-up" class=""> Click here</a> to' 
        label27="create an account"
        label28='Don’t have an account?<a vd-node="link" href="/sign-up" class=""> Click here</a> to' 
        label29="create an account"
        label30="OR"
        label31="Continue with Google"
        label32="OR"
        label33="Continue with Google"
        label34="Login To Your Account"
        label35="Complete the signin process by providing the following information."
        label37="Please Enter Mobile Number"
        label38="Get OTP"
        label39="Continue with Apple"
        label40="Continue with Apple"
        label41="Continue with Facebook"
        label42="Continue with Facebook"
        label43="youremail@example.com"
        label44=""  
        label45="Email"
        label46="Mobile Number"
        label47="Enter email"
        label48="Next"
        />
</div>
<script src="<?php echo $rootUrl; ?>pages/signin/signin.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

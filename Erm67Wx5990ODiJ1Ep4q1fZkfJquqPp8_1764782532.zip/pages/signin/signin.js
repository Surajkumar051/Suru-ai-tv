let {default:login_one}=await import(window.importLocalJs('widgets/login/login-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components= {login_one: login_one};
const app = Vue.createApp({
    components: components
});
app.use(vuexStore);
app.mount("#app");
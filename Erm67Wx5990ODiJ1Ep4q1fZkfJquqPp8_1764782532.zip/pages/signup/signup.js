let {default:register_one}=await import(window.importLocalJs('widgets/register/register-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components= { register_one: register_one };
const app = Vue.createApp({
    components: components

});
app.use(vuexStore);
app.mount("#app");
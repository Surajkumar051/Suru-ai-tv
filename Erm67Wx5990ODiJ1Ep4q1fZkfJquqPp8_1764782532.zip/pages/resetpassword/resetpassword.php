<div id="app">
        <resetpassword_one 
                id="resetpassword_one_1"
                label1="Reset Password" 
                label2="Create an new password for your account by typing out the details below" 
                label3="RESET PASSWORD"
                label4="Back to login" 
                label5="New Password"  
                label6="Confirm Password"  
                label7=""  
                label8=""
        />
</div>
<script src="<?php echo $rootUrl; ?>pages/resetpassword/resetpassword.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

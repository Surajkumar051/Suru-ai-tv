<vd-component name="purchase-history/purchase-history-one"
label1="History"
label2="Receipt"
label3="No Records found !"
/>

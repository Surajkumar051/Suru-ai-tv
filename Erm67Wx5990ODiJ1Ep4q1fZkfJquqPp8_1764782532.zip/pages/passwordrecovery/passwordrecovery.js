let {default:forgotpwd_one}=await import(window.importLocalJs('widgets/forgotpwd/forgotpwd-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components= { forgotpwd_one: forgotpwd_one };

const app = Vue.createApp({
    components: components

});
app.use(vuexStore);

app.mount("#app");
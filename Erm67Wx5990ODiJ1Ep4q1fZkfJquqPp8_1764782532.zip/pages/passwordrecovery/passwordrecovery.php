<div id="app">
    <forgotpwd_one 
        label1="Password recovery" 
        label2="Enter your registered email below to receive password reset instructions." 
        label3="SUBMIT"
        label4="Back to login"
        label5="willie.jennings@example.com"
        label6=""
        />
</div>
<script src="<?php echo $rootUrl; ?>pages/passwordrecovery/passwordrecovery.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
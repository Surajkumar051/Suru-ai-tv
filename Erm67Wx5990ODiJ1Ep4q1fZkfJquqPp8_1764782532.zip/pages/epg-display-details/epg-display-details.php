<style>
   
  .epg-sec ul li a:hover{
    color: #fff !important;
    border-radius: 48px;
    border: 1px solid rgba(255, 104, 0, 0.40);
    background: rgba(255, 104, 0, 0.16);
    opacity: 1;
    box-shadow: -1px 0px 0px 0px rgba(0, 0, 0, 0.06) inset;
}
 .hightlitday{
    opacity: 1;
    border-radius: 48px;
    background: #9A6617  !important;
    border: none;
    text-align: center;
    min-width: 200px;
    text-transform: uppercase;
    box-shadow: -1px 0px 0px 0px rgba(0, 0, 0, 0.06) inset;
} 
.epg-sec table.parent-table tbody td .inner-text {
    padding-left: 0px;
}
.epg-sec table.parent-table tbody td>div:first-child {
    margin-left: 24px;
    border-right: 1px solid rgba(255, 255, 255, 0.32);
}  
.epg-sec table.parent-table>tbody>tr>td:first-child .channel {
    text-align: center;
}
.epg-sec table.parent-table thead th {
    border-right: 1px solid rgba(255, 255, 255, 0.32);
    padding-left: 8px !important;
}
.epg-sec table.parent-table tbody td:not(:first-child){
    gap: 0px;
}
.epg-sec table.parent-table thead th:nth-child(2) {
    padding-left: 16px !important;
} 
.epg-sec table.parent-table tbody td:not(:first-child)>div {
    border-right: 1px solid rgba(255, 255, 255, 0.32);
}
.epg-sec .table-responsive .time-line {
    position: absolute;
    top: 60px !important;
    bottom: 0px !important;
    right: auto;
    z-index: 99999;
    height: auto; 
}
.epg-sec table.parent-table>tbody>tr>td:first-child {
    z-index: 100000 !important;
    background: #000;
}
</style>
<div id="app">
<div>
    <content_banner_one
        label2="..ReadMore"
        label3="Play"
        label7="Share this video"
        label8="Link"
        label9="Social"
        label12="Play"
        label13="Watch Trailer"
        label19="Play All"
        id="content_content_banner_one_1"
        />
    </div>
<epg_display_details_one id="epg_display_details_one" />
</div>
<script src="<?php echo $rootUrl; ?>pages/epg-display-details/epg-display-details.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

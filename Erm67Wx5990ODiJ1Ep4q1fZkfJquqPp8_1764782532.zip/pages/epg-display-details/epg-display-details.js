let {default:banner_one}=await import(window.importLocalJs('widgets/banner/banner-one.js'));
let {default:epg_display_details_one}=await import(window.importLocalJs('widgets/epg-display-details/epg-display-details-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components = {
    banner_one: banner_one,
    epg_display_details_one:epg_display_details_one,
};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            // isPpvmodel: localStorage.getItem("hidemodel"),
            // selectedContentUuid: '',
            // monetizationMethods: []
        }
    },
    methods: {
        
    }
});
app.use(vuexStore);
app.mount("#app");

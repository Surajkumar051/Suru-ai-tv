<div id="app">
<section class='pagenot-found'>
    <img src="<?php echo $asset_cdn_url.'pagenot-foung.png'?>" alt="page notfound" />
    <div class="page-notfound">
        <h1 class="i18n">Page Not Found</h1>
        <a href="/home" vd-node="styleOnly" class="i18n">Back to Home</a>
    </div>
</section>
</div>

<script src="<?php echo $rootUrl; ?>pages/404page/404page.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
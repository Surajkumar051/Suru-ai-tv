let {default:trailer_one}=await import(window.importLocalJs('widgets/trailer/trailer-one.js'));
var components= {
    trailer_one: trailer_one,
};
const app = Vue.createApp({
    components: components,
    mounted() {
        console.log('in a trailer js')
    }
});
app.mount("#app");

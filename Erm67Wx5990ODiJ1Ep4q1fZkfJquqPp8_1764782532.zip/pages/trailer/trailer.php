<div id="app">
    <div>
        <trailer_one 
        label1="Trailer"
        id="trailer_trailer_one_1"
        />
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/trailer/trailer.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

<div id="app">
  <div>
    <child_details_one
            id="child_details_child_details_one_1"
            label1="Episodes of"
            label2="Play"
            label3="Play All"
            label4="Watch Trailer"
            label4="Play"
            label5="Free"
            label6="Download"
            label7="Open"
                label8="Pre-order"
    />
    </div>
    <div>
        <content_purchase_one 
            id="child_details_content_purchase_one_1" 
        />
    </div>
</div>

<script src="<?php echo $rootUrl; ?>pages/child-details/child-details.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

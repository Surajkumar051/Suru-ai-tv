let {default:user_banner_one}=await import(window.importLocalJs('widgets/user-banner/user-banner-one.js'));
let {default:user_contents_one}=await import(window.importLocalJs('widgets/user-contents/user-contents-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components= {
    user_banner_one: user_banner_one,
    user_contents_one: user_contents_one,
    content_purchase_one:content_purchase_one
};
const app = Vue.createApp({
    components: components,
    mounted() {
        
    }
});
app.use(vuexStore);
app.mount("#app");

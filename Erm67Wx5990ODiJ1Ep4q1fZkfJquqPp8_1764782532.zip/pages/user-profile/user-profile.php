<div id="app">
    <div>
        <user_banner_one 
            id="user_profile_user_banner_one_1"
            label1="Joined"/>
    </div>
    <div> 
        <user_contents_one 
            id="user_profile_user_contents_one_1"
            label1="All"
            label2="Video"
            label3="Audio"
            label4="Playlist"
            label5="About"
            label6="UGC"
            label7="Minis"
            label8="Views"
            label9="Play"
            label10="Watch Trailer"
            label11="Play All"
            label12="No Content present."
            label13="Stats"
            label14="Joined"
            label15="Description"
            label16="Free"
            
        />
    </div>
    <div>
        <content_purchase_one 
            id="searchresult_content_purchase_one_1" 
        />
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/user-profile/user-profile.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

<div id="app">
    <section class="banner-section">
      <div class="container-fluid">
          <div class="row">                
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 p-0 m-0">
                  <div class="banner-content">
                      <img vd-node="image" src="<?php echo $asset_cdn_url; ?>aboutus-banner.jpg" alt="about us" class="mw-100" />                        
                  </div>
              </div>               
          </div>
      </div>        
  </section>
    <!--Banner Section End Here-->

    <!--About Title Secton Start Here-->
    <section class="aboutus-title">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 col-sm-12 co-md-12 col-lg-12 col-xl-12">
            <h1 class="font-32 white-color i18n">About us</h1>
            <p class="samll-content white-color i18n">Phoenix lets you play the music you just have to hear, instantly.Jump in and explore thousands of tracks (and counting), 
              and discover artists and tracks you'll love with personalized recommendations from the our in house Editors. Phoneix works across all your devices, 
              both online and offline, with no listening limits. It's music at your fingertips for waking up, getting going, chilling out, living life.</p>
          </div>
        </div>
      </div>  
    </section>
    <!--About Title Secton End Here-->

    <!--About us content start here-->
    <section class="about-section">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 col-sm-12 co-md-3 col-lg-6 col-xl-6">
            <div class="about-box">
              <h2 class="font-32 white-color i18n">Stream your favorite Content</h2>
              <p class="samll-content white-color i18n">With our library of over 70 million tracks and 250,000 videos,<br/> you’ll get the ultimate music experience.</p>
              <p class="samll-content white-color i18n">Create a playlist or try one of ours, hand-curated by music<br/> editors and even the artists themselves.</p>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 co-md-3 col-lg-6 col-xl-6">
            <div class="about-picture">
              <ul>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-1.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-2.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-3.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-4.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-5.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-6.jpg" alt="about" class="mw-100"/></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-12 co-md-3 col-lg-6 col-xl-6">
            <div class="about-picture">
              <ul>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-1.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-2.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-3.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-4.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-5.jpg" alt="about" class="mw-100"/></li>
                <li><img vd-node="image" src="<?php echo $asset_cdn_url; ?>about-6.jpg" alt="about" class="mw-100"/></li>
              </ul>
            </div>
          </div>          
          <div class="col-xs-12 col-sm-12 co-md-3 col-lg-6 col-xl-6">
            <div class="about-box">
              <h2 class="font-32 white-color i18n">Stream your favorite Content</h2>
              <p class="samll-content white-color i18n">With our library of over 70 million tracks and 250,000 videos,<br/> you’ll get the ultimate music experience.</p>
              <p class="samll-content white-color i18n">Create a playlist or try one of ours, hand-curated by music<br/> editors and even the artists themselves.</p>
            </div>
          </div>          
        </div>
      </div>
    </section>
</div>
<script src="<?php echo $rootUrl; ?>pages/about/about.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
<!--Checkout page 1 start Here-->
<div id="app">
    <div class="checkout-section sucess-checkout">
        <!--Image Section start here-->
        <div class="illustation">
            <img  vd-node="image" src="<?php echo $asset_cdn_url; ?>sorry.png" alt="You payment Failed" class="mw-100">
        </div>
        <!--Image Section End here-->
        <!--Massage Section start Here-->
        <div class="massage">
            <h1 id="title">{{i18n('Sorry !')}}</h1>
            <p id="subtitle" class="mb-2">{{i18n('Your payment Failed')}}</p>
        </div>
        <!--Massage Section End Here-->
        <p class="notes">{{i18n('You will be redirected to the site within 10 seconds')}}</p>
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/checkoutfail/checkoutfail.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

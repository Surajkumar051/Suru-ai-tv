let { expireSST } = await import(window.importAssetJs('js/webservices.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));

var components = {};
const app = Vue.createApp({
    components: components,
    mounted() {
        JsLoadingOverlay.hide();

        const url = new URLSearchParams(window.location.search);

        //103551-start
        const redirectAfterPurchase = localStorage.getItem("redirectAfterPurchase");
        if(redirectAfterPurchase){
            localStorage.removeItem("redirectAfterPurchase");
        }
        //103551-end

        if (url.has('muvi_sst_token')) {
            document.getElementById('title').innerText = i18n('Sorry !');
            document.getElementById('subtitle').innerText = i18n("Your Payment Failed");

            expireSST({
                sst_token: url.get('muvi_sst_token'),
                status: 'expire'
            }).then(expire_sst_response => {
                console.log(expire_sst_response);
                //103551-add condition to redirect to redirectUrl(start)
                if (redirectAfterPurchase) {
                    window.location.replace(redirectAfterPurchase);
                }else{
                    window.location.replace(url.get('callback_url'));
                }
                //103551-add condition to redirect to redirectUrl(end)

            }, ex => {
                console.log(ex);
            });
        } else {
            if (url.has('error_message')) { 
                document.getElementById('subtitle').innerText += "\n"+ i18n(url.get('error_message'));
            }
            setTimeout(() => {
                //103551-add condition to redirect to redirectUrl(start)
                if (redirectAfterPurchase) {
                    window.location.replace(redirectAfterPurchase);
                }else{
                    window.location.replace('/');
                }
                //103551-add condition to redirect to redirectUrl(end)
            }, 10 * 1000);
        }

    },
    methods: {
        i18n
    }
});
app.mount("#app");

let {default:category_list_one}=await import(window.importLocalJs('widgets/category-list/category-list-one.js'));
let {default:TooltipDirective}=await import(window.importAssetJs('js/directives/tooltip.directive.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components={
    category_list_one: category_list_one
};
const app = Vue.createApp({
    components: components
});

app.directive('tooltip', TooltipDirective);

app.use(vuexStore);
app.mount("#app");

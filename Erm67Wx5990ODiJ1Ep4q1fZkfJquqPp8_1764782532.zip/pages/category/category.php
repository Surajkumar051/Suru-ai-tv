<div id="app">
    <div>
        <category_list_one
            id="category_category_list_one_1"
            label1="Play"
            label2="Watch Trailer"
            label3="Play All"
            label4="Play"
            label5="Free"
            label6="Download"
            label7="Open"
             label8="Pre-order"
            />
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/category/category.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

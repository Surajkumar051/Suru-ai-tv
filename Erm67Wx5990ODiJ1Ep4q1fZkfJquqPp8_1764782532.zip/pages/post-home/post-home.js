let {default:banner_one}=await import(window.importLocalJs('widgets/banner/banner-one.js'));
let {default:default_featureslist_one}=await import(window.importLocalJs('widgets/default-featureslist/default-featureslist-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
let {default:multi_profile_one}=await import(window.importLocalJs('widgets/multi-profile/multi-profile-one.js'));

var components = {
    banner_one: banner_one,
    default_featureslist_one: default_featureslist_one,
    content_purchase_one:content_purchase_one,
    multi_profile_one:multi_profile_one
};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
    methods: {
        
    }
});
app.use(vuexStore);
app.mount("#app");


<div id="app">
    <div>
        <banner_one
            id="post_home_banner_one_1"
            label1="Get access to unlimited movies, TV shows and more"
            label2='<a class="callByAjax" vd-readonly="true" vd-node="button" href="/about-us">About Us</a>'
            label3="Watch Now"
        />
    </div>
    <div>
        <default_featureslist_one
            id="home_default_features_list_one_1"
            label1="Play"
            label2="Watch Trailer"
            label3="Play All"
            label4="Play"
            label5="View All"
            label6="Free"
            label7="Download"
            label8="Open"
            label9="Pre-order"
        />
    </div>
    <div>
        <content_purchase_one 
            id="home_content_purchase_one_1" 
        />
    </div>
    <div>
        <multi_profile_one
            id="multi_profile_one_1"
            label1="Who is watching"
            label2="Manage Profile"
            label3="Add Profile"
            label4="Add Profile"
            label5="Image"
            label6=" Edit"
            label7="Name"
            label8="Enter name"
            label9="Maturity Setting"
            label10="Done"
            label11="Cancel"
            label12="Edit Profile"
            label13="Image"
            label14=" Edit"
            label15="Name"
            label16="Enter name"
            label17="Maturity Setting"
            label18="Done"
            label19="Cancel"
            label20="Delete Profile"
            label21="Are you sure you want to delete this profile ?"
            label22="Please note that deleting this profile will permanently remove the profile's history and activities including my library and watch history."
            label23="Confirm"
            label24="Cancel"
            label25="Done"
            label26="Manage Profiles"
            label27="Choose Profile Image"
            label28="Done"
            label29="Cancel"
            label30="Edit Profile Image"
            label31="Edit Profile Image"
            label32="Add"
            label33="Update"
        />
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/post-home/post-home.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

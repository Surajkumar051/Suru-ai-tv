let {default:castcrew_list_two}=await import(window.importLocalJs('widgets/castcrew-list/castcrew-list-two.js'));
var components= {   
        castcrew_list_two:castcrew_list_two,   
};
const app = Vue.createApp({
    data() {
        return {
           

        }
    },
    components:components,
});
app.mount("#app");
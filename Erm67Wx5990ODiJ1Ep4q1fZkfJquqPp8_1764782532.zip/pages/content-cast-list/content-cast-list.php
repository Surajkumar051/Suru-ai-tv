<div id="app">

    <div>
        <castcrew_list_two
        id="content_cast_list_castcrew_list_two_1"
        label17="Casts of" 
        />
    </div>  
    
 </div>
 <script src="<?php echo $rootUrl; ?>/pages/content-cast-list/content-cast-list.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

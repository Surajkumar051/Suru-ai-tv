<div id="app">
<content_purchase_one
        label1="Subscription"
        label2="Pay per View"
        label3="Proceed to CHECKOUT"
        label4="Entire"
        label5="Total"
        id="content_purchase_one_1"
        />
</div>
<script src="<?php echo $rootUrl; ?>pages/ppv/ppv.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

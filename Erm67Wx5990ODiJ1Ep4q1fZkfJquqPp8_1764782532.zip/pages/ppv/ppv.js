let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
var components= { content_purchase_one: content_purchase_one };

const app = Vue.createApp({
    components: components
});

app.mount("#app");
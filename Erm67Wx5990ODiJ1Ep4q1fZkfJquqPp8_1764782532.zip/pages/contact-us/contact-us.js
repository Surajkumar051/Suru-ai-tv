let {default:contact_us_one}=await import(window.importLocalJs('widgets/contact-us/contact-us-one.js'));
var components= { contact_us_one: contact_us_one };
const app = Vue.createApp({
    components: components,
    mounted() {
        JsLoadingOverlay.hide();
    },

});
app.mount("#app");
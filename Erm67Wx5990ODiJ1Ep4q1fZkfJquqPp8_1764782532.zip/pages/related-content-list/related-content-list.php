<div id="app">

    <div>
        <related_content_two
        id="related_content_list_related_content_two_1"
        label1="Related Contents of" 
        label2="Play" 
        label4="Watch Trailer"
        label5="Play All" 
        label6="Play" 
        label7="Related Playlist of" 
        label8="Free"
        label9="Download"
        label10="Open"
        label11="Pre-order"
        />
    </div>  
    <div>
        <content_purchase_one 
            id="home_content_purchase_one_1" 
        />
    </div>
 </div>
 <script src="<?php echo $rootUrl; ?>/pages/related-content-list/related-content-list.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

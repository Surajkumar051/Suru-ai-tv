let {default:related_content_two}=await import(window.importLocalJs('widgets/related-content/related-content-two.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components= {
   
        related_content_two:related_content_two,
        content_purchase_one:content_purchase_one
   
};
const app = Vue.createApp({
    data() {
        return {
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
    components:components,
});
app.use(vuexStore);
app.mount("#app");

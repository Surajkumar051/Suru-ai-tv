<div id="app">
    <div>
        <bell_notification_one 
            id="bell_notification_one"
            label1="Notifications"/>
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/bellnotifications/bellnotifications.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

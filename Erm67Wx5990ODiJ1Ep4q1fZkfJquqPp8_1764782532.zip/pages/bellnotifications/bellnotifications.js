let {default:bell_notification_one}=await import(window.importLocalJs('widgets/bell-notification/bell-notification-one.js'));
var components= {
    bell_notification_one: bell_notification_one
};
const app = Vue.createApp({
    components: components,
    mounted() {
       
    }
});
app.mount("#app");
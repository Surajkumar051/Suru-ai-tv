let {default:playlist_details_one}=await import(window.importLocalJs('widgets/playlist-details/playlist-details-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:reviewrating_one}=await import(window.importLocalJs('widgets/reviewrating/reviewrating-one.js'));
let {default:playlist_banner_one}=await import(window.importLocalJs('widgets/playlist-banner/playlist-banner-one.js'));
let {default:related_content_one}=await import(window.importLocalJs('widgets/related-content/related-content-one.js'));
let {default:multi_profile_one}=await import(window.importLocalJs('widgets/multi-profile/multi-profile-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components= {
        playlist_details_one: playlist_details_one,
        content_purchase_one:content_purchase_one,
        reviewrating_one:reviewrating_one,
        playlist_banner_one:playlist_banner_one,
        related_content_one:related_content_one,
        multi_profile_one:multi_profile_one
};
const app = Vue.createApp({
    data() {
        return {


        }
    },
    components:components,
});
app.use(vuexStore);
app.mount("#app");

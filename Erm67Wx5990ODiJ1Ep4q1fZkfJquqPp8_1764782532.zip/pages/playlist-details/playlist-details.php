<div id="app">
   <div>
        <playlist_banner_one
        id="playlist_details_playlist_banner_one_1"
        label2="..ReadMore"
        label3="Play"
        label7="Share this video"
        label8="Link"
        label9="Social"
        label12="Play"
        label13="Watch Trailer"
        label19="Play All"
        label20="Videos"
        label21="Tracks"
        label22="Documents"
        />
    </div>
        <div>
                <playlist_details_one
                id="playlist_details_playlist_details_one_1"
                label3="Play"
                label12="Play"
                label13="Watch Trailer"
                label19="Play All"
                label20="Free"
                label21="Download"
                label22="Open"
                label23="Pre-order"
                />
        </div>
        <div>
                <related_content_one
                id="playlist_details_related_content_one_1"
                label1="Related Playlist"
                label2="Play"
                label3="Play"
                label4="Watch Trailer"
                label5="Play All"
                label6="Play"
                label7="View All"
                label9="Download"
                label10="Open"
                label11="Pre-order"
                />
        </div>

        <div>
                <reviewrating_one
                id="playlist_details_reviewrating_one_1"
                label1="Ratings & Review"
                label2="Add a review"
                label3="Ratings"
                label4="Review"
                label5="Post Review"
                label6="Data Exists"
                label7="Reviews"/>
        </div>
        <div>
                <multi_profile_one
                id="multi_profile_one_1"
                label1="Who is watching"
                label2="Manage Profile"
                label3="Add Profile"
                label4="Add Profile"
                label5="Image"
                label6=" Edit"
                label7="Name"
                label8="Enter name"
                label9="Maturity Setting"
                label10="Done"
                label11="Cancel"
                label12="Edit Profile"
                label13="Image"
                label14=" Edit"
                label15="Name"
                label16="Enter name"
                label17="Maturity Setting"
                label18="Done"
                label19="Cancel"
                label20="Delete Profile"
                label21="Are you sure you want to delete this profile ?"
                label22="Please note that deleting this profile will permanently remove the profile's history and activities including my library and watch history."
                label23="Confirm"
                label24="Cancel"
                label25="Done"
                label26="Manage Profiles"
                label27="Choose Profile Image"
                label28="Done"
                label29="Cancel"
                label30="Edit Profile Image"
                label31="Edit Profile Image"
                label32="Add"
                label33="Update"
                />
        </div>        
        <div>
                <content_purchase_one 
                id="home_content_purchase_one_1" 
                />
        </div>
 </div>
 <script src="<?php echo $rootUrl; ?>/pages/playlist-details/playlist-details.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

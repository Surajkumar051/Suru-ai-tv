let {default:product_details_one}=await import(window.importLocalJs('widgets/product-details/product-details-one.js'));
let {default:related_content_one}=await import(window.importLocalJs('widgets/related-content/related-content-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:castcrew_list_one}=await import(window.importLocalJs('widgets/castcrew-list/castcrew-list-one.js'));
let {default:content_banner_one}=await import(window.importLocalJs('widgets/content-banner/content-banner-one.js'));
let {default:content_addon_assets_one}=await import(window.importLocalJs('widgets/content-addon-assets/content-addon-assets-one.js'));
let {default:multi_profile_one}=await import(window.importLocalJs('widgets/multi-profile/multi-profile-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
let {default:reviewrating_one}=await import(window.importLocalJs('widgets/reviewrating/reviewrating-one.js'));
var components= {
    product_details_one: product_details_one,
    related_content_one: related_content_one,
    content_purchase_one: content_purchase_one,
    castcrew_list_one:castcrew_list_one,
    content_banner_one:content_banner_one,
    content_addon_assets_one:content_addon_assets_one,
    reviewrating_one:reviewrating_one,
    multi_profile_one:multi_profile_one
};
const app = Vue.createApp({
    data() {
        return {
            isPpvmodel: localStorage.getItem("hidemodel"),
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
    components:components
});

app.use(vuexStore);
app.mount("#app");

let {default:allplan_one}=await import(window.importLocalJs('widgets/allplan/allplan-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
let {default:multi_profile_one}=await import(window.importLocalJs('widgets/multi-profile/multi-profile-one.js'));

var components= {
    allplan_one: allplan_one,
    multi_profile_one:multi_profile_one
};
const app = Vue.createApp({
    components: components,


});
app.use(vuexStore);
app.mount("#app");

<div id="app">
<div>
    <allplan_one
            id="plan_allplan_one_1"
            label1="Choose a plan"
            label2="Watch on Apps"
            label3="Access our entire library for unlimited binging on the culture"
            label4="Member-only events & VIP passes"
            label5="Access to all of our trailers"
            label6="Weekly digest of the latest films, up- dates, news & more"
            label7="Proceed to Checkout"
            label8="Subscribe" />
</div>
<div>
        <multi_profile_one
            id="multi_profile_one_1"
            label1="Who is watching"
            label2="Manage Profile"
            label3="Add Profile"
            label4="Add Profile"
            label5="Image"
            label6=" Edit"
            label7="Name"
            label8="Enter name"
            label9="Maturity Setting"
            label10="Done"
            label11="Cancel"
            label12="Edit Profile"
            label13="Image"
            label14=" Edit"
            label15="Name"
            label16="Enter name"
            label17="Maturity Setting"
            label18="Done"
            label19="Cancel"
            label20="Delete Profile"
            label21="Are you sure you want to delete this profile ?"
            label22="Please note that deleting this profile will permanently remove the profile's history and activities including my library and watch history."
            label23="Confirm"
            label24="Cancel"
            label25="Done"
            label26="Manage Profiles"
            label27="Choose Profile Image"
            label28="Done"
            label29="Cancel"
            label30="Edit Profile Image"
            label31="Edit Profile Image"
            label32="Add"
            label33="Update"
        />
    </div>        
</div>
<script src="<?php echo $rootUrl; ?>pages/plan/plan.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
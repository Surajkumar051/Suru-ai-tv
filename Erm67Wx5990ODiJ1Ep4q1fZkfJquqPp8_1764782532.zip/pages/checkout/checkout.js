let {default:checkout_one}=await import(window.importLocalJs('widgets/checkout/checkout-one.js'));
let {default:CreditCardFormatDirective}=await import(window.importAssetJs('js/directives/card-validator/credit-card-format.directive.js'));
let {default:ExpiryFormatDirective}=await import(window.importAssetJs('js/directives/card-validator/expiry-format.directive.js'));
let {default:CvcFormatDirective}=await import(window.importAssetJs('js/directives/card-validator/cvc-format.directive.js'));
let { default: TooltipDirective } = await import(window.importAssetJs('js/directives/tooltip.directive.js'));
let { default: vuexStore } = await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components={
    checkout_one: checkout_one
};
const app = Vue.createApp({
    components: components
});

app.directive('tooltip', TooltipDirective);
app.directive('ccnumber', CreditCardFormatDirective);
app.directive('ccexpiry', ExpiryFormatDirective);
app.directive('cccvc', CvcFormatDirective);
app.use(vuexStore);
app.mount("#app");

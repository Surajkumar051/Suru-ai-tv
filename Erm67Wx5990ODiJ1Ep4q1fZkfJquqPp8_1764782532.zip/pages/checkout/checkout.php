<div id="app">
    <checkout_one
        id="checkout_checkout-one_1"
       	label1="Back"
        label2="Saved Cards"
        label3="Primary"
        label4="Add New"
        label5="PAY NOW"
        label6="By clicking Pay Now you authorize us to charge"
        label66="from your card"
        label67="every"
        label68="per"
        label7="until you cancel."
        label8="I am 18 and I agree to the above conditions"
        label88="and The"
        label9="Terms of Use"
        label10="and"
        label11="Privacy Policy"
        label12="By clicking on Pay Now, you will be charged a one-time refundable amount of"
        label13="to verify your card and authorize us to charge"
        label14="until you cancel your plan post free trial."
    />
</div>
<script src="<?php echo $rootUrl; ?>pages/checkout/checkout.js?v=<?php echo $cacheVersion; ?>" type="module"></script>

<div id="app">
    <section class="dashboard-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                    <!--Left Navigation Start Here-->
                    <div class="dashboard-leftnav pos-sticky">
                        <ul class="dashboard-menu">
                            <li><a class="callByAjax i18n" :class="{active: current_tab === 'profile_one'}" @click="setTab('profile_one')">Profile</a></li>
                            <li  v-if="ugcEnabled"><a class="callByAjax i18n" :class="{active: current_tab == 'my_uploads_one'}" @click="setTab('my_uploads_one')">My Uploads</a></li>
                            <li><a class="callByAjax i18n" :class="{active: current_tab === 'my_library_one'}" @click="setTab('my_library_one')">My Library</a></li>
                            <li v-if='isUserPlaylistEnabled'><a class="callByAjax i18n" href="javascript:void(0)" :class="{active: current_tab === 'playlist_enduser_list_one'}" @click="setTab('playlist_enduser_list_one')">My Playlists</a></li>
                            <li v-if="favouriteEnabled"><a class="callByAjax i18n" :class="{active: current_tab == 'my_favorites_one'}" @click="setTab('my_favorites_one')">My Favorites</a></li>
                            <!-- <li v-if="(is_test_gateway || is_non_hosted_gateway) && (is_subscription_enabled || is_ppv_enabled)">
                                <a class="callByAjax" :class="{active: current_tab === 'card_one'}" @click="setTab('card_one')">Card Information</a>
                            </li> -->
                            <li v-if="(is_subscription_enabled || is_ppv_enabled)">
                                <a class="callByAjax i18n" :class="{active: current_tab === 'billing_and_purchases_one'}" @click="setTab('billing_and_purchases_one')">Billing and Purchases</a>
                            </li>
                            <!-- <li v-if="is_subscription_enabled || is_ppv_enabled"><a class="callByAjax" :class="{active: current_tab === 'purchase_history_one'}" @click="setTab('purchase_history_one')">Purchase History</a></li> -->
                            <li v-if='isWatchHistory'><a class="callByAjax i18n" :class="{active: current_tab === 'watch_history_one'}" @click="setTab('watch_history_one')">Watch History</a></li>
                        </ul>
                    </div>
                </div>
                <!--Left Navigation End Here-->
                <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                    <!-- ER:74207 To catch the components to show the sticky Audio. -->
                    <?php if (isset($isAudioExists) && $isAudioExists == true) { ?>
                    <Keep-Alive>
                        <component :is="current_tab" v-bind="{ root_url: <?php echo "'" . $rootUrl . "'"; ?>, ...current_tab_props }"></component>
                    </Keep-Alive>
                    <?php } else { ?>
                        <component :is="current_tab" v-bind="{ root_url: <?php echo "'" . $rootUrl . "'"; ?>, ...current_tab_props }"></component>
                    <?php } ?>
                </div>
            </div>
        </div>
    </section>
</div>
<!--Dashboard section End Here-->

<!--Footer top Section Start Here-->




<!--Footer top Section End Here-->



<!-- jQuery and Bootstrap JS -->


<script>
    $(document).ready(function() {
        // $(".hide button").hide();
        // $(".plans").click(function() {
        //     $(".hide button").toggle();
        //     $(".hide").toggle();
        //     //$(".choose-plan-button").hide();
        // });
    });

    $("#addtoclose").click(function() {
        $(".addnew-card-popup").modal('hide')
        $(".blank-card-info").hide();
        $(".card-information").show();
    });
</script>
<script src="<?php echo $rootUrl; ?>pages/profile/profile.js?v=<?php echo $cacheVersion; ?>" type="module"></script>
<script src="<?php echo $asseturl; ?>js/loader-helper.js"></script>
<script src="<?php echo $asseturl; ?>js/loader.js" type="module"></script>
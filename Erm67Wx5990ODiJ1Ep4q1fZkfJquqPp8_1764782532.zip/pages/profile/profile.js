let {GET_MONETIZATION_SETTINGS,
    GET_END_USER_REGD_LOGIN_SETTING,
    GET_GATEWAY_STATUS}=await import(window.importAssetJs('js/configurations/actions.js'));
let {getConfig, getFavouriteSettingStatus,getUgcSettingStatus}=await import(window.importAssetJs('js/webservices.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
let {default:CreditCardFormatDirective}=await import(window.importAssetJs('js/directives/card-validator/credit-card-format.directive.js'));
let {default:ExpiryFormatDirective}=await import(window.importAssetJs('js/directives/card-validator/expiry-format.directive.js'));
let {default:CvcFormatDirective}=await import(window.importAssetJs('js/directives/card-validator/cvc-format.directive.js'));

const { defineAsyncComponent } = Vue;
const { mapGetters } = Vuex;

const app = Vue.createApp({
    components: {
        card_one: defineAsyncComponent(() =>import(window.importLocalJs('widgets/card/card-one.js'))),
        profile_one: defineAsyncComponent(() =>import(window.importLocalJs('widgets/profile/profile-one.js'))),
        my_library_one: defineAsyncComponent(() =>import(window.importLocalJs('widgets/my-library/my-library-one.js'))),
        my_favorites_one: defineAsyncComponent(() =>import(window.importLocalJs('widgets/my-favorites/my-favorites-one.js'))),
        billing_and_purchases_one: defineAsyncComponent(() => import(window.importLocalJs('widgets/billing-and-purchases/billing-and-purchases-one.js'))),
        watch_history_one: defineAsyncComponent(() => import(window.importLocalJs('widgets/watch-history/watch-history-one.js'))),
        purchase_history_one: defineAsyncComponent(() =>import(window.importLocalJs('widgets/purchase-history/purchase-history-one.js'))),
        my_uploads_one: defineAsyncComponent(() => import(window.importLocalJs('widgets/my-uploads/my-uploads-one.js'))),
        playlist_enduser_list_one: defineAsyncComponent(() => import(window.importLocalJs('widgets/playlist-enduser-list/playlist-enduser-list-one.js'))),
    },
    data() {
        return {
            subscriptionKey: null,
            current_tab: '',
            show_device: '',
            isWatchHistory: "",
            favouriteEnabled: false,
            ugcEnabled: false,
            profile_one_props: {
                label1: "Account Information",
                label2: "Update Profile",
                label3: "Change Password",
                label4: "Update Password",
                label5: "Plan Details",
                label6: "Choose a Plan",
                label7: "Upload Profile Image",
                label8: "Crop image here",
                label9: "We are sorry to see you go :(",
                label10: "Could you help us understand your reason ?",
                label11: "Cancel Subscription",
                label13: "All plan",
                label14: "Selected",
                label15: "/Billed",
                label16: "First",
                label17: "are free!",
                label18: "Watch on Apps",
                label19: "Access our entire library for unlimited binging on the culture",
                label20: "Member-only events & VIP passes",
                label21: "Access to all of our trailers",
                label22: "Weekly digest of the latest films, up- dates, news & more",
                label23: "No subscription plan is found",
                label24: "Upload",
                label25: "Cover & Profile Photo",
                label26:"Profile Photo",
                label27:"Cover Photo",
                label28:"About",
                label29:"Name" ,
                label30:"Email" ,
                label31:"Mobile" ,
                label32:"Current Password" ,
                label33:"New Password" ,
                label34:"Confirm Password" ,
                label35: "Upload Cover Image",
                label36: "Update",
                label37: "Permanent Delete Of Account",
                label38: "Please note account closure is a permanent action and once your account is closed it will no longer be available to you and cannot be restored. If you decide later that you want to start ordering from us again, or if you would like to use products and services that require an account, you will need to create a new account.",
                label39: "Delete Account",
                label40: "Delete Your Account?",
                label41: "Are you sure you want to delete your account? Deleting your account will remove all your access to the account.",
                label42: "Cancel",
                label43: "Confirm",
                label44: "Delete all the historical data permanently from the store"
            },
            my_library_one_props: {
                label1: "My Library",
                label2: "No data found",
                label3: "Free"
            },
            /*card_one_props: {
                name: "card/card-one",
                label1: "Card Information",
                label2: "No Card Found, Please add",
                label22: "a new card for payment",
                label3: "Primary",
                label4: "Make Default",
                label5: "Add New Card",
                label6: "Are you sure, you want to delete this card ?",
                label7: "Confirming this action will remove this card from your account. Do you want to proceed ?",
                label8: "Dismiss",
                label9: "Proceed",
                label10: "Add New Card",
                label11: "Your card will be saved for future purchases and automatic renewals."
            },*/
            /*purchase_history_one_props: {
                label1: "Purchase History",
                label2: "Receipt",
                label3: "No data found"
            },*/
            billing_and_purchases_one_props: {
                name: "card/card-one",
                label1: "Card Information",
                label2: "No Card Found, Please add",
                label22: "a new card for payment",
                label23: "* By clicking on Add Card, you will be charged a one time refundable amount of",
                label24: "to verify your card.",
                label3: "Primary",
                label4: "Make Default",
                label5: "Add New Card",
                label6: "Selected",
                label7: "No subscription plan is found",
                label8: "Dismiss",
                label9: "We are sorry to see you go :(",
                label10: "Could you help us understand your reason ?",
                label11: "Cancel Subscription",
                label12: "Plan Details",
                label13: "Purchase History",
                label14: "Receipt",
                label15: "No data found",
                label16: "Proceed",
                label17: "All plan",
                label18: "Your card will be saved for future purchases and automatic renewals."
            },
            watch_history_one_props: {
                label1: "Watch History",
                label2: "No data found",
                label3: "Free"
            },
            my_favorites_one_props: {
                label1: "My Favorites",
                label2: "Play",
                label3: "Watch Trailer",
                label4: "Play All",
                label5: "Play",
                label6: "Free",
                label7: "Download",
                label8: "Open",
                label9:"Pre-order"
             },
             my_uploads_one_props:{
                label1: "My Uploads",
                label2: "UGC",
                label3: "Minis",
                label4: "Pending Approval",
                label5: "Rejected",
                label6: "Published",
                label7: "No Contents present",
                label8: "Confirming this action will remove this content from your account. Do you want to proceed ?",
                label9: "Play",
                label10: "Watch Trailer",
                label11: "Play All",
                label12: "Are you sure, you want to delete this content ?",
                label13: "Dismiss",
                label14: "Proceed",
                label15: "Upload" ,
                label16: "Title" ,
                label17: "Category" ,
                label18: "Sub Category" ,
                label19: "Description" ,
                label20: "Upload Video" ,
                label21: "Change Video", 
                label22: "Filename" ,
                label23: "Close" ,
                label24: "Upload",
                label25: "Free"
            },
            playlist_enduser_list_one_props: {
                id: "profile_playlist_enduser_list_one_1",
                label1: "Play",
                label2: "Watch Trailer",
                label3: "Play All",
                label4: "Play",
                label5: "Free"
            },
            isUserPlaylistEnabled: null
        }
    },
    computed: {
        ...mapGetters({
            is_subscription_enabled: 'is_subscription_enabled',
            is_ppv_enabled: 'is_ppv_enabled',
            is_third_party_gateway: 'is_third_party_gateway',
        }),
        current_tab_props() {
            return this[`${this.current_tab.toLowerCase()}_props`];
        }
    },
    methods: {
        setTab(tab) {
            this.current_tab = tab;
            localStorage.setItem('profile.currenttab', tab);
        },

        getFavouriteSettingStatus() {
            getFavouriteSettingStatus().then((resp) => {
                console.log(resp.data.data.contentSettings);
                if (resp.data.code === 200 && resp.data.data.contentSettings.content_favourite_settings) {
                    this.favouriteEnabled = resp.data.data.contentSettings.content_favourite_settings.is_enabled;
                }
            });
        },
       fetchUGCSettingStatus() {
            getUgcSettingStatus().then((res) => {
                if(res.data.status == 'SUCCESS' && res.data.code==200){
                    res.data.data.sections[0].groups[0].nodes.forEach(element => {
                      if(element.node_code == 'ugc'){
                        this.ugcEnabled = (element.node_value && element.node_value ==1)?true:false;
                      }
                    });
                    this.isUserPlaylistEnabled = this.getNodeValueByCode(res.data.data, 'is_enduser_playlist_enabled');
                    console.log('isUserPlaylistEnabled', this.isUserPlaylistEnabled);
                }
            });
        },
        getNodeValueByCode(config_data, code) {
            const node = config_data?.sections
                .flatMap(section => section.groups.flatMap(group => group.nodes))
                .find(node => node.node_code === code);
            return node && parseInt(node.node_value) ? (node.node_value) : null;
        }
    },
    beforemount() {

    },
    async mounted() {
        setTimeout(() => {
            //ER:74207 Hide the loader 
            JsLoadingOverlay.hide();
        }, 2000);
        this.getFavouriteSettingStatus();
        this.fetchUGCSettingStatus();
        this.$store.dispatch(GET_MONETIZATION_SETTINGS);
        this.$store.dispatch(GET_END_USER_REGD_LOGIN_SETTING);
        this.$store.dispatch(GET_GATEWAY_STATUS);

        //CALL PLAYER SETTING
        let response = await getConfig();
        if (response.data.code == 200) {
            //CHECK PLAYER SETTING
            let getConfigResponse = response.data.data.sections[0]['groups'];
            //GET USER EXPERIENCE TAB
            let isExperienceGroups = getConfigResponse.filter((value) => { return value.code.match('experience'); });
            //CHECK WATCH HISTORY IS ENABLED
            let isWatchHistory = isExperienceGroups[0].nodes.filter((value) => { return value.node_code.match('player_watch_history'); });
            this.isWatchHistory = isWatchHistory[0]['node_value'] == 1 ? true : false;
            //SET PROFILE TAB
            // this.isWatchHistory == false ? this.setTab('profile_one') : '';
        }
        if (localStorage.getItem('profile.currenttab')) {
            if(localStorage.getItem('profile.currenttab') === 'my_favorites_one' && !this.favouriteEnabled) {
                this.setTab('profile_one');
            }else if(localStorage.getItem('profile.currenttab') === 'my_uploads_one' && !this.ugcEnabled) {
                this.setTab('profile_one');
            } else if(localStorage.getItem('profile.currenttab') === 'watch_history_one' && !this.isWatchHistory) {
                this.setTab('profile_one');
            } else if(localStorage.getItem('profile.currenttab') === 'playlist_enduser_list_one' && !this.isUserPlaylistEnabled) {
                this.setTab('profile_one');
            } else {
                this.setTab(localStorage.getItem('profile.currenttab'));
            }
        }
    }
});

app.directive('ccnumber', CreditCardFormatDirective);
app.directive('ccexpiry', ExpiryFormatDirective);
app.directive('cccvc', CvcFormatDirective);

app.use(vuexStore);
app.mount("#app");

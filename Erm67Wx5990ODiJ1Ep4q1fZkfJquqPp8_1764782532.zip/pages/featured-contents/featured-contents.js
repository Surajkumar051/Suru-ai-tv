let {default:featured_content_list_one}=await import(window.importLocalJs('widgets/featured-content-list/featured-content-list-one.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components={
        featured_content_list_one: featured_content_list_one,
        content_purchase_one:content_purchase_one
};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
    methods: {

    }


});
app.use(vuexStore);
app.mount("#app");

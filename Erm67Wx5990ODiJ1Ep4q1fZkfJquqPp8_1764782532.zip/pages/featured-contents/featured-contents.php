<div id="app">
    <div>
        <featured_content_list_one
        id="featured_contents_featured_content_list_one_1"
                label1="Play"
                label2="Watch Trailer"
                label3="Play All"
                label4="Play"
                label5="Free"
                label6="Download"
                label7="Open"
                 label8="Pre-order"
        />
    </div>
    <div>
        <content_purchase_one
            id="featured_content_purchase_one_1"
        />
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/featured-contents/featured-contents.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

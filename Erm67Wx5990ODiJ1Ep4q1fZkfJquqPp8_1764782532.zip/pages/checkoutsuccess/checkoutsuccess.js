let { captureOrderAtGateway, confirmCheckout } = await import(window.importAssetJs('js/webservices.js'));
let { i18n } = await import(window.importAssetJs('js/i18n.js'));

var components = {};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            is_free_plan: 0,
        };
    },
    mounted() {
        const url = new URLSearchParams(window.location.search);
        this.is_free_plan = parseInt(url.has('is_free_plan') ? url.get('is_free_plan') : '0');
        JsLoadingOverlay.hide();
        document.getElementsByClassName('toastCustom')[0].classList.remove('show');

        //103551-start
        const redirectAfterPurchase = localStorage.getItem("redirectAfterPurchase");
        if(redirectAfterPurchase){
            localStorage.removeItem("redirectAfterPurchase");
        }
        //103551-end

        if (url.get('gateway_type') === 'testgateway') {
            document.getElementsByClassName('toastCustom')[0].classList.add('show');

            setTimeout(() => {
                //103551-add condition to redirect to redirectUrl(start)
                if (redirectAfterPurchase) {
                    window.location.replace(redirectAfterPurchase);
                } else {
                    window.localStorage.setItem('profile.currenttab', 'billing_and_purchases_one');
                    window.location.replace('/profile');
                }
                //103551-add condition to redirect to redirectUrl(end)
            }, 10 * 1000);
        } else if (url.has('gateway_code') && url.get('gateway_code') === 'PAYTECH') { //111491
            setTimeout(() => {
                if (redirectAfterPurchase) {
                    window.location.replace(redirectAfterPurchase);
                } else {
                    window.localStorage.setItem('profile.currenttab', 'billing_and_purchases_one');
                    window.location.replace('/profile');
                }
            }, 10 * 1000);
        } else if (url.get('gateway_type') === 'hosted') {
            if (url.get('billing_type') === '4') {
                let capture_order_params = {
                    gateway_order_id: '',
                    gateway_payer_id: '',
                    gateway_code: '',
                    sst_token: ''
                };
                if(url.has('muvi_sst_token')) { //113029
                    capture_order_params.sst_token = url.get('muvi_sst_token');
                }
                if (url.has('gateway_code')) {
                    capture_order_params.gateway_code = url.get('gateway_code');
                }
                // For PayPal
                if (url.has('PayerID')) {
                    capture_order_params.gateway_order_id = url.get('token');
                    capture_order_params.gateway_payer_id = url.get('PayerID');
                }

                // For Razorpay
                if (url.has("razorpay_payment_id")) {
                    capture_order_params.gateway_order_id = url.get('razorpay_payment_id');
                    capture_order_params.gateway_payer_id = url.get('razorpay_payment_link_id');
                }

                // For Stripe
                if (url.has("session_id")) {
                    capture_order_params.gateway_order_id = url.get('session_id');
                }

                // For Paystack
                if (url.has('trxref')) {
                    capture_order_params.gateway_order_id = url.get('trxref');
                }

                console.log(JSON.stringify(capture_order_params));

                captureOrderAtGateway(capture_order_params).then(capture_order_response => {
                    console.log(capture_order_response);

                    let confirm_checkout_params = {
                        sst_token: url.get('muvi_sst_token'),
                        billing_type: url.get('billing_type'),
                        gateway_code:''
                    };
                    if (url.has('gateway_code')) {
                        confirm_checkout_params.gateway_code = url.get('gateway_code');
                    }
                    return confirmCheckout(confirm_checkout_params);
                }).then(confirm_checkout_response => {
                    console.log(confirm_checkout_response);
                    //103551-add condition to redirect to redirectUrl(start)
                    if (redirectAfterPurchase) {
                        window.location.replace(redirectAfterPurchase);
                    } else {
                        window.localStorage.setItem('profile.currenttab', 'billing_and_purchases_one');
                        window.location.replace('/profile');
                    }
                    //103551-add condition to redirect to redirectUrl(end)
                }).catch(ex => {
                    console.log(ex);
                });
            }

            if (url.get('billing_type') === '2') {
                let confirm_checkout_params = {
                    sst_token: url.get('muvi_sst_token'),
                    billing_type: url.get('billing_type'),
                    gateway_code:''
                };
                if (url.has('gateway_code')) {
                    confirm_checkout_params.gateway_code = url.get('gateway_code');
                }
                confirmCheckout(confirm_checkout_params).then(confirm_checkout_response => {
                    console.log(confirm_checkout_response);
                   //103551-add condition to redirect to redirectUrl(start)
                    if (redirectAfterPurchase) {
                        window.location.replace(redirectAfterPurchase);
                    } else {
                        window.localStorage.setItem('profile.currenttab', 'billing_and_purchases_one');
                        window.location.replace('/profile');
                    }
                    //103551-add condition to redirect to redirectUrl(end)
                }, ex => {
                    console.log(ex);
                });
            }
        } else {
            setTimeout(() => {
                //103551-add condition to redirect to redirectUrl(start)
                if (redirectAfterPurchase) {
                    window.location.replace(redirectAfterPurchase);
                } else {
                    window.localStorage.setItem('profile.currenttab', 'billing_and_purchases_one');
                    window.location.replace('/profile');
                }
                //103551-add condition to redirect to redirectUrl(end)
            }, 10 * 1000);
        }
    },
    methods: {
        i18n
    }
});
app.mount("#app");

<!--Checkout page 1 start Here-->
<div id="app">
    <div class="checkout-section sucess-checkout">
        <!--Image Section start here-->
        <div class="illustation">
            <img vd-node="image" src="<?php echo $asset_cdn_url; ?>success.png" alt="Your payment is successful" class="mw-100">
        </div>
        <!--Image Section End here-->
        <!--Massage Section start Here-->
        <div class="massage">
            <h1>{{i18n('Thank You')}}</h1>
            <p class="mb-2" v-if="is_free_plan === 1 ">{{i18n('Your Plan has been activated successfully')}}</p>
            <p class="mb-2" v-else>{{i18n('Your payment is successful')}}</p>
        </div>
        <!--Massage Section End Here-->
        <p class="notes">{{i18n('You will be redirected to the site within 10 seconds')}}</p>
        <!-- Toast start here -->
        <div class="toastCustom fade" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toastCustom-header">
                <strong class="mr-auto">{{i18n('This is not an actual transaction.')}}</strong>
                <button type="button" class="ml-2 mb-1 closeToast" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
        <!-- Toast ends here -->
    </div>
</div>
<script src="<?php echo $rootUrl; ?>pages/checkoutsuccess/checkoutsuccess.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

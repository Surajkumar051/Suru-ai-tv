let { i18n } = await import(window.importAssetJs('js/i18n.js'));

var components = {};
const app = Vue.createApp({
    components: components,
    data() {
        return {
            subscription_link: ''
        }
    },
    mounted() {
        document.body.style.margin = '0';

        document.getElementById('razorpayframe').style.display = 'block';
        document.getElementById('razorpayframe').style.border = 'none';
        document.getElementById('razorpayframe').style.height = '100vh';
        document.getElementById('razorpayframe').style.width = '100vw';

        document.getElementsByTagName('section')[0].classList.remove('container-fluid');

        let url = new URL(window.location.href);
        const params = new URLSearchParams(url.search);
        this.subscription_link = params.get('gateway_subscription_link');

        document.getElementsByClassName('toastCustom')[0].classList.add('show');
    },
    methods: {
        i18n
    }
});
app.mount("#app");

let {default:player_lite_one}=await import(window.importLocalJs('widgets/player-lite/player-lite-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
let {default:content_purchase_one}=await import(window.importLocalJs('widgets/content-purchase/content-purchase-one.js'));
let {SET_CURRENT_CONTENT_SELECTION_DATA, TOGGLE_CONTENT_PURCHASE_MODAL,GET_END_USER_REGD_LOGIN_SETTING}=await import(window.importAssetJs('js/configurations/actions.js'));

var components = {
        player_lite_one: player_lite_one,
        content_purchase_one: content_purchase_one,
    }
const app = Vue.createApp({
    data() {
        return {
            isPpvmodel: localStorage.getItem("hidemodel"),
            selectedContentUuid: '',
            monetizationMethods: []
        }
    },
    components: components
});

app.use(vuexStore);
app.mount("#app");

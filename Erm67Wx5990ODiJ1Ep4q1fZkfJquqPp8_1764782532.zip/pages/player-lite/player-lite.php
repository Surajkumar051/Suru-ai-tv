<div id="app">
    <div>
        <player_lite_one
            label1="Share"
            label2="Share this video"
            label3="Link"
            label4="Social"
            label5="Crew"
            id="player_lite_player_lite_one_1" />
    </div>
    <div>
        <content_purchase_one 
        id="content_content_purchase_one_1" 
        />
    </div>

</div>
<script src="<?php echo $rootUrl; ?>pages/player-lite/player-lite.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

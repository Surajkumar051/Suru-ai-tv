let {default:cast_banner_one}=await import(window.importLocalJs('widgets/cast-banner/cast-banner-one.js'));
let {default:cast_filmography_one}=await import(window.importLocalJs('widgets/cast-filmography/cast-filmography-one.js'));
let {getCastDetails}=await import(window.importAssetJs('js/webservices.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));
var components = {
    cast_banner_one: cast_banner_one,
    cast_filmography_one: cast_filmography_one,
};
const app = Vue.createApp({
    name: "cast_details",
    components: components,
    data() {
        return {
            castUuid: window.location.pathname.toString().split("/")[2],
            cast: Object,
        };
    },
    mounted() {
        JsLoadingOverlay.hide();
        this.fetchCastDetails();
    },
    methods: {
        fetchCastDetails() {
            getCastDetails(this.castUuid).then((res) => {
                if (res.data.code == 200 && res.data.data !== null) {
                    this.cast = res.data.data.castList.cast_list[0];
                } else {
                    window.location.href = "/404";
                }
                JsLoadingOverlay.hide();
            });
        },
    },
});
app.use(vuexStore);
app.mount("#app");

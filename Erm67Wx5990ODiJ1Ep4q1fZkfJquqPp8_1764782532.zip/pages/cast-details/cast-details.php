<div id="app">
    <div>
        <cast_banner_one 
        id="cast_details_cast_banner_one_1"
        :cast="cast"
        label1="Read More" />
    </div> 
    <div>
        <cast_filmography_one 
            id="cast_details_cast_filmography_one_1"
            :cast="cast" 
            label1="Play"
            label2="Watch Trailer"
            label3="Play All"
            label4="Videos"
            label5="Audios"
            label6="Free"
            label7="Document"
            label8="Download"
            label9="Open"
             label10="Pre-order"
 />
    </div>
 </div>
 <script src="<?php echo $rootUrl; ?>/pages/cast-details/cast-details.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

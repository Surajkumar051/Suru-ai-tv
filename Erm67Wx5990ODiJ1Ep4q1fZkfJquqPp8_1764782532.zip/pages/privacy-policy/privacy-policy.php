<div id="app">
  <section class="privacy-policy">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      <div class="privacy-data">
        <h1 class="i18n">Privacy Policy</h1>
        <p class="i18n">This privacy policy ("policy") will help you understand how [name] ("us", "we", "our") uses and protects the
          data you provide to us when you visit and use [website] ("website", "service").</p>

        <p class="i18n">We reserve the right to change this policy at any given time, of which you will be promptly updated. If you want
          to make sure that you are up to date with the latest changes, we advise you to frequently visit this page.</p>

        <h2 class="i18n">What User Data We Collect</h2>

        <ul>
          <li vd-node="text" class="no-round i18n">When you visit the website, we may collect the following data:</li>
          <li vd-node="text" class="i18n"> Your IP address.</li>
          <li vd-node="text" class="i18n">Your contact information and email address.</li>
          <li vd-node="text" class="i18n">Other information such as interests and preferences.</li>
          <li vd-node="text" class="i18n">Data profile regarding your online behavior on our website.</li>
        </ul>

        <h2 class="i18n">Why We Collect Your Data</h2>

        <ul>
          <li vd-node="text" class="no-round i18n"> We are collecting your data for several reasons:</li>
          <li vd-node="text" class="i18n">To better understand your needs.</li>
          <li vd-node="text" class="i18n">To improve our services and products.</li>
          <li vd-node="text" class="i18n">To send you promotional emails containing the information we think you will find interesting.</li>
          <li vd-node="text" class="i18n">To contact you to fill out surveys and participate in other types of market research.</li>
          <li vd-node="text" class="i18n">To customize our website according to your online behavior and personal preferences.</li>
        </ul>

        <h2 class="i18n">Safeguarding and Securing the Data</h2>
        <p class="i18n">[name] is committed to securing your data and keeping it confidential. [name] has done all in its power to
          prevent data theft, unauthorized access, and disclosure by implementing the latest technologies and software,
          which help us safeguard all the information we collect online.</p>

        <h2 class="i18n">Our Cookie Policy</h2>
        <p class="i18n">Once you agree to allow our website to use cookies, you also agree to use the data it collects regarding your
          online behavior (analyze web traffic, web pages you spend the most time on, and websites you visit).
          The data we collect by using cookies is used to customize our website to your needs. After we use the data for
          statistical analysis, the data is completely removed from our systems.</p>

        <p class="i18n">Please note that cookies don't allow us to gain control of your computer in any way. They are strictly used to
          monitor which pages you find useful and which you do not so that we can provide a better experience for you.
          If you want to disable cookies, you can do it by accessing the settings of your internet browser. (Provide links
          for cookie settings for major internet browsers).</p>

        <h2 class="i18n">Links to Other Websites</h2>

        <p class="i18n">Our website contains links that lead to other websites. If you click on these links [name] is not held
          responsible for your data and privacy protection. Visiting those websites is not governed by this privacy policy
          agreement. Make sure to read the privacy policy documentation of the website you go to from our website.</p>

        <h2 class="i18n">Restricting the Collection of your Personal Data</h2>

        <p class="i18n">At some point, you might wish to restrict the use and collection of your personal data. You can achieve this by
          doing the following:
          When you are filling the forms on the website, make sure to check if there is a box which you can leave
          unchecked, if you don't want to disclose your personal information.</p>

        <p class="i18n">If you have already agreed to share your information with us, feel free to contact us via email and we will be
          more than happy to change this for you.[name] will not lease, sell or distribute your personal information to
          any third parties, unless we have your permission. We might do so if the law forces us. Your personal
          information will be used when we need to send you promotional materials if you agree to this privacy policy.</p>


      </div>
    </div>
  </section>
</div>
<script src="<?php echo $rootUrl; ?>pages/privacy-policy/privacy-policy.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
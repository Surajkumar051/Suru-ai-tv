let {default:banner_one}=await import(window.importLocalJs('widgets/banner/banner-one.js'));
let {default:epg_display_one}=await import(window.importLocalJs('widgets/epg-display/epg-display-one.js'));

var components = {
    banner_one: banner_one,
    epg_display_one:epg_display_one
};
const app = Vue.createApp({
    components: components,
    data() {
        return {
           
        }
    },
    methods: {
        
    }
});
app.mount("#app");

<style>
   
  .epg-sec ul li a:hover{
    color: #fff !important;
    border-radius: 48px;
    border: 1px solid rgba(255, 104, 0, 0.40);
    background: rgba(255, 104, 0, 0.16);
    opacity: 1;
    box-shadow: -1px 0px 0px 0px rgba(0, 0, 0, 0.06) inset;
}
 .hightlitday{
    opacity: 1;
    border-radius: 48px;
    background: #9A6617  !important;
    border: none;
    text-align: center;
    min-width: 200px;
    text-transform: uppercase;
    box-shadow: -1px 0px 0px 0px rgba(0, 0, 0, 0.06) inset;
} 
.epg-sec table.parent-table tbody td .inner-text {
    padding-left: 0px;
}
.epg-sec table.parent-table tbody td>div:first-child {
    margin-left: 24px;
    border-right: 1px solid rgba(255, 255, 255, 0.32);
}  
.epg-sec table.parent-table>tbody>tr>td:first-child .channel {
    text-align: center;
}
.epg-sec table.parent-table thead th {
    border-right: 1px solid rgba(255, 255, 255, 0.32);
    padding-left: 8px !important;
}
.epg-sec table.parent-table tbody td:not(:first-child){
    gap: 0px;
}
.epg-sec table.parent-table thead th:nth-child(2) {
    padding-left: 16px !important;
} 
.epg-sec table.parent-table tbody td:not(:first-child)>div {
    border-right: 1px solid rgba(255, 255, 255, 0.32);
}
.epg-sec table.parent-table>tbody>tr>td:first-child {
    z-index: 100000 !important;
    background: #000;
}
.epg{
    overflow: auto;
    max-height: 530px;
}
 .epg::-webkit-scrollbar {
  width: 1em;
}
 
 .epg::-webkit-scrollbar-track {
  box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
}
 
 .epg::-webkit-scrollbar-thumb {
  background-color: darkgrey;
}
</style>
<div id="app">
<epg_display_one id="epg_display_one" />
</div>
<script src="<?php echo $rootUrl; ?>pages/epg-display/epg-display.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>

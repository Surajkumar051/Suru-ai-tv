let {default:passwordsuccess_one}=await import(window.importLocalJs('widgets/password-success/password-success-one.js'));
let {default:vuexStore}=await import(window.importAssetJs('js/configurations/vuex-store.js'));

var components = { passwordsuccess_one: passwordsuccess_one };
const app = Vue.createApp({
    components: components,
});
app.use(vuexStore);
app.mount("#app");

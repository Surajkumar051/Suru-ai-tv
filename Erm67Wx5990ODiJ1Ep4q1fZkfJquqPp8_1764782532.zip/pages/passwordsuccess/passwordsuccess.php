  <div id="app">
      <passwordsuccess_one id="passwordsuccess_one_password_success_one_1" label1="Login" label2="Check your inbox"
          label3="We have sent a password recovery instruction to your mail." />
  </div>
  <script src="<?php echo $rootUrl; ?>pages/passwordsuccess/passwordsuccess.js?v=<?php echo $cacheVersion; ?>" type="module"></script>
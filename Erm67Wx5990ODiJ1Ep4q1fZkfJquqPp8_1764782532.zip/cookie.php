<div id="cookieDiv">
    <cookie_one class="footer" id="mycookie_cookie_one_1" label1="Allow Cookie" label2="Dismiss"
        label3="Agree &amp; Proceed" label4="Customize" label5="Accept All" label6="Customize Consent Preferences"
        label7="Save" />
</div>  
<script id="cookieId" src="<?php echo $rootUrl; ?>cookie.js?v=<?php echo $cacheVersion; ?>" type="module" ></script>
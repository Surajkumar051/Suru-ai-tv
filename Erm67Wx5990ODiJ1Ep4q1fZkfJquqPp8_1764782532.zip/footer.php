<footer id="footer">
    <?php if ($is_footer) { ?>
        <div>
            <footer_one class="footer" id="footer_footer_one_1" 
            label1="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words" 
            label2="Category" 
            label3='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Action</a>' 
            label4='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Comedy</a>' 
            label5='<a vd-node="link" href="https://<?php echo explode("/",$rootUrl)[2]; ?>/privacy-policy" class="callByAjax">Privacy Policy</a>' 
            label6='<a vd-node="link" href="https://<?php echo explode("/",$rootUrl)[2]; ?>/terms-condition" class="callByAjax">Terms and Conditions</a>' 
            label7="Trending" 
            label8='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Series One</a>' 
            label9='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Movie One</a>' 
            label10='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Single One</a>' 
            label11='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Album One</a>' 
            label12="Popular" 
            label13='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Series One</a>' 
            label14='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Movie One</a>' 
            label15='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Single One</a>' 
            label16='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Album One</a>' 
            label17='Muvi Exclusive' 
            label18='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Series One</a>' 
            label19='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Movie One</a>' 
            label20='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Single One</a>' 
            label21='<a vd-node="link" href="https://www.muvi.com/" class="callByAjax">Album One</a>' 
            label22='<a vd-name="facebook" href="https://www.facebook.com/muvidotcom" rel="noopener noreferrer external" class=""><i class="fab fa-facebook-f"></i></a>' 
            label23='<a vd-name="twitter" href="https://twitter.com/muvi" rel="noopener noreferrer external" class=""><i class="fa-brands fa-x-twitter"></i></a>' 
            label24='<a vd-name="instagram" href="https://www.instagram.com/muvi_com/" rel="noopener noreferrer external" class=""><i class="fab fa-instagram"></i></a>' 
            label25='<a vd-name="youtube" href="https://www.youtube.com/c/MuviLLC" rel="noopener noreferrer external" class=""><i class="fab fa-youtube"></i></a>' 
            label26='&copy;<?php echo date('Y');?> Muvi LLC, All Rights Reserved.' />
        </div>
    <?php } ?>
</footer>

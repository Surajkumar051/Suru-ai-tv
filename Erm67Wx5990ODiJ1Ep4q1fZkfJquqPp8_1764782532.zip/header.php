<header id="navbar">
    <div>
    <?php  if($is_navbar){ ?>
        <navbar_one
            class="header"
            id="header_navbar_one_1"
            root_url="<?php echo $rootUrl; ?>"
            label1="Toggle Dropdown"
            label2="About Us" 
            label3="Contact" 
            label4="No Record Found" 
            label5="Sign Up" 
            label6="Login" 
            label7="My Profile"
            label8="Sign Out" 
            label9="Search" 
            label10="Search"
            label11="Content" 
            label12="Playlists" 
            label13="Content Partners" 
            label14="Creators" 
            label15="Notifications"
            label16="Show all notifications"
            label17="No Notification to show yet" 
        />
    <?php } ?>
    </div>
</header>